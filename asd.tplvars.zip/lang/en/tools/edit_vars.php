<?php
$MESS ['ASD_TPLVARS_TITLE'] = 'Переменные сайта';
$MESS ['ASD_TPLVARS_DESC'] = 'Название';
$MESS ['ASD_TPLVARS_VAR'] = 'Символьный код';
$MESS ['ASD_TPLVARS_VAL'] = 'Значение';
$MESS ['ASD_TPLVARS_DEL'] = 'Удалить';
$MESS ['ASD_TPLVARS_DENIED'] = 'Доступ запрещен';
$MESS ['ASD_TPLVARS_NOT_INCL'] = 'Модуль настроек не установлен';
$MESS ['ASD_TPLVARS_SESSID'] = 'Ваша сессия истекла, пересохраните';