<?php
$MESS ['ASD_TPLVARS_MODULE_NAME'] = 'Переменные сайта';
$MESS ['ASD_TPLVARS_MODULE_DESCRIPTION'] = 'Простой инструмент для хранения и получения переменных сайта.';
$MESS ['ASD_TPLVARS_PARTNER_NAME'] = 'Долганин Антон';
$MESS ['ASD_TPLVARS_NEED_RIGHT_VER'] = 'Для установки данного решения необходима версия главного модуля #NEED# или выше.';
$MESS ['ASD_TPLVARS_NEED_MODULES'] = 'Для установки данного решения необходимо наличие модуля #MODULE#.';