<?php
$MESS ['ASD_TPLVARS_PANEL_TITLE'] = 'Переменные сайта';