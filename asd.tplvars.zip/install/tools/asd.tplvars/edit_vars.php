<?php
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/asd.tplvars/tools/edit_vars.php');