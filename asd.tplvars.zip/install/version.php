<?
$arModuleVersion = array(
	"VERSION" => "1.6.2",
	"VERSION_DATE" => "2019-09-20 11:20:53"
);
?>