<?
$arModuleVersion = array(
	"VERSION" => "1.0.6",
	"VERSION_DATE" => "2024-09-12 13:00:00"
);
?>