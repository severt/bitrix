<?
$MESS["TEMPLATE_DESCRIPTION"] = "Пустой шаблон";
?>