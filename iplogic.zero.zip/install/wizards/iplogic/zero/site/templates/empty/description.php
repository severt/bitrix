<?
use Bitrix\Main\Localization\Loc;

$arTemplate = array (
	'NAME' => 'Empty',
	'DESCRIPTION' => Loc::getMessage("TEMPLATE_DESCRIPTION"),
	'SORT' => 200,
);
?>