<?
$MESS["TEMPLATE_DESCRIPTION"] = "Empty template";
?>