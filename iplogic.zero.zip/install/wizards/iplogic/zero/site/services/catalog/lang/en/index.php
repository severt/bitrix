<?
$MESS["STORE_DESCR_1"] = "Base store";
$MESS["STORE_ADR_1"] = "Store address";
$MESS["CAT_STORE_NAME"] = "Base";
$MESS["BASE_PRICE_NAME"] = "Retail";
$MESS["WIZ_VAT_0"] = "No VAT";
$MESS["WIZ_VAT_10"] = "10% VAT";
$MESS["WIZ_VAT_20"] = "20% VAT";
?>