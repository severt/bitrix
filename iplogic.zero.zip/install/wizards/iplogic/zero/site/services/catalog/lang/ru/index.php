<?
$MESS["STORE_DESCR_1"] = "Основной склад";
$MESS["STORE_ADR_1"] = "Адрес склада";
$MESS["CAT_STORE_NAME"] = "Основной";
$MESS["BASE_PRICE_NAME"] = "Розничная";
$MESS["WIZ_VAT_0"] = "Без НДС";
$MESS["WIZ_VAT_10"] = "НДС 10%";
$MESS["WIZ_VAT_20"] = "НДС 20%";
?>