<?
$MESS["SALE_WIZARD_GROUP"] = "Группа местоположений";
$MESS["SALE_WIZARD_COUR"] = "Доставка курьером";
$MESS["SALE_WIZARD_COUR_DESCR"] = "Доставка осуществляется в течение дня в удобное для вас время.";
$MESS["SALE_WIZARD_PICK"] = "Самовывоз";
$MESS["SALE_WIZARD_PICK_DESCR"] = "Вы можете самостоятельно забрать заказ из нашего магазина.";
$MESS["SALE_WIZARD_MAIL2"] = "Почта России";
$MESS["SALE_WIZARD_MAIL_DESC2"] = "Доставка почтой  (расчёт на основании табличных данных)";
$MESS["SALE_WIZARD_KAZ_POST"] = "Казпочта";
$MESS["SALE_WIZARD_UPS"] = "Mеждународная доставка";
$MESS["SALE_WIZARD_SPSR"] = "СПСР-Экспресс";
$MESS["SALE_WIZARD_SPSR_DESCR"] = "Срочная доставка почты";
?>