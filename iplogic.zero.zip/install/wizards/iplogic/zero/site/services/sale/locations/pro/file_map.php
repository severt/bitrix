<?
$LOCATION_FILE_MAP = array(
	'loc_ussr.csv' => 		'russia.csv',
	'loc_ua.csv' => 		'ukrain.csv',
	'loc_kz.csv' => 		'kazakhstan.csv',
	'loc_cntr.csv' => 		'world.csv',
	'loc_usa.csv' => 		'usa.csv',
	'loc_belarus.csv' => 	'belarus.csv',
);