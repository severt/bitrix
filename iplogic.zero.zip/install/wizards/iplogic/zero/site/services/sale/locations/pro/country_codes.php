<?
$LOCALIZATION_COUNTRY_CODE_MAP = array(
	'ru' => '0000028023',
	'ua' => '0000000364',
	'kz' => '0000000276',
	'bl' => '0000000001'
);