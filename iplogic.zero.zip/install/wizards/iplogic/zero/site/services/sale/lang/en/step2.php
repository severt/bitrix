<?
$MESS["SALE_WIZARD_GROUP"] = "Location group";
$MESS["SALE_WIZARD_COUR"] = "Courier";
$MESS["SALE_WIZARD_COUR_DESCR"] = "Delivery will be made within one day at a time convenient for you.";
$MESS["SALE_WIZARD_PICK"] = "Pick-up by customer";
$MESS["SALE_WIZARD_PICK_DESCR"] = "You can pick your order yourself at our local store.";
$MESS["SALE_WIZARD_MAIL2"] = "Russian post";
$MESS["SALE_WIZARD_MAIL_DESC2"] = "Delivery by mail (calculation based on tabular data)";
$MESS["SALE_WIZARD_KAZ_POST"] = "Kazpost";
$MESS["SALE_WIZARD_UPS"] = "International delivery";
$MESS["SALE_WIZARD_SPSR"] = "SPSR-Express";
$MESS["SALE_WIZARD_SPSR_DESCR"] = "Express post delivery";
?>