<?
$MESS["MAIN_OPT_DESCRIPTION"] = "Описание страницы";
$MESS["MAIN_OPT_KEYWORDS"] = "Ключевые слова";
$MESS["MAIN_OPT_TITLE"] = "Заголовок окна браузера";
$MESS["MAIN_OPT_KEYWORDS_INNER"] = "Продвигаемые слова";
?>