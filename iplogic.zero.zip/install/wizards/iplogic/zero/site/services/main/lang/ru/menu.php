<?
$MESS["MENU_CATALOG"] = "Каталог товаров";
$MESS["MENU_PRIVATE"] = "Личный кабинет";
$MESS["MENU_TOP"] = "Верхнее меню";
$MESS["MENU_SIDE"] = "Боковое меню";
$MESS["MENU_BOTTOM"] = "Нижнее меню";
?>