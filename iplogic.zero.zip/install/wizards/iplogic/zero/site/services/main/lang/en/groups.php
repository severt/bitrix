<?php
$MESS["SALE_WIZARD_ADMIN_SALE"] = "Online store administrators";
$MESS["SALE_WIZARD_ADMIN_SALE_DESCR"] = "Full access to online store management (including orders) and trade catalog parameters (price types, markups, discounts, etc.).";
$MESS["REGISTERED_USERS"] = "Registered users";