<?
$MESS["MENU_CATALOG"] = "Product catalog";
$MESS["MENU_PRIVATE"] = "Personal Area";
$MESS["MENU_TOP"] = "Top menu";
$MESS["MENU_SIDE"] = "Side menu";
$MESS["MENU_BOTTOM"] = "Bottom menu";
?>