<?
$MESS["CATALOG_TYPE_NAME"] = "Каталог";
$MESS["CATALOG_ELEMENT_NAME"] = "Товары";
$MESS["CATALOG_SECTION_NAME"] = "Разделы";
$MESS["CONTENT_TYPE_NAME"] = "Контент";
$MESS["CONTENT_ELEMENT_NAME"] = "Материалы";
$MESS["CONTENT_SECTION_NAME"] = "Разделы";
$MESS["REFERENCE_TYPE_NAME"] = "Справочники";
$MESS["REFERENCE_ELEMENT_NAME"] = "Элементы";
$MESS["REFERENCE_SECTION_NAME"] = "Разделы";
?>