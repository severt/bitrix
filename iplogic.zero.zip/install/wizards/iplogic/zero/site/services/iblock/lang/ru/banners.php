<?
$MESS["EDIT1"] = "Элемент";
$MESS["DATE_CREATE"] = "Создан";
$MESS["TIMESTAMP_X"] = "Изменен";
$MESS["ACTIVE"] = "Активность";
$MESS["ACTIVE_FROM"] = "Начало активности";
$MESS["ACTIVE_TO"] = "Окончание активности";
$MESS["DETAIL_PICTURE"] = "Фон";
$MESS["NAME"] = "*Название";
$MESS["SORT"] = "Сортировка";
$MESS["PROPERTY_COLOR"] = "Цвет текста";
$MESS["PROPERTY_REF"] = "Ссылка";
$MESS["PROPERTY_BUTTON"] = "Текст кнопки";
$MESS["PROPERTY_WIDTH"] = "Ширина";
$MESS["DETAIL_TEXT"] = "Текст";
$MESS["XML_ID"] = "*Внешний код";