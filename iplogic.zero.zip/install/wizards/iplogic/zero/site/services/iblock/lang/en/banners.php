<?
$MESS["EDIT1"] = "Element";
$MESS["DATE_CREATE"] = "Created on";
$MESS["TIMESTAMP_X"] = "Modified on";
$MESS["ACTIVE"] = "Active";
$MESS["ACTIVE_FROM"] = "Activity Start";
$MESS["ACTIVE_TO"] = "Activity End";
$MESS["DETAIL_PICTURE"] = "Background";
$MESS["NAME"] = "*Name";
$MESS["SORT"] = "Sorting";
$MESS["PROPERTY_COLOR"] = "Text color";
$MESS["PROPERTY_REF"] = "Reference";
$MESS["PROPERTY_BUTTON"] = "Button text";
$MESS["PROPERTY_WIDTH"] = "Width";
$MESS["DETAIL_TEXT"] = "Text";
$MESS["XML_ID"] = "*Code in external DB source";