<?php

$eventManager = \Bitrix\Main\EventManager::getInstance();

/*$eventManager->addEventHandler("iblock", "OnAfterIBlockElementAdd", Array("IblockEventsHandler", "OnAfterIBlockElementAddHandler"));

class IblockEventsHandler
{
	public static function OnAfterIBlockElementAddHandler(&$arFields) {
		//AddMessage2Log($arFields);
	}
}*/