<?
$sSectionName="News";
?>