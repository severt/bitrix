<?
$aMenuLinks = [
	[
		"Home",
		"/", 
		[],
		[],
		"" 
	],
	[
		"News",
		"/news/",
		[],
		[],
		"" 
	]
];
?>