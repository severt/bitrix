<?
$sSectionName = 'Authorization';
$arDirProperties = array(
	'title' => 'Authorization',
	'description' => '',
	'keywords' => '',
	'robots' => 'noindex, nofollow'
);
?>