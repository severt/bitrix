<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("New site");
?>
<?
/*
 * Insert your content here
 * */
?>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>