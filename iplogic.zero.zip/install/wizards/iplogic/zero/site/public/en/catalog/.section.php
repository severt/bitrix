<?
$sSectionName="Catalog";
?>