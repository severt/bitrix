<?
$aMenuLinks = Array(
	Array(
		"Personal Area",
		"/personal/",
		Array(),
		Array(),
		""
	),
	Array(
		"User profile",
		"/personal/private/",
		Array(),
		Array(),
		""
	),
	Array(
		"Current orders",
		"/personal/orders/",
		Array(),
		Array(),
		""
	),
	Array(
		"Order history",
		"/personal/orders/?filter_history=Y",
		Array(),
		Array(),
		""
	),
	Array(
		"Basket",
		"/cart/",
		Array(),
		Array(),
		""
	),
	Array(
		"Subscriptions",
		"/personal/subscribe/",
		Array(),
		Array(),
		""
	)
);
?>