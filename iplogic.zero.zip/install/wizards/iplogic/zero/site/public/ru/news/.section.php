<?
$sSectionName="Новости";
?>