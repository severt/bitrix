<?
$sSectionName="Личный кабинет";
?>