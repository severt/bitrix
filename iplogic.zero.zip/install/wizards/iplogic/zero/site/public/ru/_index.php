<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Новый сайт");
?>
<?
/*
 * Insert your content here
 * */
?>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>