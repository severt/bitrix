<?
$sSectionName="Каталог";
?>