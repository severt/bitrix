<?
$sSectionName = 'Авторизация';
$arDirProperties = array(
	'title' => 'Авторизация',
	'description' => '',
	'keywords' => '',
	'robots' => 'noindex, nofollow'
);
?>