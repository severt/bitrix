<?
$aMenuLinks = Array(
	Array(
		"Личный кабинет", 
		"/personal/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Профиль пользователя", 
		"/personal/private/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Текущие заказы", 
		"/personal/orders/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"История заказов", 
		"/personal/orders/?filter_history=Y", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Корзина", 
		"/cart/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Подписки", 
		"/personal/subscribe/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>