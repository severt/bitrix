<?
$sSectionName="Корзина";
?>