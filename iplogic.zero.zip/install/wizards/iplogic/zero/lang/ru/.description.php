<?
$MESS["PORTAL_WIZARD_NAME"] = "Zero";
$MESS["PORTAL_WIZARD_DESC"] = "Мастер установки решения для разработчиков Zero";
?>