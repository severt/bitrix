<?
$MESS ['SERVICE_MAIN_SETTINGS'] = "Настройки сайта";
$MESS ['SERVICE_IBLOCK'] = "Информационные блоки";
$MESS ['SERVICE_FILES'] = "Файлы";
$MESS ['SERVICE_CATALOG'] = "Настройки каталога";
$MESS ['SERVICE_SALE'] = "Настройки интернет-магазина";
?>