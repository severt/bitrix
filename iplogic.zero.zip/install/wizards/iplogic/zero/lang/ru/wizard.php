<?
$MESS["SELECT_SITE_TITLE"] = "Выбор сайта";
$MESS["SELECT_SITE_SUBTITLE"] = "Выбор сайта для установки решения";
$MESS["SELECT_TEMPLATE_TITLE"] = "Выбор шаблона";
$MESS["wiz_company_name"] = "Название сайта:";
$MESS["wiz_email_from"] = "E-Mail адрес по умолчанию:";
$MESS["wiz_name"] = "Новый интернет-магазин";
$MESS["wiz_name_site"] = "Новый сайт";
$MESS["wiz_site_folder"] = "Папка сайта:";
$MESS["wiz_server_name"] = "URL сервера (без http://):";
$MESS["wiz_domains"] = "Доменное имя:<br>(список доменных имен, каждое в новой строке)";
$MESS["wiz_settings"] = "Настройки";
$MESS["wiz_site_settings"] = "Настройки сайта";
$MESS["wiz_agents_settings"] = "Дополнительные настройки";
$MESS["wiz_install"] = "Установить";
$MESS["NEXT_BUTTON"] = "Далее";
$MESS["PREVIOUS_BUTTON"] = "Назад";
$MESS["WIZ_STEP_SS"] = "Информация о магазине";
$MESS["WIZ_STEP_PL"] = "Платежи и доставка";

$MESS["WIZ_TEMPLATE_DIR_ERROR"] = "Не верно введено имя директории (допустимы только буквы, цифры и нижнее подчеркивание)";
$MESS["WIZ_TEMPLATE_DESCRIPTION_DEFAULT"] = "Новый сайт";
$MESS["WIZ_TEMPLATE_NAME_DEFAULT"] = "Мой новый сайт";
$MESS["WIZ_TEMPLATE_SETTINGS"] = "Настройки шаблона";
$MESS["WIZ_TEMPLATE_NAME"] = "Название";
$MESS["WIZ_TEMPLATE_DESCRIPTION"] = "Описание";
$MESS["WIZ_TEMPLATE_DIR"] = "Директория";

$MESS["WIZ_NO_MODULE_CATALOG"] = "Не установлен модуль торгового каталога. Для продолжения работы мастера <a href='/bitrix/admin/module_admin.php'>перейдите по ссылке</a> и установите модуль.";
$MESS["WIZ_SHOP_LOCALIZATION"] = "Выбор локализации магазина";
$MESS["WIZ_SHOP_LOCALIZATION_RUSSIA"] = "Россия";
$MESS["WIZ_SHOP_LOCALIZATION_UKRAINE"] = "Украина";
$MESS["WIZ_SHOP_LOCALIZATION_KAZAKHSTAN"] = "Казахстан";
$MESS["WIZ_SHOP_LOCALIZATION_BELORUSSIA"] = "Белоруссия";
$MESS["WIZ_SHOP_LOCALIZATION_ANOTHER"] = "Другие страны";
$MESS["WIZ_SHOP_EMAIL"] = "Email для получения информации о заказах";
$MESS["WIZ_SHOP_OF_NAME"] = "Название компании";
$MESS["WIZ_SHOP_OF_NAME_DEF"] = "ООО \"Интернет-магазин\"";
$MESS["WIZ_SHOP_OF_NAME_DESCR"] = "Название юридического лица или субъекта предпринимательской деятельности";
$MESS["WIZ_SHOP_LOCATION"] = "Местоположение компании (город)";
$MESS["WIZ_SHOP_LOCATION_DEF"] = "Москва";
$MESS["WIZ_SHOP_LOCATION_DESCR"] = "Место регистрации (город)";
$MESS["WIZ_SHOP_ADR"] = "Адрес компании";
$MESS["WIZ_SHOP_ADR_DEF"] = "ул. Москворецкая 25";
$MESS["WIZ_SHOP_ADR_DESCR"] = "Юридический адрес";
$MESS["WIZ_SHOP_ZIP"] = "Почтовый индекс";

$MESS["WIZ_SHOP_BANK_TITLE"] = "Банковские реквизиты";
$MESS["WIZ_SHOP_INN"] = "ИНН";
$MESS["WIZ_SHOP_KPP"] = "КПП";
$MESS["WIZ_SHOP_NS"] = "Расчетный счет";
$MESS["WIZ_SHOP_BANK"] = "Банк";
$MESS["WIZ_SHOP_BANK_DEF"] = "ОАО \"Сбербанк России\", г. Москва";
$MESS["WIZ_SHOP_BANKREKV"] = "Банковские реквизиты";
$MESS["WIZ_SHOP_BANKREKV_DEF"] = "БИК 044525225";
$MESS["WIZ_SHOP_KS"] = "Корреспондентский счет";

$MESS["WIZ_SHOP_LOGO"] = "Логотип компании (рекомендуемые размеры 80x80 px)";
$MESS["WIZ_SHOP_STAMP"] = "Печать (рекомендуемые размеры 150x150 px)";
$MESS["WIZ_SHOP_DIR_SIG"] = "Подпись генерального директора (рекомендуемые размеры 200x50 px)";
$MESS["WIZ_SHOP_ACC_SIG"] = "Подпись главного бухгалтера (рекомендуемые размеры 200x50 px)";

$MESS["WIZ_PERSON_TYPE_TITLE"] = "Типы плательщиков";
$MESS["WIZ_PERSON_TYPE"] = "Выберите типы плательщиков, которым вы будете продавать товары на сайте. Для разных типов плательщиков возможны различные способы оплаты и доставки, а также различный набор свойств заказа.";
$MESS["WIZ_PERSON_TYPE_FIZ"] = "Физическое лицо";
$MESS["WIZ_PERSON_TYPE_UR"] = "Юридическое лицо";

$MESS["WIZ_LOCATION_TITLE"] = "Местоположения";
$MESS["WSL_STEP2_GFILE_USSR"] = "Россия и СНГ (страны и города)";
$MESS["WSL_STEP2_GFILE_KZ"] = "Казахстан";
$MESS["WSL_STEP2_GFILE_USA"] = "США (города)";
$MESS["WSL_STEP2_GFILE_CNTR"] = "Мир (страны)";
$MESS["WSL_STEP2_GFILE_NONE"] = "не загружать";

$MESS["WIZ_PAYMENT_TITLE"] = "Добавить способы оплаты";
$MESS["WIZ_PAYSYSTEM_CASH"] = "Наличный расчет";
$MESS["WIZ_PAYSYSTEM_BILL"] = "Счет на оплату";
$MESS["WIZ_PAYSYSTEM_COLLECT"] = "Наложенный платеж";
$MESS["WIZ_PAYSYSTEM_SBER"] = "Сбербанк (квитанция)";

$MESS["WIZ_DELIVERY_TITLE"] = "Добавить способы доставки";
$MESS["WIZ_DELIVERY_PICKUP"] = "Самовывоз";
$MESS["WIZ_DELIVERY_COURIER"] = "Доставка курьером";
$MESS["WIZ_DELIVERY_RUS_POST"] = "Почта России";
$MESS["WIZ_DELIVERY_KAZ_POST"] = "Казпочта";
$MESS["WIZ_DELIVERY_UPS"] = "UPS";
$MESS["WIZ_DELIVERY_SPSR"] = "СПСР";

$MESS["WIZ_AGENTS"] = "Агенты (можно включить позже в настройках)";
$MESS["WIZ_AGENT_CBRF"] = "Получение курсов валют из ЦБРФ";
$MESS["WIZ_AGENT_UPLOAD_CLEAN"] = "Периодическая очистка папки upload";
$MESS["WIZ_SYSTEM_FILES"] = "Системные файлы";
$MESS["WIZ_PHP_INTERFACE"] = "Создать файл init.php и другие служебные файлы в папке local для этого сайта";
$MESS["WIZ_PUBLIC"] = "Публичная часть";
$MESS["WIZ_PUB_AUTH"] = "Авторизация";
$MESS["WIZ_PUB_PRIVATE"] = "Личный кабинет";
$MESS["WIZ_PUB_NEWS"] = "Новости";
$MESS["WIZ_PUB_CATALOG"] = "Каталог";
$MESS["WIZ_PUB_CART"] = "Корзина";
$MESS["WIZ_PUB_INDEX"] = "index.php";
$MESS["WIZ_PUB_404"] = "404.php";
$MESS['WIZ_MENU'] = "Типы меню";
$MESS["WIZ_MENU_TOP"] = "Верхнее";
$MESS["WIZ_MENU_BOTTOM"] = "Нижнее";
$MESS["WIZ_MENU_SIDE"] = "Боковое";
$MESS["WIZ_MENU_CATALOG"] = "Каталог";
$MESS['WIZ_IBLOCKS'] = "Инфоблоки";
$MESS["WIZ_IBLOCKS_NEWS"] = "Новости";
$MESS["WIZ_IBLOCKS_CATALOG"] = "Каталог товаров";
$MESS["WIZ_IBLOCKS_OFFER"] = "Торговые предложения";
$MESS["WIZ_IBLOCKS_BRANDS"] = "Бренды";
$MESS["WIZ_IBLOCKS_BANNER"] = "Баннеры";
$MESS["WIZ_UNCHECK_ALL"] = "Снять все выделения";


?>