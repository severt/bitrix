<?
$MESS ['SERVICE_MAIN_SETTINGS'] = "Site settings";
$MESS ['SERVICE_IBLOCK'] = "Information blocks";
$MESS ['SERVICE_FILES'] = "Files";
$MESS ['SERVICE_CATALOG'] = "Catalog settings";
$MESS ['SERVICE_SALE'] = "Online store settings";
?>