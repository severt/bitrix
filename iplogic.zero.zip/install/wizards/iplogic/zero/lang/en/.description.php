<?
$MESS["PORTAL_WIZARD_NAME"] = "Zero";
$MESS["PORTAL_WIZARD_DESC"] = "Solution for developers Zero wizard";
?>