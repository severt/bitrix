<?
$moduleName = "iplogic.zero_default_option";
$$moduleName = [
	"GROUP_DEFAULT_RIGHT" => 'R',
	"cli_execute_method" => "WGET",
	"cli_php" => "/usr/bin/php",
	"cli_wget_miss_cert" => "Y",
	"turn_on_сu_agent" => "N",
	"agent_delete_files" => "Y",
	"agent_save_backup" => "Y",
	"agent_search_path" => "/iblock",
	"agent_backup_folder" => "/iblock_Backup/",
	"turn_on_сr_agent" => "N",
	"agent_currencies" => "USD,EUR",
];
?>
