<?
$MESS["iplogic.zero_MODULE_OPTIONS"] = "Zero Module settings";
$MESS["MODULE_OPTIONS_DENIED"] = "Not enough rights to view";
$MESS["IPL_BACKGROUND_SCRIPTS"] = "Running background scripts";
$MESS["IPL_CLI_METHOD"] = "Running method";
$MESS["IPL_CLI_MISS_CERT"] = "Don't screw up the certificate";
$MESS["IPL_PHP_FILE"] = "PHP run file";
$MESS["IPL_AGENTS"] = "Agents";
$MESS["IPL_TURN_ON_СU_AGENT"] = "Enable the upload folder cleanup agent";
$MESS["IPL_TURN_ON_СR_AGENT"] = "Enable an agent for receiving currency rates from the Central Bank";
$MESS["IPL_СR_AGENT_CURRENCIES"] = "Currencies to receive the exchange rate";
$MESS["IPL_СU_AGENT_DELETE"] = "Delete files";
$MESS["IPL_СU_AGENT_BACKUP"] = "Save backup";
$MESS["IPL_СU_AGENT_SEARCH_PATH"] = "Search path (in upload folder)";
$MESS["IPL_СU_AGENT_BACKUP_FOLDER"] = "Backup folder (in upload folder)";
$MESS["IPL_ACTIONS"] = "Actions";
?>