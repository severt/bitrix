<?
$MESS["IPLOGIC_MODULE_NAME"] = "Zero";
$MESS["IPLOGIC_MODULE_DESC"] = "Solution for the initial installation of Bitrix and further development of the site. Contains additional libraries to expand the capabilities of standard modules.";
$MESS["IPLOGIC_PARTNER_NAME"] = "iPloGic";
$MESS["IPLOGIC_PARTNER_URI"] = "https://iplogic.ru";
$MESS["IPLOGIC_MODULE_INSTALLED"] = "The Zero module is installed. Additional features are available in its settings.";
$MESS["IPLOGIC_MODULE_UNINSTALLED"] = "The module has been successfully removed from the system";
$MESS["IPLOGIC_MODULE_INSTALLED_TITLE"] = "Installing the Zero Module";
$MESS["IPLOGIC_MODULE_UNINSTALLED_TITLE"] = "Removing the Zero Module";
$MESS["IPLOGIC_MODULE_INSTALLED_TEXT"] = "The module has been successfully installed, but you can also add additional features";
$MESS["BACK"] = "Back";
$MESS["FINISH"] = "Finish";
$MESS["MOD_INSTALL_CU_AGENT"] = "Install the upload folder cleanup agent";
$MESS["MOD_INSTALL_CR_AGENT"] = "Install an agent for receiving currency rates from the Central Bank";
?>