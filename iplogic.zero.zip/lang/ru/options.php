<?
$MESS["iplogic.zero_MODULE_OPTIONS"] = "Настройки модуля Zero";
$MESS["MODULE_OPTIONS_DENIED"] = "Недостаточно прав для просмотра";
$MESS["IPL_BACKGROUND_SCRIPTS"] = "Запуск фоновых скриптов";
$MESS["IPL_CLI_METHOD"] = "Метод запуска";
$MESS["IPL_CLI_MISS_CERT"] = "Не проверять сертификат";
$MESS["IPL_PHP_FILE"] = "Файл запуска PHP";
$MESS["IPL_AGENTS"] = "Агенты";
$MESS["IPL_TURN_ON_СU_AGENT"] = "Включить агент очистки папки upload";
$MESS["IPL_TURN_ON_СR_AGENT"] = "Включить агент получения курса валют";
$MESS["IPL_СR_AGENT_CURRENCIES"] = "Валюты для получения курса";
$MESS["IPL_СU_AGENT_DELETE"] = "Удалять файлы";
$MESS["IPL_СU_AGENT_BACKUP"] = "Сохранять бэкап";
$MESS["IPL_СU_AGENT_SEARCH_PATH"] = "Путь поиска (в папке upload)";
$MESS["IPL_СU_AGENT_BACKUP_FOLDER"] = "Папка бэкапа (в папке upload)";
$MESS["IPL_ACTIONS"] = "Действия";
?>