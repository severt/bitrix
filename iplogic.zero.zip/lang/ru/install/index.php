<?
$MESS["IPLOGIC_MODULE_NAME"] = "Zero";
$MESS["IPLOGIC_MODULE_DESC"] = "Решение для первоначальной установки Битрикс и дальнейшей разработки сайта. Содержит дополнительные библиотеки для расширения возможностей штатных модулей.";
$MESS["IPLOGIC_PARTNER_NAME"] = "iPloGic";
$MESS["IPLOGIC_PARTNER_URI"] = "https://iplogic.ru";
$MESS["IPLOGIC_MODULE_INSTALLED"] = "Модуль Zero установлен. Дополнительные возможности доступны в его настройках.";
$MESS["IPLOGIC_MODULE_UNINSTALLED"] = "Модуль успешно удален из системы";
$MESS["IPLOGIC_MODULE_INSTALLED_TITLE"] = "Установка модуля Zero";
$MESS["IPLOGIC_MODULE_UNINSTALLED_TITLE"] = "Удаление модуля Zero";
$MESS["IPLOGIC_MODULE_INSTALLED_TEXT"] = "Модуль успешно установлен, но Вы можете также добавить дополнительные возможности";
$MESS["BACK"] = "Назад";
$MESS["FINISH"] = "Завершить";
$MESS["MOD_INSTALL_CU_AGENT"] = "Установить агент очистки папки upload";
$MESS["MOD_INSTALL_CR_AGENT"] = "Установить агент получения курса валют из ЦБ";
?>