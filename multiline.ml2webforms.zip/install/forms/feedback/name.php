<?php
return array(
    'ru' => 'Обратная связь',
    'en' => 'Feedback',
);