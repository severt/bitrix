<?
$arModuleVersion = array(
	"VERSION" => "1.0.16",
	"VERSION_DATE" => "2024-07-24 10:00:00"
);
?>