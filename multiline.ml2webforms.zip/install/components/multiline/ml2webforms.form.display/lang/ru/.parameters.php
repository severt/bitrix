<?
$MESS["ML2WEBFORMS_ID_MESSAGE"] = "ID формы";
?>