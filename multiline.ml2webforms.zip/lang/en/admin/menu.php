<?php

$MESS['ML2WEBFORMS_ADMIN_MENU_TITLE'] = 'Multiline: Web-forms';