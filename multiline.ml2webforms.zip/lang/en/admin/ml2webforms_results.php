<?php

$MESS['ml2webforms_results_list_title'] = 'Results';

$MESS['ml2webforms_result_id'] = 'ID';
$MESS['ml2webforms_result_datetime'] = 'Time';

$MESS['ml2webforms_results_list_note'] = '';
