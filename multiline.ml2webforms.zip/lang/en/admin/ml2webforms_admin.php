<?php

$MESS['ml2webforms_list_title'] = 'Multiline: Web-forms';

$MESS['ml2webforms_field_ID'] = 'Form ID';
$MESS['ml2webforms_field_NAME'] = 'Form name';

$MESS['ml2webforms_add'] = 'Generate new form';
$MESS['ml2webforms_results'] = 'View results';
$MESS['ml2webforms_edit'] = 'Edit form';