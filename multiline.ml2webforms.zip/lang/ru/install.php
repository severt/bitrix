<?php
/**
 * Created by Multiline / A M I O.
 * User: r.panfilov@amio.ru
 * Date: 28.10.14
 * Time: 18:22
 */

$MESS ['multiline.ml2webforms_MODULE_NAME'] = "Multiline: Веб-формы";
$MESS ['multiline.ml2webforms_MODULE_DESC'] = "Модуль для создания веб-форм на сайте.";
$MESS ['multiline.ml2webforms_PARTNER_NAME'] = "Multiline";
$MESS ['multiline.ml2webforms_PARTNER_URI'] = "http://www.multiline.ru/";
$MESS ['ML2WEBFORMS_INSTALL_NAME'] = "Multiline: Веб-формы";
$MESS ['ML2WEBFORMS_INSTALL_DESCRIPTION'] = "Модуль для создания веб-форм на сайте.";
$MESS ['ML2WEBFORMS_INSTALL_PARTNER_NAME'] = "Multiline";
$MESS ['ML2WEBFORMS_INSTALL_PARTNER_URI'] = "http://www.multiline.ru/";
$MESS ['ML2WEBFORMS_INSTALL_TITLE'] = "Установка модуля \"Multiline: Веб-формы\"";
$MESS ['ML2WEBFORMS_INSTALL_PUBLIC_DIR'] = "Публичная папка";
$MESS ['ML2WEBFORMS_INSTALL_SETUP'] = "Установить";
$MESS ['ML2WEBFORMS_INSTALL_COMPLETE_OK'] = "Установка завершена. Для дополнительной помощи обратитесь в раздел помощи.";
$MESS ['ML2WEBFORMS_INSTALL_COMPLETE_ERROR'] = "Установка завершена с ошибками";
$MESS ['ML2WEBFORMS_INSTALL_ERROR'] = "Ошибки при установке";
$MESS ['ML2WEBFORMS_INSTALL_BACK'] = "Вернуться в управление модулями";
$MESS ['ML2WEBFORMS_INSTALL_ERROR_BITRIX_VERSION'] = "Модуль требует для работы версию битрикс 15 и выше";
$MESS ['ML2WEBFORMS_INSTALL_ERROR_PHP_VERSION'] = "Модуль требует для работы версию php 5.3.0 и выше";
$MESS ['ML2WEBFORMS_UNINSTALL_WARNING'] = "Внимание! Модуль будет удален из системы.";
$MESS ['ML2WEBFORMS_UNINSTALL_SAVEDATA'] = "Вы можете сохранить данные в таблицах базы данных, если установите флажок &quot;Сохранить таблицы&quot;";
$MESS ['ML2WEBFORMS_UNINSTALL_SAVETABLE'] = "Сохранить таблицы и файлы классов форм";
$MESS ['ML2WEBFORMS_UNINSTALL_SAVEMAIL'] = "Сохранить почтовые шаблоны";
$MESS ['ML2WEBFORMS_UNINSTALL_DEL'] = "Удалить";
$MESS ['ML2WEBFORMS_UNINSTALL_ERROR'] = "Ошибки при удалении:";
$MESS ['ML2WEBFORMS_UNINSTALL_COMPLETE'] = "Удаление завершено.";
$MESS ['ML2WEBFORMS_INSTALL_PUBLIC_SETUP'] = "Установить";
$MESS ['ML2WEBFORMS_INSTALL_UNPOSSIBLE'] = "Деинсталляция модуля невозможна.";
