<?php

$MESS['ml2webforms_results_list_title'] = 'Заявки';

$MESS['ml2webforms_result_id'] = 'ID';
$MESS['ml2webforms_result_datetime'] = 'Время заполнения';

$MESS['ml2webforms_results_list_note'] = '';
