<?php

$MESS['ml2webforms_list_title'] = 'Multiline: Веб-формы';

$MESS['ml2webforms_field_ID'] = 'ID формы';
$MESS['ml2webforms_field_NAME'] = 'Название формы';

$MESS['ml2webforms_add'] = 'Создать форму';
$MESS['ml2webforms_results'] = 'Посмотреть заявки';
$MESS['ml2webforms_edit'] = 'Параметры формы';