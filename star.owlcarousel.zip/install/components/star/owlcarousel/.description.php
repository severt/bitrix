<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("STAR_OWLCAROUSEL_NAME"),
	"DESCRIPTION" => GetMessage("STAR_OWLCAROUSEL_DESCRIPTION"),
	"CACHE_PATH" => "Y",
	"SORT" => 70,
	"PATH" => array(	
		"ID" => "star",
		"NAME" => GetMessage("STAR_COMPONENTS")
	),
);

?>