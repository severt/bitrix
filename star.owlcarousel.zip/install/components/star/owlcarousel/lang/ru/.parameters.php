<?
	$MESS["STAR_OWLCAROUSEL_JQUERY"] = "Подключить jQuery";

	$MESS["STAR_OWLCAROUSEL_DATA_TYPE"] = "Источник данных";
	$MESS["STAR_OWLCAROUSEL_FOLDER"] = "Выбрать папку с фото";
	$MESS["STAR_OWLCAROUSEL_FOLDER_PATH"] = "Укажите папку относительно корня сайта";
	$MESS["STAR_OWLCAROUSEL_IBLOCK"] = "Использовать инфоблок";

	$MESS["STAR_OWLCAROUSEL_YES"] = "Да";
	$MESS["STAR_OWLCAROUSEL_NO"] = "Нет";


	$MESS["STAR_OWLCAROUSEL_IBLOCK_TYPE"] = "Тип информационного блока";
	$MESS["STAR_OWLCAROUSEL_IBLOCK_ID"] = "Код информационного блока";
	$MESS["STAR_OWLCAROUSEL_IBLOCK_COUNT"] = "Количество записей";
	$MESS["STAR_OWLCAROUSEL_IBLOCK_IMAGE"] = "Использовать картинку";
	$MESS["STAR_OWLCAROUSEL_IBLOCK_IMAGE_PREVIEW"] = "Картинка для анонса";
	$MESS["STAR_OWLCAROUSEL_IBLOCK_IMAGE_DETAIL"] = "Детальная картинка";
	$MESS["STAR_OWLCAROUSEL_IBLOCK_PROPERTY"] = "Брать ссылку из свойства";

	

	$MESS["STAR_OWLCAROUSEL_BANNER_COUNT_SLIDES"] = "Количество слайдов";

	$MESS["STAR_OWLCAROUSEL_BANNER_LOOP"] = "Бесконечное зацикливание слайдера";
	

	$MESS["STAR_OWLCAROUSEL_BANNER_MARGIN"] = "Отступ справа у элементов внутри слайдера (значение в px)";

	$MESS["STAR_OWLCAROUSEL_BANNER_CONTROLS"] = "Показывать стрелки";
	$MESS["STAR_OWLCAROUSEL_BANNER_PAGER"] = "Показывать переключатель слайдов";
	$MESS["STAR_OWLCAROUSEL_BANNER_AUTO"] = "Автоматическое переключение слайдов";
	$MESS["STAR_OWLCAROUSEL_BANNER_PAUSE"] = "Интервалы между пролистыванием элементов (в секундах)";

	$MESS["STAR_OWLCAROUSEL_LINK"] = "Оборачивать ссылкой";
	$MESS["STAR_OWLCAROUSEL_BANNER_NEW_WINDOW"] = "Открывать ссылку в новом окне";

	$MESS["STAR_OWLCAROUSEL_SORT_ID"] = "ID";
	$MESS["STAR_OWLCAROUSEL_SORT_NAME"] = "Название";
	$MESS["STAR_OWLCAROUSEL_SORT_SORT"] = "Сортировка";
	$MESS["STAR_OWLCAROUSEL_SORT_ASC"] = "По возрастанию";
	$MESS["STAR_OWLCAROUSEL_SORT_DESC"] = "По убыванию";
	$MESS["STAR_OWLCAROUSEL_SORT_BY1"] = "Поле для сортировки";
	$MESS["STAR_OWLCAROUSEL_SORT_ORDER1"] = "Направление для сортировки";

?>