<?
$MESS ['STAR_OWLCAROUSEL_NAME'] = "OWL Карусель";
$MESS ['STAR_OWLCAROUSEL_DESCRIPTION'] = "Модуль поможет вам добавить на страницу стильную адаптивную галерею-карусель на основе скрипта Owl Carousel 2";
$MESS ['STAR_COMPONENTS'] = "STARt";
?>