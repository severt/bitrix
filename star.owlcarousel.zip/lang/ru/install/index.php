<?php
	$MESS["STAR_OWLCAROUSEL_MODULE_NAME"] = "OWL Карусель";
	$MESS["STAR_OWLCAROUSEL_MODULE_DESC"] = "Модуль поможет вам добавить на страницу стильную адаптивную галерею-карусель на основе скрипта Owl Carousel 2";
	$MESS["STAR_OWLCAROUSEL_PARTNER_NAME"] = "STARt";
	$MESS["STAR_OWLCAROUSEL_PARTNER_URI"] = "https://startpl.ru/";
?>