<?if(!check_bitrix_sessid()) return;?>
<?
echo CAdminMessage::ShowNote("Модуль Авторизация в модальном окне успешно удален из системы");
?>