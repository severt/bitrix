<?
$arModuleVersion = array(
"VERSION" => "1.0.5",
"VERSION_DATE" => "2020-07-23 10:00:00");
?>