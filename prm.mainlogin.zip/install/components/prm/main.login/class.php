<?
use Bitrix\Main;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Web\Json;

/**
 * @var $APPLICATION CMain
 * @var $USER CUser
 */
Bitrix\Main\Loader::includeModule("prm.mainlogin");

class MainLogin extends MainLoginHandler
{
    protected $post;
    protected $errors;

	public function executeComponent()
	{
        $context = \Bitrix\Main\Application::getInstance()->getContext();
        $this->post = $context->getRequest()->getPostList();
		$this->start();

	}

	protected function getUser()
	{
		$user = null;

		if ($user === null)
		{
			$user = $GLOBALS['USER'];
		}

		return $user;
	}

	protected function request($field){
		return isset($this->post[$field]) ? $this->post[$field] : false;
	}

    protected function actionLogin(){

		$password = null;

		$password = $this->post['password'];

		$user = $this->getUserLogin();

		if (empty($this->errors)) {
			$authResult = $this->getUser()->Login($user['LOGIN'], $password, 'Y');
			if ($authResult['TYPE'] == 'ERROR') {
				$this->addError(
					strip_tags($authResult['MESSAGE'])
				);
				echo json_encode(array(
					'status' => 'error',
					'errors' => $this->errors,
				));
			}else{
				echo json_encode(array(
					'status' => 'success',
				));
			}
				
		}else{
			$this->errorMessage();
		}
	}

    protected function actionRegister(){
		if (empty($this->post['phone'])) {
			$this->addError(Loc::getMessage("REQUIRED_PHONE"));
		}
		if (empty($this->post['email'])) {
			$this->addError(Loc::getMessage("REQUIRED_EMAIL"));
		}
		if (strlen($this->post['email']) < 3) {
			$this->addError(Loc::getMessage("REQUIRED_EMAIL_3_SYMBOLS"));
		}
		if (empty($this->post['conditions'])) {
			$this->addError(Loc::getMessage("REQUIRED_CONDITIONS"));
		}
		if (empty($this->post['generatePassword'])) {
			if (empty($this->post['password'])) {
				$this->addError(Loc::getMessage("REQUIRED_PASSWORD"));
			}else{
				$password = $this->post['password'];
			}
		}else{
			$password = $this->generatePassword();
		}
		if (\Bitrix\Main\Config\Option::get('main', 'captcha_registration') == 'Y') {
			if (!$GLOBALS['APPLICATION']->CaptchaCheckCode($this->post["captcha_word"], $this->post["captcha_code"])){
				$this->addError(Loc::getMessage("WRONG_CAPTCHA"));
			}
		}
		if (empty($this->errors)) {
			$userGroups = COption::GetOptionString("main", "new_user_registration_def_group", "");
			if($userGroups != ""){
				$userGroups = explode(",", $userGroups);
			}
			$user = new CUser;
			$arFields = array(
				"LOGIN" => $this->post['email'],
				"EMAIL" => $this->post['email'],
				"PHONE_NUMBER" => str_replace(' ', '', $this->post['phone']),
				"ACTIVE" => "Y",
				"PASSWORD" => $password,
				"CONFIRM_PASSWORD" => $password,
				"GROUP_ID" => $userGroups
			);
			$newUser = $user->Add($arFields);
			/*$result = $this->getUser()->Register($this->post['email'], "", "", $password, $password, $this->post['email'], false);*/
			if (intval($newUser) > 0){
				if ($this->getUser()->Authorize($newUser)) {
					$mail1 = \Bitrix\Main\Mail\Event::send(array(
					    "EVENT_NAME" => "PRM_MAINLOGIN_SEND_PASSWORD",
					    "LID" => SITE_ID,
					    "C_FIELDS" => array(
					        "EMAIL" => $this->post['email'],
					        "PHONE" => $this->post['phone'],
					        "PASSWORD" => $password
					    ),
					)); 
					echo json_encode(array(
						'status' => 'success',
						'ID' => $newUser,
					));
					
				}else{
					$this->addError(Loc::getMessage("ERROR_AUTHORIZATION"));
					$this->errorMessage();
				}
			}else{
				$errors = explode('<br>', $user->LAST_ERROR);
				foreach ($errors as $error) {
					if (!empty($error)) {
						$this->addError($error);
					}
					
				}
				$this->errorMessage();
			}
		}else{
			$this->errorMessage();
		}
	}

    protected function getUserLogin(){
		if ($this->post['methodLogin'] == 'phone') {
			if (empty($this->post['phone'])) {
				$this->addError(Loc::getMessage("REQUIRED_PHONE"));
				return false;
			}
			$result = \Bitrix\Main\UserPhoneAuthTable::getList(array(
			    'filter' => array('=PHONE_NUMBER' => str_replace(' ', '', $this->post['phone'])),
			    'limit' => 1,
			));
			while ($row = $result->fetch())
			{
			    $userIdByPhone = $row;
			}
			if (empty($userIdByPhone)) {
				$this->addError(Loc::getMessage("USER_NOT_FOUND"));
				return false;
			}
			$filter = array("ID" => $userIdByPhone['USER_ID']);
		}
		if ($this->post['methodLogin'] == 'email') {
			if (empty($this->post['email'])) {
				$this->addError(Loc::getMessage("REQUIRED_EMAIL"));
				return false;
			}
			$filter = array("=EMAIL" => $this->post['email']);
		}
			
		$rsUsers = CUser::GetList(
			($by="id"), 
			($order="desc"), 
			$filter, 
			array(
				'NAV_PARAMS' => array(
					'nTopCount' => 1, 
					'FIELDS' => array('LOGIN')
				)
			)
		);
		while ($arUser = $rsUsers->Fetch()) {
			$user = $arUser;
		}
		if (empty($user)) {
			$this->addError(Loc::getMessage("USER_NOT_FOUND"));
			return false;
		}
		return $user;

	}


    protected function addError(string $error){
		$this->errors[] = $error;
	}

	/**
	 * Redirect to the success page.
	 * @return void
	 */
	/*protected function successRedirect()
	{
		if ($this->arParams['AUTH_SUCCESS_URL'])
		{
			\localRedirect(
				$this->arParams['AUTH_SUCCESS_URL']
			);
		}
	}*/

	/**
	 * Refresh current page.
	 * @param array $params Delete or add params.
	 * @return void
	 */
	/*protected function refresh(array $params = array())
	{
		$request = \Bitrix\Main\Application::getInstance()->getContext()->getRequest();
		$uriString = $request->getRequestUri();
		if (
			isset($params['add']) && is_array($params['add']) ||
			isset($params['delete']) && is_array($params['delete'])
		)
		{
			$uriSave = new \Bitrix\Main\Web\Uri($uriString);
			if (isset($params['add']))
			{
				$uriSave->addParams($params['add']);
			}
			if (isset($params['delete']))
			{
				$uriSave->deleteParams($params['delete']);
			}
			$uriString = $uriSave->getUri();
		}
		\localRedirect($uriString);
	}*/

    protected function errorMessage(){
		echo json_encode(array(
			'status' => 'error',
			'errors' => $this->errors
		));
	}
    protected function generatePassword($length = 8){
		return randString($length);
	}

    protected function generateCaptcha(){
		$cpt = new CCaptcha();
		$captchaPass = COption::GetOptionString("main", "captcha_password", "");
		if(strlen($captchaPass) <= 0)
		{
		    $captchaPass = randString(10);
		    COption::SetOptionString("main", "captcha_password", $captchaPass);
		}
		$cpt->SetCodeCrypt($captchaPass);
		echo json_encode(array(
			'status' => 'updateCaptcha',
			'code' => htmlspecialchars($cpt->GetCodeCrypt()),
		));
	}

    protected function restorePassword(){
		if (empty($this->post['email'])) {
			$this->addError(Loc::getMessage("REQUIRED_EMAIL"));
		}
		if (empty($this->errors)) {
			$filter = array("=EMAIL" => $this->post['email']);
				
			$rsUsers = CUser::GetList(
				($by="id"), 
				($order="desc"), 
				$filter, 
				array(
					'NAV_PARAMS' => array(
						'nTopCount' => 1, 
						'FIELDS' => array('LOGIN')
					)
				)
			);
			while ($arUser = $rsUsers->Fetch()) {
				$user = $arUser;
			}
			if (empty($user)) {
				$this->addError(Loc::getMessage("USER_NOT_FOUND"));
				$this->errorMessage();
			}else{
				$mail = $this->getUser()->SendPassword($this->post['email'], $this->post['email']);
				if ($mail['TYPE'] == 'ERROR') {
					$this->addError(
						strip_tags($mail['MESSAGE'])
					);
					echo json_encode(array(
						'status' => 'error',
						'errors' => $this->errors,
					));
				}else{
					echo json_encode(array(
						'status' => 'successrestore',
						'result' => strip_tags($mail['MESSAGE']),
					));
				}
					
			}
		}else{
			$this->errorMessage();
		}
	}
}