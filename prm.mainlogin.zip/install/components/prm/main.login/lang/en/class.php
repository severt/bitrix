<?
$MESS['REQUIRED_PHONE'] = 'Field "Phone" is required';
$MESS['REQUIRED_EMAIL'] = 'Field "E-Mail" is required';
$MESS['REQUIRED_EMAIL_3_SYMBOLS'] = 'The E-Mail field must contain more than 3 symbols';
$MESS['REQUIRED_CONDITIONS'] = 'You must accept the terms of use';
$MESS['REQUIRED_PASSWORD'] = 'Field "Password" is required';
$MESS['WRONG_CAPTCHA'] = 'Wrond captcha';
$MESS['ERROR_AUTHORIZATION'] = 'Authorization error';
$MESS['USER_NOT_FOUND'] = 'The user is not found';
?>