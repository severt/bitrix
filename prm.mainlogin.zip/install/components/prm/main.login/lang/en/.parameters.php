<?
$MESS['SOA_USER_POLICY'] = "Link to the user agreement";
$MESS['SOA_PROFILE_LINK'] = "Link to the user profile";
?>