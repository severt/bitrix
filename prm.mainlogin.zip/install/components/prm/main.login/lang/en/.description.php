<?
$MESS['SOF_DEFAULT_TEMPLATE_NAME_MAIN_LOGIN'] = "Authorization in modal";
$MESS['SOF_DEFAULT_TEMPLATE_DESCRIPTION_MAIN_LOGIN'] = "The authorization module implemented in the form of a modal";
$MESS['SOF_NAME_MAIN_LOGIN'] = "PRM Modules";