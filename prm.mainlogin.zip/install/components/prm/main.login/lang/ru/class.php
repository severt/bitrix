<?
$MESS['REQUIRED_PHONE'] = 'Заполните поле "Телефон"';
$MESS['REQUIRED_EMAIL'] = 'Заполните поле "E-Mail"';
$MESS['REQUIRED_EMAIL_3_SYMBOLS'] = 'В поле E-Mail должно быть введено более 3 символов';
$MESS['REQUIRED_CONDITIONS'] = 'Необходимо принять условия использования';
$MESS['REQUIRED_PASSWORD'] = 'Заполните поле "Пароль"';
$MESS['WRONG_CAPTCHA'] = 'Неправильно введена Captcha';
$MESS['ERROR_AUTHORIZATION'] = 'Ошибка авторизации';
$MESS['USER_NOT_FOUND'] = 'Пользователь не найден';
