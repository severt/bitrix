<?
$MESS['SOF_DEFAULT_TEMPLATE_NAME_MAIN_LOGIN'] = "Авторизация в модальном окне";
$MESS['SOF_DEFAULT_TEMPLATE_DESCRIPTION_MAIN_LOGIN'] = "Модуль, добавляющий компонент авторизации и регистрации в модальном окне на Vue.js";
$MESS['SOF_NAME_MAIN_LOGIN'] = "Модули PRM";