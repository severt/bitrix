<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("SOF_DEFAULT_TEMPLATE_NAME_MAIN_LOGIN"),
	"DESCRIPTION" => GetMessage("SOF_DEFAULT_TEMPLATE_DESCRIPTION_MAIN_LOGIN"),
	"PATH" => array(
		"ID" => "PRM_MODULES",
		"NAME" => GetMessage("SOF_NAME_MAIN_LOGIN"),
	),
);
?>