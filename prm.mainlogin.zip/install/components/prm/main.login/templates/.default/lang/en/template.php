<?
$MESS['LOGOUT'] = 'Logout';
$MESS['OPEN_MODAL'] = 'Log in/Sign up';
$MESS['LOGIN'] = 'Log in';
$MESS['PHONE'] = 'Phone';
$MESS['EMAIL'] = 'E-Mail';
$MESS['PASSWORD'] = 'Password';
$MESS['LOGIN_BUTTON'] = 'Log in';
$MESS['LOGIN_BY_EMAIL'] = 'Log in by E-Mail';
$MESS['LOGIN_BY_PHONE'] = 'Log in by Phone';
$MESS['FORGOT_PASSWORD'] = 'Forgot password?';
$MESS['REGISTER'] = 'Register';
$MESS['REGISTRATION'] = 'Sign up';
$MESS['GENERATE_PASSWORD'] = 'Generate a password and send him to my email address';
$MESS['ACCEPT_TERMS'] = 'I accept <a href="#LINK#" target="_blank">the Terms, data usage Policy and cookie Policy.</a>';
$MESS['CAPTCHA'] = 'Captcha code:';
$MESS['SEND_MAIL'] = 'Send to my E-mail';
?>
