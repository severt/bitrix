<?
$MESS['LOGOUT'] = 'Выйти';
$MESS['OPEN_MODAL'] = 'Вход/регистрация';
$MESS['LOGIN'] = 'Вход';
$MESS['PHONE'] = 'Телефон';
$MESS['EMAIL'] = 'E-Mail';
$MESS['PASSWORD'] = 'Пароль';
$MESS['LOGIN_BUTTON'] = 'Войти';
$MESS['LOGIN_BY_EMAIL'] = 'Войти по E-Mail';
$MESS['LOGIN_BY_PHONE'] = 'Войти по телефону';
$MESS['FORGOT_PASSWORD'] = 'Забыли пароль?';
$MESS['REGISTER'] = 'Зарегистрироваться';
$MESS['REGISTRATION'] = 'Регистрация';
$MESS['GENERATE_PASSWORD'] = 'Сгенерировать пароль и отправить на почту';
$MESS['ACCEPT_TERMS'] = 'Я принимаю <a href="#LINK#" target="_blank">Условия, Политику использования данных и Политику в отношении файлов cookie.</a>';
$MESS['CAPTCHA'] = 'Введите код:';
$MESS['SEND_MAIL'] = 'Отправить письмо на почту';
?>
