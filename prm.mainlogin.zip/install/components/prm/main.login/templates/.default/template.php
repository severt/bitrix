<? if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main,
	Bitrix\Main\Localization\Loc;

/**
 * @var array $arParams
 * @var array $arResult
 * @var CMain $APPLICATION
 * @var CUser $USER
 * @var SaleOrderAjax $component
 * @var string $templateFolder
 */

$context = Main\Application::getInstance()->getContext();
$request = $context->getRequest();

$this->addExternalJs($templateFolder . '/plugins/inputmask.min.js');

$APPLICATION->SetAdditionalCSS($templateFolder.'/style.css', true);
//$this->addExternalJs($templateFolder.'/script.js');

?>
<NOSCRIPT>
	<div style="color:red"><?=Loc::getMessage('SOA_NO_JS')?></div>
</NOSCRIPT>
<div style="clear: both;"></div>
<div class="hidden" id="prmAuthorizationModule">
	<?if ($GLOBALS['USER']->IsAuthorized()) {?>
		<div class="auth-module__user">
			<a href="<?=$arParams['PROFILE_LINK'];?>"><?=$GLOBALS['USER']->GetFullName();?></a>
			<a href="?logout=yes"><?=Loc::getMessage("LOGOUT");?></a>
		</div>
	<?}else{?>
		<a href="#" @click="_modal('show');"><?=Loc::getMessage("OPEN_MODAL");?></a>
	<?}?>
	
	<div class="auth-modal">
		<div class="auth-modal__window">
			<div class="auth-modal__content">
				<div v-if="action == 'login'">
					<div class="auth-modal__header">
						<h5 class="auth-modal__title"><?=Loc::getMessage("LOGIN");?></h5>
						<button type="button" class="auth-modal__close" @click="_modal('hide');">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="auth-modal__body">
						<div class="auth-modal__errors">
							<div class="auth-modal_error" v-for="error in errors">
								{{error}}
							</div>
						</div>
						<div class="auth-form">
							<div class="auth-form__group" id="auth1" v-if="methodLogin == 'phone'">
								<div class="auth-form__label">
									<?=Loc::getMessage("PHONE");?>
								</div>
								<input type="text" name="phone" class="auth-form__input auth-form__input_phone" placeholder="+7 000 000 00 00" data-inputmask="'mask': '+9 999 999 99 99'" key="phone-input">
							</div>
							<div class="auth-form__group" id="auth2" v-else>
								<div class="auth-form__label">
									<?=Loc::getMessage("EMAIL");?>
								</div>
								<input type="text" name="email" class="auth-form__input auth-form__input_email" placeholder="<?=Loc::getMessage("EMAIL");?>" key="email-input">
							</div>
							<div class="auth-form__group">
								<div class="auth-form__label">
									<?=Loc::getMessage("PASSWORD");?>
								</div>
								<input type="password" name="password" class="auth-form__input" placeholder="<?=Loc::getMessage("PASSWORD");?>">
							</div>
							<div class="auth-form__buttons">
								<a href="javascript:void(0);" class="auth-form__submit" @click="query();"><?=Loc::getMessage("LOGIN_BUTTON");?></a>
								<a href="javascript:void(0);" class="auth-form__primary auth-form__primary_email" @click="changeMethodLogin();" v-if="methodLogin == 'phone'"><?=Loc::getMessage("LOGIN_BY_EMAIL");?></a>
								<a href="javascript:void(0);" class="auth-form__primary auth-form__primary_phone" @click="changeMethodLogin();" v-else><?=Loc::getMessage("LOGIN_BY_PHONE");?></a>
							</div>
						</div>
						<div class="auth-modal__links">
							<a href="javascript:void(0);" @click="changeAction('forgot');" class="auth-modal__link">
								<?=Loc::getMessage("FORGOT_PASSWORD");?>
							</a>
							<a href="javascript:void(0);" @click="changeAction('register')" class="auth-modal__link">
								<?=Loc::getMessage("REGISTER");?>
							</a>
						</div>
					</div>
				</div>
				<div v-if="action == 'register'">
					<div class="auth-modal__header">
						<h5 class="auth-modal__title"><?=Loc::getMessage("REGISTRATION");?></h5>
						<button type="button" class="auth-modal__close" @click="_modal('hide');">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="auth-modal__body">
						<div class="auth-modal__errors">
							<div class="auth-modal_error" v-for="error in errors">
								{{error}}
							</div>
						</div>
						<form class="auth-form">
							<div class="auth-form__group">
								<div class="auth-form__label">
									<?=Loc::getMessage("PHONE");?>
								</div>
								<input type="text" name="phone" class="auth-form__input auth-form__input_phone" placeholder="+7 000 000 00 00" data-inputmask="'mask': '+9 999 999 99 99'">
							</div>
							<div class="auth-form__group">
								<div class="auth-form__label">
									<?=Loc::getMessage("EMAIL");?>
								</div>
								<input type="text" name="email" class="auth-form__input auth-form__input_email" placeholder="<?=Loc::getMessage("EMAIL");?>">
							</div>
							<div class="auth-form__group" v-if="!generatePassword">
								<div class="auth-form__label">
									<?=Loc::getMessage("PASSWORD");?>
								</div>
								<input type="password" name="password" class="auth-form__input auth-form__input_email" placeholder="<?=Loc::getMessage("PASSWORD");?>">
							</div>
							<div class="auth-form__checkboxes">
								<div class="auth-form__checkbox">
									<label>
										<input type="checkbox" name="generatePassword" v-model="generatePassword">
										<span><?=Loc::getMessage("GENERATE_PASSWORD");?></span>
									</label>
								</div>
								<div class="auth-form__checkbox">
									<label>
										<input type="checkbox" name="conditions">
										<span><?=Loc::getMessage("ACCEPT_TERMS", array('#LINK' => $arParams['USER_POLICY']));?></span>
									</label>
								</div>
							</div>
							<div class="auth-form__captcha">
								<div class="auth-form__group">
									<div class="auth-form__label">
										<?=Loc::getMessage("CAPTCHA");?>
									</div>
									<div class="auth-form__captcha-image-block">
										<img src="/bitrix/tools/captcha.php?captcha_code=">
										<div class="auth-form__refresh" @click="updateCaptcha();"></div>
									</div>
										
									<input name="captcha_code" value="" type="hidden">
									<input id="captcha_word" name="captcha_word" class="auth-form__input" type="text">
								</div>
							</div>
							<div class="auth-form__buttons">
								<a href="javascript:void(0);" @click="query()" class="auth-form__submit"><?=Loc::getMessage("REGISTER");?></a>
							</div>
						</form>
						<div class="auth-modal__links">
							<a href="javascript:void(0);" @click="changeAction('login');" class="auth-modal__link">
								<?=Loc::getMessage("LOGIN_BUTTON");?>
							</a>
						</div>
					</div>
				</div>
				<div v-if="action == 'forgot'">
					<div class="auth-modal__header">
						<h5 class="auth-modal__title"><?=Loc::getMessage("FORGOT_PASSWORD");?></h5>
						<button type="button" class="auth-modal__close" @click="_modal('hide');">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="auth-modal__body">
						<div class="auth-modal__errors">
							<div class="auth-modal_error" v-for="error in errors">
								{{error}}
							</div>
						</div>
						<div class="auth-modal__success">
							<div class="auth-modal__success-item" v-for="successItem in success">
								{{successItem}}
							</div>
						</div>
						<form class="auth-form">
							<div class="auth-form__group">
								<div class="auth-form__label">
									<?=Loc::getMessage("EMAIL");?>
								</div>
								<input type="text" name="email" class="auth-form__input" placeholder="<?=Loc::getMessage("EMAIL");?>">
							</div>
							<div class="auth-form__buttons">
								<a href="javascript:void(0);" @click="query()" class="auth-form__submit"><?=Loc::getMessage("SEND_MAIL");?></a>
							</div>
						</form>
						<div class="auth-modal__links">
							<a href="javascript:void(0);" @click="changeAction('register');" class="auth-modal__link">
								<?=Loc::getMessage("REGISTER");?>
							</a>
							<a href="javascript:void(0);" @click="changeAction('login');" class="auth-modal__link">
								<?=Loc::getMessage("LOGIN_BUTTON");?>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>