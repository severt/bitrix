<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

use Bitrix\Main\Loader;

$arTemplateParameters = array(
	/*"MODAL_MODULE" => array(
		"NAME" => 'Реализация через модальное окно',
		"TYPE" => "CHECKBOX",
		"DEFAULT" => "Y",
		"PARENT" => "VISUAL",
	),*/
);