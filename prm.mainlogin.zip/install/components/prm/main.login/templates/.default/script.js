$(function(){
	authorizationModule = BX.Vue.create({
		el: '#prmAuthorizationModule',
		data: {
			info: [],
			methodLogin: 'phone',
			action: 'login',
			errors: [],
			success: [],
			generatePassword: false,
		},
		methods: {
			query(){
				var that = this;
				var form = $(this.$el).find('.auth-form').find('input');
				var formData = form.serializeArray();
				formData.push({
					name: "action",
					value: this.action
				});
				formData.push({
					name: "methodLogin",
					value: this.methodLogin
				});
				$.ajax({
					type: 'POST',
					url: "?",
					data: formData,
					dataType: 'json',
					beforeSend: function(){
						BX.showWait();
					},
					success: function(data){
						BX.closeWait();
						switch (data.status) {
						  	case 'error':
						  	  that.errors = data.errors;
						  	  if (that.action == 'register') {
						  	  	that.updateCaptcha();
						  	  }
						  	  break;
						  	case 'success':
						  		that._clearErrors();
						  		document.location.reload();
						    	break;
						    case 'successrestore':
						    	that.success = [];
						    	that._clearErrors();
						    	that.success.push(data.result);
						}						
					},
					error: function(e){
						console.log(e);
					}
				});
			},
			getData(task, params = {}) {

				var request = '',
					dataPost = {
						'mode': 'ajax',
						'action': task,
						'orderRequest': {}
					},
					that = this;
				$.ajax({
					type: 'POST',
					//contentType: 'application/json; charset=utf-8',
					url: "?" + request,
					data: dataPost,
					beforeSend: function(){
						BX.showWait();
					},
					success: function(data){
						BX.closeWait();
						that.info = data;
					},
					error: function(e){
						console.log(e);
					}
				});
			
			},
			_modal(action){
				that = this;
				switch(action) {
					case 'show':
						$(that.$el).find('.auth-modal').addClass('auth-modal_active');
						$('body').addClass('auth-modal__body-class');
						this.changeAction('login');
						this._clearErrors();
						setTimeout("$('.auth-modal__window').addClass('auth-modal__window_active');", 50);
						break;
					case 'hide':
						$(this.$el).find('.auth-modal').removeClass('auth-modal_active');
						$(this.$el).find('.auth-modal__window').removeClass('auth-modal__window_active');
						$('body').removeClass('auth-modal__body-class');
						break;
					default:
						break;
				}
			},
			changeMethodLogin(){
				if (this.methodLogin == 'phone') {
					this.methodLogin = 'email';
				}else{
					this.methodLogin = 'phone';
				}
				this._clearErrors();
				setTimeout('authorizationModule._maskPhone();', 300);
			},
			changeAction(action){
				this.action = action;
				if (action == 'register') {
					this.updateCaptcha();
				}
				this._clearErrors();
				setTimeout('authorizationModule._maskPhone();', 300);
			}, 
			_clearErrors(){
				this.errors = [];
			},
			updateCaptcha(){
				var that = this;
				$.ajax({
					type: 'POST',
					url: "?",
					data: {action: 'updateCaptcha'},
					dataType: 'json',
					beforeSend: function(){
						BX.showWait();
					},
					success: function(data){
						BX.closeWait();
						if (data.status == 'updateCaptcha') {
							$('.auth-form__captcha img').attr('src', '/bitrix/tools/captcha.php?captcha_code=' + data.code);
							$('.auth-form__captcha input[name="captcha_code"]').val(data.code);
						}
					},
					error: function(e){
						console.log(e);
					}
				});
			},
			_maskPhone(){
				Inputmask({clearIncomplete: true}).mask(document.querySelectorAll('input[name="phone"]'));
			}
		},
		computed: {
		},
		created() {
		},
		mounted() {
			//this.getData('view');
			$(this.$el).removeClass('hidden');
			
		}
	});
})
	