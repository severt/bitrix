<?php
/**
 * Created by PhpStorm.
 * User: akorolev
 * Date: 01.10.2018
 * Time: 10:11
 */

$MESS["INTERLABS_FEEDBACKFORM_NAME"] = "Interlabs - Формы";
$MESS["INTERLABS_FEEDBACKFORM_DESCRIPTION"] = "Сохраняет форму в инфоблок и отсылает на email";
$MESS["INTERLABS_FEEDBACKFORM_PARTNER_NAME"] = "Interlabs";
$MESS["INTERLABS_FEEDBACKFORM_PARTNER_URI"] = "https://www.interlabs.ru/";

$MESS["INTERLABS_FEEDBACKFORM_INSTALL_ERROR_VERSION"] = "Версия главного модуля ниже 14. Не поддерживается технология D7, необходимая модулю. Пожалуйста обновите систему.";
$MESS["INTERLABS_FEEDBACKFORM_INSTALL_TITLE"] = "Установка модуля";
$MESS["INTERLABS_FEEDBACKFORM_UNINSTALL_TITLE"] = "Деинсталляция модуля";


$MESS["INTERLABS_FEEDBACKFORM_STEP_BEFORE"] = "Модуль";
$MESS["INTERLABS_FEEDBACKFORM_STEP_AFTER"] = "установлен";
$MESS["INTERLABS_FEEDBACKFORM_STEP_SUBMIT_BACK"] = "Вернуться в список";


$MESS["INTERLABS_FEEDBACKFORM_UNSTEP_BEFORE"] = "Модуль";
$MESS["INTERLABS_FEEDBACKFORM_UNSTEP_AFTER"] = "удален";
$MESS["INTERLABS_FEEDBACKFORM_UNSTEP_SUBMIT_BACK"] = "Вернуться в список";


$MESS["INTERLABS_FEEDBACKFORM_EVENT_NAME"] ="Message feedback form (Interlabs - form)";
$MESS["INTERLABS_FEEDBACKFORM_EVENT_DESCRIPTION"] =<<<EOF
#SUBJECT# - тема
#EMAIL_FROM# - от 
#EMAIL_TO# - кому
#FIO# - имя
#EMAIL# - email
#PHONE# - телефон
#BODY# - как название:значение\r\n
EOF;
