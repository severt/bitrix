<?php
/**
 * Created by PhpStorm.
 * User: akorolev
 * Date: 01.10.2018
 * Time: 10:11
 */

$MESS["INTERLABS_FEEDBACKFORM_NAME"] = "Interlabs - form";
$MESS["INTERLABS_FEEDBACKFORM_DESCRIPTION"] = "Interlabs - form";
$MESS["INTERLABS_FEEDBACKFORM_PARTNER_NAME"] = "Interlabs";
$MESS["INTERLABS_FEEDBACKFORM_PARTNER_URI"] = "https://www.interlabs.ru/";

$MESS["INTERLABS_FEEDBACKFORM_INSTALL_ERROR_VERSION"] = "Version of the main module 14 below. D7 technology required by the module is not supported. Please update your system.";
$MESS["INTERLABS_FEEDBACKFORM_INSTALL_TITLE"] = "Install the module";
$MESS["INTERLABS_FEEDBACKFORM_UNINSTALL_TITLE"] = "Uninstalling the module";


$MESS["INTERLABS_FEEDBACKFORM_STEP_BEFORE"] = "Module";
$MESS["INTERLABS_FEEDBACKFORM_STEP_AFTER"] = "installed";
$MESS["INTERLABS_FEEDBACKFORM_STEP_SUBMIT_BACK"] = "Back to list";


$MESS["INTERLABS_FEEDBACKFORM_UNSTEP_BEFORE"] = "Module";
$MESS["INTERLABS_FEEDBACKFORM_UNSTEP_AFTER"] = "delete";
$MESS["INTERLABS_FEEDBACKFORM_UNSTEP_SUBMIT_BACK"] = "Back to list";

$MESS["INTERLABS_FEEDBACKFORM_EVENT_NAME"] = "Send feedback form (Interlabs - form)";
$MESS["INTERLABS_FEEDBACKFORM_EVENT_DESCRIPTION"] = <<<EOF
#SUBJECT# - subject of message
#EMAIL_FROM# - from
#EMAIL_TO# - to
#FIO# - name of user
#EMAIL# - email
#PHONE# - phone of user
#BODY# - as label:data\r\n
EOF;
