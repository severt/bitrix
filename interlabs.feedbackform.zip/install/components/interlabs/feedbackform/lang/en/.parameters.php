<?php
/**
 * Created by PhpStorm.
 * User: akorolev
 * Date: 05.10.2018
 * Time: 11:58
 */

$MESS ["EMAIL_FROM"] = "Where to send email from [default set in module options]";
$MESS ["EMAIL_TO"] = "Where to send email [default set in module options]";
$MESS["SUBJECT"] = "Email header";
$MESS["USE_CAPTCHA"] = "Use captcha";
$MESS ["EVENT_TYPE"] = "Mail event Type";
$MESS["MESSAGE_ID"] = "ID mail template";
$MESS ["IBLOCK_TYPE"] = "Info block Type";
$MESS["IBLOCK_ID"] = "ID of the information block";
$MESS ["FIELD_CHECK"] = "List of fields to be checked";
$MESS["AGREE_PROCESSING"] = "I Agree to the processing of";
$MESS["MAX_FILE_COUNT"] = "Maximum number of files";
$MESS["MAX_FILE_SIZE"] = "Maximum size MByte";

$MESS["FORM_ID"] = "Form id";

$MESS['IBLOCK_FIELDS_USE'] = 'The properties of the InfoBlock on the form';
$MESS['IBLOCK_FIELD_EMAIL'] = 'Field email';
$MESS['IBLOCK_FIELD_PHONE'] = 'Field phone';

$MESS['AJAX_MODE'] = 'AJAX';