<?php
/**
 * Created by PhpStorm.
 * User: akorolev
 * Date: 05.10.2018
 * Time: 11:58
 */

$MESS["COMPONENT_NAME"] = "Feedback form";
$MESS["COMPONENT_DESCRIPTION"] = "Form for sending feedback via email and saving to IB";
