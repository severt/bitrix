<?php
/**
 * Created by PhpStorm.
 * User: akorolev
 * Date: 01.11.2018
 * Time: 14:48
 */

$MESS["SUBJECT_DEFAULT"] = "Feedback form";


$MESS["ERROR_NO_CAPTCHA_CODE"] = "You have not entered a captcha code";

$MESS["ERROR_CAPTCHA_CODE_WRONG"] = "The code from the picture is filled incorrectly";

$MESS["ERROR_AGREE_REQUIRED"] = "You must agree to the processing";


$MESS["ERROR_ERROR_TO_MANY_FILES"] = "Too many files";

$MESS["ERROR_ERROR_FILE_SIZE_BIG"] = "File is too big";



$MESS["ERROR_ERROR_FIELD_REQUIRED"] = "Required to fill";