<?php
/**
 * Created by PhpStorm.
 * User: akorolev
 * Date: 05.10.2018
 * Time: 11:58
 */

$MESS["COMPONENT_NAME"] = "Форма обратной связи";
$MESS["COMPONENT_DESCRIPTION"] = "Форма для отправки обратной связи по почте и сохранении в ИБ";
