<?php
/**
 * Created by PhpStorm.
 * User: akorolev
 * Date: 01.11.2018
 * Time: 14:48
 */

$MESS["SUBJECT_DEFAULT"] = "Форма обратной связи";


$MESS["ERROR_NO_CAPTCHA_CODE"] = "Не введен защитный код";

$MESS["ERROR_CAPTCHA_CODE_WRONG"] = "Код с картинки заполнен не правильно";

$MESS["ERROR_AGREE_REQUIRED"] = "Необходимо дать согласие на обработку";


$MESS["ERROR_ERROR_TO_MANY_FILES"] = "Слишком много файлов";

$MESS["ERROR_ERROR_FILE_SIZE_BIG"] = "Слишком большой файл";



$MESS["ERROR_ERROR_FIELD_REQUIRED"] = "Обязательно для заполнения";

$MESS['AJAX_MODE'] = 'AJAX';