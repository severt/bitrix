<?php
/**
 * Created by PhpStorm.
 * User: akorolev
 * Date: 05.10.2018
 * Time: 11:58
 */

$MESS["EMAIL_FROM"] = "Откуда отправлять письмо [по умолчанию задано в опциях модуля]";
$MESS["EMAIL_TO"] = "Куда отправлять письмо [по умолчанию задано в опциях модуля]";
$MESS["SUBJECT"] = "Заголовок письма";
$MESS["USE_CAPTCHA"] = "Использовать капчу";
$MESS["EVENT_TYPE"] = "Тип почтового события";
$MESS["MESSAGE_ID"] = "ID почтового шаблона";
$MESS["IBLOCK_TYPE"] = "Тип инфоблока";
$MESS["IBLOCK_ID"] = "ID инфоблока";
$MESS["FIELD_CHECK"] = "Должны быть заполнены";
$MESS["AGREE_PROCESSING"] = "Согласен на обработку";
$MESS["MAX_FILE_COUNT"] = "Максимальное кол-во файлов";
$MESS["MAX_FILE_SIZE"] = "Максимальный размер, MByte";

$MESS["FORM_ID"] = "ID формы";


$MESS['IBLOCK_FIELDS_USE'] = 'Свойства инфоблока на форме';
$MESS['IBLOCK_FIELD_EMAIL'] = 'Поле email';
$MESS['IBLOCK_FIELD_PHONE'] = 'Поле телефон';

$MESS['AJAX_MODE'] = 'AJAX';