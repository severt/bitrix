<?php
/**
 * Created by PhpStorm.
 * User: akorolev
 * Date: 01.10.2018
 * Time: 10:45
 */

$MESS["fio"] = "Ф.И.О";
$MESS["phone"] = "Телефон";
$MESS["email"] = "email";
$MESS["CAPTCHA_ENTER_CODE"] = "Введите код с картинки:";

$MESS["AGREE_PROCESSING"] = "Согласен на обработку";
$MESS["AGREE_PROCESSING_DIALOG_TITLE"] = "Соглашение";

$MESS["FORM_POPUP_SHOW_BUTTON"] = "Обратный звонок";
$MESS["FORM_TITLE"] = "Заголовок";
$MESS["FORM_SEND"] = "Отправить";
$MESS["FORM_CLOSE"] = "Закрыть";
$MESS["FORM_SAVED"] = "Сохранено";


$MESS['ERROR_FILE_TO_MANY_FILES']='Слишком много файлов';
$MESS['ERROR_FILE_SIZE_BIG']='Размер файла слишком велик';
$MESS['ERROR_FIELD_REQUIRED']='Заполните поле';

$MESS['JQUERY_VALIDATOR_MESSAGES']=<<<EOF
var __validatorMessages={
    required: "Заполните",  
};
EOF;


$MESS['INPUT_FILE_DEFAULT']='Файл не выбран';

