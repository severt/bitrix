<?php
/**
 * Created by PhpStorm.
 * User: akorolev
 * Date: 01.10.2018
 * Time: 10:45
 */

$MESS["fio"] = "Name";
$MESS["phone"] = "Phone";
$MESS["email"] = "email";
$MESS["CAPTCHA_ENTER_CODE"] = "Enter the code from the image:";

$MESS["AGREE_PROCESSING"] = "I agree to the processing of";
$MESS["AGREE_PROCESSING_DIALOG_TITLE"] = "Agreement";

$MESS["FORM_POPUP_SHOW_BUTTON"] = "show";

$MESS["FORM_TITLE"] = "Title";
$MESS["FORM_SEND"] = "Send";
$MESS["FORM_CLOSE"] = "Close";
$MESS["FORM_SAVED"] = "Saved";


$MESS['ERROR_FILE_TO_MANY_FILES']='To many files';
$MESS['ERROR_FILE_SIZE_BIG']='File is so big';
$MESS['ERROR_FIELD_REQUIRED']='Required';

$MESS['JQUERY_VALIDATOR_MESSAGES']=<<<EOF
var __validatorMessages={
    required: "Заполните",  
};
EOF;

$MESS['INPUT_FILE_DEFAULT']='No file chosen';