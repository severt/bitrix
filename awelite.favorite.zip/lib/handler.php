<?php

namespace Awelite\Favorite;

use Bitrix\Catalog\PriceTable;
use Bitrix\Iblock\ElementTable;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Event;
use Bitrix\Main\Loader;
use Bitrix\Main\Type\DateTime;
use Awelite\Favorite\Entity\FavoritesTable;
use Awelite\Favorite\Entity\PriceChangeFavoriteTable;
use Awelite\Favorite\Tools\Helper;

/**
 * Class Handler
 * @package Awelite\Favorite
 */
class Handler
{
    /**
     * @param array $data
     * @return array
     */
    public static function onTriggerList(array $data = []): array
    {
        if (Option::get('awelite.favorite', 'mailing') === 'Y') {
            $data['TRIGGER'] = [
                '\Awelite\Favorite\Triggers\SenderProductsInFavorite',
            ];
        }

        return $data;
    }

    /**
     * @param \Bitrix\Main\ORM\Event $arFields
     */
    public static function onAfterUpdatePriceHandler(\Bitrix\Main\ORM\Event $arFields):void
    {
        try {
            if (!Loader::includeModule('catalog')) return;
            if (!Loader::includeModule('iblock')) return;

            $parameters = $arFields->getParameter('fields');

            $element = ElementTable::getList([
                'select' => ['*', 'PRICE_LIST'],
                'filter' => ['=ID' => (int) $parameters['PRODUCT_ID']],
                'runtime' => [
                    'PRICE_LIST' => [
                        'data_type' => PriceTable::class,
                        'reference' => [
                            '=ref.PRODUCT_ID' => 'this.ID',
                        ],
                        'join_type' => 'inner'
                    ],
                ],
            ])->fetch();

            if (empty($element)) {
                return;
            }

            if ($parameters['PRICE'] < $element['IBLOCK_ELEMENT_PRICE_LIST_PRICE']) {
                $parameters['NAME'] = $element['NAME'];
                $res = PriceChangeFavoriteTable::getList([
                    'filter' => ['UF_PRODUCT_ID' => $parameters['PRODUCT_ID']]
                ]);
                if ($dbRes = $res->fetch()) {
                    PriceChangeFavoriteTable::delete($dbRes['ID']);
                }
                $id = PriceChangeFavoriteTable::getList([
                    'filter' => [
                        'UF_PRODUCT_ID' => $parameters['PRODUCT_ID']
                    ]
                ])->fetch()['ID'];

                if (!empty($id)) PriceChangeFavoriteTable::delete($id);

                PriceChangeFavoriteTable::add([
                    'UF_PRODUCT_ID' => $parameters['PRODUCT_ID'],
                    'UF_PRICE' => $parameters['PRICE'],
                    'UF_OLD_PRICE' => $element['IBLOCK_ELEMENT_PRICE_LIST_PRICE'],
                    'UF_DATE' => new DateTime(),
                ]);
            }
        } catch (\Exception $e) {
            Helper::log($e->getMessage());
        }
    }

    /**
     * @param $arUser
     * @throws \Bitrix\Main\ArgumentException
     * @throws \Bitrix\Main\ObjectPropertyException
     * @throws \Bitrix\Main\SystemException
     */
    public static function OnAfterUserAuthorizeHandler($arUser): void
    {
        try {
            $objCookieFav = new Cookies();
            $arrCookies = $objCookieFav->getArray();

            $userId = (int) $arUser['user_fields']['ID'];

            $elementsTable = FavoritesTable::getList([
                'select' => ['*'],
                'filter' => ['UF_OWNER' => $userId]
            ])->fetchAll();

            //������ ������� ID ����� ����� ���������� ���� UF_SITE_ID
            foreach ($elementsTable as $element) {
                if (is_null($element['UF_SITE_ID'])) {
                    $favoriteObj = new FavoritesTable($element['UF_IBLOCK'], $element['UF_ENTITY']);
                    $favoriteObj->updateElement($element['ID']);
                }
            }

            $helper = new Helper();
            $tableFormat = $helper->transformCookieFormat($elementsTable);

            // ��������� ����������� ����� � ��
            $dif = self::compareCookiesTable($arrCookies, $tableFormat);

            if ($dif !== []) {
                // ���������� � �� ������������� ���������
                foreach ($dif as $siteKey => $iblockArr) {
                    foreach ($iblockArr as $iblockId => $arrEntityId) {
                        foreach ($arrEntityId as $elementId) {
                            $favoriteObj = new FavoritesTable($iblockId, $elementId, $siteKey);
                            $favoriteObj->addElement();
                        }
                    }
                }
            }

            // ����������� ������ ����� � ��
            if (!empty($arrCookies)) {
                $newCookie = self::mergeArrays($arrCookies, $tableFormat);
            }

            // ���� �� ��������� ���������, ���������� ������ �� �������
            $cookie = $newCookie ?? $tableFormat;

            $arrCookies = $cookie;

            // ������� ������ �����
            if (!empty($arrSiteCookies)) {
                $objCookieFav->clear();
            }

            // ��������� ����� �����
            $objCookieFav->set($arrCookies);
        } catch (\Exception $e) {
            Helper::log($e->getMessage());
        }
    }

    public static function OnAfterUserLogoutHandler(): void
    {
        try {
            $objCookieFav = new Cookies();
            $objCookieFav->clear();
        } catch (\Exception $e) {
            Helper::log($e->getMessage());
        }
    }

    /**
     * @param array $arrCookies
     * @param array $arrTable
     * @return array
     */
    private static function compareCookiesTable(array $arrCookies, array $arrTable): array
    {
        $diff = [];

        foreach ($arrCookies as $siteKey => $iblockArr) {
            if (isset($arrTable[$siteKey])) {
                foreach ($iblockArr as $iblockId => $arrEntityId) {
                    if (isset($arrTable[$siteKey][$iblockId])) {
                        $difference = array_diff($arrEntityId, $arrTable[$siteKey][$iblockId]);
                        if (!empty($difference)) {
                            $diff[$siteKey][$iblockId] = $difference;
                        }
                    } else {
                        $diff[$siteKey][$iblockId] = $arrEntityId;
                    }
                }
            } else {
                $diff[$siteKey] = $iblockArr;
            }
        }

        return $diff;
    }

    /**
     * @param array $arrCookies
     * @param array $arrTable
     * @return array
     */
    private static function mergeArrays(array $arrCookies, array $arrTable): array
    {
        $result = $arrCookies;

        foreach ($arrTable as $siteKey => $iblockArr) {
            if (isset($result[$siteKey])) {
                foreach ($iblockArr as $iblockId => $arrEntityId) {
                    if (isset($result[$siteKey][$iblockId])) {
                        $result[$siteKey][$iblockId] = array_unique(array_merge($result[$siteKey][$iblockId], $arrEntityId));
                    } else {
                        $result[$siteKey][$iblockId] = $arrEntityId;
                    }
                }
            } else {
                $result[$siteKey] = $iblockArr;
            }
        }

        return $result;
    }
}