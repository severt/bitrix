<?

namespace Awelite\Favorite\Entity;

use Awelite\Favorite\Tools\Helper;
use Bitrix\Iblock\ElementTable;
use Bitrix\Main\ArgumentNullException;
use Bitrix\Main\Entity;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\SystemException;
use Bitrix\Main\Type\DateTime;
use Bitrix\Main\Loader;

class FavoritesTable extends Entity\DataManager
{
    private int $iblockId;
    private int $elementId;
    private string $siteId;

    /**
     * FavoritesTable constructor.
     * @param int $iblockId
     * @param int $elementId
     */
    public function __construct(int $iblockId, int $elementId, string $siteId = null)
    {
        $this->iblockId = $iblockId;
        $this->elementId = $elementId;
        $this->siteId = $siteId ?? Helper::getSiteId();
    }

    /**
     * @return string
     */
    public static function getTableName(): string
    {
        return 'awelite_favorites';
    }

    /**
     * @return string
     */
    public static function getHlTableName(): string
    {
        return 'AweliteFavorites';
    }

    /**
     * @return array
     */
    public static function getMap(): array
    {
        $arFields = [];
        try {
            $arFields = [
                new Entity\IntegerField('ID', [
                    'primary' => true,
                    'autocomplete' => true
                ]),
                new Entity\IntegerField('UF_OWNER'),
                new Entity\IntegerField('UF_IBLOCK'),
                new Entity\IntegerField('UF_ENTITY'),
                new Entity\DatetimeField('UF_DATE'),
                new Entity\ReferenceField(
                    'ELEMENT',
                    'Bitrix\Iblock\ElementTable',
                    [
                        '=this.UF_ENTITY' => 'ref.ID',
                    ]
                ),
                new Entity\StringField('UF_SITE_ID'),
            ];
        } catch (\Exception $e) {
        }

        return $arFields;
    }

    /**
     * @return int
     * @throws ArgumentNullException
     * @throws SystemException
     * @throws \Bitrix\Main\ArgumentException
     * @throws \Bitrix\Main\ObjectPropertyException
     * @throws \Exception
     */
    public function addElement(): int
    {
        global $USER;
        if (!$USER->IsAuthorized()) {
            throw new SystemException('Error');
        }

        if (!Loader::includeModule('iblock')) {
            throw new \Exception(Loc::getMessage('AWELITE_FAVORITE_NOT_INSTALL_IBLOCK'));
        }

        $elem = ElementTable::getList([
            'filter' => ['ID' => $this->elementId]
        ])->fetch();

        if (empty($elem)) {
            throw new ArgumentNullException(Loc::getMessage('AWELITE_FAVORITE_ELEMENT_FIND_ERROR'));
        }

        $userId = $USER->GetID();

        $rs = self::add([
            'UF_OWNER' => $userId,
            'UF_ENTITY' => $this->elementId,
            'UF_IBLOCK' => $this->iblockId,
            'UF_DATE' => new DateTime(),
            'UF_SITE_ID' => $this->siteId,
        ]);

        if ($rs->isSuccess()) {
            $result = $rs->getId();
        } else {
            throw new SystemException(implode(', ', $rs->getErrorMessages()));
        }

        return $result;
    }

    /**
     * @param int $fieldId
     * @return bool
     * @throws ArgumentNullException
     * @throws SystemException
     * @throws \Bitrix\Main\ArgumentException
     * @throws \Bitrix\Main\LoaderException
     * @throws \Bitrix\Main\ObjectPropertyException
     */
    public function updateElement(int $fieldId): bool
    {
        global $USER;
        if (!$USER->IsAuthorized()) {
            throw new SystemException('Error');
        }

        if (!Loader::includeModule('iblock')) {
            throw new \Exception(Loc::getMessage('AWELITE_FAVORITE_NOT_INSTALL_IBLOCK'));
        }

        $elem = self::getList([
            'filter' => ['=ID' => $fieldId]
        ])->fetch();

        if (empty($elem)) {
            throw new ArgumentNullException(Loc::getMessage('AWELITE_FAVORITE_ELEMENT_FIND_ERROR'));
        }

        $rs = self::update(
            ['ID' => $fieldId],
            [
                'UF_ENTITY' => $this->elementId,
                'UF_IBLOCK' => $this->iblockId,
                'UF_SITE_ID' => $this->siteId,
            ]
        );

        if ($rs->isSuccess()) {
            return true;
        }

        throw new  SystemException(implode(', ', $rs->getErrorMessages()));
    }

    /**
     * @return bool
     * @throws \Bitrix\Main\ArgumentException
     * @throws \Bitrix\Main\ArgumentNullException
     * @throws \Bitrix\Main\ObjectPropertyException
     * @throws \Bitrix\Main\SystemException
     * @throws \Exception
     */
    public function deleteElement(): bool
    {
        global $USER;
        if (!$USER->IsAuthorized()) {
            throw new SystemException('Error');
        }

        if (!Loader::includeModule('iblock')) {
            throw new \Exception(Loc::getMessage('AWELITE_FAVORITE_NOT_INSTALL_IBLOCK'));
        }

        $elem = self::getList([
            'filter' => ['UF_ENTITY' => $this->elementId, 'UF_IBLOCK' => $this->iblockId, 'UF_SITE_ID' => $this->siteId]
        ])->fetch();

        if (empty($elem)) {
            throw new ArgumentNullException(Loc::getMessage('AWELITE_FAVORITE_ELEMENT_FIND_ERROR'));
        }

        $rs = self::delete($elem['ID']);
        if ($rs->isSuccess()) {
            return true;
        }

        throw new  SystemException(implode(', ', $rs->getErrorMessages()));
    }
}