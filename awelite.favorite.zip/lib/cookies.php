<?php

namespace Awelite\Favorite;

use Awelite\Favorite\Tools\Helper;
use Bitrix\Main\Application;
use \Bitrix\Main\Config\Option;
use Bitrix\Main\Context;
use Bitrix\Main\Web\Cookie;

/**
 * Class Cookies
 * @package Awelite\Favorite
 */
class Cookies
{
    private string $siteId;

    public function __construct()
    {
        $this->siteId = Helper::getSiteId();
    }

    /**
     * @return string|null
     */
    public function getJson(): ?string
    {
        return Application::getInstance()->getContext()->getRequest()->getCookie('Favorites');
    }

    /**
     * @return array
     */
    public function getArray(): array
    {
        $arrCookies = json_decode($this->getJson(), true) ?? [];

        if (empty($arrCookies)) {
            return $arrCookies;
        }

        $isExistStructureSiteId = false;

        foreach ($arrCookies as $siteCookie) {
            foreach ($siteCookie as $key => $value) {
                if (is_array($value)) $isExistStructureSiteId = true;
                break;
            }
        }

        if (!array_key_exists($this->siteId, $arrCookies) && !$isExistStructureSiteId) {
            $arrCookies = $this->migrateCookies($arrCookies);
            $this->set($arrCookies);
            $arrCookies = json_decode($this->getJson(), true) ?? [];
        }

        return $arrCookies;
    }

    /**
     * �������� ������ ������ � ���� �� ����� ��������� � SITE_ID.
     *
     * @param array $oldCookies
     * @return array
     */
    private function migrateCookies(array $oldCookies): array
    {
        return [$this->siteId => $oldCookies];
    }

    public function clear(): void
    {
        Context::getCurrent()->getResponse()->addCookie(
            new Cookie('Favorites', $this->getJson(), time() - 3600 * 24 * 30)
        );
    }

    /**
     * @param int|null $iblockId
     * @return array|null
     */
    public function getIds(int $iblockId = null): ?array
    {
        $arrCookies = $this->getArray();
        $arrIds = [];

        if ($iblockId !== null) {
            $arrCookies = $arrCookies[$this->siteId][$iblockId];
            foreach ($arrCookies as $id) {
                $arrIds[] = $id;
            }

            if (empty($arrIds)) {
                return null;
            }

            return $arrIds;
        }

        foreach ($arrCookies[$this->siteId] as $cookie) {
            foreach ($cookie as $id) {
                $arrIds[] = $id;
            }
        }

        return $arrIds ?? null;
    }

    /**
     * @param array $arCookie
     */
    public function set(array $arCookie): void
    {
        $jsonCookie = json_encode($arCookie);
        $cookie = new Cookie("Favorites", $jsonCookie, time() + 3600 * 24 * 30);
        $cookie->setSecure(false);
        Application::getInstance()->getContext()->getResponse()->addCookie($cookie);
    }

    /**
     * @param int $iblockId
     * @param int $elementId
     * @return array|null
     */
    public function save(int $iblockId, int $elementId): ?array
    {
        $arrCurrentCookies = $this->getArray();

        if (!isset($arrCurrentCookies[$this->siteId][$iblockId])) {
            $arrCurrentCookies[$this->siteId][$iblockId] = [];
        }

        if (in_array($elementId, $arrCurrentCookies[$this->siteId][$iblockId])) {
            $this->delete($iblockId, $elementId);
            return $this->returnArrayMethodDelete();
        }

        $arrCurrentCookies[$this->siteId][$iblockId][] = $elementId;
        $this->set($arrCurrentCookies);

        return $this->returnArrayMethodAdd();
    }

    /**
     * @return array
     */
    private function returnArrayMethodAdd(): array
    {
        return [
            'count' => count($this->getIds()) + 1,
            'method' => 'addElement',
            'classAdd'  => Option::get('awelite.favorite', 'addClass'),
            'classDelete' => Option::get('awelite.favorite', 'removeClass'),
        ];
    }

    /**
     * @return array
     */
    private function returnArrayMethodDelete(): array
    {
        return [
            'count' => count($this->getIds()) - 1,
            'method' => 'deleteElement',
            'classAdd'  => Option::get('awelite.favorite', 'removeClass'),
            'classDelete' => Option::get('awelite.favorite', 'addClass'),
        ];
    }

    /**
     * @param int $iblockId
     * @param int $elementId
     */
    public function delete(int $iblockId, int $elementId): void
    {
        $arrCurrentCookies = $this->getArray();

        $arrIds = $arrCurrentCookies[$this->siteId][$iblockId];
        $removeKey = array_search($elementId, $arrIds);
        unset($arrCurrentCookies[$this->siteId][$iblockId][$removeKey]);

        if (count($arrCurrentCookies[$this->siteId][$iblockId]) === 0) {
            unset($arrCurrentCookies[$this->siteId][$iblockId]);
        }

        if (empty($arrCurrentCookies[$this->siteId])) {
            unset($arrCurrentCookies[$this->siteId]);
        }

        if (empty($arrCurrentCookies)) {
            $this->clear();
            return;
        }

        $this->set($arrCurrentCookies);
    }

    /**
     * @param int $iblockId
     * @param int $elementId
     */
    public function add(int $iblockId, int $elementId): void
    {
        $arrCurrentCookies = $this->getArray();
        $arrCurrentCookies[$this->siteId][$iblockId][] = $elementId;

        $this->set($arrCurrentCookies);
    }
}
