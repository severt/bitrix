<?php

namespace Awelite\Favorite\Tools;

use Bitrix\Main\Application;
use Bitrix\Main\Config\Option;

/**
 * Class Helper
 * @package Awelite\Favorite\Tools
 */
class Helper
{
    /**
     * @param array $elementsTable
     * @return array
     */
    public function transformCookieFormat(array $elementsTable): array
    {
        $tableFormatCookies = [];

        foreach ($elementsTable as $cookie) {
            $siteId = $cookie['UF_SITE_ID'] ?: self::getSiteId();
            $iblockId = $cookie['UF_IBLOCK'];

            if (!isset($tableFormatCookies[$siteId])) {
                $tableFormatCookies[$siteId] = [];
            }

            $tableFormatCookies[$siteId][$iblockId][] = $cookie['UF_ENTITY'];
        }

        return $tableFormatCookies;
    }

    /**
     * @param string $error
     */
    public static function log(string $error): void
    {
        if (Option::get('awelite.favorite', 'log') === 'Y') {
            \CEventLog::Add([
                "SEVERITY" => "SECURITY",
                "AUDIT_TYPE_ID" => "AWELITE_FAVORITE_ERROR",
                "MODULE_ID" => "awelite.favorite",
                "DESCRIPTION" => $error,
            ]);
        }
    }

    /**
     * @return string
     */
    public static function getSiteId(): string
    {
        return defined('SITE_ID') ? SITE_ID : self::detectSiteId();
    }

    /**
     * ����� ��� ��������������� ����������� SITE_ID (���� �� ��������� ���������)
     *
     * @return string
     */
    private static function detectSiteId(): string
    {
        return Application::getInstance()->getContext()->getSite();
    }
}