<?
$sSectionName="awelite.favorite";
?>