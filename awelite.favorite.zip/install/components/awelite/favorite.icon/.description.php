<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

use Bitrix\Main\Localization\Loc;

Loc::loadMessages(__FILE__);

$arComponentDescription = [
    "NAME" => Loc::getMessage('AWELITE_FAVORITE_FAVORITE_NAME'),
    "DESCRIPTION" => Loc::getMessage('AWELITE_FAVORITE_DESCRIPTION'),
    "PATH" => [
        "ID" => "awelite.favorite",
        "CHILD" => [
            "ID" => "icon",
            "NAME" => Loc::getMessage('AWELITE_FAVORITE_CHILD_NAME')
        ]
    ],
    "ICON" => "/images/icon.gif",
];