<?php

$MESS['AWELITE_FAVORITE_FAVORITE_NAME'] = 'Подсчитывает количество избранного';
$MESS['AWELITE_FAVORITE_DESCRIPTION'] = 'Подсчитывает количество избранного';
$MESS['AWELITE_FAVORITE_CHILD_NAME'] = 'Количество записей в избранном';