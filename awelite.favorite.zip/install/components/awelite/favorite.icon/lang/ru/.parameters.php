<?php

$MESS['AWELITE_FAVORITE_NAME'] = 'Ссылка на страницу с избранным';