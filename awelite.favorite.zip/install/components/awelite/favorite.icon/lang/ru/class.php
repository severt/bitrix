<?php

$MESS['INSTALL_ERROR_MODULES_AWELITE_FAVORITE'] = 'Модуль awelite.favorite не установлен';