<?php if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<a href="<?=$arResult['LINK'] ?>" id="awelite_favorites_equation">
    <i class="fa fa-heart" aria-hidden="true"></i>
    <p class="count"></p>
</a>