module.exports = {
	input: 'src/awelite.lib.js',
	output: 'dist/awelite.lib.bundle.js',
	namespace: 'BX.Awelite',
	browserslist: true,
};