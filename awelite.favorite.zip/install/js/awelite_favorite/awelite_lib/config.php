<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
{
	die();
}

return [
	'css' => 'dist/awelite.lib.bundle.css',
	'js' => 'dist/awelite.lib.bundle.js',
	'rel' => [
		'main.polyfill.core',
	],
	'skip_core' => true,
];