<?
$arModuleVersion = [
	"VERSION" => "1.0.9",
	"VERSION_DATE" => "2024-08-21 09:03:19"
];
?>