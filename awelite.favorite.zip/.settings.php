<?php
return [
    "controllers" => [
        "value" => [
            "namespaces" => [
                "\\Awelite\\Favorite\\Controllers" => "controller"
            ]
        ],
        "readonly" => true
    ]
];