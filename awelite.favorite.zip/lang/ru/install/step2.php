<?php

$MESS['MODULE_FAVORITE_IN_MENU'] = 'Вернуться в меню';
$MESS['AWELITE_FAVORITE_DOCUMENTATION_READ'] = 'Подробная настройка моудял доступна по ';
$MESS['AWELITE_FAVORITE_DOCUMENTATION'] = 'ссылке';
$MESS['AWELITE_FAVORITE_SETTINGS_PROBLEM'] = 'При возникновении проблем с работой модуля вы всегда сможете написать нам на почту ';
$MESS['AWELITE_FAVORITE_SETTINGS_PROBLEM_LINK'] = 'Здесь';

$MESS['AWELITE_FAVORITE_THANK'] = 'Спасибо за установку модуля!';
$MESS['AWELITE_FAVORITE_WAY_DESC'] = 'Настройки модуля можно найти по пути:';
$MESS['AWELITE_FAVORITE_WAY'] = 'Настройки - Модули - Awelite: Избранное.';
$MESS['AWELITE_FAVORITE_OPPORTUNITIES_TITLE'] = 'В настройках модуля можно:';
$MESS['AWELITE_FAVORITE_OPPORTUNITIES_1'] = 'Задать css-класс иконки избранного';
$MESS['AWELITE_FAVORITE_OPPORTUNITIES_2'] = 'Скопировать код компонента, для вставки на страницу';
$MESS['AWELITE_FAVORITE_OPPORTUNITIES_3'] = 'Включить логирование ошибок';
$MESS['AWELITE_FAVORITE_INSTRUCTION'] = 'Подробная инструкция модуля находится';
$MESS['AWELITE_FAVORITE_INSTRUCTION_LINK'] = 'здесь';
$MESS['AWELITE_FAVORITE_SUPPORT_TEXT'] = 'Все вопросы по работе модуля, предложения можно направить на почту';
$MESS['AWELITE_FAVORITE_GOODBYE'] = 'С уважением, компания “Авелайт”';
