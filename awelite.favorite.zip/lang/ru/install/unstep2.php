<?php

$MESS['MODULE_AWELITE_FAVORITE_IN_MENU'] = 'Вернуться в меню';