<?php

$MESS['MODULE_AWELITE_FAVORITE_NAME'] = 'Awelite: Избранное';
$MESS['MODULE_AWELITE_FAVORITE_PARTHER_NAME'] = 'Авелайт';
$MESS['MODULE_AWELITE_FAVORITE_DESCRIPTION'] = 'Модуль для сохранения элементов в избранное';
$MESS['AWELITE_FAVORITES_OPTIONS_INPUT_APPLY'] = 'Сохранить изменения';
$MESS['AWELITE_FAVORITES_OPTIONS_INPUT_DEFAULT'] = 'Настройки по умолчанию';
$MESS['AWELITE_FAVORITES_OPTIONS_TAB_GENERAL'] = 'Настройки';

$MESS['ERROR_MODULE_CATALOG'] = 'Не установлен модуль "Каталог"';
$MESS['ERROR_MODULE_IBLOCK'] = 'Не установлен модуль "Инфоблок"';

$MESS['AWELITE_FAVORITE_FIELD_OWNER'] = 'Владелец';
$MESS['AWELITE_FAVORITE_ERROR_FIELD_OWNER'] = 'Ошибка при заполнении владельца';

$MESS['AWELITE_FAVORITE_FIELD_ENTITY'] = 'Сущность';
$MESS['AWELITE_FAVORITE_ERROR_FIELD_ENTITY'] = 'Ошибка при заполнении сущности';

$MESS['AWELITE_FAVORITE_FIELD_DATE'] = 'Дата создания';
$MESS['AWELITE_FAVORITE_ERROR_FIELD_DATE'] = 'Ошибка при заполнении даты';

$MESS['AWELITE_FAVORITE_FIELD_IBLOCK_ID'] = 'Инфоблок';
$MESS['AWELITE_FAVORITE_ERROR_FIELD_IBLOCK_ID'] = 'Ошибка при заполнении Инфоблока';

$MESS['AWELITE_FAVORITE_FIELD_SITE_ID'] = 'Сайт';
$MESS['AWELITE_FAVORITE_ERROR_FIELD_SITE_ID'] = 'Ошибка при заполнении поля Сайт';

$MESS['AWELITE_FAVORITE_FIELD_PRODUCT_ID'] = 'Товар';
$MESS['AWELITE_FAVORITE_ERROR_FIELD_PRODUCT_ID'] = 'Ошибка при заполнении Товара';

$MESS['AWELITE_FAVORITE_FIELD_NEW_PRICE'] = 'Новая цена';
$MESS['AWELITE_FAVORITE_ERROR_FIELD_NEW_PRICE'] = 'Ошибка при заполнении Новой цены';

$MESS['AWELITE_FAVORITE_FIELD_OLD_PRICE'] = 'Старая цена';
$MESS['AWELITE_FAVORITE_ERROR_FIELD_OLD_PRICE'] = 'Ошибка при заполнении Старой цены';

$MESS['AWELITE_FAVORITE_FIELD_DATE_CREATE'] = 'Дата создания';
$MESS['AWELITE_FAVORITE_ERROR_FIELD_DATE_CREATE'] = 'Ошибка при заполнении даты';

$MESS['AWELITE_FAVORITE_HELLO'] = 'Установка модуля "Awelite: Избранное"';