<?php

$MESS['AWELITE_FAVORITE_NAME_TRIGGER'] = 'Снизилась цена на товары в избранном';