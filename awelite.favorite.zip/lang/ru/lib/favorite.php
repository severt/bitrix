<?php

$MESS['AWELITE_FAVORITE_AUTH_USER_ERROR'] = 'Ошибка авторизации';
$MESS['AWELITE_FAVORITE_ELEMENT_FIND_ERROR'] = 'Элемент не найден';
$MESS['AWELITE_FAVORITE_NOT_INSTALL_IBLOCK'] = 'Модуль iblock не установлен';