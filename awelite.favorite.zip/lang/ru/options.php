<?php

$MESS['AWELITE_FAVORITE_OPTIONS_INPUT_APPLY'] = 'Сохранить настройки';
$MESS['AWELITE_FAVORITE_OPTIONS_INPUT_DEFAULT'] = 'По умолчанию';
$MESS['AWELITE_FAVORITE_OPTIONS_TAB_GENERAL'] = 'Настройки';
$MESS['AWELITE_FAVORITE_SETTINGS_ADD_CLASS'] = 'css-класс иконки "товар в избранном"';
$MESS['AWELITE_FAVORITE_SETTINGS_REMOVE_CLASS'] = 'css-класс иконки "товар не добавлен в избранное"';
$MESS['AWELITE_FAVORITE_CHECKBOX_MAILING'] = 'Уведомлять пользователей о снижении стоимости товара';
$MESS['AWELITE_FAVORITE_CHECKBOX_LOG'] = 'Логировать ошибки работы модуля в журнал события Битрикс';
$MESS['AWELITE_FAVORITE_MODULE_NOT_INSTALL_EMAIL'] = 'Для работы триггерных рассылок, требуется установленный модуль "Email-маркетинг"';

$MESS['AWELITE_FAVORITE_DOCUMENTATION'] = 'Документация';

$MESS['AWELITE_FAVORITE_SNIPPET_1'] = 'Код вызова компонента favorite.icon';