<?php
$MESS ["ITTOWER_SIMPLEPROPS_MODULE_DESC"] = "Позволяет редактирование значений параметров свойств инфоблоков в списке, при режиме
 использования параметров свойств в компонентах и формах.";
$MESS ["ITTOWER_SIMPLEPROPS_MODULE_NAME"] = "Множественное редактирование параметров свойств инфоблоков";
$MESS ["ITTOWER_SIMPLEPROPS_INSTALL_ERROR_VERSION"] = "При установке модуля произошла ошибка. Ядро не поддерживает D7";
$MESS ["ITTOWER_SIMPLEPROPS_INSTALL_TITLE"] = "Установка завершена успешно";
$MESS ["ITTOWER_SIMPLEPROPS_PARTNER_NAME"] = "ITtower";
$MESS ["ITTOWER_SIMPLEPROPS_INSTALL_TITLE"] = "Установка";
$MESS ["ITTOWER_SIMPLEPROPS_UNINSTALL_TITLE"] = "Удаление";
$MESS ["ITTOWER_SIMPLEPROPS_DENIED"] = "Доступ запрещен";
$MESS ["ITTOWER_SIMPLEPROPS_READ_COMPONENT"] = "Чтение";
$MESS ["ITTOWER_SIMPLEPROPS_WRITE_SETTINGS"] = "Запись";
$MESS ["ITTOWER_SIMPLEPROPS_FULL"] = "Полный доступ";