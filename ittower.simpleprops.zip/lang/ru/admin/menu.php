<?php
$MESS ["ITTOWER_SIMPLEPROPS_MENU_TEXT"] = "Редактирование свойств";
$MESS ["ITTOWER_SIMPLEPROPS_MENU_HEADER_TEXT"] = "Управление свойствами инфоблока";
$MESS ["ITTOWER_SIMPLEPROPS_HEADER_TITLE"] = "Управление свойствами инфоблока (множественное редактирование свойств)";
$MESS ["ITTOWER_SIMPLEPROPS_MENU_TITLE"] = "Управление свойствами инфоблока в режиме
 использования параметров свойств в компонентах и формах";
