<?
$MESS ["ITTOWER_SIMPLEPROPS_SHOW_DETAIL"] = "Показывать на детальной странице элемента";
$MESS ["ITTOWER_SIMPLEPROPS_SHOW_LIST"] = "Показывать на странице списка элементов";
$MESS ["ITTOWER_SIMPLEPROPS_SHOW_FILTER"] = "Отображать в фильтре";
$MESS ["ITTOWER_SIMPLEPROPS_NO_PROPERTY"] = "Инфоблок не содержит никаких свойств.";