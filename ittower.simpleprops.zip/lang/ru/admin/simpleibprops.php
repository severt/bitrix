<?php
$MESS ["ITTOWER_SIMPLEPROPS_TITLE"] = "Редактирование свойств";
$MESS ["ITTOWER_SIMPLEPROPS_CHOOSE_IB"] = "Выберите инфоблок";
$MESS ["ITTOWER_SIMPLEPROPS_DESCRIPTION"] = "<span class=\"required\">Внимание! Отключено использование параметров свойств в компонентах и формах. </span> 
Изменения параметров свойств не будут работать в данном случае.<br>
Перейдите в настройки модуля <a href='settings.php?lang=ru&mid=iblock&mid_menu=1'>\"Информационные блоки\"</a> 
и активируйте чекбокс \"Использовать параметры свойств в компонентах и формах\".
            Подробнее  <a href=\"https://dev.1c-bitrix.ru/learning/course/index.php?COURSE_ID=42&LESSON_ID=1986\" target=\"_blank\">здесь</a>";
$MESS ["ITTOWER_SIMPLEPROPS_SAVE_BTN"] = "Сохранить";