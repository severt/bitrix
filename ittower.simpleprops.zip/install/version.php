<?
$arModuleVersion = array(
    "VERSION" => "1.0.0",
    "VERSION_DATE" => "2021-06-13 23:00:00"
); 
