<?
$MESS["NEWSITE_TREEPROPERTY_INSTALL_NAME"] = "Отображение дерева свойств инфоблока";
$MESS["NEWSITE_TREEPROPERTY_INSTALL_DESCRIPTION"] = "Отображение дерева разделов и привязанных к ним свойств инфоблока";
$MESS["NEWSITE_TREEPROPERTY_INSTALL_COPMPANY_NAME"] = "Новый сайт";