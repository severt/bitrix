<?php
$MESS['NEWSITE_TREEPROPERTY_NOT_INHERITED'] = 'Непривязанные св-ва (#COUNT# шт.)';
$MESS['NEWSITE_TREEPROPERTY_IBLOCK'] = 'Корневой уровень инфоблока';