<?
$MESS["NEWSITE_TREEPROPERTY_FIELD_SETTINGS_LIST"] = "Отображение дерева свойств инфоблока";
$MESS["NEWSITE_TREEPROPERTY_TYPE_BLOCK"] = "Тип инфоблока";
$MESS["NEWSITE_TREEPROPERTY_IBLOCK_ID"] = "ID инфоблока";