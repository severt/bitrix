<?
$MESS["NEWSITE_TREEPROPERTY_MODULE_NAME"] = "Отображение дерева свойств инфоблока";
$MESS["NEWSITE_TREEPROPERTY_MODULE_DESC"] = "Отображение дерева разделов и привязанных к ним свойств инфоблока";