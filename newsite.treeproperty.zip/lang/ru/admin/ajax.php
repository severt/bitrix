<?
$MESS["NEWSITE_TREEPROPERTY_INVALID_REQUEST"] = "Некорректный запрос";
