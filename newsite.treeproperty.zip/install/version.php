<?
$arModuleVersion = [
	"VERSION" => "1.0.6",
	"VERSION_DATE" => "2023-04-17 12:00:00"
];
?>