<?
$arModuleVersion = [
	"VERSION" => "1.3.0",
	"VERSION_DATE" => "2024-09-02 21:36:45"
];
?>