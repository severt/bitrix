<?
$arModuleVersion = array(
	"VERSION" => "1.2.0",
	"VERSION_DATE" => "2023-01-06 19:39:12"
);
?>