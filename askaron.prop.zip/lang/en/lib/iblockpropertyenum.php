<?
$MESS['ASKARON_PROP_IBLOCK_PROPERTY_ENUM_DESCRIPTION'] = 'Привязка по ID к варианту значения для свойства типа список (askaron.prop)';
$MESS['ASKARON_PROP_IBLOCK_PROPERTY_ENUM_SETTINGS_FORM'] = 'Настройки списка';
$MESS['ASKARON_PROP_IBLOCK_PROPERTY_ENUM_SETTINGS_LINK_PROPERTY_ID'] = 'Свойство типа список, варианты значений которого выводить';
$MESS['ASKARON_PROP_IBLOCK_PROPERTY_ENUM_SETTINGS_LINK_PROPERTY_ID_EMPTY'] = '(выберите)';
$MESS['ASKARON_PROP_IBLOCK_PROPERTY_ENUM_SETTINGS_SIZE'] = 'Размер списка для отображения';
$MESS['ASKARON_PROP_IBLOCK_PROPERTY_ENUM_SETTINGS_SHOW_KEY'] = 'Показывать ID в списке';


$MESS['ASKARON_PROP_NO_VALUE'] = '(не установлено)';
$MESS['ASKARON_PROP_FIELD_DESCRIPTION'] = 'Описание';
$MESS['ASKARON_PROP_ANY_VALUE'] = '(любой)';