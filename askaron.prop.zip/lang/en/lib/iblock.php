<?php
$MESS['ASKARON_PROP_IBLOCK_DESCRIPTION'] = 'Привязка к инфоблоку по ID (askaron.prop)';
$MESS['ASKARON_PROP_NO_VALUE'] = '(не установлено)';
$MESS['ASKARON_PROP_FIELD_DESCRIPTION'] = 'Описание';
$MESS['ASKARON_PROP_ANY_VALUE'] = '(любой)';