<?
$MESS['ASKARON_PROP_IBLOCK_PROPERTY_DESCRIPTION'] = 'Привязка к свойству инфоблока по ID (askaron.prop)';
$MESS['ASKARON_PROP_NO_VALUE'] = '(не установлено)';
$MESS['ASKARON_PROP_FIELD_DESCRIPTION'] = 'Описание';
$MESS['ASKARON_PROP_ANY_VALUE'] = '(любой)';