<?
$MESS['ASKARON_PROP_PRICE_DESCRIPTION'] = 'Привязка к типу цен по ID (askaron.prop)';
$MESS['ASKARON_PROP_NO_VALUE'] = '(не установлено)';
$MESS['ASKARON_PROP_FIELD_DESCRIPTION'] = 'Описание';
$MESS['ASKARON_PROP_ANY_VALUE'] = '(любой)';