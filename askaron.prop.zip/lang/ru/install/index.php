<?
$MESS ['ASKARON_PROP_MODULE_PARTNER_NAME'] = "Аскарон системс";
$MESS ['ASKARON_PROP_MODULE_PARTNER_URL']= "http://askaron.ru";
$MESS ['ASKARON_PROP_MODULE_VERSION'] = '0.0.2';
$MESS ['ASKARON_PROP_MODULE_VERSION_DATE'] = '2016-11-14 14:33:26';
$MESS ['ASKARON_PROP_MODULE_NAME'] = 'Дополнительные свойства инфоблоков. Аскарон';
$MESS ['ASKARON_PROP_MODULE_DESCRIPTION'] = 'Дополнительный свойства инфоблоков: Привязка к складу по ID, Привязка к типу цен по ID, Привязка к группе пользователей по ID, Привязка к инфоблоку по ID, Привязка к свойству по ID, Привязка по ID к варианту значения для свойства типа список';
