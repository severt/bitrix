<?php
$MESS['ASKARON_PROP_GROUP_DESCRIPTION'] = 'Привязка к группе пользователей по ID (askaron.prop)';
$MESS['ASKARON_PROP_NO_VALUE'] = '(не установлено)';
$MESS['ASKARON_PROP_FIELD_DESCRIPTION'] = 'Описание';
$MESS['ASKARON_PROP_ANY_VALUE'] = '(любой)';