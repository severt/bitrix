<?php if(!defined('B_PROLOG_INCLUDED') or B_PROLOG_INCLUDED!==true) die();
	
CModule::IncludeModule('fileman');
CMedialib::Init();

$arCol = CMedialibCollection::GetList(array(
											'arFilter' => array(
																'ACTIVE' => 'Y'
																)
											)
									  );
									  
foreach($arCol as $collection){
	$arColpar[$collection['ID']]=$collection['NAME'];
}

$arComponentParameters = array(
	'GROUPS' => array(
		'GALLERY_SETTINGS' => array(
			'SORT' => 120,
			'NAME' => GetMessage('GALLERY_SETTINGS'),
		),
	),
	'PARAMETERS' => array(
		'CHOSEN_COLLECTIONS' => array(
			'PARENT' => 'GALLERY_SETTINGS',
			'NAME' => GetMessage('CHOSEN_COLLECTIONS'),
			'TYPE' => 'LIST',
			'MULTIPLE' => 'N',
			'VALUES' => $arColpar,
		),
		'SET_JQ' => Array(
			'PARENT' => 'GALLERY_SETTINGS',
			'NAME' => GetMessage('SET_JQ'),
			'TYPE' => 'CHECKBOX',
			'DEFAULT' => 'Y',
			'REFRESH' => 'Y',
		),
		'SET_FB' => Array(
			'PARENT' => 'GALLERY_SETTINGS',
			'NAME' => GetMessage('SET_FB'),
			'TYPE' => 'CHECKBOX',
			'DEFAULT' => 'Y',
			'REFRESH' => 'Y',
		)
	)
);
?>