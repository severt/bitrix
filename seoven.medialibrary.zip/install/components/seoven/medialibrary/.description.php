<?php if (!defined("B_PROLOG_INCLUDED") or B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	'NAME' => GetMessage('NAME'),
	'DESCRIPTION' => GetMessage('DESCR'),
	'ICON' => '/images/icon.gif',
	'SORT' => 10,
	'CACHE_PATH' => 'Y',
	'PATH' => array(
		'ID' => GetMessage('SECT_NAME')
	),
	'COMPLEX' => 'N'
);

?>