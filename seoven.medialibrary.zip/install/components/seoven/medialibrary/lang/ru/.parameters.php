<?php if (!defined('B_PROLOG_INCLUDED') or B_PROLOG_INCLUDED!==true) die();
	
$MESS['GALLERY_SETTINGS']              = 'Настройки галереи';
$MESS['CHOSEN_COLLECTIONS']            = 'Раздел галереи';
$MESS['MAIN_TITLE_VALUE']              = 'Фотогалерея';
$MESS['SET_JQ']                        = 'Подключить JQuery';
$MESS['SET_FB']                        = 'Подключить Fancybox';
?>