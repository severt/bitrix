<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
$MESS["seoven.medialibrary_NO_MEDIA"] = "В компоненте seoven.medialibrary не выбран раздел галереи.";