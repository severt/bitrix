<?
$MESS["seoven.medialibrary_MODULE_NAME"] = "Галерея из медиабиблиотеки";
$MESS["seoven.medialibrary_MODULE_DESC"] = "Галерея для сайта из медиабиблиотеки";
$MESS["seoven.medialibrary_PARTNER_NAME"] = "ООО СЕОВЕН";
$MESS["seoven.medialibrary_PARTNER_URI"] = "https://seoven.ru";
?>