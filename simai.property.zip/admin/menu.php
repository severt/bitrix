<?php
if (!is_object($GLOBALS['USER_FIELD_MANAGER'])) {
    return false;
}

\Bitrix\Main\Localization\Loc::loadMessages(__FILE__);

$aMenu = array();

global $USER;
$bUserIsAdmin = $USER->IsAdmin();

$bHasXRight = false;
$bHasWRight = false;
$bHasSRight = false;

if ($bUserIsAdmin || $bHasWRight || $bHasXRight || $bHasSRight) {
    $arItems = array();

    if ($bUserIsAdmin || $bHasXRight) {
        $arItems[] = array(
            'text' => GetMessage('SF_PROPERTY_TEST_FORM'),
            'url' => '/bitrix/admin/simai/sf_property_test.php?lang='.LANGUAGE_ID,
            //'more_url' => array('sf_property_test.php'),
            'module_id' => 'simai.property',
            'title' => GetMessage('SF_STORAGE_TEST_FORM_TITLE'),
        );
    }

    $aMenu[] = array(
        'parent_menu' => 'global_menu_content',
        'section' => 'simai.property',
        'sort' => 390,
        'text' => GetMessage('SF_PROPERTY_MENU_SEPARATOR'),
        'title' => GetMessage('SF_PROPERTY_MENU_SETTINGS_TITLE'),
        'icon' => 'iblock_menu_icon_settings',
        'page_icon' => 'iblock_page_icon_settings',
        'items_id' => 'menu_sf_property',
        'module_id' => 'simai.property',
        'items' => $arItems,
    );
}

return $aMenu;
