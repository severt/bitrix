<?php
require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_before.php');
\Bitrix\Main\Loader::includeSharewareModule('simai.property');
require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/simai.property/prolog.php');
\Bitrix\Main\Localization\Loc::loadMessages(__FILE__);

$request = \Bitrix\Main\Application::getInstance()->getContext()->getRequest();

require($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_after.php');

$aTabs = array(
    array('DIV' => 'tab_integer', 'TAB' => 'Number', 'ICON' => 'ib_settings', 'TITLE' => 'Number type test'),
    array('DIV' => 'tab_string', 'TAB' => 'String', 'ICON' => 'ib_settings', 'TITLE' => 'String type test'),
    array('DIV' => 'tab_datetime', 'TAB' => 'Datetime', 'ICON' => 'ib_settings', 'TITLE' => 'Datetime type test'),
    array('DIV' => 'tab_text', 'TAB' => 'Text', 'ICON' => 'ib_settings', 'TITLE' => 'Text type test'),
    array('DIV' => 'tab_list', 'TAB' => 'List', 'ICON' => 'ib_settings', 'TITLE' => 'List type test  (uses list of types)'),
    array('DIV' => 'tab_entity', 'TAB' => 'Entity', 'ICON' => 'ib_settings', 'TITLE' => 'Entity type test'),
    array('DIV' => 'tab_url', 'TAB' => 'URL', 'ICON' => 'ib_settings', 'TITLE' => 'URL type test'),
    array('DIV' => 'tab_file', 'TAB' => 'File', 'ICON' => 'ib_settings', 'TITLE' => 'File type test'),
    array('DIV' => 'tab_color', 'TAB' => 'Color', 'ICON' => 'ib_settings', 'TITLE' => 'Color type test'),
    array('DIV' => 'tab_checkbox', 'TAB' => 'Checkbox', 'ICON' => 'ib_settings', 'TITLE' => 'Checkbox type test'),
    array('DIV' => 'tab_sort', 'TAB' => 'Sortable list', 'ICON' => 'ib_settings', 'TITLE' => 'Sortable list type test  (uses list of types)'),
    array('DIV' => 'tab_link', 'TAB' => 'Link', 'ICON' => 'ib_settings', 'TITLE' => 'URL link with protocol'),
    array('DIV' => 'tab_phone', 'TAB' => 'Phone', 'ICON' => 'ib_settings', 'TITLE' => 'Phone (masked) test'),
    array('DIV' => 'tab_ymap', 'TAB' => 'Yandex map', 'ICON' => 'ib_settings', 'TITLE' => 'Yandex map test'),
);
$tabControl = new CAdminTabControl('tabControl', $aTabs);

$tabControl->Begin();

$bVarsFromForm = false;

if ($request->getRequestMethod() == 'POST') {
    $bVarsFromForm = true;
}
?>
<form enctype="multipart/form-data" name="testform" method="post" action="<?=$APPLICATION->GetCurPage()?>?lang=<?=LANGUAGE_ID?>">

<?// Number
$tabControl->BeginNextTab();?>
<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>
<td width="60%">			
<?php
$values = array(1, 22, -333);
\SIMAI\Property::view(
    'number', // type
    '',// template
    $values, // values
    array() // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">			
<?php
$values = array(1, 22, -333);
if ($bVarsFromForm) {
    $values = $request->getPost('prop_1_value');
}
\SIMAI\Property::edit(
    'number', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_1_value',
        'multiple' => 'Y',
        'cols' => 10,
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">			
<?php
$values = array(11, 22);
if ($bVarsFromForm) {
    $values = array($request->getPost('find_prop_1_from'), $request->getPost('find_prop_1_to'));
}
\SIMAI\Property::filter(
    'number', // type
    '', // template
    $values, // values
    array(
        'field_name_from' => 'find_prop_1_from',
        'field_name_to' => 'find_prop_1_to',
        'cols' => 8
    ) // params
);
?>
</td>
</tr>

<?// String
$tabControl->BeginNextTab();?>
<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>
<td width="60%">			
<?php
$values = array('a', 'bb', 'ccc');
\SIMAI\Property::view(
    'string', // type
    '',// template
    $values, // values
    array(
        'strip_tags' => 'N',
        'max_length' => 50
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">			
<?php
$values = array('a', 'bb', 'ccc');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_2_value');
}
\SIMAI\Property::edit(
    'string', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_2_value',
        'multiple' => 'Y',
        'cols' => 30,
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">			
<?php
$values = array('bb');
if ($bVarsFromForm) {
    $values = $request->getPost('find_prop_2');
}
\SIMAI\Property::filter(
    'string', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'find_prop_2',
        'cols' => 50
    ) // params
);
?>
</td>
</tr>

<?// Datetime
$tabControl->BeginNextTab();?>
<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>
<td width="60%">			
<?php
$values = array('01.01.2017 12:30:00');
\SIMAI\Property::view(
    'datetime', // type
    '',// template
    $values, // values
    array() // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">			
<?php
$values = array('01.01.2017 12:30:00');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_3_value');
}
\SIMAI\Property::edit(
    'datetime', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_3_value',
        'multiple' => 'Y',
        'cols' => 18,
        'form_name' => 'testform',
        'show_time' => 'Y',
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">			
<?php
$values = array('01.01.2017 12:00:00', '01.01.2017 13:00:00');
if ($bVarsFromForm) {
    $values = array($request->getPost('find_prop_3_from'), $request->getPost('find_prop_3_to'));
}
\SIMAI\Property::filter(
    'datetime', // type
    '', // template
    $values, // values
    array(
        'field_name_from' => 'find_prop_3_from',
        'field_name_to' => 'find_prop_3_to',
        'form_name' => 'testform'
    ) // params
);
?>
</td>
</tr>

<?// Text
$tabControl->BeginNextTab();?>
<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>
<td width="60%">			
<?php
$values = array('Text <b>is so</b> text');
\SIMAI\Property::view(
    'text', // type
    '',// template
    $values, // values
    array(
        'strip_tags' => 'N',
        'max_length' => 200
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">
<?php
$values = array('Text <b>is so</b> text');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_4_value');
}
\SIMAI\Property::edit(
    'text', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_4_value',
        'multiple' => 'Y',
        'cols' => 40,
        'rows' => 5,
        'multiple_cnt' => 2,
        'text_type' => 'visual',
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">			
<?php
$values = array('text');
if ($bVarsFromForm) {
    $values = $request->getPost('find_prop_4');
}
\SIMAI\Property::filter(
    'text', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'find_prop_4',
        'cols' => 50
    ) // params
);
?>
</td>
</tr>

<?// List
$tabControl->BeginNextTab();

$proplist = \SIMAI\Property::types_list();

$all_types_names = array();
foreach ($proplist as $type)
{
	$all_types_names[$type['id']] = $type['name'];
}
?>
<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>

<td width="60%">			
<?php
$values = array('number','string');
\SIMAI\Property::view(
    'list', // type
    '',// template
    $values, // values
    array(
        'variants' => $all_types_names,
    ) // params
);
?>
</td>
</tr>

<tr class="heading">
<td colspan="2">
'list_type' => 'check'
</td>
</tr>

<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">			
<?php
$values = array('number','string');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_5_value');
}
\SIMAI\Property::edit(
    'list', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_5_value',
        'multiple' => 'Y',
        'list_type' => 'check',
        'variants' => $all_types_names,
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">			
<?php
$values = array('number','string');
if ($bVarsFromForm) {
    $values = $request->getPost('find_prop_5');
}
\SIMAI\Property::filter(
    'list', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'find_prop_5',
        'rows' => 4,
        'list_type' => 'check',
        'multiple' => 'Y',
        'max_width' => '350px',
        'variants' => $all_types_names,
    ) // params
);
?>
</td>
</tr>

<tr class="heading">
<td colspan="2">
'list_type' => 'list'
</td>
</tr>

<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">			
<?php
$values = array('number','string');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_5_value');
}
\SIMAI\Property::edit(
    'list', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_5_value',
        'multiple' => 'Y',
        'list_type' => 'list',
        'variants' => $all_types_names,
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">			
<?php
$values = array('number','string');
if ($bVarsFromForm) {
    $values = $request->getPost('find_prop_5');
}
\SIMAI\Property::filter(
    'list', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'find_prop_5',
        'rows' => 4,
        'list_type' => 'list',
        'multiple' => 'Y',
        'max_width' => '350px',
        'variants' => $all_types_names,
    ) // params
);
?>
</td>
</tr>

<?// Entity
$tabControl->BeginNextTab();?>

<?php
if (\Bitrix\Main\Loader::includeModule('simai.storage')):
?>

<tr class="heading">
<td colspan="2">
'entity' => '\SIMAI\Storage\Storage'
</td>
</tr>

<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>
<td width="60%">			
<?php
$values = array('abc', 'cde');
\SIMAI\Property::view(
    'entity', // type
    '',// template
    $values, // values
    array(
        'entity' => '\SIMAI\Storage\Storage',
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">			
<?php
$values = array('abc', 'cde');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_63_value');
}
\SIMAI\Property::edit(
    'entity', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_63_value',
        'multiple' => 'Y',
        'entity' => '\SIMAI\Storage\Storage',
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">			
<?php
$values = array('abc');
if ($bVarsFromForm) {
    $values = $request->getPost('find_prop_63');
}
\SIMAI\Property::filter(
    'entity', // type
    '', // template
    $values, // values
    array(
        'entity' => '\SIMAI\Storage\Storage',
        'field_name' => 'find_prop_63',
        'cols' => 50
    ) // params
);
?>
</td>
</tr>

<tr class="heading">
<td colspan="2">
'entity' => '\SIMAI\Storage\Element', 'storage_id' => 'abc'
</td>
</tr>

<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>
<td width="60%">			
<?php
$values = array('1', '2');
\SIMAI\Property::view(
    'entity', // type
    '',// template
    $values, // values
    array(
        'entity' => '\SIMAI\Storage\Element',
        'storage_id' => 'abc', // required parameter for storage element
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">			
<?php
$values = array('1', '2');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_62_value');
}
\SIMAI\Property::edit(
    'entity', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_62_value',
        'multiple' => 'Y',
        'entity' => '\SIMAI\Storage\Element',
        'search_get_vals' => array(),
        'storage_id' => 'abc', // required parameter for storage element
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">			
<?php
$values = array('1');
if ($bVarsFromForm) {
    $values = $request->getPost('find_prop_62');
}
\SIMAI\Property::filter(
    'entity', // type
    '', // template
    $values, // values
    array(
        'entity' => '\SIMAI\Storage\Element',
        'field_name' => 'find_prop_62',
        'cols' => 50
    ) // params
);
?>
</td>
</tr>

<?php
endif;

if (\Bitrix\Main\Loader::includeModule('iblock')):
?>

<tr class="heading">
<td colspan="2">
'entity' => '\Bitrix\Iblock\Section',
</td>
</tr>

<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>
<td width="60%">			
<?php
$values = array('1', '2');
\SIMAI\Property::view(
    'entity', // type
    '',// template
    $values, // values
    array(
        'entity' => '\Bitrix\Iblock\Section',
        
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">			
<?php
$values = array('1');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_60_value');
}
\SIMAI\Property::edit(
    'entity', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_60_value',
        'multiple' => 'Y',
        'entity' => '\Bitrix\Iblock\Section',
        'search_get_vals' => array(
            'IBLOCK_ID' => '1',
            // 'IBLOCK_CODE' => 'shop_news', // you can use it istead of IBLOCK_ID
        ),
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>

<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test (use code):
</td>
<td width="60%">			
<?php
$values = array('test1');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_60_2_value');
}
\SIMAI\Property::edit(
    'entity', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_60_2_value',
        'multiple' => 'Y',
        'entity' => '\Bitrix\Iblock\Section',
        'search_get_vals' => array(
            //'IBLOCK_ID' => '1',
            // 'IBLOCK_CODE' => 'shop_news', // you can use it istead of IBLOCK_ID
            'use_code' => 'y',
        ),
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>

<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">			
<?php
$values = array('1');
if ($bVarsFromForm) {
    $values = $request->getPost('find_prop_60');
}
\SIMAI\Property::filter(
    'entity', // type
    '', // template
    $values, // values
    array(
        'entity' => '\Bitrix\Iblock\Section',
        'field_name' => 'find_prop_60',
        'cols' => 50
    ) // params
);
?>
</td>
</tr>

<tr class="heading">
<td colspan="2">
'entity' => '\Bitrix\Iblock\Element',
</td>
</tr>

<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>
<td width="60%">			
<?php
$values = array('1', '2');
\SIMAI\Property::view(
    'entity', // type
    '',// template
    $values, // values
    array(
        'entity' => '\Bitrix\Iblock\Element',
        
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">			
<?php
$values = array('1', '2');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_61_value');
}
\SIMAI\Property::edit(
    'entity', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_61_value',
        'multiple' => 'Y',
        'entity' => '\Bitrix\Iblock\Element',
        'search_get_vals' => array(
            'IBLOCK_ID' => '1',
            // 'IBLOCK_CODE' => 'shop_news', // you can use it istead of IBLOCK_ID
        ),
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test (use code):
</td>
<td width="60%">			
<?php
$values = array('test1');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_61_2_value');
}
\SIMAI\Property::edit(
    'entity', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_61_2_value',
        'multiple' => 'Y',
        'entity' => '\Bitrix\Iblock\Element',
        'search_get_vals' => array(
            'IBLOCK_ID' => '1',
            // 'IBLOCK_CODE' => 'shop_news', // you can use it istead of IBLOCK_ID
            'use_code' => 'y',
        ),
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">			
<?php
$values = array('1');
if ($bVarsFromForm) {
    $values = $request->getPost('find_prop_61');
}
\SIMAI\Property::filter(
    'entity', // type
    '', // template
    $values, // values
    array(
        'entity' => '\Bitrix\Iblock\Element',
        'field_name' => 'find_prop_61',
        'cols' => 50
    ) // params
);
?>
</td>
</tr>

<?php
endif;
?>

<tr class="heading">
<td colspan="2">
'entity' => '\Bitrix\Main\UserTable',
</td>
</tr>

<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>
<td width="60%">			
<?php
$values = array('1');
\SIMAI\Property::view(
    'entity', // type
    '',// template
    $values, // values
    array(
        'entity' => '\Bitrix\Main\UserTable',
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">			
<?php
$values = array('1');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_64_value');
}
\SIMAI\Property::edit(
    'entity', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_64_value',
        'multiple' => 'Y',
        'entity' => '\Bitrix\Main\UserTable',
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">			
<?php
$values = array('1');
if ($bVarsFromForm) {
    $values = $request->getPost('find_prop_64');
}
\SIMAI\Property::filter(
    'entity', // type
    '', // template
    $values, // values
    array(
        'entity' => '\Bitrix\Main\UserTable',
        'field_name' => 'find_prop_64',
        'cols' => 50
    ) // params
);
?>
</td>
</tr>


<?// Url
$tabControl->BeginNextTab();?>
<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>
<td width="60%">
<?php
$values = array('#SITE_DIR#/#STORAGE_ID#/', '#SITE_DIR#/#SECTION_ID#/', '#SITE_DIR#/#ITEM_ID#/');
\SIMAI\Property::view(
    'url', // type
    '',// template
    $values, // values
    array() // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">			
<?php
$values = array('#SITE_DIR#/#STORAGE_ID#/', '#SITE_DIR#/#SECTION_ID#/', '#SITE_DIR#/#ITEM_ID#/');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_7_value');
}
\SIMAI\Property::edit(
    'url', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_7_value',
        'multiple' => 'Y',
        'cols' => 30,
        'bVarsFromForm' => $bVarsFromForm,
        'insert_vars' => array(
            array('SITE_DIR', 'Site directory'),
            'SEPARATOR',
            array('STORAGE_ID', 'Storage id'),
            array('SECTION_ID', 'Section id'),
            array('ITEM_ID', 'Item id'),
        )
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">			
<?php
$values = array('SITE_DIR');
if ($bVarsFromForm) {
    $values = $request->getPost('find_prop_7');
}
\SIMAI\Property::filter(
    'url', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'find_prop_7',
        'cols' => 50
    ) // params
);
?>
</td>
</tr>

<?// File
$tabControl->BeginNextTab();?>
<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>
<td width="60%">			
<?php
$values = array(2);
\SIMAI\Property::view(
    'file', // type
    '',// template
    $values, // values
    array(
        
        
        
    ) // params
);
?>
</td>
</tr>

<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">			
<?php
$values = array(2);

// get uploaded files, files to update and delete example
if ($request->getRequestMethod() == 'POST') {
    $arFiles = array();
    $arDelFiles = array();
    
    // get uploaded files through post
    $arFiles = $request->getPost('prop_8_value');

    // get files to delete
    $arDelFiles = $request->getPost('prop_8_value_del');
    
    foreach ($arDelFiles as $key => $val) {
        if ($arFiles[$key] > 0) {
            $arFiles[$key] = array('del_file' => $arFiles[$key]);
        }
    }
    
    //echo '<pre>'; print_r($arFiles); echo '</pre>';
    
    /*
    // repair files tmp_name if tmp_name is not absolute
    $file_array_check = \CFile::MakeFileArray($file_array['tmp_name'], $file_array['type']);
    $file_array['tmp_name'] = $file_array_check['tmp_name'];
    */
}

\SIMAI\Property::edit(
    'file', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_8_value',
        'multiple' => 'Y',
        'file_type' => 'I', // I - image | F - all files
        'file_ext' => 'jpg,gpeg,png,gif,bmp',
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>

<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">			
<?php
$values = false;
if ($bVarsFromForm) {
    $values = $request->getPost('find_prop_8');
}
\SIMAI\Property::filter(
    'file', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'find_prop_8',
    ) // params
);
?>
</td>
</tr>

<?// Color
$tabControl->BeginNextTab();?>
<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>
<td width="60%">			
<?php
$values = array('#E91E63', '#4CAF50', '#1E88E5');
\SIMAI\Property::view(
    'color', // type
    '',// template
    $values, // values
    array() // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">			
<?php
$values = array('#E91E63', '#4CAF50', '#1E88E5');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_9_value');
}
\SIMAI\Property::edit(
    'color', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_9_value',
        'multiple' => 'Y',
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">			
<?php
$values = array('bb');
if ($bVarsFromForm) {
    $values = $request->getPost('find_prop_9');
}
\SIMAI\Property::filter(
    'color', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'find_prop_9',
        'cols' => 50
    ) // params
);
?>
</td>
</tr>

<?// Checkbox

$tabControl->BeginNextTab();?>
<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>
<td width="60%">			
<?php
$values = array('Y');
\SIMAI\Property::view(
    'checkbox', // type
    '',// template
    $values, // values
    array() // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">			
<?php
$values = array('Y');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_10_value');
}
\SIMAI\Property::edit(
    'checkbox', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_10_value',
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">			
<?php
$values = array('Y');
if ($bVarsFromForm) {
    $values = $request->getPost('find_prop_10');
}
\SIMAI\Property::filter(
    'checkbox', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'find_prop_10',
    ) // params
);
?>
</td>
</tr>

<?// Sortable list
$tabControl->BeginNextTab();

$proplist = \SIMAI\Property::types_list();

$all_types_names = array();
foreach ($proplist as $type)
{
	$all_types_names[$type['id']] = $type['name'];
}
?>
<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>
<td width="60%">			
<?php
$values = array('number', 'entity', 'file');

\SIMAI\Property::view(
    'sort', // type
    '',// template
    $values, // values
    array(
        'variants' => $all_types_names,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">			
<?php
$values = array('number', 'entity', 'file');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_11_value');
}
\SIMAI\Property::edit(
    'sort', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_11_value',
        'variants' => $all_types_names,
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">	
<?php
$values = array('number', 'entity', 'file');
if ($bVarsFromForm) {
    $values = $request->getPost('find_prop_11');
}
\SIMAI\Property::filter(
    'list', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'find_prop_11',
        'rows' => 4,
        'list_type' => 'check',
        'multiple' => 'Y',
        'max_width' => '350px',
        'variants' => $all_types_names,
    ) // params
);
?>
</td>
</tr>

<?// Link
$tabControl->BeginNextTab();?>
<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>
<td width="60%">			
<?php
$values = array('http://yandex.ru', 'https://google.ru');
\SIMAI\Property::view(
    'link', // type
    '',// template
    $values, // values
    array(
        'target' => '_blank',
        'download' => 'N',
        'rel' => 'nofollow'
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">			
<?php
$values = array('http://yandex.ru', 'https://google.ru');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_12_value');
}
\SIMAI\Property::edit(
    'link', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_12_value',
        'multiple' => 'Y',
        'cols' => 10,
        'bVarsFromForm' => $bVarsFromForm,
        //'local' => 'Y',
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">			
<?php
$values = 'yandex';
if ($bVarsFromForm) {
    $values = $request->getPost('find_prop_12');
}
\SIMAI\Property::filter(
    'link', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'find_prop_12',
        'cols' => 8
    ) // params
);
?>
</td>
</tr>

<?// Phone
$tabControl->BeginNextTab();?>
<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>
<td width="60%">			
<?php
$values = array('+7 (950) 111-1111', '+7 (950) 222-2222');
\SIMAI\Property::view(
    'phone', // type
    '',// template
    $values, // values
    array() // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">			
<?php
$values = array('+7 (950) 111-1111', '+7 (950) 222-2222');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_13_value');
}
\SIMAI\Property::edit(
    'phone', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_13_value',
        'multiple' => 'Y',
        'cols' => 30,
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test:
</td>
<td width="60%">			
<?php
$values = array('111');
if ($bVarsFromForm) {
    $values = $request->getPost('find_prop_13');
}
\SIMAI\Property::filter(
    'phone', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'find_prop_13',
        'cols' => 50
    ) // params
);
?>
</td>
</tr>

<?// Map
$tabControl->BeginNextTab();?>
<tr>
<td class="adm-detail-valign-top" width="40%">
View test:
</td>
<td width="60%">
<?php
$values = array('54.729335, 55.941318');
\SIMAI\Property::view(
    'map', // type
    '',// template
    $values, // values
    array(
        'width' => '500px',
        'height' => '300px',
        'scrollZoom' => true,
        'zoomControl' => true,
        'searchControl' => true,
        'typeSelector' => true,
        'fullscreenControl' => true,
        'routeButtonControl' => true,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Edit test:
</td>
<td width="60%">
<?php
$values = array('54.729335, 55.941318');
if ($bVarsFromForm) {
    $values = $request->getPost('prop_14_value');
}
\SIMAI\Property::edit(
    'map', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'prop_14_value',
        'multiple' => 'N',
        'width' => '500px',
        'height' => '300px',
        'bVarsFromForm' => $bVarsFromForm,
    ) // params
);
?>
</td>
</tr>
<tr>
<td class="adm-detail-valign-top" width="40%">
Filter test (no filters for Yandex map):
</td>
<td width="60%">
<?php
$values = array();
if ($bVarsFromForm) {
    $values = $request->getPost('find_prop_14');
}
\SIMAI\Property::filter(
    'map', // type
    '', // template
    $values, // values
    array(
        'field_name' => 'find_prop_14',
    ) // params
);
?>
</td>
</tr>

<?$tabControl->Buttons(array("disabled" => false));
$tabControl->End();?>
</form>

<?php
$APPLICATION->SetTitle('SIMAI property test form');

require($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/epilog_admin.php');?>