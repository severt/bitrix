<?php
require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_before.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/simai.property/prolog.php');
\Bitrix\Main\Localization\Loc::loadMessages(__FILE__);

\Bitrix\Main\Loader::includeSharewareModule('simai.property');

$request = \Bitrix\Main\Application::getInstance()->getContext()->getRequest();

$entity = '';
if ($request->get('entity')) {
    $entity = preg_replace('/[^a-zA-Z0-9\\\_]/', '', $request->get('entity'));
}

$inp_id = '';
if ($request->get('inp_id')) {
    $inp_id = preg_replace('/[^a-zA-Z0-9_]/', '', $request->get('inp_id'));
}

if (trim($request->get('IBLOCK_CODE'))) {
    \Bitrix\Main\Loader::includeModule('iblock');
    
    $IB_CODE = addslashes(trim($request->get('IBLOCK_CODE')));
    $IB_ID = 0;
    
    $res = CIBlock::GetList(array(), array('CODE' => $IB_CODE), false);
    if ($arr = $res->fetch()) {
        $IB_ID = $arr['ID'];
    }
    $get_str = array();
    foreach ($request->getQueryList() as $code => $val) {
        if ($code == 'IBLOCK_CODE') {
            continue;
        }
        $get_str[] = $code.'='.$val;
    }
    if ($IB_ID) {
        $get_str[] = 'IBLOCK_ID='.$IB_ID;
    }
    $get_str = 'sf_property_entity_search.php?'.implode('&', $get_str);
    LocalRedirect($get_str);
    exit();
}

$use_code = false;
if (trim($request->get('use_code')) == 'y') {
    $use_code = true;
}

$primary = \SIMAI\PropertyEntitiesType::GetPrimary($entity);

if ($primary) {
    \SIMAI\PropertyEntitiesType::SetModule($entity);
    
    $required_value = false;
    $required_var = \SIMAI\PropertyEntitiesType::GetRequired($entity);
    
    if ($required_var) {
        $required_value = htmlspecialcharsbx($request->get($required_var));
    }
    
    $entity_fields = \SIMAI\PropertyEntitiesType::GetFields($entity, $required_value, false, true);
    
    //$entity_fields_map = $entity::GetMap();
    
    $connection = \Bitrix\Main\Application::getConnection();

    // Data table ID
    $sTableID = 'tbl_entity_'.md5($entity.'-'.$required_value);

    // Sorting init
    
    $sort_arr = \SIMAI\PropertyEntitiesType::GetSort($entity);
    
    $default_sort = $sort_arr['REGULAR'];
    if (!is_array($default_sort)) {
        $default_sort = array($primary => 'asc');
    }
    
    $oSort = new CAdminSorting($sTableID, key($default_sort), current($default_sort));
    
    $sort_order = array($by => $order);
    
    if (!array_key_exists($by, $entity_fields)) {
        $sort_order = $default_sort;
    } elseif ($entity_fields[$by]['not_in_sorting']) {
        $sort_order = $default_sort;
    }

    $arOrder = array();
    if (is_array($sort_arr['PRIORITY'])) {
        foreach ($sort_arr['PRIORITY'] as $key => $val) {
            $arOrder[$key] = $val;
        }
    }
    if (is_array($sort_arr['PRIORITY_DEPENDENT'])) {
        if (isset($sort_arr['PRIORITY_DEPENDENT'][$by])) {
            foreach ($sort_arr['PRIORITY_DEPENDENT'] as $key) {
                $arOrder[$key] = $order;
            }
        }
    }
    foreach ($sort_order as $key => $val) {
        $arOrder[$key] = $val;
    }
    
    // List init
    $lAdmin = new CAdminList($sTableID, $oSort);

    // Filters for list
    $arFilterFields = array();
    
    foreach ($entity_fields as $field_id => $field) {
        if (isset($field['filter_params']['field_name_from']) || isset($field['filter_params']['field_name_to'])) {
            $arFilterFields[] = $field['filter_params']['field_name_from'];
            $arFilterFields[] = $field['filter_params']['field_name_to'];
        } elseif (isset($field['filter_params']['field_name'])) {
            $arFilterFields[] = $field['filter_params']['field_name'];
        }
        
        if ($field_id == 'IBLOCK_SECTION_ID' || $field_id == 'PARENT_ID') {
            $arFilterFields[] = 'find_include_subsections';
        }
    }

    $lAdmin->InitFilter($arFilterFields);

    $arFilter = array();
    
    foreach ($entity_fields as $field_id => $field) {
        if (isset($field['filter_ar_field']) || isset($field['filter_ar_field_from']) || isset($field['filter_ar_field_to'])) {
            if (isset($field['filter_params']['field_name'])) {
                if (${$field['filter_params']['field_name']} == false || ${$field['filter_params']['field_name']} == null) {
                    if ($request->get($field_id)) {
                        ${$field['filter_params']['field_name']} = htmlspecialcharsbx($request->get($field_id));
                    }
                }
            }
            
            if (isset($field['filter_params']['field_name_from']) || isset($field['filter_params']['field_name_to'])) {
                if (${$field['filter_params']['field_name_from']}) {
                    $arFilter[$field['filter_ar_field_from']] = ${$field['filter_params']['field_name_from']};
                }
                if (${$field['filter_params']['field_name_to']}) {
                    $arFilter[$field['filter_ar_field_to']] = ${$field['filter_params']['field_name_to']};
                }
            } elseif (isset($field['filter_params']['field_name'])) {
                if (is_array(${$field['filter_params']['field_name']})) {
                    $check_array_filter = array();
                    foreach (${$field['filter_params']['field_name']} as $key => $val) {
                        if ($val) {
                            $check_array_filter[] = $val;
                        }
                    }
                    if (count($check_array_filter)) {
                        $arFilter[$field['filter_ar_field']] = $check_array_filter;
                    }
                } elseif (${$field['filter_params']['field_name']}) {
                    $arFilter[$field['filter_ar_field']] = ${$field['filter_params']['field_name']};
                    if (isset($field['filter_ar_field_lang'])) {
                        $arFilter[$field['filter_ar_field_lang']] = array('', LANGUAGE_ID);
                    }
                } elseif (isset($field['default_filter_val'])) {
                    $arFilter[$field['filter_ar_field']] = $field['default_filter_val'];
                    ${$field['filter_params']['field_name']} = $field['default_filter_val'];
                    if (isset($field['filter_ar_field_lang'])) {
                        $arFilter[$field['filter_ar_field_lang']] = array('', LANGUAGE_ID);
                    }
                }

                if (isset($field['not_set_value'])) {
                    if (${$field['filter_params']['field_name']} == $field['not_set_value']) {
                        unset($arFilter[$field['filter_ar_field']]);
                        unset($arFilter[$field['filter_ar_field_lang']]);
                    }
                }
            }
        }
    }
    
    if (isset($arFilter['SECTION_ID']) && $find_include_subsections == 'Y') {
        if (intval($arFilter['SECTION_ID'] > 0)) {
            $arFilter['INCLUDE_SUBSECTIONS'] = 'Y';
        } else {
            unset($arFilter['SECTION_ID']);
        }
    }
    
    if (isset($arFilter['=PARENT_ID']) && $find_include_subsections == 'Y') {
        if (intval($arFilter['=PARENT_ID'] > 0)) {
            $arFilter['INCLUDE_SUBSECTIONS'] = 'Y';
        } else {
            unset($arFilter['=PARENT_ID']);
        }
    }
    
    // page elements count
    $nPageSize = CAdminResult::GetNavSize($sTableID, array('nPageSize' => 20, 'sNavID' => $APPLICATION->GetCurPage().'?entity='.$entity));

    // Fill list with data
    $rsData = \SIMAI\PropertyEntitiesType::GetListDbResult($entity, $required_value, array('filter' => $arFilter, 'order' => $arOrder, 'limit' => $nPageSize), false, true);
    
    
    
    $rsData = new CAdminResult($rsData, $sTableID);
    $rsData->NavStart();

    // Set page navigation
    $lAdmin->NavText($rsData->GetNavPrint(\SIMAI\PropertyEntitiesType::GetTitle($entity)));

    // List headers/columns
    $arHeaders = array();

    if (is_array($entity_fields)) {
        foreach ($entity_fields as $field_id => $field) {
            if (!$field['not_show_col']) {
                $header_col = array(
                    'id' => $field_id,
                    'content' => $field['title'],
                    'default' => true,
                );
                if (!$entity_fields[$field_id]['not_in_sorting']) {
                    $header_col['sort'] = $field_id;
                }
                if (isset($entity_fields[$field_id]['align'])) {
                    $header_col['align'] = $entity_fields[$field_id]['align'];
                }
                $arHeaders[] = $header_col;
            }
        }
    }
    
    $lAdmin->AddHeaders($arHeaders);
    
    // Build elements list
    while ($arRes = $rsData->NavNext(true, 'f_')) {
        $modified_cols = \SIMAI\PropertyEntitiesType::GetModifiedCols($entity, $required_value, ${'f_'.$primary});
        
        $row =& $lAdmin->AddRow(${'f_'.$primary}, $arRes);

        foreach ($entity_fields as $field_id => $field) {
            if (!$field['not_show_col']) {
                if (is_array($field['value_titles'])) {
                    $row->AddViewField($field_id, $field['value_titles'][${'f_'.$field_id}]);
                } elseif (isset($modified_cols[$field_id])) {
                    $row->AddViewField($field_id, $modified_cols[$field_id]);
                } else {
                    $row->AddViewField($field_id, ${'f_'.$field_id});
                }
            }
        }
        
        $arActions = array();
        
        if ($entity == '\SIMAI\Storage\Element') {
            $storage_id = $required_value;
            if (trim($storage_id) == '') {
                $storage_id = $arFilter['storage_id'];
            }
            
            $arActions[] = array(
                'TEXT'=>GetMessage('SF_PROPERTY_SELECT'),
                'ACTION'=>"javascript:SelEntObj('".${'f_ELEMENT_ID'}.":".$storage_id."', '".$modified_cols['PROP_TITLE']."')",
                'DEFAULT'=>true,
            );
        } elseif ($entity == '\Bitrix\Iblock\Element' || $entity == '\Bitrix\Iblock\Section') {
            if ($use_code) {
                $arActions[] = array(
                    'TEXT'=>GetMessage('SF_PROPERTY_SELECT'),
                    'ACTION'=>"javascript:SelEntObj('".$f_CODE."', '".$f_NAME."')",
                    'DEFAULT'=>true,
                );
            } else {
                $arActions[] = array(
                    'TEXT'=>GetMessage('SF_PROPERTY_SELECT'),
                    'ACTION'=>"javascript:SelEntObj('".$f_ID."', '".$f_NAME."')",
                    'DEFAULT'=>true,
                );
            }
        } elseif ($entity == '\Bitrix\Main\UserTable') {
            $arActions[] = array(
                'TEXT'=>GetMessage('SF_PROPERTY_SELECT'),
                'ACTION'=>"javascript:SelEntObj('".${'f_'.$primary}."', '".$f_LOGIN."')",
                'DEFAULT'=>true,
            );
        } else {
            $arActions[] = array(
                'TEXT'=>GetMessage('SF_PROPERTY_SELECT'),
                'ACTION'=>"javascript:SelEntObj('".${'f_'.$primary}."', '')",
                'DEFAULT'=>true,
            );
        }
        
        $row->AddActions($arActions);
    }

    // "footer" of the list
    $lAdmin->AddFooter(
        array(
            array('title'=>GetMessage('MAIN_ADMIN_LIST_SELECTED'), 'value'=>$rsData->SelectedRowsCount()),
            array('counter'=>true, 'title'=>GetMessage('MAIN_ADMIN_LIST_CHECKED'), 'value'=>'0'),
        )
    );
    
    // Check if list will be output (in this case, rest of the script will be skipped)
    $lAdmin->CheckListMode();

    $APPLICATION->SetTitle(GetMessage('SF_PROPERTY_ELSEARCH_TITLE'));

    // Start of visual output
    require($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_popup_admin.php');

    // Filter output?>
    <form name="filter_<?=$sTableID?>" method="GET" action="<?=$APPLICATION->GetCurPage()?>?inp_id=<?=urlencode($inp_id)?>&entity=<?=urlencode($entity).($required_value ? '&amp;'.$required_var.'='.$required_value : '')?>">
    
    <input type="hidden" name="use_code" value="<?=($use_code ? 'y' : 'n')?>">
    
    <?php
    $ofilter_names = array();
    foreach ($entity_fields as $field_id => $field) {
        if (isset($field['filter_type'])) {
            if (isset($field['necessary_var']) && (!${$field['necessary_var']} || ${$field['necessary_var']} == -1)) {
                continue;
            }
            $ofilter_names[] = $field['title'];
        }
    }
    
    $oFilter = new CAdminFilter(
        $sTableID.'_filter',
        $ofilter_names
    );

    $oFilter->Begin();
    
    foreach ($entity_fields as $field_id => $field) {
        if (isset($field['filter_type'])) {
            if (isset($field['necessary_var']) && (!${$field['necessary_var']} || ${$field['necessary_var']} == -1)) {
                continue;
            } ?>
    <tr>
        <td><?=$field['title']?><?=($field['title'] ? ':' : '')?></td>
        <td>
<?php
            $filter_vals = array();
            if (isset($field['filter_params']['field_name_from']) || isset($field['filter_params']['field_name_to'])) {
                $filter_vals = array(
                    ${$field['filter_params']['field_name_from']},
                    ${$field['filter_params']['field_name_to']},
                );
            } elseif (isset($field['filter_params']['field_name'])) {
                $filter_vals = array(
                    ${$field['filter_params']['field_name']},
                );
            }
            
            \SIMAI\Property::filter(
                $field['filter_type'],
                '',
                $filter_vals,
                $field['filter_params']
            );
            
            if ($field_id == 'IBLOCK_SECTION_ID' || $field_id == 'PARENT_ID') {
                \SIMAI\Property::filter(
                    'list',
                    '',
                    $find_include_subsections,
                    array(
                        'field_name' => 'find_include_subsections',
                        'list_type' => 'check',
                        'multiple' => 'N',
                        'variants' => array(
                            'Y' => GetMessage('SF_PROPERTY_INCLUDE_SUBSECTIONS_Y'),
                        )
                    )
                );
            }
            
            if ($field['reload'] && $field['filter_params']['field_id']) {
                ?>
            <script type="text/javascript">
            BX.ready(function()
            {
                BX.bindDelegate(
                    document.body, 'change', {id: '<?=$field['filter_params']['field_id']?>'},
                    function()
                    {
                        reloadFilter('<?=$field_id?>', BX('<?=$field['filter_params']['field_id']?>').value, '<?=htmlspecialcharsbx($request->get($field_id))?>');
                    }
                );
            });
            </script>
<?php
            } ?>
        </td>
    </tr>
<?php
        }
    }
    
    $oFilter->Buttons(array('table_id' => $sTableID, 'url' => $APPLICATION->GetCurPage().'?inp_id='.urlencode($inp_id).'&entity='.urlencode($entity).($required_value ? '&'.$required_var.'='.$required_value : ''), 'form' => 'filter_'.$sTableID));
    $oFilter->End(); ?>
    </form>
    <script type="text/javascript">
    function SelEntObj(primary, iname)
    {
        var inp = window.opener.document.getElementById('<?=$inp_id?>');
        if (inp)
        {
            inp.value = primary;
        }
        
        var inp_span = window.opener.document.getElementById('<?=$inp_id?>span');
        if (inp_span)
        {
            inp_span.innerHTML = iname;
        }
        
        window.close();
    }
    
    function reloadFilter(reload_var, reload_value, current_value)
    {
        if (reload_value != current_value)
        {
            var newUrl = 'sf_property_entity_search.php?inp_id=<?=urlencode($inp_id)?>&entity=<?=urlencode($entity)?>&' + reload_var + '=' + reload_value + '<?if ($use_code):?>&use_code=y<?endif;?>&lang=<?=LANGUAGE_ID?>&set_filter=y';
            location.href = newUrl;
        }
    }
    
    </script>
    <?php

    // Here is List will be displayed
    $lAdmin->DisplayList();
} else {
    ShowError(GetMessage('SF_PROPERTY_WRONG_ENTITY'));
}

require($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/epilog_popup_admin.php');
?>