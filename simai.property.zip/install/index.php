<?php
\Bitrix\Main\Localization\Loc::loadMessages(__FILE__);

define('SF_PROPERTY_DOCUMENT_ROOT', Bitrix\Main\Application::getDocumentRoot());

if (class_exists('simai_property'))
{
    return;
}

class simai_property extends CModule
{
    var $MODULE_ID = 'simai.property';
    var $MODULE_VERSION;
    var $MODULE_VERSION_DATE;
    var $MODULE_NAME;
    var $MODULE_DESCRIPTION;
    var $MODULE_GROUP_RIGHTS = 'N';
    var $PARTNER_NAME;
    var $PARTNER_URI;
    
    function __construct() //simai_property()
    {
        $arModuleVersion = array();
        $path = str_replace('\\', '/', __FILE__);
        $path = substr($path, 0, strlen($path) - strlen('/index.php'));
        include($path.'/version.php');
        $this->MODULE_VERSION = $arModuleVersion['VERSION'];
        $this->MODULE_VERSION_DATE = $arModuleVersion['VERSION_DATE'];
        $this->MODULE_NAME = GetMessage('SF_PROPERTY_MODULE_NAME');
        $this->MODULE_DESCRIPTION = GetMessage('SF_PROPERTY_MODULE_DESCRIPTION');
        $this->PARTNER_NAME = 'SIMAI';
        $this->PARTNER_URI = 'http://simai.ru';
    }
    
    function InstallDB($arParams = array())
    {
        $this->errors = false;
        if ($this->errors !== false)
        {
            $APPLICATION->ThrowException(implode('<br>', $this->errors));
            return false;
        }
        else
        {
            $this->InstallTasks();
            
            RegisterModule('simai.property');
        }
        return true;
    }
    
    function UnInstallDB($arParams = array())
    {	
        $this->errors = false;
        
        UnRegisterModule('simai.property');

        if ($this->errors !== false)
        {
            $APPLICATION->ThrowException(implode('<br>', $this->errors));
            return false;
        }
        return true;
    }
    
    function InstallEvents()
    {
        return true;
    }
    
    function UnInstallEvents()
    {
        return true;
    }
    
    function InstallFiles()
    {
        $this->errors = false;
        
        \Bitrix\Main\IO\Directory::createDirectory(SF_PROPERTY_DOCUMENT_ROOT.'/simai/property');
        \Bitrix\Main\IO\Directory::createDirectory(SF_PROPERTY_DOCUMENT_ROOT.'/simai/asset/simai.property');
        \Bitrix\Main\IO\Directory::createDirectory(SF_PROPERTY_DOCUMENT_ROOT.'/simai/admin');
        \Bitrix\Main\IO\Directory::createDirectory(SF_PROPERTY_DOCUMENT_ROOT.'/bitrix/admin/simai');
        
        CopyDirFiles(SF_PROPERTY_DOCUMENT_ROOT.'/bitrix/modules/simai.property/install/simai/property/', SF_PROPERTY_DOCUMENT_ROOT.'/simai/property', true, true);
        
        CopyDirFiles(SF_PROPERTY_DOCUMENT_ROOT.'/bitrix/modules/simai.property/install/simai/asset/simai.property/', SF_PROPERTY_DOCUMENT_ROOT.'/simai/asset/simai.property', true, true);
        
        CopyDirFiles(SF_PROPERTY_DOCUMENT_ROOT.'/bitrix/modules/simai.property/install/bitrix/admin/simai/', SF_PROPERTY_DOCUMENT_ROOT.'/bitrix/admin/simai');
        
        CopyDirFiles(SF_PROPERTY_DOCUMENT_ROOT.'/bitrix/modules/simai.property/install/simai/admin/', SF_PROPERTY_DOCUMENT_ROOT.'/simai/admin/', true, true);
        
        return true;
    }
    
    function UnInstallFiles()
    {
        DeleteDirFilesEx('/simai/property');
        DeleteDirFilesEx('/simai/asset/simai.property');
        DeleteDirFiles(SF_PROPERTY_DOCUMENT_ROOT.'/bitrix/modules/simai.property/install/simai/admin/', SF_PROPERTY_DOCUMENT_ROOT.'/simai/admin');
        DeleteDirFiles(SF_PROPERTY_DOCUMENT_ROOT.'/bitrix/modules/simai.property/install/bitrix/admin/simai', SF_PROPERTY_DOCUMENT_ROOT.'/bitrix/admin/simai', array(".htaccess", "sf_admin_redirect.php"));
        
        //DeleteDirFilesEx('/bitrix/js/simai.property');
        
        return true;
    }
    
    function DoInstall()
    {
        global $USER, $APPLICATION, $step;
        
        $request = \Bitrix\Main\Application::getInstance()->getContext()->getRequest();

        if ($USER->IsAdmin())
        {
            $this->InstallDB();
            $this->InstallEvents();
            $this->InstallFiles();
            
            $GLOBALS['errors'] = $this->errors;
        }
    }
    
    function DoUninstall()
    {
        global $USER, $APPLICATION, $step;
        
        $request = \Bitrix\Main\Application::getInstance()->getContext()->getRequest();
        
        if ($USER->IsAdmin())
        {
            $this->UnInstallFiles();
            $this->UnInstallDB();
            $GLOBALS['errors'] = $this->errors;
        }
    }
}
