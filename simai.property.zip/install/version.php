<?php
$arModuleVersion = array(
    "VERSION" => "4.1.4",
    "VERSION_DATE" => "2024-07-23 02:00:00",
);
