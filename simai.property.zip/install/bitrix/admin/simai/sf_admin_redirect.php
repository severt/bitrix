<?php
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");

use Bitrix\Main\Application;
use Bitrix\Main\Web\Uri;

$request = Application::getInstance()->getContext()->getRequest();
$uriString = $request->getRequestUri();
$uri = new Uri($uriString);

$redirect = $uri->getUri(); 

$redirect = str_replace('/bitrix/admin/simai/', '/bitrix/admin/', $redirect);

LocalRedirect($redirect);

//echo $redirect;
?>