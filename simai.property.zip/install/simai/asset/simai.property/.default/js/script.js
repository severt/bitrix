function SFPropAddNewRow(tableID, row_to_clone)
{
	var tbl = document.getElementById(tableID);
	var cnt = tbl.rows.length;
	if(row_to_clone == null)
		row_to_clone = -2;
	var sHTML = tbl.rows[cnt+row_to_clone].cells[0].innerHTML;
	var oRow = tbl.insertRow(cnt+row_to_clone+1);
	var oCell = oRow.insertCell(0);

	var s, e, n, p;
	p = 0;
	while(true)
	{
		s = sHTML.indexOf('[n',p);
		if(s<0)break;
		e = sHTML.indexOf(']',s);
		if(e<0)break;
		n = parseInt(sHTML.substr(s+2,e-s));
		sHTML = sHTML.substr(0, s)+'[n'+(++n)+']'+sHTML.substr(e+1);
		p=s+1;
	}
	p = 0;
	while(true)
	{
		s = sHTML.indexOf('__n',p);
		if(s<0)break;
		e = sHTML.indexOf('_',s+2);
		if(e<0)break;
		n = parseInt(sHTML.substr(s+3,e-s));
		sHTML = sHTML.substr(0, s)+'__n'+(++n)+'_'+sHTML.substr(e+1);
		p=e+1;
	}
	p = 0;
	while(true)
	{
		s = sHTML.indexOf('__N',p);
		if(s<0)break;
		e = sHTML.indexOf('__',s+2);
		if(e<0)break;
		n = parseInt(sHTML.substr(s+3,e-s));
		sHTML = sHTML.substr(0, s)+'__N'+(++n)+'__'+sHTML.substr(e+2);
		p=e+2;
	}
	p = 0;
	while(true)
	{
		s = sHTML.indexOf('xxn',p);
		if(s<0)break;
		e = sHTML.indexOf('xx',s+2);
		if(e<0)break;
		n = parseInt(sHTML.substr(s+3,e-s));
		sHTML = sHTML.substr(0, s)+'xxn'+(++n)+'xx'+sHTML.substr(e+2);
		p=e+2;
	}
	p = 0;
	while(true)
	{
		s = sHTML.indexOf('%5Bn',p);
		if(s<0)break;
		e = sHTML.indexOf('%5D',s+3);
		if(e<0)break;
		n = parseInt(sHTML.substr(s+4,e-s));
		sHTML = sHTML.substr(0, s)+'%5Bn'+(++n)+'%5D'+sHTML.substr(e+3);
		p=e+3;
	}
	oCell.innerHTML = sHTML;

	var patt = new RegExp ("<"+"script"+">[^\000]*?<"+"\/"+"script"+">", "ig");
	var code = sHTML.match(patt);
	if(code)
	{
		for(var i = 0; i < code.length; i++)
		{
			if(code[i] != '')
			{
				s = code[i].substring(8, code[i].length-9);
				jsUtils.EvalGlobal(s);
			}
		}
	}

	if (BX && BX.adminPanel)
	{
		BX.adminPanel.modifyFormElements(oRow);
		BX.onCustomEvent('onAdminTabsChange');
	}

	setTimeout(function() {
		var r = BX.findChildren(oCell, {tag: /^(input|select|textarea)$/i});
		if (r && r.length > 0)
		{
			for (var i=0,l=r.length;i<l;i++)
			{
				if (r[i].form && r[i].form.BXAUTOSAVE)
					r[i].form.BXAUTOSAVE.RegisterInput(r[i]);
				else
					break;
			}
		}
	}, 10);
}

function SFSetUrlVar(id, el_id)
{
	var obj_ta = BX(el_id);
	//IE
	if (document.selection)
	{
		obj_ta.focus();
		var sel = document.selection.createRange();
		sel.text = id;
		//var range = obj_ta.createTextRange();
		//range.move('character', caretPos);
		//range.select();
	}
	//FF
	else if (obj_ta.selectionStart || obj_ta.selectionStart == '0')
	{
		var startPos = obj_ta.selectionStart;
		var endPos = obj_ta.selectionEnd;
		var caretPos = startPos + id.length;
		obj_ta.value = obj_ta.value.substring(0, startPos) + id + obj_ta.value.substring(endPos, obj_ta.value.length);
		obj_ta.setSelectionRange(caretPos, caretPos);
		obj_ta.focus();
	}
	else
	{
		obj_ta.value += id;
		obj_ta.focus();
	}

	BX.fireEvent(obj_ta, 'change');
	obj_ta.focus();
}

function SFEChangeProptocol(link_md5_id)
{
	var protocol_ = BX('pro' + link_md5_id).value;	
	var linkval = BX('link' + link_md5_id).value;
	linkval = linkval.trim();
	while (linkval.substr(0, 1) == '/')
	{
		linkval = linkval.substr(1);
	}
	var linkval_ = linkval.toLowerCase();
	if (linkval_.substr(0, 8) == 'https://')
	{
		BX('link' + link_md5_id).value = linkval.substr(8);
		BX('full' + link_md5_id).value = protocol_ + linkval.substr(8);
	}
	else if (linkval_.substr(0, 7) == 'http://')
	{
		BX('link' + link_md5_id).value = linkval.substr(7);
		BX('full' + link_md5_id).value = protocol_ + linkval.substr(7);
	}
	else if (linkval.length > 0)
	{
		BX('full' + link_md5_id).value = protocol_ + linkval;
	}
	else
	{
		BX('full' + link_md5_id).value = '';
	}
}

function SFEParseUrl(link_md5_id)
{
	var linkval = BX('link' + link_md5_id).value;
	linkval = linkval.trim();
	var linkval_ = linkval.toLowerCase();
	if (linkval_.substr(0, 8) == 'https://')
	{
		BX('pro' + link_md5_id).value = 'https://';
		linkval = linkval.substr(8);
		while (linkval.substr(0, 1) == '/')
		{
			linkval = linkval.substr(1);
		}
		BX('link' + link_md5_id).value = linkval;
		BX('full' + link_md5_id).value = 'https://' + linkval;
	}
	else if (linkval_.substr(0, 7) == 'http://')
	{
		BX('pro' + link_md5_id).value = 'http://';
		linkval = linkval.substr(7);
		while (linkval.substr(0, 1) == '/')
		{
			linkval = linkval.substr(1);
		}
		BX('link' + link_md5_id).value = linkval;
		BX('full' + link_md5_id).value = 'http://' + linkval;
	}
	else if (linkval_.substr(0, 2) == '//')
	{
		BX('pro' + link_md5_id).value = 'http://';
		while (linkval.substr(0, 1) == '/')
		{
			linkval = linkval.substr(1);
		}
		BX('link' + link_md5_id).value = linkval;
		BX('full' + link_md5_id).value = 'http://' + linkval;
	}
	else if (linkval_.substr(0, 1) == '/')
	{
		BX('pro' + link_md5_id).value = '/';
		while (linkval.substr(0, 1) == '/')
		{
			linkval = linkval.substr(1);
		}
		BX('link' + link_md5_id).value = linkval;
		BX('full' + link_md5_id).value = '/' + linkval;
	}
	else if (linkval.length > 0)
	{
		BX('full' + link_md5_id).value = BX('pro' + link_md5_id).value + linkval;
	}
	else
	{
		BX('full' + link_md5_id).value = '';
	}
}