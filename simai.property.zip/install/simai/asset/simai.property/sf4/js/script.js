
function property() {

    var list = document.body.querySelectorAll('input:not([type="hidden"])');
    var select = document.body.querySelectorAll('select');
    var textarea = document.body.querySelectorAll('textarea');
    var checkbox = document.body.querySelectorAll('input[type="checkbox"]');
    var listImage = document.body.querySelectorAll('[data-list]');
    var cond = document.querySelectorAll('.radio-change');
    var sort = document.querySelectorAll('[data-sort]');

    function isTrue(el) {
        if(el != null && el != undefined) return true; else return false;
    }

    var inactive = document.body.querySelectorAll('.sf4_property_inactive');

    if(isTrue(inactive)) {
        for(var k = 0; k < inactive.length; k++) {
            var el = inactive[k];
            el.addEventListener('click', function(e) {
                e.currentTarget.classList.remove('sf4_property_inactive');
                var input = e.currentTarget.querySelector('.hidden-input'),
                    allElements = e.currentTarget.querySelectorAll('[disabled=""]');

                for(var k = 0; k < allElements.length; k++)
                    if(allElements[k].hasAttribute('disabled')) allElements[k].removeAttribute('disabled');
                if(isTrue(input)) {
                    input.setAttribute('value', "Y");
                    input.value = "Y";
                }
                var allInput = e.currentTarget.querySelectorAll('input'),
                    event = new Event('input');
                if(isTrue(allInput)) {
                    for(var x = 0; x < allInput.length; x++) {
                        var eIn = allInput[x];
                        if(eIn.classList.contains('hidden-input')) {
                            eIn.focus();
                        }
                    }
                }
            })
        }
    }


    var btnMulti = document.body.querySelectorAll('input[data-button-property=""]');
        if(btnMulti != null) {
            for(var k = 0; k < btnMulti.length; k++) {
                btnMulti[k].onclick = function(e) {
                    addField(e);
                }
            }
        }


    // ----------- SELECT ------------- //

    if(select != null) {
        for(var k = 0; k < select.length; k++) {
            var slc = select[k];
                slc.addEventListener('change', function(e) {
                    var el = e.currentTarget;
                    var chang = el.parentNode.querySelector('[if-type="checkbox"]');
                    for(var s = 0; s < el.options.length; s++) {
                        var opt = el.options[s];
                        if(opt.selected) {
                            opt.setAttribute('selected', '');
                            if (chang != null) {
                                chang.setAttribute('checked', 'checked');
                                chang.setAttribute('value', opt.value);
                            }
                        } else {
                            opt.removeAttribute('selected');
                            if (chang != null) {
                                chang.removeAttribute('checked');
                            }
                        }
                    }
                    var chan = new Event('change');
                    if (chang != null) {
                        chang.dispatchEvent(chan);
                    }
                });
        }
    }

    if(isTrue(list)) {
        for(var k = 0; k < list.length; k++) {
            var el = list[k];
            el.addEventListener('input', function(e) {
                var input = e.target,
                    condition = input.nextElementSibling,
                    event = new Event('change');
                if(condition.type != "hidden" || condition.type != "hidden") {
                    if(isTrue(condition)) {
                        condition.setAttribute('value', linkConditionSetValue(input) + input.value)
                        condition.setAttribute('checked', 'checked');
                        condition.dispatchEvent(event);
                        if(input.hasAttribute('data-protocol')) {
                            condition.value = linkConditionSetValue(input) + input.value;
                        } else condition.value = input.value;
                        condition.checked = true;
                    }
                    if(isTrue(input)) {
                        if(input.classList.contains('form-check-input')) {
                            if(input.checked) {
                                input.value = "Y";
                                input.checked = true;
                                input.setAttribute('value', 'Y');
                                input.setAttribute('checked', 'checked');
                            } else {
                                input.setAttribute('value', 'N');
                                input.removeAttribute('checked');
                                input.checked = false;
                                input.value = "N";
                            }
                        }
                    }
                }
                
                
            });
        }
    }

    function linkConditionSetValue(input) {
        if(input) {
            if(input.hasAttribute('data-protocol')) {
                
                var container = input.parentNode,
                    selectProtocol = container.querySelector('select[data-protocol=""]');
                if(selectProtocol) {
                    for(var k = 0; k < selectProtocol.options.length; k++) {
                        var opt = selectProtocol.options[k];
                        if(opt.selected) {
                            return opt.value;
                        }
                    }
                }
            }
        }
    }

    if(isTrue(textarea)) {
        for(var k = 0; k < textarea.length; k++) {
            var el = textarea[k];
            el.addEventListener('input', function(e) {
                var input = e.target,
                    condition = input.nextElementSibling,
                    event = new Event('change');
                if(isTrue(condition)) {
                    condition.setAttribute('value', input.value)
                    condition.setAttribute('checked', 'checked');
                    condition.dispatchEvent(event);
                    condition.value = input.value;
                    condition.checked = true;
                }
            })
        }
    }

    if(isTrue(listImage)) {
        for(var k = 0; k < listImage.length; k++) {
            var data = listImage[k];
            if(data.hasAttribute('data-list')) {
                var dataList = data.getAttribute('data-list');
                //imageAction(data);
            }
        }
    }

    // ----------- CHECKBOX ------------- //

    if(checkbox != null) {
        for(var k = 0; k < checkbox.length; k++) {
            var check = checkbox[k],
                chang = check.nextElementSibling;

            if(check.checked) {
                check.setAttribute('checked', '');
                if(chang != null && chang != undefined)
                    chang.setAttribute('checked', 'checked');
            } else {
                check.removeAttribute('checked', '');
                if(chang != null && chang != undefined)
                    chang.removeAttribute('checked');
            }

            if(chang != null && chang != undefined) {
                var chan = new Event('change');
                chang.dispatchEvent(chan);
            }
        }
    }

    var checkbox = document.body.querySelectorAll('[data-property-checkbox]');

    if(checkbox != null) {
        for(var k = 0; k < checkbox.length; k++) {
            checkbox[k].addEventListener('change', function(e) {
                var el = e.target,
                    chang = el.nextElementSibling
                if(el.checked) {
                    el.value = 'Y'
                    el.setAttribute('value', 'Y');
                    el.setAttribute('checked', '');
                    chang.setAttribute('checked', 'checked');
                    chang.setAttribute('value', el.value);
                } else {
                    el.value = "N";
                    el.setAttribute('value', 'N');
                    el.setAttribute('checked', '');
                    el.removeAttribute('checked');      
                    chang.removeAttribute('checked');   
                    chang.setAttribute('value', el.value);
                }
                var chan = new Event('change');
                chang.dispatchEvent(chan);
            });
        }
    }
        if(inactive != null) {
            for(var i = 0; i < inactive.length; i++) {

                var input = inactive[i].querySelectorAll('input'),
                    select = inactive[i].querySelectorAll('select'),
                    textarea = inactive[i].querySelectorAll('textarea');

                if(inactive[i].hasAttribute('data-input')) {
                    inactive[i].ondragend = function(e) {
                        e.target.parentNode.parentNode.querySelector('.hidden-input').value = 'Y'; 
                        searchParent(e.target);				
                    }
                }

                if(input != null) {
                    for(var k = 0; k < input.length; k++) {
                        var data = input[k];

                        

                        if(data.hasAttribute('data-property-checkbox')) {
                            var dataCheck = data.getAttribute('data-property-checkbox');
                                data.addEventListener('input', function(e) {
                                    var el = e.target,
                                        elHidden = el.parentNode.querySelector('.hidden-input');

                                    if(el.checked) {
                                        el.value = 'Y';
                                        el.setAttribute('value', 'Y');
                                        el.setAttribute('checked', 'checked');
                                    } else {
                                        el.value = 'N';
                                        el.setAttribute('value', 'N');
                                        el.removeAttribute('checked')
                                    }
                                    
                                    if(elHidden != null) {
                                        elHidden.value = 'Y'; 
                                        elHidden.setAttribute('value', 'Y');                                                                       
                                    }
                                    searchParent(el);
                                });
                        }

                        if(data.hasAttribute('data-entity')) {
                            if(data.getAttribute('data-entity')) {

                                var btn = data.parentNode.querySelector('input[type="button"]');
                                if(btn != null) {
                                    btn.addEventListener('click', function(e) {
                                        var el = e.target;
                                        var hidden = el.parentNode.parentNode.querySelector('.hidden-input');
                                        hidden.value = "Y";
                                        hidden.setAttribute('value', 'Y');
                                        searchParent(el);
                                    });
                                }
                            }
                        }

                        if(data.hasAttribute('data-datetime')) {
                            if(data.getAttribute('data-datetime') == 'inactive-public') {
                                data.addEventListener('click', function(e) {
                                    data.classList.remove("sf4_property_inactive");
                                })
                                inactiveMode(data);
                            }
                        }
                    }
                }
            }
        }


        if(list != null) {
            for(var k = 0; k < list.length; k++) {
                var listOne = list[k];
                
                if(listOne.hasAttribute('data-list')) {
                    switch(listOne.getAttribute('data-list')) {
                        case 'public-button':
                            imageAction(listOne, true);
                            break;
                        case 'public-button-radio':
                            imageAction(listOne, true);
                            break;
                        case 'public-image-list-one':
                            imageAction(listOne);
                        break;
                        case 'public-image-list-multi':
                            imageAction(listOne);
                            break;                  
                    }
                }

                if(listOne.hasAttribute('data-number')) {
                    switch(listOne.getAttribute('data-number')) {
                        case 'public-one':
                            
                            listOne.addEventListener('input', function(e) {
                                var chang = e.target.nextElementSibling;
                                chang.setAttribute('value', e.target.value);
                                chang.setAttribute('checked', 'checked')
                                var chan = new Event('change');
                                chang.dispatchEvent(chan);
                            });
                            break;
                    }
                }
            }
        }

        function addField(e) {
            var btn = e.target,
                container = btn.parentNode;
            if(container != null) {
                var el = container.querySelectorAll("*");
                var propContainerElement = btn.parentNode.parentNode.querySelectorAll('*');
                var input = [],
                    entity = [],
                    string = [],
                    text = [],
                    number = [],
                    phone = [],
                    url = [],
                    link = [],
                    date = [];

                for(var i = 0; i < el.length; i++) {
                    if(el[i].hasAttribute('data-property-field')) {
                        switch(el[i].getAttribute('data-property-field')) {
                            case 'entity':
                                entity.push(el[i]);
                                break;
                            case 'string':
                                string.push(el[i]);
                                break;
                            case 'text':
                                text.push(el[i]);
                                break;
                            case 'number':
                                number.push(el[i]);
                                break;
                            case 'phone':
                                phone.push(el[i]);
                                break;
                            case 'url':
                                url.push(el[i]);
                                break;
                            /*case 'link':
                                link.push(el[i]);
                                break;*/
                            case 'date':
                                date.push(el[i]);
                                break;
                        }
                    }
                }
                for(var k = 0; k < propContainerElement.length; k++) {
                    if(propContainerElement[k].hasAttribute('data-property-field')) {
                        switch(propContainerElement[k].getAttribute('data-property-field')) {
                            case 'link':
                                link.push(propContainerElement[k]);
                                break;
                        }
                    }
                }
                if(entity.length != 0) addEntity(entity, e);
                if(text.length != 0) addText(text, e);
                if(string.length != 0) addString(string, e);
                if(number.length != 0) addString(number, e);
                if(phone.length != 0) addString(phone, e);
                if(url.length != 0) addString(url, e);
                if(link.length != 0) addStringLink(link, e);
                if(date.length != 0) addDate(date, e);
            }
        }
        
        function inactiveMode(input) {


            input.addEventListener('input', function(e) {
                var el = e.target;
                el.parentNode.parentNode.querySelector('.hidden-input').value = 'Y'; 
                searchParent(el);
            });

            input.addEventListener('change', function(e) {
                var el = e.target;            
                el.parentNode.parentNode.querySelector('.hidden-input').value = 'Y'; 					
                searchParent(el);
            });
        }

        function imageAction(input, active) {
            input.addEventListener('click', function(e) {
                var el = e.target;
                var radio = el.parentNode.parentNode.querySelectorAll('input');
                

                var chang = el.nextElementSibling;
                if(isTrue(chang))
                    var par = chang.parentNode.parentNode.querySelectorAll('.radio-change');
                else {
                    chang = el.parentNode.parentNode.querySelector('.radio-change');
                    par = el.parentNode.parentNode.querySelectorAll('.radio-change');
                }

                var checkedValue = '';

                for(var k = 0; k < radio.length; k++) {
                    if(radio[k].checked && radio.length == 1) {
                        checkedValue += radio[k].value
                    } else if(radio[k].checked && radio.length > 1) {
                        checkedValue += radio[k].value;
                    }
                }

                par[0].setAttribute('value', checkedValue)

                chang.setAttribute('checked', 'checked')
                

                var chan = new Event('change');
                chang.dispatchEvent(chan);
                par[0].dispatchEvent(chan)
                chang.setAttribute('value', el.value);


                if(input.type == 'radio') {
                    for(var k = 0; k < radio.length; k++) {
                        radio[k].checked = false;
                        radio[k].removeAttribute('checked');
                        if(active) radio[k].parentNode.classList.remove('active');   
                    }
                    el.checked = true;
                    el.setAttribute('checked', '');
                    if(active) el.parentNode.classList.add('active');
                } else if(input.type == 'checkbox') {
                    if(!el.checked) {
                        el.checked = false;
                        el.removeAttribute('checked');
                        if(active) el.parentNode.classList.remove('active');
                    } else {
                        el.checked = true;
                        el.setAttribute('checked', '');
                        if(active) el.parentNode.classList.add('active');
                    }
                }
            });
        }

        function searchParent(el) {
            if(el != null && el.tagName != 'BODY') {
                if(!el.parentNode.classList.contains('sf4_property_inactive')) searchParent(el.parentNode);
                else el.parentNode.classList.remove('sf4_property_inactive');
            }
        }
        
        function rand() {
            return Math.random() * (500000000000000000 - 50000000000000000) + 50000000000000000;
        }

        function addStringLink(link, e) {
            var btnContainer = document.createElement('div');
            btnContainer.className = e.currentTarget.parentNode.getAttribute('class');
            var endClone = link[link.length - 1].cloneNode(true),
                btnClone = e.currentTarget.cloneNode(true),
                input = endClone.querySelectorAll('input'),
                name = [];
            if(input) {
                for(var k = 0; k < input.length; k++) name.push(input[k].name);
                for(var k = 0; k < input.length; k++) {
                    input[k].value = '';
                    input[k].name = fieldIncrementName(name[k], link);
                    input[k].removeAttribute('required');
                }
                btnClone.onclick = function(ev) {
                    addField(ev);
                }
                btnContainer.appendChild(btnClone);
                link.push(endClone);
                link.push(btnContainer);
                var parent = link[0].parentNode;
                parent.innerHTML = '';
                for(var i = 0; i < link.length; i++) parent.appendChild(link[i]);
            }
        }

        function addString(string, e) {
            var endClone = string[string.length - 1].cloneNode(true),
                btnClone = e.target.cloneNode(true),
                input = endClone.querySelectorAll('input'),
                name = input[0].name;
                btnClone.onclick = function(e) {
                    addField(e);
                }
                if(input == null)
                    input = endClone.querySelectorAll('textarea');
                input[0].value = '';
                input[0].name = nameReplace(name, string);
                input[0].removeAttribute('required');

                if(input[0].hasAttribute('data-phone')) {
                    var id = 'phone_mask_' + rand();
                    input[0].id = id;
                    id = '#' + id;

                    jQuery(function($) {
                        $(id).mask('+9 (999) 999-9999');
                    });
                }

                if(input[0].hasAttribute('data-url')) {
                    var id = rand();
                    input[0].id = id;
                    var btn = input[1];
                    if(btn != null) {
                        btn.addEventListener('click', function(e) {
                                BX.adminShowMenu(this, [
                                    {'TEXT':'Site directory','TITLE':'#SITE_DIR# - Site directory','ONCLICK':'SF.SFSetUrlVar(\'#SITE_DIR#\', \''+ id + '\')'},
                                    {'SEPARATOR':true},
                                    {'TEXT':'Storage id','TITLE':'#STORAGE_ID# - Storage id','ONCLICK':'SF.SFSetUrlVar(\'#STORAGE_ID#\', \''+ id + '\')'},
                                    {'TEXT':'Section id','TITLE':'#SECTION_ID# - Section id','ONCLICK':'SF.SFSetUrlVar(\'#SECTION_ID#\', \''+ id + '\')'},
                                    {'TEXT':'Item id','TITLE':'#ITEM_ID# - Item id','ONCLICK':'SF.SFSetUrlVar(\'#ITEM_ID#\', \''+ id + '\')'}], ''
                                );
                            });
                    }
                }
                
                string.push(endClone);
                string.push(btnClone);
                var parent = string[0].parentNode;
                parent.innerHTML = '';
                for(var i = 0; i < string.length; i++) parent.appendChild(string[i]);
        }

        function addDate(date, e) {
            var endClone = date[date.length - 1].cloneNode(true),
                btnClone = e.target.cloneNode(true);
                var input = endClone.querySelectorAll('input'),
                name = input[0].name;
                btnClone.onclick = function(e) {
                    addField(e);
                }
                input[0].value = '';
                input[0].name = nameReplace(name, date);
                input[0].removeAttribute('required');
                date.push(endClone);
                date.push(btnClone);
                var parent = date[0].parentNode;
                parent.innerHTML = '';
                for(var i = 0; i < date.length; i++) parent.appendChild(date[i]);

                jQuery(function($) {
                    $('input[name="' + input[0].name + '"]').flatpickr({
                        dateFormat: "d.m.Y",
                        allowInput: true,
                        locale: 'ru',
                    });
                });
        }

        function addText(text, e) {
            var endClone = text[text.length - 1].cloneNode(true),
                btnClone = e.target.cloneNode(true),
                textArea = endClone.querySelectorAll('textarea'),
                name = textArea[0].name;
                btnClone.onclick = function(e) {
                    addField(e);
                }
                var newText = document.createElement('textarea'),
                    conText = document.createElement('div');
                conText.className = 'form-group';
                conText.setAttribute('data-property-field', 'text');
                newText.name = nameReplace(name, text);
                newText.className = 'form-control';
                newText.removeAttribute('required');
                newText.rows = textArea[0].rows;
                newText.cols = textArea[0].cols;
                conText.appendChild(newText);  
                text.push(conText);
                text.push(btnClone);
                var parent = text[0].parentNode;
                parent.innerHTML = '';
                for(var i = 0; i < text.length; i++) parent.appendChild(text[i]);
        }

        function nameReplace(name, text) {
            /*var startIndex = name.indexOf('[n', 0);
            var length = 2;
            if (startIndex < 0) {
                startIndex = name.indexOf('[', 0);
                length = 1;
            }

            if(text.length > 11) {
                var index = name.substr(startIndex + length, 2);
                var name = name.substr(0, name.length - 3);
            }
            else {
                var index = name.substr(startIndex + length, 1);
                var name = name.substr(0, name.length - 2);
            }
            
            name += (Number(index)) + rand() + ']';*/
            
            var name_arr = name.split('[n');
            var n_index = name_arr.pop();
            if (n_index && name_arr.length > 0)
            {
                n_index = '0' + n_index.replace(/\D+/g,"");
                n_index = parseInt(n_index);
                n_index ++;
                name = name_arr.join('[n');
                name += '[n' +  n_index + ']';
            }
            else
            {
                var name_arr = name.split('[');
                name_arr.pop();
                name = name_arr.join('[');
                name += '[n0]';
            }
            
            return name;
        }

        function fieldIncrementName(name, text) {
            var limit = name.substr(name.indexOf('[n', 0) + 2),
                index = name.substr(name.indexOf('[n', 0) + 2, limit.length - 2),
                name = name.substr(0, name.indexOf('[n', 0) + 2);
            index++;
            return name + index + '1]';
        }

        function addEntity(entity, e) {
            var cI = entity[entity.length - 1].cloneNode(true),
                cB = e.target.cloneNode(true),
                inp = cI.querySelectorAll('input'),
                id = inp[0].id,
                btn = inp[1].getAttribute('onclick'),
                name = inp[0].name,
                randId = rand();

            cB.onclick = function(e) {
                addField(e);
            }
            btn = btn.replace(id, randId);
            inp[0].value = '';
            inp[0].name = nameReplace(name, entity);
            inp[0].setAttribute('id', randId);
            inp[1].setAttribute('onclick', btn);
            entity.push(cI);
            entity.push(cB);
            var parent = entity[0].parentNode;
            parent.innerHTML = '';
            for(var j = 0; j < entity.length; j++) parent.appendChild(entity[j]);
        }


    // #region Link
    
        var link = document.body.querySelectorAll('.container-link');
        for(var k = 0; k < link.length; k++) {
            var container = link[k].querySelectorAll('.property_link');
            for(var w = 0; w < container.length; w++) {
                var input = container[w].querySelectorAll('input');
                var select = container[w].querySelector('select');
                for(var h = 0; h < input.length; h++) {
                    if(input[h].hasAttribute('data-protocol')) {
                        deleteSpace(input[h]);
                        replaiceProtocol(select, input[h]);
                        identifyProtocol(input[h]);
                    }
                }
            }
        }

       /* window.addEventListener('click', function(e) {
            var el = e.target;
            if(el.oninput != null)
                identifyProtocol(el);
            if(el.hasAttribute('data-protocol'))
                identifyProtocol(el);
        });*/

        function deleteSpace(input) {
            var str = '';                
            for(var s = 0; s < input.value.length; s++) if(input.value[s] != ' ') str += input.value[s];
            input.value = str;
        }

        function identifyProtocol(el) {
            if(el.hasAttribute('data-protocol')) { 
                var input = el;
                var select = el.parentNode.querySelector('select');
                if(input != null) {
                    if(input.hasAttribute('data-protocol')) {
                        el.elSelect = select;
                        select.elInput = el;
                        el.oninput = function(e) {
                            let input = e.currentTarget;
                            replaiceProtocol(input.elSelect, input);
                        }
                        select.addEventListener('change', function(e) {
                            var sel = e.currentTarget;
                            replaiceProtocol(sel, sel.elInput);
                        })
                    }
                }
            }
        }

        function replaiceProtocol(select, input) {
            deleteSpace(input);
            var fullLink = select.parentNode.querySelector('input[data-link-full=""]');
            for(var j = 0; j < select.options.length; j++) {
                var options = select.options[j];
                if(input.value.substring(0, options.value.length) == options.value) {
                    select.selectedIndex = j;
                    input.value = input.value.substring(options.value.length, input.value.length);
                    select.options[j].setAttribute('selected', '');
                    select.options[j].selected = true;
                } else if(input.value.substring(0, 1) === '/') {
                    select.selectedIndex = 2;
                    select.options[2].selected = true;
                    select.options[2].setAttribute('selected', '');
                } else if(input.value.substring(0, options.value.length) === './') {
                    select.selectedIndex = 3;
                    select.options[3].selected = true;
                    select.options[3].setAttribute('selected', '');
                } else if(input.value.substring(0, options.value.length) === '../') {
                    select.selectedIndex = 4;
                    select.options[4].selected = true;
                    select.options[4].setAttribute('selected', '');
                }
            }
            if(input.value != "") fullLink.value = setFullLink(select) + input.value;
            else fullLink.value = '';
        }

        function setFullLink(select) {
            for(var k = 0; k < select.options.length; k++) if(select.options[k].selected) return select.options[k].value;
            return false;
        }

        if(isTrue(cond)) {
            for(var k = 0; k < cond.length; k++) {
                var el = cond[k],
                    event = new Event('change');
                el.dispatchEvent(event);
            }
        }

    // #endregion Link

    SF.SFSetUrlVar = function(id, el_id) {
    var obj_ta = BX(el_id);
    //IE
    if (document.selection) {
        obj_ta.focus();
        var sel = document.selection.createRange();
        sel.text = id;
        //var range = obj_ta.createTextRange();
        //range.move('character', caretPos);
        //range.select();
    }
    //FF
    else if (obj_ta.selectionStart || obj_ta.selectionStart == '0')
    {
        var startPos = obj_ta.selectionStart;
        var endPos = obj_ta.selectionEnd;
        var caretPos = startPos + id.length;
        obj_ta.value = obj_ta.value.substring(0, startPos) + id + obj_ta.value.substring(endPos, obj_ta.value.length);
        obj_ta.setSelectionRange(caretPos, caretPos);
        obj_ta.focus();
    }
    else
    {
        obj_ta.value += id;
        obj_ta.focus();
    }

    BX.fireEvent(obj_ta, 'change');
    obj_ta.focus();
}


'use strict';

;( function ( document, window, index ) {
    var inputs = document.querySelectorAll( '[data-file=""]' );
    
    Array.prototype.forEach.call( inputs, function( input )
    {
        var label	 = input.nextElementSibling,
            labelVal = label.innerHTML;

        input.addEventListener( 'change', function(e) {  
            var fileName = '';
            if( this.files && this.files.length > 1 )
                fileName = ( this.getAttribute( 'data-multiple-caption' ) || '' ).replace( '{count}', this.files.length );
            else fileName = e.target.value.split( '\\' ).pop();

            if( fileName ) {
                if(fileName.length > 16)
                    label.querySelector( 'span' ).innerHTML = fileName.slice(0, 16) + '...';
                else label.querySelector( 'span' ).innerHTML = fileName;
            }
            else label.innerHTML = labelVal;

            // Для свойств
            var el = e.target;
            if(el.hasAttribute('data-inactive'))
                el.parentNode.parentNode.classList.remove('sf4_property_inactive')
        });

        // Firefox bug fix
        input.addEventListener( 'focus', function(){ input.classList.add( 'has-focus' ); });
        input.addEventListener( 'blur', function(){ input.classList.remove( 'has-focus' ); });
    });
}( document, window, 0 ));


};


try {
    property();
} catch(error) {
    window.addEventListener('DOMContentLoaded', function(e) {
        property();
    });
}





SF.send = function(event, element) {
    if(document.createEvent){
        var e = document.createEvent('Events');
        e.initEvent(event, true, false);
    }
    else if(document.createEventObject()) {
        var e = document.createEventObject();
    }
    else return;

    if(element.dispatchEvent)
        element.dispatchEvent(e);
    else if(element.fireEvent) element.fireEvent(event, e);
}

SF.receive = function(event, el, handler) {
    if(window.addEventListener)
        el.addEventListener(event, handler, false);
    else if(window.attachEvent)
        el.attachEvent(event, handler);
}

SF.receive('open-setting', window, property);

