;

'use strict'



SF.rand = function() {
    return Math.random() * (500000000000000000 - 50000000000000000) + 50000000000000000;
}

SF.Maps = function() {

};

SF.Maps.createMap = function(id, position) {
    var search = new ymaps.control.SearchControl({
        options: {
            // ����� ������� ���������� �����
            // � ���� ��������� ������.
            size: 'large',
            // ������� ����������� ������
            // �� ������ ��������, �� � �����������.
            provider: 'yandex#search'            
        }
    });

    //var ID = 'sf-map-' + id;

    search.events.add('resultselect', function (e) {
        var cMap = document.querySelector('[' + id + ']');
        var results = search.getResultsArray(),
            selected = e.get('index'),
            point = results[selected].geometry.getCoordinates();
        if(cMap != null && cMap != undefined) {
            cMap.value = point;
        }
    });
    
    var mapMain = new ymaps.Map(id, {
        center: ['54.729335, 55.941318'],
        zoom: 16,
        controls: ["zoomControl", search],
    });

    mapMain.setType('yandex#map');

    //console.log(mapMain)
    //mapMain.behaviors.disabled('scroolZoom');

    var placemarkMain = new ymaps.Placemark([position], {}, {
        precent: 'islands#blueDotIcon',
    });

    mapMain.geoObjects.add(placemarkMain);
}

SF.receive('open-setting', window, function(e) {
    var addMap = document.querySelectorAll('.map_property');


    
    
    for(var k = 0; k < addMap.length; k++) {
        var itemAll = addMap[k].querySelectorAll('.map_property__item'),
            btn = addMap[k].querySelector('.map_property__btn_add');
        
        //console.log(btn)
//btn.addEventListener
    if(btn != null && btn != undefined) {
        btn.addEventListener('click', function(e) {
            /*var script = document.createElement('script');
            script.src = '//api-maps.yandex.ru/2.1/?lang=ru-RU&load=package.full';
            document.head.appendChild(script)*/
            var item = itemAll[itemAll.length - 1],
                input = item.querySelector('.map_property__field'),
                name = input.name,
                namePrefix = name.substr(0, name.indexOf('[', 0)),
                pos_1 = name.indexOf('[', 0) + 1,
                pos_2 = name.indexOf(']', name.length - 1),
                index = name.slice(pos_1, pos_2),
                id = SF.rand(),
                mapItem = document.createElement('div'),
                mapEl = document.createElement('div'),
                mapField = document.createElement('input'),
                mapId = 'sf-map-' + id,
                searchId = 'search_' + id,
                placemark = 'placemark_' + id;

            mapItem.classList.add('map_property__item');

            mapEl.id = 'sf-map-' + id;
            mapEl.className = 'w-100 mb-4 h-auto';
            mapEl.style.height = '400px';

            mapField.type = 'hidden';
            mapField.setAttribute('sf-map-' + id, '');
            mapField.value = "54.729335, 55.941318";
            mapField.classList.add('map_property__field');
            mapField.name = namePrefix + '[' + (Number (index) + 1) + ']';

            mapItem.appendChild(mapEl);
            mapItem.appendChild(mapField);
            e.target.parentNode.insertBefore(mapItem, e.target);
            //setTimeout(function(e) {
                SF.Maps.createMap(mapId, '54.729335, 55.941318');
            //}, 1000)
            
        })
    }

        


    }
})

