<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

use Bitrix\Main\Page\Asset;
	\SIMAI\Main\Page\Asset::getInstance()->load('sf4property');

$cols = intval($params['cols']);
if ($cols < 1):	$cols = 25;
elseif ($cols > 100): $cols = 100; endif;

$MULTIPLE_CNT = intval($params['multiple_cnt']);
if ($MULTIPLE_CNT <= 0 || $MULTIPLE_CNT > 30): $MULTIPLE_CNT = 3; endif;

$bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));
$cnt = ($params["multiple"] == "Y" ? $MULTIPLE_CNT + ($bInitDef ? 1 : 0) : 1);
$start = 0;?>

<?if (!is_array($values)): $values = array($values); endif;?>


<div class="container-entity sf4_property <?if($params["inactive"] == "Y"):?>sf4_property_inactive<?endif?>">
	<?foreach($values as $key => $val):?>
		<div class="form-group sf4_property" data-property-field="number">
			<input
				data-number="public-one"
				name="<?=$params["field_name"]?>[<?=$key?>1]"
				class="form-control"
				value="<?=$val?>"
				size="<?=$cols?>"
				type="text"
				<?if($params["required"] == "Y"):?>required<?endif?> />
			<div
				checked="checked"
				if-type="text"
				class="d-none radio-change"
				name="<?=$params["field_name"]?>[0]"
				value="<?=$val?>"></div>
		</div>
		<?if ($params["multiple"] != "Y"):
			$params["bVarsFromForm"] = true;
			break;
		endif;
	endforeach;?>
	<?if (!$params["bVarsFromForm"]):
		for ($i = 0; $i < $cnt; $i++):?>
			<?if ($i == 0 && $bInitDef): $val = $params["default_value"];
			else: $val = ""; endif;?>
			<div class="form-group" data-property-field="number">
				<input 
					data-number="public-multi"
					class="form-control"
					name="<?=$params["field_name"]?>[n<?=($start + $i)?>]"
					value="<?=$val?>"
					size="<?=$cols?>"
					type="text"
					<?if($params["required"] == "Y"):?>required<?endif?> />
			</div>
		<?endfor;
	endif;?>
	<?if($params["inactive"] == "Y"):?>
		<input name="<?=$params["field_name"]?>_edit" value="N" type="hidden" class="hidden-input" />
	<?endif?>
	<?if ($params["multiple"] == "Y"):?>	
		<input class="btn btn-primary" type="button" 
			value="<?=GetMessage("SF_PROPERTY_AT_PROP_ADD")?>"
			data-button-property="">
	<?endif;?>
</div>