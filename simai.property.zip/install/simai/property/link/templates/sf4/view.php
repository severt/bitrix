<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$params["view_length"] = intval($params["view_length"]);

if (!is_array($values)):
	$values = array($values);
endif;

if (in_array($params['target'], array('_blank', '_self', '_parent', '_top'))):
	$target = $params['target'];
else:
	$target = '_blank';
endif;

$download = '';
if ($params['download'] == 'Y'):
	$download = ' download';
endif;

$rel = '';
if (trim($params['rel'])):
	$rel = ' rel="'.$params['rel'].'"';
endif;

foreach ($values as $i => $value):
	$value = trim($value);
	if (substr($value, 0, 7) == 'http://' || substr($value, 0, 8) == 'https://' || substr($value, 0, 1) == '/' || substr($value, 0, 2) == './' || substr($value, 0, 3) == '../'):
		$values[$i] = '<a target="'.$target.'"'.$download.$rel.' href="'.$value.'">'.($params["view_length"] > 0 ? TruncateText($value, $params["view_length"]) : $value).'</a>';
	endif;
endforeach;

echo implode('<br />', $values);
?>