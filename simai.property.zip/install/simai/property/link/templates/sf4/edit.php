<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
	$local = $params["local"] == "Y";

	$cols = intval($params['cols']);
	if ($cols < 1):	$cols = 25;
	elseif ($cols > 100): $cols = 100; endif;

	$MULTIPLE_CNT = intval($params['multiple_cnt']);
	if ($MULTIPLE_CNT <= 0 || $MULTIPLE_CNT > 30): $MULTIPLE_CNT = 3; endif;

	$bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));
	$cnt = ($params["multiple"] == "Y" ? $MULTIPLE_CNT + ($bInitDef ? 1 : 0) : 1);
	$start = 0;?>
	
	<?use Bitrix\Main\Page\Asset,
		Bitrix\Main\Localization\Loc;
	Asset::getInstance()->addCss('/simai/asset/simai.property/sf4/css/link/sf4/style.css');
	\SIMAI\Main\Page\Asset::getInstance()->load('sf4property');?>

	<?if(!is_array($values)):$values = Array("0" => array("VALUE" => $values, "DESCRIPTION" => $params['text'])); endif;?>

	<div class="container-link sf4_property <?if($params["inactive"] == "Y"):?>sf4_property_inactive<?endif?>">
		<?foreach($values as $key=>$val):?>
			<?if(is_int($key)) $index = $key; else $index = 0;?>
			<div class="property_link form-group form-inline align-items-start" data-property-field="link">
				<?if (!$local):?>
					<select class="sf_link_protocol form-control property_link__select" data-protocol="" <?if($params["inactive"] == "Y"):?>disabled<?endif?>
						<?if($params["required"] == "Y"):?>required<?endif?>>
						<option value="http://">http://</option>
						<option value="https://">https://</option>	
						<option value="/">(local from root) /</option>
						<option value="./">(local from current) ./</option>
						<option value="../">(local from parent) ../</option>
					</select>
				<?endif?>
				<input name="<?=$params["field_name"]?>[<?=$index?>1][VALUE]" data-protocol="" <?if($params["inactive"] == "Y"):?>disabled<?endif?>
					class="form-control sf_link_input property_link__field <?if($params["description"] === "Y"):?>mb-2<?endif?>"
					value="<?if(is_array($val)):?><?=$val['VALUE']?><?else:?><?=$values["VALUE"]?><?endif?>"
					size="<?=$cols?>" type="text" <?if($params["required"] == "Y"):?>required<?endif?> />
				<div <?if ($val == 'Y'):?>checked="checked"<?endif?> class="d-none radio-change" if-type="checkbox" name="<?=$params["field_name"]?>[0]" value="<?if(is_array($val)):?><?=$val['VALUE']?><?else:?><?=$values["VALUE"]?><?endif?>"></div>
				<input type="hidden" name="<?=$params["field_name"]?>[<?=$index?>1][VALUE]" data-link-full="" value="<?if(is_array($val)):?><?=$val['VALUE']?><?else:?><?=$values["VALUE"]?><?endif?>" />
				<?if($params["description"] === "Y"):?>
					<input class="form-control sf_link_description property_link__description" value="<?if(is_array($val)):?><?=$val['DESCRIPTION']?><?else:?><?=$values["DESCRIPTION"]?><?endif?>" type="text" name="<?=$params["field_name"]?>[<?=$index?>1][DESCRIPTION]" />
				<?endif?>
			</div>
			<?if($params["multiple"] != "Y"):$params["bVarsFromForm"] = true; break; endif;?>
		<?endforeach;?>

		<?if (!$params["bVarsFromForm"]):
			$start = $index;
			for ($i = 1; $i < $cnt; $i++):?>
				<div class="property_link form-group form-inline align-items-start" data-property-field="link">
					<?if ($i == 1 && $bInitDef): $val = $params["default_value"]; else: $val = ""; endif;?>
					<?if (!$local):?>
						<select class="sf_link_protocol form-control property_link__select" data-protocol="" <?if($params["required"] == "Y"):?>required<?endif?> <?if($params["inactive"] == "Y"):?>disabled<?endif?>>
							<option value="http://">http://</option>
							<option value="https://">https://</option>
							<option value="/">(local from root) /</option>
							<option value="./">(local from current) ./</option>
							<option value="../">(local from parent) ../</option>
						</select>
					<?endif?>
					<input name="<?=$params["field_name"]?>[<?=($start + $i)?>1][VALUE]" data-protocol="" <?if($params["inactive"] == "Y"):?>disabled<?endif?>
						class="form-control sf_link_input property_link__field <?if($params["description"] === "Y"):?>mb-2<?endif?>"
						value="<?=$val?>" size="<?=$cols?>" type="text" <?if($params["required"] == "Y"):?>required<?endif?> />
					<div <?if ($val == 'Y'):?>checked="checked"<?endif?> class="d-none radio-change" if-type="checkbox" name="<?=$params["field_name"]?>[0]" value="<?=$val?>"></div>
					<input type="hidden" name="<?=$params["field_name"]?>[<?=($start + $i)?>1][VALUE]" data-link-full="" value="<?=$val?>" />
					<?if($params["description"] === "Y"):?>
						<input class="form-control sf_link_description property_link__description" value="<?=$params["text"]?>" type="text" name="<?=$params["field_name"]?>[<?=($start + $i)?>1][DESCRIPTION]" />
					<?endif?>
				</div>
			<?endfor;?>
		<?endif;?>
		<?if($params["inactive"] == "Y"):?><input name="<?=$params["field_name"]?>_edit" value="N" type="hidden" class="hidden-input" /><?endif?>
		<?if ($params["multiple"] == "Y"):?>
			<div class="btn-container d-inline-flex align-items-start justify-content-start w-100">
				<input class="btn btn-primary" type="button" data-button-property="" value="<?=Loc::getMessage("SF_PROPERTY_AT_PROP_ADD")?>" />
			</div>
		<?endif;?>
	</div>