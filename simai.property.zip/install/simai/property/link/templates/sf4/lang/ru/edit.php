<?
$MESS ['SF_PROPERTY_AT_PROP_ADD'] = "Добавить";
?>