<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$params['img_max_width'] = intval($params['img_max_width']);
if ($params['img_max_width'] < 1 || $params['img_max_width'] > 1000)
{
	$params['img_max_width'] = 50;
}

$params['img_max_height'] = intval($params['img_max_height']);
if ($params['img_max_height'] < 1 || $params['img_max_height'] > 1000)
{
	$params['img_max_height'] = 50;
}

$params['filename_max_length'] = intval($params['filename_max_length']);
if ($params['filename_max_length'] < 1 || $params['filename_max_length'] > 300)
{
	$params['filename_max_length'] = 20;
}

if ($params['resize_type'] != 'BX_RESIZE_IMAGE_EXACT')
{
	$params['resize_type'] = 'BX_RESIZE_IMAGE_PROPORTIONAL';
}

if (!is_array($values)):
	$values = array($values);
endif;

$print_vals = array();

foreach ($values as $key => $val):	
	if ($val > 0):
		$arFile = CFile::GetFileArray($val);
		if ($arFile['WIDTH'] > 0 && $arFile['HEIGHT'] > 0 && $params["multiple"] != "Y" && count($values) < 2):
			$image = CFile::ResizeImageGet($val, array('width' => $params['img_max_width'], 'height' => $params['img_max_height']), $params['resize_type'], true);
			$print_vals[] = '<img src="'.$image['src'].'" width="'.$image['width'].'"  width="'.$image['height'].'" />';
		elseif ($arFile['SRC']):
			$print_vals[] = '<a download rel="nofollow" href="'.$arFile['SRC'].'">'.htmlspecialcharsbx(TruncateText($arFile['FILE_NAME'], $params['filename_max_length'])).'</a>';
		endif;
	endif;
endforeach;

echo implode(' <br /> ', $print_vals);
?>