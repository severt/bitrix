<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if ($params["file_type"] != 'I' && $params["file_type"] != 'F')
{
	$params["file_type"] = 'F';
}

$start = 0;

$table_id = rand();

?>
<table cellpadding="0" cellspacing="0" border="0" class="nopadding" width="100%" id="tb<?=md5($table_id)?>">
<tr><td>

<?
if (!is_array($values)):
	$values = array($values);
endif;

/*
if ($params["multiple"] != "Y"):
	$params["bVarsFromForm"] = true;
	break;
endif;
*/

\Bitrix\Main\Loader::includeModule('fileman');

if ($params["multiple"] != "Y"):
	
	$inputName = array();
	foreach ($values as $key => $val):
		if (is_array($val)):
			$inputName[$params["field_name"]."[".$key."]"] = $val["VALUE"];
		else:
			$inputName[$params["field_name"]."[".$key."]"] = $val;
		endif;
	endforeach;
		
	echo \Bitrix\Main\UI\FileInput::createInstance((
		array(
			"name" => $params["field_name"]."[n#IND#]",
			//"id" => $params["field_name"]."[n#IND#]_".mt_rand(1, 1000000),
			"description" => false,
			"allowUpload" => $params["file_type"],
			"allowUploadExt" => $params["file_ext"],
			"maxCount" => 1,
			"upload" => true,
			"delete" => true,
			"medialib" => true,
			"fileDialog" => true,
			"cloud" => true
		)
	))->show($inputName);
		
else:

	$inputName = array();
	foreach ($values as $key => $val):
		if (is_array($val)):
			$inputName[$params["field_name"]."[".$key."]"] = $val["VALUE"];
		else:
			$inputName[$params["field_name"]."[".$key."]"] = $val;
		endif;
	endforeach;

	echo \Bitrix\Main\UI\FileInput::createInstance((
		array(
			"name" => $params["field_name"]."[n#IND#]",
			//"id" => $params["field_name"]."[n#IND#]_".mt_rand(1, 1000000),
			"description" => false,
			"allowUpload" => $params["file_type"],
			"allowUploadExt" => $params["file_ext"],
			"maxCount" => 30,
			"upload" => true,
			"delete" => true,
			"medialib" => true,
			"fileDialog" => true,
			"cloud" => true
		)
	))->show($inputName);
	
endif;
?>

<br>
</td></tr>
</table>