<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$inp_id = md5(rand());

if (is_array($values)):
	$values = current($values);
endif;
?>
<input type="checkbox" id="<?=$inp_id?>" name="<?=$params["field_name"]?>" value="Y"<?if ($values == 'Y'):?> checked<?endif?>>
<label for="<?=$inp_id?>"><?=getMessage('SF_PROPERTY_AT_PROP_FILE_EXISTS')?></label>