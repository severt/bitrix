<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>
<div class="form-group">
	?$inp_id = md5(rand());
	if (is_array($values)):
		$values = current($values);
	endif;?>
	<label for="<?=$inp_id?>"><?=getMessage('SF_PROPERTY_AT_PROP_FILE_EXISTS')?></label>
	<input class="form-control" type="checkbox" id="<?=$inp_id?>" name="<?=$params["field_name"]?>" value="Y"<?if ($values == 'Y'):?> checked<?endif?>>
</div>