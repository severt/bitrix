<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

use Bitrix\Main\Page\Asset;
use Bitrix\Main\Localization\Loc; 

Loc::loadMessages(__FILE__); 

Asset::getInstance()->addCss('/simai/asset/simai.property/sf4/css/file/sf4/style.css');
\SIMAI\Main\Page\Asset::getInstance()->load('sf4property');

if ($params["file_type"] != 'I' && $params["file_type"] != 'F')
	$params["file_type"] = 'F';?>

<?if (!is_array($values)): $values = array($values); endif;?>

<?\Bitrix\Main\Loader::includeModule('fileman');

global $USER;?>
<div class="file_block_property <?if($params["inactive"] == "Y"):?>sf4_property_inactive<?endif?>">
	<?if ($params["multiple"] != "Y"):
		if ($USER->IsAuthorized()):
			$inputName = array();
			foreach ($values as $key => $val):
				if (is_array($val)):
					$inputName[$params["field_name"]."[".$key."1]"] = $val["VALUE"];
				else:
					$inputName[$params["field_name"]."[".$key."1]"] = $val;
				endif;
			endforeach;?>
				
			<?=\Bitrix\Main\UI\FileInput::createInstance((
				array(
					"name" => $params["field_name"]."[n#IND#]",
					"description" => true,
					"allowUpload" => $params["file_type"],
					"allowUploadExt" => $params["file_ext"],
					"maxCount" => 1,
					"upload" => true,
					"delete" => true,
					"medialib" => true,
					"fileDialog" => true,
					"cloud" => true
				)
			))->show($inputName);?>
			<div <?if ($val !== ''):?>checked="checked"<?endif?> class="d-none radio-change"
					if-type="checkbox"
					name="<?=$params["field_name"]?>[0]"
					value="<?=$values?>"></div>
		<?else:?>
			<div class="form-group">
				<input
					type="file"
					name="<?=$params["field_name"]?>[0]"
					class="form-control-file"
					<?if($params["required"] == "Y"):?>required<?endif?>/>
			</div>
		<?endif;?>
	<?else:?>
		<?if ($USER->IsAuthorized()):?>
			<?$inputName = array();
			foreach ($values as $key => $val):
				if (is_array($val)):
					$inputName[$params["field_name"]."[".($key+1)."]"] = $val["VALUE"];
				else:
					$inputName[$params["field_name"]."[".($key+1)."]"] = $val;
				endif;
			endforeach;?>

			<?=\Bitrix\Main\UI\FileInput::createInstance((
				array(
					"name" => $params["field_name"]."[n#IND#]",
					"description" => true,
					"allowUpload" => $params["file_type"],
					"allowUploadExt" => $params["file_ext"],
					"multiple" => "Y",
					"upload" => true,
					"delete" => true,
					"medialib" => true,
					"fileDialog" => true,
					"cloud" => true
				)
			))->show($inputName);?>
			<div <?if ($val !== ''):?>checked="checked"<?endif?> class="d-none radio-change"
					if-type="checkbox"
					name="<?=$params["field_name"]?>[0]"
					value="<?=$values?>"></div>
		<?else:?>
			<div class="form-group">
			 <input
					type="file"
					name="<?=$params["field_name"]?>"
					multiple
					class="form-control-file"
					<?if($params["required"] == "Y"):?>required<?endif?>/>
			</div>	
		<?endif;?>
	<?endif;?>
	
	<?if($params["inactive"] == "Y"):?>
		<input name="<?=$params["field_name"]?>_edit" value="N" type="hidden" class="hidden-input" />
	<?endif?>
</div>