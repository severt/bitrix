<?
$MESS ['SF_PROPERTY_TYPE_NAME'] = "Карта";
?>