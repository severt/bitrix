<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

global $APPLICATION;

$table_id = rand();
$salt = \Bitrix\Main\Security\Random::getString(4);

$apikey = '';
if ($params['yandex_map_api_key']):
    $apikey = '&apikey='.htmlspecialcharsbx($params['yandex_map_api_key']);
endif;

if (!$params['width']):
    $params['width'] = '600px';
endif;

if (!$params['height']):
    $params['height'] = '400px';
endif;

$behaviors = array("'default'");
$controls = array();

if ($params['scrollZoom']):
    $behaviors[] = "'scrollZoom'";
endif;

if ($params['zoomControl']):
    $controls[] = "'zoomControl'";
endif;
if ($params['searchControl']):
    $controls[] = "'searchControl'";
endif;
if ($params['typeSelector']):
    $controls[] = "'typeSelector'";
endif;
if ($params['fullscreenControl']):
    $controls[] = "'fullscreenControl'";
endif;
if ($params['routeButtonControl']):
    $controls[] = "'routeButtonControl'";
endif;

$APPLICATION->AddHeadString('<script src="https://api-maps.yandex.ru/2.1/?lang=ru_RU'.$apikey.'" type="text/javascript"></script>');

$MAP_ID = "YMaps".$salt;

if (!is_array($values)):
    $values = array($values);
endif;

$value = current($values);

if (strlen($value) > 0)
{
    list($POINT_LAT, $POINT_LON) = explode(',', $value);
    $bHasValue = true;
}
else
{
    $bHasValue = false;
}
?>

<div id="<?=$MAP_ID?>" style="width:<?=$params['width']?>; height:<?=$params['height']?>;"></div>

<script type="text/javascript">
    ymaps.ready(function () {
        var myMap = new ymaps.Map('<?=$MAP_ID?>', {
            center: [55.75581376138799, 37.624845039099476],
            zoom: 10,
            behaviors: [<?=implode(', ', $behaviors)?>], 
            controls: [<?=implode(', ', $controls)?>]
        });
        
        window.obPoint = null;
        
        <?if ($bHasValue):?>
        window.obPoint = new ymaps.Placemark([<?=htmlspecialcharsbx($POINT_LAT)?>, <?=htmlspecialcharsbx($POINT_LON)?>], {}, {draggable:false});
        
        myGeoObject = new ymaps.GeoObject({});
        myMap.geoObjects.add(myGeoObject).add(window.obPoint);
        
        myMap.setCenter([<?=htmlspecialcharsbx($POINT_LAT)?>, <?=htmlspecialcharsbx($POINT_LON)?>], 10);
        <?endif?>
    });
</script>