<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

global $APPLICATION;

$table_id = rand();
$salt = \Bitrix\Main\Security\Random::getString(4);

$apikey = '';
if ($params['yandex_map_api_key']):
    $apikey = '&apikey='.htmlspecialcharsbx($params['yandex_map_api_key']);
endif;

if (!$params['width']):
    $params['width'] = '600px';
endif;

if (!$params['height']):
    $params['height'] = '400px';
endif;

if (!$params["default_value"]):
    $params["default_value"] = "55.75581376138799, 37.624845039099476";
endif;

$APPLICATION->AddHeadString('<script src="https://api-maps.yandex.ru/2.1/?lang=ru_RU'.$apikey.'" type="text/javascript"></script>');

$MAP_ID = "YMaps".$salt;

if (!is_array($values)):
    $values = array($values);
endif;

$value = current($values);

if (strlen($value) > 0)
{
    list($POINT_LAT, $POINT_LON) = explode(',', $value);
    $bHasValue = true;
}
else
{
    $bHasValue = false;
}
?>

<div id="<?=$MAP_ID?>" style="width:<?=$params['width']?>; height:<?=$params['height']?>;"></div>
<div class="form-group">
    <input type="hidden" id="value_<?=$MAP_ID?>" name="<?=$params["field_name"]?>" value="<?=htmlspecialcharsbx($value)?>" />
</div>

<script type="text/javascript">
ymaps.ready(function () {
    var myMap = new ymaps.Map('<?=$MAP_ID?>', {
            center: [<?=$params["default_value"]?>],
            zoom: 10,
            controls: []
        }),

    mySearchControl<?=$salt?> = new ymaps.control.SearchControl({
            options: {
                noPlacemark: true
            }
        }),

    mySearchResults<?=$salt?> = new ymaps.GeoObjectCollection(null, {
            hintContentLayout: ymaps.templateLayoutFactory.createClass('$[properties.name]')
        });
    myMap.controls.add(mySearchControl<?=$salt?>);
    myMap.geoObjects.add(mySearchResults<?=$salt?>);
    
    mySearchResults<?=$salt?>.events.add('click', function (e) {
        //e.get('target').options.set('preset', 'islands#redIcon');
        
        mySearchResults<?=$salt?>.removeAll();
        window.obPoint<?=$salt?> = null;
        
        clearPointPosition<?=$salt?>();
    });
    
    mySearchControl<?=$salt?>.events.add('resultselect', function (e) {
        
        mySearchResults<?=$salt?>.removeAll();
        window.obPoint<?=$salt?> = null;
        
        var index = e.get('index');
        mySearchControl<?=$salt?>.getResult(index).then(function (res) {
            var coords = res.geometry.getCoordinates();
            
            if (null == window.obPoint<?=$salt?>)
            {
                window.obPoint<?=$salt?> = new ymaps.Placemark(coords, {}, {draggable:true});
                
                myGeoObject = new ymaps.GeoObject({});
                myMap.geoObjects.add(myGeoObject).add(window.obPoint<?=$salt?>);
                
                window.obPoint<?=$salt?>.events.add('dragend', updatePointPosition<?=$salt?>);
                
                mySearchResults<?=$salt?>.add(window.obPoint<?=$salt?>);
            }
            else
            {
                window.obPoint<?=$salt?>.geometry.setCoordinates(coords);
            }
            
            updatePointPosition<?=$salt?>();
        });
        
    }).add('submit', function () {
            mySearchResults<?=$salt?>.removeAll();
        });
        
    myMap.events.add('click', function (e) {
        var coords = e.get('coords');
        
        if (null == window.obPoint<?=$salt?>)
        {
            window.obPoint<?=$salt?> = new ymaps.Placemark(coords, {}, {draggable:true});
            
            myGeoObject = new ymaps.GeoObject({});
            myMap.geoObjects.add(myGeoObject).add(window.obPoint<?=$salt?>);
            
            window.obPoint<?=$salt?>.events.add('dragend', updatePointPosition<?=$salt?>);
            
            mySearchResults<?=$salt?>.add(window.obPoint<?=$salt?>);
        }
        else
        {
            window.obPoint<?=$salt?>.geometry.setCoordinates(coords);
        }
        
        updatePointPosition<?=$salt?>(coords);
        //setPointValue(e)
    });
    
    window.obPoint<?=$salt?> = null;
    
    <?if ($bHasValue):?>
    window.obPoint<?=$salt?> = new ymaps.Placemark([<?=htmlspecialcharsbx($POINT_LAT)?>, <?=htmlspecialcharsbx($POINT_LON)?>], {}, {draggable:true});
    
    myGeoObject = new ymaps.GeoObject({});
    myMap.geoObjects.add(myGeoObject).add(window.obPoint<?=$salt?>);
    
    window.obPoint<?=$salt?>.events.add('dragend', updatePointPosition<?=$salt?>);
    
    mySearchResults<?=$salt?>.add(window.obPoint<?=$salt?>);
    
    myMap.setCenter([<?=htmlspecialcharsbx($POINT_LAT)?>, <?=htmlspecialcharsbx($POINT_LON)?>], 10);
    <?endif?>
});

function updatePointPosition<?=$salt?>(obPoint<?=$salt?>)
{
    if (!!obPoint<?=$salt?> && !!obPoint<?=$salt?>.geometry)
        obPoint<?=$salt?> = obPoint<?=$salt?>.geometry.getCoordinates();
    else if (!!window.obPoint<?=$salt?>)
        obPoint<?=$salt?> = window.obPoint<?=$salt?>.geometry.getCoordinates();
    else
        obPoint<?=$salt?> = null;
    
    BX('value_<?=$MAP_ID?>').value = obPoint<?=$salt?> ? obPoint<?=$salt?>[0] + ',' +obPoint<?=$salt?>[1] : '';
    BX.fireEvent(BX('value_<?=$MAP_ID?>'), 'change');
}

function clearPointPosition<?=$salt?>()
{
    BX('value_<?=$MAP_ID?>').value = obPoint<?=$salt?> ? obPoint<?=$salt?>[0] + ',' +obPoint<?=$salt?>[1] : '';
    BX.fireEvent(BX('value_<?=$MAP_ID?>'), 'change');
}
</script>