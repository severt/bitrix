<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$apikey = '';
if ($params['yandex_map_api_key']):
    $apikey = '&apikey='.htmlspecialcharsbx($params['yandex_map_api_key']);
endif;

if (!$params["default_value"]):
    $params["default_value"] = "54.729335, 55.941318";
endif;

\Bitrix\Main\Page\Asset::getInstance()->addCss('/simai/asset/simai.property/sf4/css/map/sf4/style.css');
\Bitrix\Main\Page\Asset::getInstance()->addJs('/simai/asset/simai.property/sf4/js/map/sf4/script.js');
\SIMAI\Main\Page\Asset::getInstance()->load('sf4property');
\Bitrix\Main\Page\Asset::getInstance()->addString('<script src="//api-maps.yandex.ru/2.1/?lang=ru-RU&load=package.full'.$apikey.'" type="text/javascript"></script>');

$MULTIPLE_CNT = intval($params['multiple_cnt']);
if ($MULTIPLE_CNT <= 0 || $MULTIPLE_CNT > 30):
    $MULTIPLE_CNT = 1;
endif;

$bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));
$cnt = ($params["multiple"] == "Y" ? $MULTIPLE_CNT + ($bInitDef ? 1 : 0) : 1);
$start = 0;

if(!$values):
    $values = Array(
        0 => $params["default_value"],
    );
endif;

if (!is_array($values)):
    $values = array($values);
endif;

$index = 1;
?>

<div class="map_property <?if($params["inactive"] == "Y"):?>sf4_property_inactive<?endif?>">
    
    <? if(!$params["bVarsFromForm"]):
        for($i = 0; $i < $cnt; $i++):?>
        <? $index++;?>
            <div class="map_property__item">
                <? $salt = rand();?>
                <?
                if($values[$i]):
                   $val = $values[$i];
                else:
                    $val = $params["default_value"];
                endif;
                ?>
                <div id="sf-maps-<?=$salt?>" class="w-100 mb-4 h-auto" style="height:400px"></div>
                <input type="hidden" sf-map-<?=$salt?> value="<?=$val?>" class="map_property__field" name="<?=$params["field_name"]?>[<?=$i?>]" />
                <script type="text/javascript">
                    
                    if(!stat_<?=$salt?>) {
                        
                        
                        ymaps.load(initYMap_<?=$salt?>);
                        
                        function initYMap_<?=$salt?>() {
                            var stat_<?=$salt?> = true;

                            var search_<?=$salt?> = new ymaps.control.SearchControl({
                                options: {
                                    size: 'large',
                                    provider: 'yandex#search'            
                                }
                            });

                            search_<?=$salt?>.events.add('resultselect', function (e) {
                                
                                var cMap = document.querySelector('[sf-map-<?=$salt?>]');
                                var results = search_<?=$salt?>.getResultsArray(),
                                    selected = e.get('index'),
                                    point = results[selected].geometry.getCoordinates();
                                if(cMap != null && cMap != undefined) {
                                    cMap.value = point;
                                }
                            })

                            var sf_map_<?=$salt?> = new ymaps.Map('sf-maps-<?=$salt?>', {
                                center: [<?=$val?>],
                                zoom: 16,
                                controls: ['zoomControl', search_<?=$salt?>],
                            });

                            sf_map_<?=$salt?>.setType('yandex#map');
                            sf_map_<?=$salt?>.behaviors
                                .disable('scrollZoom');

                            var placemark_<?=$salt?> = new ymaps.Placemark([<?=$val?>], {}, {
                                precent: 'islands#blueDotIcon',
                            });

                            sf_map_<?=$salt?>.geoObjects.add(placemark_<?=$salt?>);
                            
                            
                            sf_map_<?=$salt?>.events.add('dblclick', function (e) {
                                e.preventDefault(); 
                                var coords = e.get('coords');
                                $('[name="<?=$params["field_name"]?>[<?=$i?>]"]').val(coords);
                                var placemark_<?=$salt?> = new ymaps.Placemark(coords, {}, {
                                precent: 'islands#blueDotIcon',
                              });
                                sf_map_<?=$salt?>.geoObjects.set(0,placemark_<?=$salt?>);
                            });
                            
                        }
                    }
                    var stat_<?=$salt?> = false;
                </script>
            </div>
        <? endfor;
    endif;?>

    <? if($params["inactive"] == "Y"):?>
        <input name="<?=$params["field_name"]?>_edit" value="N" type="hidden" class="hidden-input" />
    <? endif?>
    <? if ($params["multiple"] == "Y"):?>
        <input class="btn btn-primary map_property__btn_add" data-button-property type="button" value="<?=GetMessage("SF_PROPERTY_AT_PROP_ADD")?>" />
    <? endif;?>
</div>

<script>

</script>