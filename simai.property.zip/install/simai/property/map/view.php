<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if (!isset($params['yandex_map_api_key']))
    $params['yandex_map_api_key'] = \Bitrix\Main\Config\Option::get('fileman', 'yandex_map_api_key', '');
?>