<?
$MESS ['SF_PROPERTY_TYPE_NAME'] = "Составное свойство хранилищ";
?>