<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$FROM_STORAGE_MODE = false;
$arProp = array();
$ALL_LANGS = array();

// check if we can use simai.storage to set view
if (\Bitrix\Main\Loader::includeModule('simai.storage') && $params['storage_id'] && $params['storage_complex_prop_code']):
	
	$FROM_STORAGE_MODE = true;
	
	$ALL_LANGS = \SIMAI\Storage\UserAccess::GetAllLangs();
	
	$propFilter = array(array('=STORAGE_ID' => $params['storage_id'], '=TYPE' => 'complex'));
	if (preg_match('/^[0-9]+$/i', $params['storage_complex_prop_code'])):
		$propFilter['=PROPERTY_ID'] = intval($params['storage_complex_prop_code']);
	else:
		$propFilter['=CODE'] = $params['storage_complex_prop_code'];
	endif;
	$res = \SIMAI\Storage\Property::getList(array('filter' => $propFilter));
	if ($arProp = $res->fetch()):
		
		$params['property'] = array();
		
		$propFilter = array(array('=STORAGE_ID' => $params['storage_id'], '!=TYPE' => 'complex', '=COMPLEX' => $arProp['CODE']));
		$res = \SIMAI\Storage\Property::getList(array('filter' => $propFilter, 'order' => array('SYSTEM' => 'desc', 'SORT' => 'asc', 'PROPERTY_ID' => 'asc')));
		while ($arr = $res->fetch()):
			
			$arSubProp = $arr;
			
			$res_lan = \SIMAI\Storage\PropertyLanTable::GetList(array('filter' => array('=PROPERTY_ID' => $arSubProp['PROPERTY_ID'])));
			while ($arr_lan = $res_lan->fetch()):
				$arSubProp['LANGUAGE'][$arr_lan['LANGUAGE_ID']] = $arr_lan['NAME'];
			endwhile;
			
			$show_edit_type = false;
			$show_edit_type_arr = \SIMAI\Storage\PropertyType::getShowEditType($arSubProp['TYPE']);
			if (is_array($show_edit_type_arr)):
				$arSubProp['VIEW_TYPE'] = $show_edit_type_arr['type'];
				
				foreach ($show_edit_type_arr['params'] as $key => $val):
					$arSubProp['SETTINGS'][$key] = $val;
				endforeach;
			endif;
			
			$params['property'][$arSubProp['CODE']] = $arSubProp;
		endwhile;
	endif;
	
endif;

if (is_array($values)):
	foreach ($values as $propValId => $val_arr):
		if (is_array($params['property']) && is_array($val_arr)):
		?>
		
		<!-- show one complex value -->
		<table class="prop_complex_val">
			<?if (isset($val_arr['title'])):?>
				<!-- show complex value title -->
				<caption><?=$val_arr['title']?></caption>
			<?endif?>
			<tr>
			<?
			foreach ($params['property'] as $subPropCode => $arSubProp):
				
				$subPropCode = str_replace('~', '', $subPropCode); // removing tilda from sub property code
				$arSubProp['CODE'] = str_replace('~', '', $arSubProp['CODE']); // removing tilda from sub property code
				
				if (isset($val_arr[$subPropCode])):
				?>
				<th>
					<!-- sub-property name -->
					<?
					$sub_name = $subPropCode;
					if (isset($arSubProp['LANGUAGE'][$params['LANGUAGE_ID']])):
						$sub_name = $arSubProp['LANGUAGE'][$params['LANGUAGE_ID']];
					elseif (isset($arSubProp['name'])):
						$sub_name = $arSubProp['name'];
					endif;
					
					echo htmlspecialcharsbx($sub_name);
					?>
				</th>
				<?
				endif;
			endforeach;
			?>
			</tr>
			<tr>
			<?
			foreach ($params['property'] as $subPropCode => $arSubProp):
				if (isset($val_arr[$subPropCode])):
					
					$sub_value = $val_arr[$subPropCode];
					
					$sub_type = isset($arSubProp['VIEW_TYPE']) ? $arSubProp['VIEW_TYPE'] : $arSubProp['type'];
					
					$sub_params = isset($arSubProp['SETTINGS']) ? $arSubProp['SETTINGS'] : $arSubProp['parameter'];
					
					$sub_params['multiple'] = isset($sub_params['multiple']) ? $sub_params['multiple'] : $arSubProp['multiple'];
					?>
				<td>
					<!-- sub-property value -->
					<?
					\SIMAI\Property::view(
						$sub_type, // type
						(isset($arSubProp['template']) ? htmlspecialcharsbx($arSubProp['template']) : $template), // template
						$sub_value, // values
						$sub_params, // params
						false // not use safe values ($sub_value and $sub_params are parts of $values and $params)
					);
					?>
				</td>
					<?
				endif;
			endforeach;
			?>
			</tr>
		</table>
		<?
		endif;
	endforeach;
endif;?>