<?
$MESS ['SF_STORAGE_ADD'] = "Добавить";
?>