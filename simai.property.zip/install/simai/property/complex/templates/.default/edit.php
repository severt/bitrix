<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

global $APPLICATION;

$APPLICATION->SetAdditionalCSS('/simai/asset/simai.property/.default/css/complex/style.css');

$APPLICATION->AddHeadScript('/simai/asset/simai.property/.default/js/jquery.js');
$APPLICATION->AddHeadScript('/simai/asset/simai.property/.default/js/sort.js');

$sortable_ul_id = rand(99, 99999);

if (!is_array($values)):
    $values = array();
endif;

$FROM_STORAGE_MODE = false;
$arProp = array();
$ALL_LANGS = array();

// check if we can use simai.storage to set form
if (\Bitrix\Main\Loader::includeModule('simai.storage') && $params['storage_id'] && $params['storage_complex_prop_code']):
    
    $FROM_STORAGE_MODE = true;
    
    $ALL_LANGS = \SIMAI\Storage\UserAccess::GetAllLangs();
    
    $propFilter = array(array('=STORAGE_ID' => $params['storage_id'], '=TYPE' => 'complex'));
    if (preg_match('/^[0-9]+$/i', $params['storage_complex_prop_code'])):
        $propFilter['=PROPERTY_ID'] = intval($params['storage_complex_prop_code']);
    else:
        $propFilter['=CODE'] = $params['storage_complex_prop_code'];
    endif;
    $res = \SIMAI\Storage\Property::getList(array('filter' => $propFilter));
    if ($arProp = $res->fetch()):
        $params['property'] = array();
        
        $propFilter = array(array('=STORAGE_ID' => $params['storage_id'], '!=TYPE' => 'complex', '=COMPLEX' => $arProp['CODE']));
        $res = \SIMAI\Storage\Property::getList(array('filter' => $propFilter, 'order' => array('SYSTEM' => 'desc', 'SORT' => 'asc', 'PROPERTY_ID' => 'asc')));
        while ($arr = $res->fetch()):
            $arSubProp = $arr;
            
            $res_lan = \SIMAI\Storage\PropertyLanTable::GetList(array('filter' => array('=PROPERTY_ID' => $arSubProp['PROPERTY_ID'])));
            while ($arr_lan = $res_lan->fetch()):
                $arSubProp['LANGUAGE'][$arr_lan['LANGUAGE_ID']] = $arr_lan['NAME'];
            endwhile;
            
            $params['property'][$arSubProp['PROPERTY_ID']] = $arSubProp;
        endwhile;
    endif;
    
    if (!$params['field_name']):
        $params['field_name'] = 'CPROPVAL['.$params['storage_complex_prop_code'].']';
    endif;
    
    require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/simai.storage/include/sf_storage_props.php');
    
endif;
?>

<ul data-input="inp<?=$sortable_ul_id?>" id="ul<?=$sortable_ul_id?>" class="complexprop-sort-ul">

<?
$sortvals = array();

$values_exists = false;
foreach ($values as $propValId => $value):
    $propValId = htmlspecialcharsbx($propValId);
    
    $sortvals[] = $propValId;

    $deleted = '';
    
    $title = '';
    if (isset($value['title'])):
        $title = $value['title'];
    endif;
?>
<li class="li<?=$sortable_ul_id?> sort-elem complexprop-sort-li li_<?=$sortable_ul_id?>_<?=$propValId?><?if ($deleted == 'y'):?> cprop_deleted<?endif?>" data-code="<?=$propValId?>">
    
    <input type="hidden" id="delval_<?=$sortable_ul_id?>_<?=$propValId?>" name="<?=$params["field_name"]?>[deleted_values][<?=$propValId?>]" value="<?=$deleted?>">
    
    <table class="complexprop-props-title<?if ($params["simple"] == 'Y'):?> opened<?endif?>" id="title_<?=$sortable_ul_id?>_<?=$propValId?>">
    <tr>
        
    <?if ($params["simple"] == 'Y'):?>
        <td>
            <input type="hidden" name="<?=$params["field_name"]?>[additional_vals][titles][<?=$propValId?>]" value="<?=$title?>">
            &nbsp;
        </td>
    <?else:?>
        <td class="title">
            <input type="text" name="<?=$params["field_name"]?>[additional_vals][titles][<?=$propValId?>]" value="<?=$title?>">
        </td>
        <td class="edit" onclick="ShowHideComplexVal<?=$sortable_ul_id?>('<?=$propValId?>')">
            &nbsp;
        </td>
    <?endif?>
        
        <td class="del" onclick="DelComplexVal<?=$sortable_ul_id?>('<?=$propValId?>')">
            &nbsp;
        </td>
    </tr>
    </table>
    
    <div class="complexprop-props" id="props_<?=$sortable_ul_id?>_<?=$propValId?>"<?if ($params["simple"] == 'Y'):?> style="display:block;"<?endif?>>
    
        <div class="complexprop-props-in">
        <table width="100%">
        <?
        foreach ($params['property'] as $subPropCode => $arSubProp):
            
            $subPropCode = str_replace('~', '', $subPropCode); // removing tilda from sub property code
            $arSubProp['CODE'] = str_replace('~', '', $arSubProp['CODE']); // removing tilda from sub property code
            
            // use simai.storage helpers
            if ($FROM_STORAGE_MODE):
                
                SFShowElPropVal($params['storage_id'], $params['element_id'], $arSubProp['PROPERTY_ID'], $arSubProp, $ALL_LANGS, $params['bVarsFromForm'], $params['copy_id'], (isset($arSubProp['template']) ? $arSubProp['template'] : $template), $params['storage_complex_prop_code'], $propValId, $value, $params["field_name"]);
                
            // or use "property" sub-array "as is"
            else:
                
                $subprop_name = $subPropCode;
                if (isset($arSubProp['name'])):
                    $subprop_name = $arSubProp['name'];
                endif;
                
                $sub_type = isset($arSubProp['VIEW_TYPE']) ? $arSubProp['VIEW_TYPE'] : $arSubProp['type'];
                $sub_params = isset($arSubProp['SETTINGS']) ? $arSubProp['SETTINGS'] : $arSubProp['parameter'];
                $sub_params['multiple'] = isset($sub_params['multiple']) ? $sub_params['multiple'] : $arSubProp['multiple'];
                
                $sub_params["field_name"] = $params["field_name"].'['.$propValId.']['.$subPropCode.']';
                
                $sub_value = array();
                
                if (isset($value[$subPropCode])):
                    $sub_value = $value[$subPropCode];
                endif;
                
                ?>
                <tr>
                <td class="adm-detail-valign-top" width="40%">
                    <?=$subprop_name?>:
                </td>
                <td width="60%">
                    <?
                    \SIMAI\Property::edit(
                        $sub_type, // type
                        (isset($arSubProp['template']) ? $arSubProp['template'] : $template), // template
                        $sub_value, // values
                        $sub_params, // params
                        false // not use safe values
                    );
                    ?>
                </td>
                </tr>
            <?
            endif;
        endforeach;
        ?>
        </table>
        </div>
    </div>
</li>
<?
    $values_exists = true;
    if ($params['multiple'] != 'Y'):
        break;
    endif;
endforeach;

if (!$values_exists && $params["not_show_first"] != 'Y')
{
    $propValId = rand(99, 99999);
    
    $sortvals[] = $propValId;
    
    $deleted = '';
    
    $title = '';
?>
<li class="li<?=$sortable_ul_id?> sort-elem complexprop-sort-li li_<?=$sortable_ul_id?>_<?=$propValId?>" data-code="<?=$propValId?>">
    
    <input type="hidden" class="delval_<?=$sortable_ul_id?>_<?=$i?>" id="delval_<?=$sortable_ul_id?>_<?=$propValId?>" name="<?=$params["field_name"]?>[deleted_values][<?=$propValId?>]" value="<?=$deleted?>">
    
    <table class="complexprop-props-title opened" id="title_<?=$sortable_ul_id?>_<?=$propValId?>">
    <tr>
        
    <?if ($params["simple"] == 'Y'):?>
        <td>
            <input type="hidden" name="<?=$params["field_name"]?>[additional_vals][titles][<?=$propValId?>]" value="<?=$title?>">
            &nbsp;
        </td>
    <?else:?>
        <td class="title">
            <input type="text" name="<?=$params["field_name"]?>[additional_vals][titles][<?=$propValId?>]" value="<?=$title?>">
        </td>
        <td class="edit" onclick="ShowHideComplexVal<?=$sortable_ul_id?>('<?=$propValId?>')">
            &nbsp;
        </td>
    <?endif?>
        
        <td class="del" onclick="DelComplexVal<?=$sortable_ul_id?>('<?=$propValId?>')">
            &nbsp;
        </td>
    </tr>
    </table>
    
    <div class="complexprop-props" id="props_<?=$sortable_ul_id?>_<?=$propValId?>" style="display:block;">
    
        <div class="complexprop-props-in">
        <table width="100%">
        <?
        foreach ($params['property'] as $subPropCode => $arSubProp):
            // use simai.storage helpers
            if ($FROM_STORAGE_MODE):
                if ($params['copy_id'] > 0 && $params['element_id'] <= 0 && $arSubProp['TYPE'] == 'file'):
                    $value[$arSubProp['CODE']] = array();
                endif;
                
                SFShowElPropVal($params['storage_id'], $params['element_id'], $arSubProp['PROPERTY_ID'], $arSubProp, $ALL_LANGS, $params['bVarsFromForm'], $params['copy_id'], (isset($arSubProp['template']) ? $arSubProp['template'] : $template), $params['storage_complex_prop_code'], $propValId, array($arSubProp['CODE'] => array()), $params["field_name"]);
            // or use "property" sub-array "as is"
            else:
                $subprop_name = $subPropCode;
                if (isset($arSubProp['name'])):
                    $subprop_name = $arSubProp['name'];
                endif;
                
                $sub_type = isset($arSubProp['VIEW_TYPE']) ? $arSubProp['VIEW_TYPE'] : $arSubProp['type'];
                $sub_params = isset($arSubProp['SETTINGS']) ? $arSubProp['SETTINGS'] : $arSubProp['parameter'];
                $sub_params['multiple'] = isset($sub_params['multiple']) ? $sub_params['multiple'] : $arSubProp['multiple'];
                
                $sub_params["field_name"] = $params["field_name"].'['.$propValId.']['.$subPropCode.']';
                
                $sub_value = $arSubProp['default'] ? $arSubProp['default'] : array();
                ?>
                <tr>
                <td class="adm-detail-valign-top" width="40%">
                    <?=$subprop_name?>:
                </td>
                <td width="60%">
                    <?
                    \SIMAI\Property::edit(
                        $sub_type, // type
                        (isset($arSubProp['template']) ? $arSubProp['template'] : $template), // template
                        $sub_value, // values
                        $sub_params, // params
                        false // not use safe values
                    );
                    ?>
                </td>
                </tr>
            <?
            endif;
        endforeach;
        ?>
        </table>
        </div>
        
    </div>
</li>
<?
}


if ($params['multiple'] == 'Y'):
    $multiple_cnt = 15;
    
    for ($i = 0; $i < $multiple_cnt; $i++):
        $propValId = rand(99, 99999);
        
        $sortvals[] = $propValId;
        
        $deleted = 'y';
        
        $title = '';
    ?>
    <li class="li<?=$sortable_ul_id?> sort-elem complexprop-sort-li li_<?=$sortable_ul_id?>_<?=$propValId?> complexprop_new<?=$sortable_ul_id?> n_<?=$sortable_ul_id?>_<?=$i?>" data-code="<?=$propValId?>">
        
        <input type="hidden" class="delval_<?=$sortable_ul_id?>_<?=$i?>" id="delval_<?=$sortable_ul_id?>_<?=$propValId?>" name="<?=$params["field_name"]?>[deleted_values][<?=$propValId?>]" value="<?=$deleted?>">
        
        <table class="complexprop-props-title opened" id="title_<?=$sortable_ul_id?>_<?=$propValId?>">
        <tr>
            
        <?if ($params["simple"] == 'Y'):?>
            <td>
                <input type="hidden" name="<?=$params["field_name"]?>[additional_vals][titles][<?=$propValId?>]" value="<?=$title?>">
                &nbsp;
            </td>
        <?else:?>
            <td class="title">
                <input type="text" name="<?=$params["field_name"]?>[additional_vals][titles][<?=$propValId?>]" value="<?=$title?>">
            </td>
            <td class="edit" onclick="ShowHideComplexVal<?=$sortable_ul_id?>('<?=$propValId?>')">
                &nbsp;
            </td>
        <?endif?>
            
            <td class="del" onclick="DelComplexVal<?=$sortable_ul_id?>('<?=$propValId?>')">
                &nbsp;
            </td>
        </tr>
        </table>
        
        <div class="complexprop-props" id="props_<?=$sortable_ul_id?>_<?=$propValId?>" style="display:block;">
        
            <div class="complexprop-props-in">
            <table width="100%">
            <?
            foreach ($params['property'] as $subPropCode => $arSubProp):
                // use simai.storage helpers
                if ($FROM_STORAGE_MODE):
                    SFShowElPropVal($params['storage_id'], $params['element_id'], $arSubProp['PROPERTY_ID'], $arSubProp, $ALL_LANGS, $params['bVarsFromForm'], $params['copy_id'], (isset($arSubProp['template']) ? $arSubProp['template'] : $template), $params['storage_complex_prop_code'], $propValId, array($arSubProp['CODE'] => array()), $params["field_name"]);
                // or use "property" sub-array "as is"
                else:
                    
                    $subprop_name = $subPropCode;
                    if (isset($arSubProp['name'])):
                        $subprop_name = $arSubProp['name'];
                    endif;
                    
                    $sub_type = isset($arSubProp['VIEW_TYPE']) ? $arSubProp['VIEW_TYPE'] : $arSubProp['type'];
                    $sub_params = isset($arSubProp['SETTINGS']) ? $arSubProp['SETTINGS'] : $arSubProp['parameter'];
                    $sub_params['multiple'] = isset($sub_params['multiple']) ? $sub_params['multiple'] : $arSubProp['multiple'];
                    
                    $sub_params["field_name"] = $params["field_name"].'['.$propValId.']['.$subPropCode.']';
                    
                    $sub_value = $arSubProp['default'] ? $arSubProp['default'] : array();
                    ?>
                    <tr>
                    <td class="adm-detail-valign-top" width="40%">
                        <?=$subprop_name?>:
                    </td>
                    <td width="60%">
                        <?
                        \SIMAI\Property::edit(
                            $sub_type, // type
                            (isset($arSubProp['template']) ? $arSubProp['template'] : $template), // template
                            $sub_value, // values
                            $sub_params, // params
                            false // not use safe values
                        );
                        ?>
                    </td>
                    </tr>
                <?
                endif;
            endforeach;
            ?>
            </table>
            </div>
            
        </div>
    </li>
    <?
    endfor;
endif;
?>



</ul>

<?if ($params['multiple'] == 'Y'):?>
<input type="button" value="<?=GetMessage('SF_STORAGE_ADD')?>" onclick="AddNew<?=$sortable_ul_id?>()" id="add_new_<?=$sortable_ul_id?>">
<?endif;?>

<input type="hidden" id="cur_new_<?=$sortable_ul_id?>" value="0">

<input type="hidden" name="<?=$params["field_name"]?>[additional_vals][sort]" value="<?=implode(',', $sortvals)?>" id="inp<?=$sortable_ul_id?>">

<script type="text/javascript">
function ShowHideComplexVal<?=$sortable_ul_id?>(propValId)
{
<?if ($params['simple'] != 'Y'):?>
    $('#title_<?=$sortable_ul_id?>_' + propValId).toggleClass('opened');
    $('#props_<?=$sortable_ul_id?>_' + propValId).toggle();
<?endif?>
}

function DelComplexVal<?=$sortable_ul_id?>(propValId)
{
    if ($('#delval_<?=$sortable_ul_id?>_' + propValId).val() == '')
    {
        $('#delval_<?=$sortable_ul_id?>_' + propValId).val('y');
        $('.li_<?=$sortable_ul_id?>_' + propValId).addClass('cprop_deleted');
    }
    else
    {
        $('#delval_<?=$sortable_ul_id?>_' + propValId).val('');
        $('.li_<?=$sortable_ul_id?>_' + propValId).removeClass('cprop_deleted');
    }
}

<?if ($params['multiple'] == 'Y'):?>
function AddNew<?=$sortable_ul_id?>()
{
    var cur_al_new = $('#cur_new_<?=$sortable_ul_id?>').val();
    $('.delval_<?=$sortable_ul_id?>_' + cur_al_new).val('');
    $('.n_<?=$sortable_ul_id?>_' + cur_al_new).css('display', 'block');
    cur_al_new++;
    $('#cur_new_<?=$sortable_ul_id?>').val(cur_al_new);
    if (cur_al_new >= <?=$multiple_cnt?>)
    {
        $('#add_new_<?=$sortable_ul_id?>').css('display', 'none');
    }
}

sortable(
    '#ul<?=$sortable_ul_id?>', 
    {
        forcePlaceholderSize: true,
        placeholderClass: 'li<?=$sortable_ul_id?>',
    }
);

$('.complexprop_new<?=$sortable_ul_id?>').css('display', 'none');
<?endif;?>
</script>