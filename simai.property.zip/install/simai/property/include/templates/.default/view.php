<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$table_id = rand();

if(file_exists($params["file"]))
	 require $params["file"];
?>
