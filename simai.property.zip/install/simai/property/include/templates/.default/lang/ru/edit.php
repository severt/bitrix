<?
$MESS ['SF_PROPERTY_AT_PROP_ADD'] = "Добавить";
$MESS ['SF_PROPERTY_AT_FILE_DELETE'] = "удалить файл";
$MESS ['SF_PROPERTY_FILE'] = "Файл";
?>