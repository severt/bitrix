<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$table_id = rand();?>

<?
	$cols = intval($params['cols']);
	if ($cols < 1):	$cols = 25;
	elseif ($cols > 100):$cols = 100; endif;

	$rows = intval($params['rows']);
	if ($rows < 1):	$rows = 1;
	elseif ($rows > 30):$rows = 30; endif;

	
?>

<?if(file_exists($_SERVER["DOCUMENT_ROOT"].$params["path"])):

$text = file_get_contents($_SERVER["DOCUMENT_ROOT"].$params["path"]);


?>
	
	
	<div class="form-group sf4_property">
			<textarea
				class="form-control text_property__field"
				name="<?=$params["field_name"]?>[0]"
				<?if ($params["required"] == "Y"):?>required<?endif;?>
				cols="<?=$cols?>"
				rows="<?=$rows?>"><?=htmlspecialchars($text)?></textarea>
    </div>				
						
						
<?endif;?>



