<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$params["max_length"] = intval($params["max_length"]);

$obParser = new CTextParser;

$allow_tags = '<p><br><br /><strong><em><b><i><u><a><ul><ol><li><span><div><table><tr><th><td><caption><thead><tbody><tfoot><img><code>';

if (!is_array($values)):
	$values = array($values);
endif;

foreach ($values as $i => $value):
	if ($params['strip_tags'] == 'Y'):
		$value = strip_tags(htmlspecialcharsBack($value));
	else:
		$value = strip_tags(htmlspecialcharsBack($value), $allow_tags);
	endif;
	
	if ($params["max_length"] > 0):
		$value = $obParser->html_cut($value, $params["max_length"]);
	endif;
	
	$values[$i] = $value;
endforeach;

echo implode(' <br /><br /> ', $values);
?>