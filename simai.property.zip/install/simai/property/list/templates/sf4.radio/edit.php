<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>

	<?use Bitrix\Main\Page\Asset;
	\SIMAI\Main\Page\Asset::getInstance()->load('sf4property');?>

	<?$rows = intval($params['rows']);
	if ($rows < 1 && $params["multiple"] != "Y"): $rows = 1;
	elseif ($rows < 1 && $params["multiple"] == "Y"): $rows = 5;	
	elseif ($rows > 20): $rows = 20; endif;

	$list_type = ($params['list_type'] == 'check' ? 'check' : 'list');
	$bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));
	$start = 0;?>

	<?if (!is_array($values)): $values = array($values);endif;

	$checked = false;
	$id = rand();

	if (!is_array($params["variants"])):$params["variants"] = array();endif;?>
	<?$checkedMulti = '';?>
	<div class="d-flex align-items-center flex-wrap <?if($params["inactive"] == "Y"):?>sf4_property_inactive<?endif?>" data-list-button data-toggle="">
		<?if ($params["multiple"] == "Y" ):?>
			<?if(count($params["variants"]) > 1):
				foreach($params["variants"] as $keyP => $item):?>
				<?$id = rand();?>
					<div class="sf4_property__list_checkbox form-check mr-2">
						<input
							id="sf4_list__checkbox-<?=$id?>"
							name="<?=$params["field_name"]?>[<?=$keyP?>]"
							data-list="checkbox" 
							value="<?=$keyP?>"
							type="checkbox"
							<?if($params["required"]):?>required<?endif?>
							<?foreach($values as $key => $itemP): $checked = $keyP;?>
								<?if($keyP == $itemP):?>
									checked
									<?if(count($values) == 1):?>
										<?$checkedMulti .= $itemP?>
									<?elseif(count($values) > 1):?>
										<?$checkedMulti .= $itemP.','?>
									<?endif?>
								<?endif?>
							<?endforeach?>
							autocomplete="off"
							class="form-check-input" />
						<label for="sf4_list__checkbox-<?=$id?>" class="form-check-label">
							<?=html_entity_decode($item);?>
						</label>
					</div>
				<?endforeach?>
			<?endif;?>
		<?else:?>
			<?if (count($params["variants"]) > 1):?>
				<?foreach($params["variants"] as $keyP => $item):?>
				<?$id = rand();?>
					<div class="sf4_property__list_radio form-check mr-2">
						<input id="<?=$params["field_name"]?><?=$id?>"
							name="<?=$params["field_name"]?>"
							<?if($params["required"]):?>required<?endif?>
							value="<?=$keyP?>"
							type="radio"
							<?if ($values[0] == $keyP): $checked = $keyP;?><?$checkedMulti .= $keyP?> checked<?endif;?>
							class="form-check-input"
							data-list="radio" />
						<label for="<?=$params["field_name"]?><?=$id?>" class="form-check-label">
							<?=html_entity_decode($item)?>
						</label>
					</div>
				<?endforeach?>
			<?else:?>
			<?$id = rand();?>
				<div class="sf4_property__list_radio form-check mr-2">
					<input id="<?=$params["field_name"]?><?=$id?>"
						name="<?=$params["field_name"]?>"
						<?if($params["required"]):?>required<?endif?>
						value="<?=$values[0]?>"
						type="radio"
						<?if ($values[0] == $keyP): $checked = $keyP;?><?$checkedMulti .= $keyP?> checked<?endif;?>
						autocomplete="off"
						class="form-check-input"
						data-list="radio" />
					<label for="<?=$params["field_name"]?><?=$id?>" class="form-check-label">
						<?=html_entity_decode($values[0])?>
					</label>
				</div>
			<?endif;?>
		<?endif;?>
		<div 
								<?foreach($values as $key => $itemP):?>
									<?if($checked == $itemP):?>
										checked="checked"
									<?endif?>
								<?endforeach?>
								if-type="button"
								class="d-none radio-change"
								name="<?=$params["field_name"]?>[0]"
								value="<?=$checkedMulti?>"></div>
		<?if($params["inactive"] == "Y"):?>
            <input name="<?=$params["field_name"]?>_edit" value="N" type="hidden" class="hidden-input" />
        <?endif?>
	</div>