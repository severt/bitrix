<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>
<div class="form-group">
	<?$rows = intval($params['rows']);
	if ($rows < 1):
		$rows = 5;
	elseif ($rows > 20):
		$rows = 20;
	endif;

	if (!is_array($values)):
		$values = array($values);
	endif;

	if (!is_array($params["variants"])):
		$params["variants"] = array();
	endif;

	$list_type = ($params['list_type'] == 'check' ? 'check' : 'list');

	if ($list_type == 'check'):

		foreach($params["variants"] as $v_key => $v_val):
			$uniq = md5(uniqid(rand(), true));
			$sel = in_array((string) $v_key, $values);
			if ($params["multiple"] == "Y" || count($params["variants"]) == 1):?>
				<label for="<?=$uniq?>">
					<?if (count($params["variants"]) > 1):?>
						<?=$v_val?><?else:?>
					<?endif?>
				</label>			
				<input class="form-control" type="checkbox" name="<?=$params["field_name"]?><?if ($params["multiple"] == 'Y'):?>[]<?endif?>" value="<?=htmlspecialcharsex($v_key)?>" id="<?=$uniq?>"<?=($sel ? " checked" : "")?>>
			
			<?else:?>
				<label for="<?=$uniq?>"><?=$v_val?></label>			
				<input class="form-control" type="radio" name="<?=$params["field_name"]?>" value="<?=htmlspecialcharsex($v_key)?>" id="<?=$uniq?>"<?=($sel? " checked" : "")?>>
			<?endif;
		endforeach;
	else:?>

		<select class="custom-select" name="<?=$params["field_name"]?><?if ($params["multiple"] == 'Y'):?>[]<?endif?>"<?if ($params["field_id"]):?> id="<?=$params["field_id"]?>"<?endif?> size="<?=$rows?>"<?if ($params["multiple"] == 'Y'):?> multiple<?endif?><?if ($params["max_width"]):?> style="max-width:<?=$params["max_width"]?>"<?endif?>>
			<?foreach($params["variants"] as $v_key => $v_val):
				$sel = in_array((string) $v_key, $values);?>
				<option value="<?=htmlspecialcharsex($v_key)?>"<?=($sel ? " selected" : "")?>><?=$v_val?></option>
			<?endforeach?>
		</select>
	<?endif;?>
</div>