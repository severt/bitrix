<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>

<?use Bitrix\Main\Page\Asset;
	\SIMAI\Main\Page\Asset::getInstance()->load('sf4property');	
	Asset::getInstance()->addCss('/simai/asset/simai.property/sf4/css/list/sf4.image.card/style.css');	?>	

<div class="list_image_card container-image-card <?if($params["inactive"] == "Y"):?>sf4_property_inactive<?endif?>">
	<?$rows = intval($params['rows']);
	if ($rows < 1):$rows = 2;endif;
	//elseif ($rows < 1 && $params["multiple"] == "Y"): $rows = 5;	
	//elseif ($rows > 20):$rows = 20;	endif;

	$list_type = ($params['list_type'] == 'check' ? 'check' : 'list');
	$bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));
	$start = 0;?>

	<?if (!is_array($values)): $values = array($values);endif;

	if (!is_array($params["variants"])): $params["variants"] = array();	endif;
	$index = 0;?>
		<?if ($params["multiple"] == "Y" ):
			if(count($params["variants"]) > 1):
				foreach($params["variants"] as $keyP => $item):?>				
					<label class="image-card list_image_card__item" style="max-width:<?=(100 / $rows)-1?>%;flex-basis:<?=(100 / $rows)?>%">
						<input
							class="d-none" 
							name="<?=$params["field_name"]?>[<?=$keyP?>]"
							value="<?=$keyP?>"
							data-list="public-image-card-multi"
							type="checkbox"
							<?if($params["required"]):?>required<?endif?>
							<?foreach($values as $key => $itemP):?>
								<?if($keyP == $itemP):?>
									checked
								<?endif?>
							<?endforeach?>
							autocomplete="off" />
						<div <?foreach($values as $key => $itemP):?>
								<?if($keyP == $itemP):?>
									checked
								<?endif?>
							<?endforeach?>
							class="d-none radio-change"
							if-type="checkbox" name="<?=$params["field_name"]?>[0]" value="<?=$item?>"></div>
						<div class="aspect-ratio aspect-ratio-1x1 container-image">
							<div class="overlay-image aspect-ratio-content b-2 p-3">
								<img class="img-fluid align-middle" src="<?=$item;?>"/>
							</div>
						</div>
					</label>
				<?endforeach?>						
			<?endif;
		else:?>
			<?if ($params["multiple"] != "Y" && count($params["variants"]) > 1):
				$uniq = md5(uniqid(rand(), true));?>
				<?foreach($params["variants"] as $keyP => $item):?>
					<label class="image-card list_image_card__item" style="max-width:<?=(100 / $rows)-1?>%;flex-basis:<?=(100 / $rows)?>%">
						<input
							class="d-none"
							name="<?=$params["field_name"]?>[<?=$keyP?>]"
							value="<?=$keyP?>"
							type="radio"
							data-list="public-image-list-one"
							<?if($params["required"]):?>required<?endif?>	
							<?foreach($values as $key => $itemP):?>
								<?if($keyP == $itemP):?>
									checked
								<?endif?>
							<?endforeach?>
							autocomplete="off" />
						<div <?foreach($values as $key => $itemP):?>
								<?if($keyP == $itemP):?>
									checked
								<?endif?>
							<?endforeach?>
							class="d-none radio-change"
							if-type="checkbox"
							name="<?=$params["field_name"]?>[0]"
							value="<?=$item?>"></div>
							<?//$padding = $index % 3;?>
						<div class="aspect-ratio aspect-ratio-1x1 container-image">
							<div class="overlay-image aspect-ratio-content b-2 p-3">
								<img class="img-fluid align-middle" src="<?=$item;?>"/>
						</div>
						</div>
					</label>
				<?endforeach?>
			<?endif;?>
		<?endif;?>
		<?if($params["inactive"] == "Y"):?>
			<input name="<?=$params["field_name"]?>_edit" value="N" type="hidden" class="hidden-input" />
		<?endif?>
</div>