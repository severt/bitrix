<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>


<?\SIMAI\Main\Page\Asset::getInstance()->load('sf4property');?>

<?//echo $params["inactive"];?>

	<?$rows = intval($params['rows']);
	if ($rows < 1 && $params["multiple"] != "Y"): $rows = 1;
	elseif ($rows < 1 && $params["multiple"] == "Y"): $rows = 5;	
	elseif ($rows > 20): $rows = 20; endif;

	$list_type = ($params['list_type'] == 'check' ? 'check' : 'list');
	$bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));
	$start = 0;?>

	<?if (!is_array($values)): $values = array($values); endif;

	if (!is_array($params["variants"])): $params["variants"] = array();	endif;?>

	<div class="list_block_property <?if($params["inactive"] == "Y"):?>sf4_property_inactive<?endif?>">
		<?if ($list_type == 'check'):
			if ($params["multiple"] != "Y" && count($params["variants"]) > 1):?>
				<div class="form-group">
					<label><?=GetMessage("SF_PROPERTY_NOT_DEFINED")?></label>
					<input
						class="form-control"
						type="radio"
						name="<?=$params["field_name"]?>[01]"
						value=""
						<?if($params["required"] == "Y"):?>required<?endif?> />
					<div <?if ($val == 'Y'):?>checked="checked"<?endif?> class="d-none radio-change"
						if-type="checkbox"
						name="<?=$params["field_name"]?>[0]"
						value="<?=$values?>"></div>
				</div>
			<?endif;
				foreach($params["variants"] as $v_key => $v_val):?>
					<div class="form-group">
						<?if($bInitDef): $sel = ($v_key == $params["default_value"]);
						else: $sel = in_array((string) $v_key, $values); endif;?>
						<?if ($params["multiple"] == "Y" || count($params["variants"]) == 1):?>
							<?if (count($params["variants"]) > 1):?>
								<label><?=$v_val?></label>
							<?endif?>
							<input
								class="form-control"
								type="checkbox"
								name="<?=$params["field_name"]?>[01]"
								value="<?=htmlspecialcharsex($v_key)?>"
								<?=($sel? " checked" : "")?> 
								<?if($params["required"] == "Y"):?>required<?endif?> />
							<div <?=($sel? " checked" : "")?> class="d-none radio-change"
								if-type="checkbox"
								name="<?=$params["field_name"]?>[0]"
								value="<?=htmlspecialcharsex($v_key)?>"></div>
						<?else:?>
							<label><?=$v_val?></label>
							<input
								class="form-control"
								type="radio"
								name="<?=$params["field_name"]?>[01]"
								value="<?=htmlspecialcharsex($v_key)?>"
								<?=($sel ? " checked" : "")?> 
								<?if($params["required"] == "Y"):?>required<?endif?> />
							<div <?=($sel? " checked" : "")?> class="d-none radio-change"
								if-type="checkbox"
								name="<?=$params["field_name"]?>[0]"
								value="<?=htmlspecialcharsex($v_key)?>"></div>
						<?endif?>
					</div>
				<?endforeach;
		else:?>
		<div class="form-group">
			<select
				class="form-control" data-list="select"
				<?if($params["required"] == "Y"):?> required <?endif;?>
				<?if($params["multiple"] == "Y"):?>
					name="<?=$params["field_name"]?>[]"		
				<?else:?>
					name="<?=$params["field_name"]?>[01]"
				<?endif;?>
				size="<?=$rows?>"
				<?=($params["multiple"] == "Y" ? "multiple" : "")?>>

				<?if ($params["multiple"] != "Y"):?>
					<option value=""><?=GetMessage("SF_PROPERTY_NOT_DEFINED")?></option>
				<?endif;
				
				foreach($params["variants"] as $v_key => $v_val):
					if($bInitDef): $sel = ($v_key == $params["default_value"]);
					else: $sel = in_array((string) $v_key, $values); endif;?>
					<option value="<?=htmlspecialcharsex($v_key)?>"
						<?=($sel ? " selected" : "")?>>
						<?=$v_val?>
						<?if($sel) $value = htmlspecialcharsex($v_key);?>
					</option>
				<?endforeach?>
			</select>
			<div
				<?foreach($values as $key => $itemP):?>
					<?if($keyP == $itemP):?>
						checked="checked"
					<?endif?>
				<?endforeach?>
				if-type="select"
				class="d-none radio-change"
				name="<?=$params["field_name"]?>[0]"
				value="<?=$value?>"></div>
		</div>
		<?endif;?>
		<?if($params["inactive"] == "Y"):?>
            <input name="<?=$params["field_name"]?>_edit" value="N" type="hidden" class="hidden-input" />
        <?endif?>
	</div>