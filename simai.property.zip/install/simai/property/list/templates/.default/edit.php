<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$rows = intval($params['rows']);
if ($rows < 1 && $params["multiple"] != "Y"):
	$rows = 1;
elseif ($rows < 1 && $params["multiple"] == "Y"):
	$rows = 5;	
elseif ($rows > 20):
	$rows = 20;
endif;

$list_type = ($params['list_type'] == 'check' ? 'check' : 'list');

$bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));

$start = 0;
//

$table_id = rand();
?>
<table cellpadding="0" cellspacing="0" border="0" class="nopadding" width="100%" id="tb<?=md5($table_id)?>">
<tr><td>
<?
if (!is_array($values)):
	$values = array($values);
endif;

if (!is_array($params["variants"])):
	$params["variants"] = array();
endif;

if ($list_type == 'check'):
	if ($params["multiple"] != "Y" && count($params["variants"]) > 1):
		$uniq = md5(uniqid(rand(), true));
?>
<input type="radio" name="<?=$params["field_name"]?>[]" value="" id="<?=$uniq?>">&nbsp;<label for="<?=$uniq?>"><?=GetMessage("SF_PROPERTY_NOT_DEFINED")?></label><br>		
<?
	endif;
	foreach($params["variants"] as $v_key => $v_val):
		$uniq = md5(uniqid(rand(), true));
		if($bInitDef):
			$sel = ($v_key == $params["default_value"]);
		else:
			$sel = in_array((string) $v_key, $values);
		endif;
		
		if ($params["multiple"] == "Y" || count($params["variants"]) == 1):
?>
<input type="checkbox" name="<?=$params["field_name"]?>[]" value="<?=htmlspecialcharsex($v_key)?>" id="<?=$uniq?>"<?=($sel? " checked" : "")?>><?if (count($params["variants"]) > 1):?>&nbsp;<label for="<?=$uniq?>"><?=$v_val?></label><?endif?><br>	
<?
		else:
?>
<input type="radio" name="<?=$params["field_name"]?>[]" value="<?=htmlspecialcharsex($v_key)?>" id="<?=$uniq?>"<?=($sel ? " checked" : "")?>>&nbsp;<label for="<?=$uniq?>"><?=$v_val?></label><br>	
<?
		endif;
	endforeach;
else:
?>
<select name="<?=$params["field_name"]?>[]"<?if ($params["field_id"]):?> id="<?=$params["field_id"]?>"<?endif?> size="<?=$rows?>" <?=($params["multiple"] == "Y" ? "multiple" : "")?> style="max-width:300px;">
	<?
	if ($params["multiple"] != "Y"):
	?>
<option value=""><?=GetMessage("SF_PROPERTY_NOT_DEFINED")?></option>
	<?
	endif;
	foreach($params["variants"] as $v_key => $v_val):
		if($bInitDef):
			$sel = ($v_key == $params["default_value"]);
		else:
			$sel = in_array((string) $v_key, $values);
		endif;?>
<option value="<?=htmlspecialcharsex($v_key)?>"<?=($sel? " selected" : "")?>><?=$v_val?></option>
	<?endforeach?>
</select>
<?
endif;
?>
</td></tr>
</table>