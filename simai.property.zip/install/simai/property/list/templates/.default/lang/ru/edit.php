<?
$MESS ['SF_PROPERTY_NOT_DEFINED'] = "- Нет значения -";
?>