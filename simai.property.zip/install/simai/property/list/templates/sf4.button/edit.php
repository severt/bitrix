<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>

	<?use Bitrix\Main\Page\Asset;
	Asset::getInstance()->addCss('/simai/asset/simai.property/sf4/css/list/sf4.button/style.css');
	\SIMAI\Main\Page\Asset::getInstance()->load('sf4property');
	Asset::getInstance()->addJs('/simai/asset/simai.framework/sf4.master/bootstrap/js/sf-bootstrap.min.js');?>

	<?$rows = intval($params['rows']);
	if ($rows < 1 && $params["multiple"] != "Y"): $rows = 1;
	elseif ($rows < 1 && $params["multiple"] == "Y"): $rows = 5;	
	elseif ($rows > 20): $rows = 20; endif;

	$list_type = ($params['list_type'] == 'check' ? 'check' : 'list');
	$bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));
	$start = 0;?>

	<?if (!is_array($values)): $values = array($values);endif;

	$checked = false;

	if (!is_array($params["variants"])):$params["variants"] = array();endif;?>
	<?$checkedMulti = '';?>
	<div class="d-flex align-items-center flex-wrap <?if($params["inactive"] == "Y"):?>sf4_property_inactive<?endif?>" data-list-button data-toggle="">
		<?if ($params["multiple"] == "Y" ):?>
			<?if(count($params["variants"]) > 1):
				foreach($params["variants"] as $keyP => $item):?>
					<label class="btn btn-primary btn-outline mr-2 list_button
						<?foreach($values as $key => $itemP):?>
							<?if($keyP == $itemP): $checked = $keyP;?>
								active
							<?endif?>
						<?endforeach?>">
						<input
							name="<?=$params["field_name"]?>[<?=$keyP?>]"
							data-list="public-button" 
							value="<?=$keyP?>"
							type="checkbox"
							<?if($params["required"]):?>required<?endif?>
							<?foreach($values as $key => $itemP): $checked = $keyP;?>
								<?if($keyP == $itemP):?>
									checked
									<?if(count($values) == 1):?>
										<?$checkedMulti .= $itemP?>
									<?elseif(count($values) > 1):?>
										<?$checkedMulti .= $itemP.','?>
									<?endif?>
								<?endif?>
							<?endforeach?>
							autocomplete="off"
							class="btn-checkbox" />
							
						<?=html_entity_decode($item);?>
					</label>
				<?endforeach?>
			<?endif;?>
		<?else:?>
			<?if (count($params["variants"]) > 1):?>
				<?foreach($params["variants"] as $keyP => $item):?>
					<label class="btn btn-primary btn-outline mr-2 list_button <?if ($values[0] == $keyP):?>active<?endif?>">
						<input
							name="<?=$params["field_name"]?>[<?=$keyP?>]"
							<?if($params["required"]):?>required<?endif?>
							value="<?=$keyP?>"
							type="radio"
							<?if ($values[0] == $keyP): $checked = $keyP;?><?$checkedMulti .= $keyP?> checked<?endif;?>
							autocomplete="off"
							class="btn-checkbox"
							data-list="public-button-radio" />

						<?=html_entity_decode($item)?>
					</label>
				<?endforeach?>
			<?else:?>
				<label class="btn btn-primary btn-outline mr-2 list_button <?if ($values[0] == $keyP):?>active<?endif?>">
					<input
						name="<?=$params["field_name"]?>[<?=$keyP?>]"
						value="<?=$keyP?>"
						type="radio"
						<?if($params["required"]):?>required<?endif?>
						data-list="public-button-radio"
						<?if ($values[0] == $keyP): $checked = $keyP;?><?$checkedMulti .= $keyP?> checked<?endif;?>
						autocomplete="off"
						class="btn-checkbox" />

					<?=html_entity_decode($item)?>
				</label>
			<?endif;?>
		<?endif;?>
		<div 
			<?foreach($values as $key => $itemP):?>
				<?if($checked == $itemP):?>
					checked="checked"
				<?endif?>
			<?endforeach?>
			if-type="button"
			class="d-none radio-change"
			name="<?=$params["field_name"]?>[0]"
			value="<?=$checkedMulti?>"></div>
		<?if($params["inactive"] == "Y"):?>
            <input name="<?=$params["field_name"]?>_edit" value="N" type="hidden" class="hidden-input" />
        <?endif?>
	</div>