<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>

<div class="d-flex align-items-center justify-content-between flex-wrap" data-toggle="buttons">
	<?$rows = intval($params['rows']);
	if ($rows < 1 && $params["multiple"] != "Y"):
		$rows = 1;
	elseif ($rows < 1 && $params["multiple"] == "Y"):
		$rows = 5;	
	elseif ($rows > 20):
		$rows = 20;
	endif;

	$list_type = ($params['list_type'] == 'check' ? 'check' : 'list');
	$bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));
	$start = 0;
	$table_id = rand();?>

	<?if (!is_array($values)):
		$values = array($values);
	endif;

	if (!is_array($params["variants"])):
		$params["variants"] = array();
	endif;

	$uniq = md5(uniqid(rand(), true));?>

	<?if ($params["multiple"] == "Y" ):
		if(count($params["variants"]) > 1):
			$index = 1;
			foreach($params["variants"] as $keyP => $item):?>
				<label class="btn btn-default btn-outline">
					<input name="<?=$params["field_name"]?>[0]" value="Y" type="checkbox"<?if ($values == 'Y'):?> checked<?endif;?> id="option<?=$index;?>" autocomplete="off">
					<?=$item;?>
				</label>
				<?$index++;?>
			<?endforeach?>
		<?endif;
	else:?>
		<?if ($params["multiple"] != "Y" && count($params["variants"]) > 1):?>
			<?foreach($params["variants"] as $keyP => $item):
				$index = 1;?>
				<label class="btn btn-default btn-outline">
					<input name="<?=$params["field_name"]?>[0]" value="Y" type="radio"<?if ($values == 'Y'):?> checked<?endif;?> id="option<?=$index;?>" autocomplete="off">
					<?=$item?>
				</label>
				<?$index++;?>
			<?endforeach?>
		<?endif;?>
	<?endif;?>
</div>