<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>

<?use Bitrix\Main\Page\Asset;
	Asset::getInstance()->addCss('/simai/asset/simai.property/sf4/css/list/sf4.image.list/style.css');
	\SIMAI\Main\Page\Asset::getInstance()->load('sf4property');	
	Asset::getInstance()->addCss('/bitrix/js/simai.property/css/list/public-image-list/style.css');?>		

<div class="container-image-list d-flex flex-column w-100 <?if($params["inactive"] == "Y"):?>sf4_property_inactive<?endif?>">
	<?$rows = intval($params['rows']);
	if ($rows < 1 && $params["multiple"] != "Y"): $rows = 1;
	elseif ($rows < 1 && $params["multiple"] == "Y"): $rows = 5;	
	elseif ($rows > 20): $rows = 20; endif;

	$list_type = ($params['list_type'] == 'check' ? 'check' : 'list');
	$bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));
	$start = 0;?>

	<?if (!is_array($values)): $values = array($values); endif;

	if (!is_array($params["variants"])): $params["variants"] = array();	endif;
	
	if ($params["multiple"] == "Y" ):
		if(count($params["variants"]) > 1):
			foreach($params["variants"] as $keyP => $item):?>
				<label class="image-list m-1 w-100">
					<input
						class="d-none"
						name="<?=$params["field_name"]?>[<?=$item?>]"
						value="<?=$keyP?>"
						type="checkbox"
						<?if($propertyParam["required"]):?>required<?endif?>
						data-list="public-image-list-multi"
						<?foreach($values as $key => $itemP):?>
							<?if($keyP == $itemP):?>
								checked
							<?endif?>
						<?endforeach?>
						autocomplete="off" />
					<div <?foreach($values as $key => $itemP):?>
							<?if($keyP == $itemP):?>
								checked
							<?endif?>
						<?endforeach?>
						class="d-none radio-change"
						if-type="checkbox"
						name="<?=$params["field_name"]?>[0]"
						value="<?=$item?>"></div>
					<img class="w-100" src="<?=$item;?>"/>
					<div class="overlay-image"></div>
				</label>
			<?endforeach?>		
		<?endif;
	else:?>
		<?if ($params["multiple"] != "Y" && count($params["variants"]) > 1):?>
			<?foreach($params["variants"] as $keyP => $item):?>
				<label class="image-list m-1 w-100">
					<input
						class="d-none"
						name="<?=$params["field_name"]?>[<?=$item?>]"
						value="<?=$keyP?>"
						type="radio"
						<?if($propertyParam["required"]):?>required<?endif?>
						data-list="public-image-list-one"
						<?foreach($values as $key => $itemP):?>
							<?if($keyP == $itemP):?>
								checked
							<?endif?>
						<?endforeach?>
						autocomplete="off" />
					<div <?foreach($values as $key => $itemP):?>
							<?if($keyP == $itemP):?>
								checked
							<?endif?>
						<?endforeach?>
						class="d-none radio-change"
						if-type="checkbox"
						name="<?=$params["field_name"]?>[0]"
						value="<?=$item?>"></div>
					<img class="w-100" src="<?=$item;?>"/>
					<div class="overlay-image"></div>								
				</label>
			<?endforeach?>
		<?endif;?>
	<?endif;?>
	<?if($params["inactive"] == "Y"):?>
		<input name="<?=$params["field_name"]?>_edit" value="N" type="hidden" class="hidden-input" />
	<?endif?>
</div>