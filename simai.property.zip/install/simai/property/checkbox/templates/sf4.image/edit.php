<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>

    <?use Bitrix\Main\Page\Asset;
    Asset::getInstance()->addCss("/simai/asset/simai.property/sf4/css/checkbox/sf4.image/style.css");
    \SIMAI\Main\Page\Asset::getInstance()->load('sf4property');?>

    <?if (is_array($values)):$values = current($values);endif;?>
    <?$id = rand()?>

    <label class="image-checkbox w-100 <?if($params["inactive"] == "Y"):?>sf4_property_inactive<?endif?>">
        <input 
            class="d-none"
            name="<?=$params["field_name"]?>[01]"
            value="<?=$values;?>"
            type="checkbox"
            data-property-checkbox="<?if($params["inactive"] == "Y"):?>inactive-public<?else:?>public<?endif?>"
            <?if ($values == 'Y'):?>checked<?endif;?>
            <?if ($params["required"] == "Y"):?>required<?endif;?> />
            <div <?if ($values == 'Y'):?>checked="checked"<?endif?>
                class="d-none radio-change"
                if-type="checkbox"
                name="<?=$params["field_name"]?>[0]"
                value="<?=$values?>"></div>
        <img class="w-100" src="<?=$params["image"];?>" />
        <div class="overlay-image"></div>
        <?if($params["inactive"] == "Y"):?>
            <input name="<?=$params["field_name"]?>_edit" value="N" type="hidden" class="hidden-input" />
        <?endif?>
    </label>