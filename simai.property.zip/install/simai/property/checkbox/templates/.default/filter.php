<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if (is_array($values)):
	$values = current($values);
endif;
?>
<input type="checkbox" name="<?=$params["field_name"]?>" value="Y"<?if ($values == 'Y'):?> checked<?endif;?>>