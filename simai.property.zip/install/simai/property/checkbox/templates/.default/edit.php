<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if (is_array($values)):
	$values = current($values);
endif;

$table_id = rand();
?>
<table cellpadding="0" cellspacing="0" border="0" class="nopadding" width="100%" id="tb<?=md5($table_id)?>">

<tr><td>

   <input name="<?=$params["field_name"]?>[0]" value="Y" type="checkbox"<?if ($values == 'Y'):?> checked<?endif;?>>

<br></td>
</tr>


</table>