<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>
    <?use Bitrix\Main\Page\Asset;
    //Asset::getInstance()->addCss('/simai/asset/simai.property/sf4/css/checkbox/sf4/style.css');
    \SIMAI\Main\Page\Asset::getInstance()->load('sf4property');?>
    <?if (is_array($values)):$values = current($values);endif;?>
    <?$id = rand()?>

    <div class="sf4_property__checkbox form-check <?if($params["inactive"] == "Y"):?>sf4_property_inactive<?endif?>">
        <input type="checkbox" value="<?=$values;?>" id="sf4_checkbox-<?=$id?>" class="form-check-input"
            name="<?=$params["field_name"]?>[01]" <?if($params["required"] == "Y"):?>required<?endif;?>
            <?if($values == 'Y'):?>checked<?endif;?> />

        <div <?if($values == 'Y'):?>checked="checked"<?endif?> class="d-none radio-change"
            if-type="checkbox" name="<?=$params["field_name"]?>[0]" value="<?=$values?>"></div>

        <label for="sf4_checkbox-<?=$id?>" class="form-check-label"><?=$params["name"]?></label>
        <?if($params["inactive"] == "Y"):?>
            <input name="<?=$params["field_name"]?>_edit" value="N" type="hidden" class="hidden-input" />
        <?endif?>
    </div>