<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>
<div class="form-check">
	<?if (is_array($values)):
		$values = current($values);
	endif;?>

<input class="form-check-input" type="checkbox" name="<?=$params["field_name"]?>" value="Y"<?if ($values == 'Y'):?> checked<?endif;?>>

</div>