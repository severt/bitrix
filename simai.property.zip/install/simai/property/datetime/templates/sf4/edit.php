<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>

<?global $APPLICATION;
global $DB;
\SIMAI\Main\Page\Asset::getInstance()->load('sf4property');
\Bitrix\Main\Page\Asset::getInstance()->addJs('/simai/asset/jquery/jquery-3.3.1/jquery.min.js');
\Bitrix\Main\Page\Asset::getInstance()->addJs('/simai/asset/flatpickr/flatpickr-4.3.2/js/flatpickr.min.js');
\Bitrix\Main\Page\Asset::getInstance()->addJs('/simai/asset/flatpickr/flatpickr-4.3.2/js/ru.js');
\Bitrix\Main\Page\Asset::getInstance()->addCss('/simai/asset/flatpickr/flatpickr-4.3.2/css/flatpickr.min.css'); //ru.js

	$cols = intval($params['cols']);
	if ($cols < 1): $cols = 25;
	elseif ($cols > 100): $cols = 100;endif;

	$MULTIPLE_CNT = intval($params['multiple_cnt']);
	if ($MULTIPLE_CNT <= 0 || $MULTIPLE_CNT > 30): $MULTIPLE_CNT = 3; endif;

	$bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));
	$cnt = ($params["multiple"] == "Y" ? $MULTIPLE_CNT + ($bInitDef ? 1 : 0) : 1);
	$start = 0;

	
	?>

	<?if (!is_array($values)):$values = array($values);endif;?>

	<div class="container-datetime sf4_property <?if($params["inactive"] == "Y"):?>sf4_property_inactive<?endif?>" data-time="">
		<?foreach($values as $key => $val):?>
			<?$id = rand();?>
			<div class="form-group" data-property-field="date">
				<input
					class="form-control" style="flex:1"
					name="<?=$params["field_name"]?>[<?=$key?>1]"
					<?if ($params["required"] == "Y" && $key == 0):?>required<?endif;?>
					data-datetime="public"
					value="<?=$val?>"
					size="<?=$cols?>"
					id="datatime-<?=$id;?>"
					type="text" />
				<div <?if ($val !== ''):?>checked="checked"<?endif?> class="d-none radio-change"
					if-type="text"
					name="<?=$params["field_name"]?>[0]"
					value="<?=$val?>"></div>
			</div>
			<script type="text/javascript">
				jQuery(function($){
					flatpickr('#datatime-<?=$id;?>',{
						dateFormat: "<?if(!$params["calendar"]):?><?if($params["date"]):?><?=$params["date"]?><?else:?><?=$DB->DateFormatToPHP(CSite::GetDateFormat("SHORT"))?><?endif?><?endif?><?if($params["time"]):?><?=$params["time"]?><?endif?>",						
						<?if($params["time"]):?>enableTime: true,<?endif?>
						<?if($params["calendar"]):?>noCalendar: true,<?endif?>
						allowInput: true,
						defaultDate: "<?=$val?>",
						locale: <?if($params["locale"]):?>'<?=$params["locale"]?>' <?else:?>'<?=LANGUAGE_ID?>'<?endif?>,
					});
				});
			</script>
			<?if ($params["multiple"] != "Y"):
				$params["bVarsFromForm"] = true;
				break;
			endif;?>
		<?endforeach;?>

		<?/*if (!$params["bVarsFromForm"]):
			for ($i = 0; $i < $cnt; $i++):?>
				<?$id = rand();?>
				<?if ($i == 0 && $bInitDef):$val = $params["default_value"];
				else: $val = ""; endif;?>
				<div class="form-group" data-property-field="date">			
					<input
						class="form-control" style="flex:1"
						data-datetime="public"
						name="<?=$params["field_name"]?>[n<?=($start + $i)?>1]"
						<?if ($params["required"] == "Y" && $i == 0):?>required<?endif;?>
						value="<?=$val?>"
						size="<?=$cols?>"
						id="datatime-<?=$id;?>"
						type="text" />
					<div <?if ($val !== ''):?>checked="checked"<?endif?> class="d-none radio-change"
						if-type="text"
						name="<?=$params["field_name"]?>[0]"
						value="<?=$val?>"></div>
				</div>
				<script type="text/javascript">
					jQuery(function($){
						flatpickr('#datatime-<?=$id;?>',{
							dateFormat: "<?if(!$params["calendar"]):?><?if($params["date"]):?><?=$params["date"]?><?else:?><?=$DB->DateFormatToPHP(CSite::GetDateFormat("SHORT"))?><?endif?><?endif?><?if($params["time"]):?><?=$params["time"]?><?endif?>",
							<?if($params["time"]):?>enableTime: true,<?endif?>
							<?if($params["calendar"]):?>noCalendar: true,<?endif?>
							allowInput: true,
							defaultDate: "<?=$val?>",
							locale: <?if($params["locale"]):?>'<?=$params["locale"]?>' <?else:?>'<?=LANGUAGE_ID?>'<?endif?>,
						});
					});
				</script>
			<?endfor;
		endif;*/?>
		<?if ($params["multiple"] == "Y"):?>
			<input class="btn btn-primary" type="button" data-button-property="" value="<?=GetMessage("SF_PROPERTY_AT_PROP_ADD")?>"/>
		<?endif;?>
		<?if($params["inactive"] == "Y"):?>
			<input name="<?=$params["field_name"]?>_edit" value="N" type="hidden" class="hidden-input" />
		<?endif?>
	</div>

