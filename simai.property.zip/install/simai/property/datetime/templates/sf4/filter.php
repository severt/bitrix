<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
$cols = intval($params['cols']);
if ($cols < 1):
	$cols = 15;
elseif ($cols > 100):
	$cols = 100;
endif;

if (!is_array($values)):
	$values = array($values, $values);
endif;

if ($params["use_mode"] == 'public'):
	global $APPLICATION;?>
	<div class="form-group">
		<input class="form-control" name="<?=$params["field_name_from"]?>" value="<?=$values[0]?>" size="<?=$cols?>" type="text">
		<?$APPLICATION->IncludeComponent(
			'bitrix:main.calendar',
			'',
			array(
				'FORM_NAME' => $params["form_name"],
				'INPUT_NAME' => $params["field_name_from"],
				'INPUT_VALUE' => $values[0],
				'SHOW_TIME' => ($params["show_time"] == 'Y' ? 'Y' : 'N'),
			),
			null,
			array('HIDE_ICONS' => 'Y')
		);?>
		...
		<input class="form-control" name="<?=$params["field_name_to"]?>" value="<?=$values[1]?>" size="<?=$cols?>" type="text">
		<?$APPLICATION->IncludeComponent(
			'bitrix:main.calendar',
			'',
			array(
				'FORM_NAME' => $params["form_name"],
				'INPUT_NAME' => $params["field_name_to"],
				'INPUT_VALUE' => $values[1],
				'SHOW_TIME' => ($params["show_time"] == 'Y' ? 'Y' : 'N'),
			),
			null,
			array('HIDE_ICONS' => 'Y')
		);?>
	</div>
<?else:?>
	<?=CalendarPeriod($params["field_name_from"], $values[0], $params["field_name_to"], $values[1], $params["form_name"], 'Y')?>
<?endif;?>