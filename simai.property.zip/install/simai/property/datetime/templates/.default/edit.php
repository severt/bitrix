<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

global $APPLICATION;

$cols = intval($params['cols']);
if ($cols < 1):
	$cols = 25;
elseif ($cols > 100):
	$cols = 100;
endif;

$MULTIPLE_CNT = intval($params['multiple_cnt']);
if ($MULTIPLE_CNT <= 0 || $MULTIPLE_CNT > 30):
	$MULTIPLE_CNT = 3;
endif;

$bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));

$cnt = ($params["multiple"] == "Y" ? $MULTIPLE_CNT + ($bInitDef ? 1 : 0) : 1);

$start = 0;


$table_id = rand();
?>
<table cellpadding="0" cellspacing="0" border="0" class="nopadding" width="100%" id="tb<?=md5($table_id)?>">
<?
if (!is_array($values)):
	$values = array($values);
endif;

foreach($values as $key=>$val):
	
?>
<tr><td>
<input name="<?=$params["field_name"]?>[<?=$key?>]" value="<?=$val?>" size="<?=$cols?>" type="text"><?
$APPLICATION->IncludeComponent(
	'bitrix:main.calendar',
	'',
	array(
		'FORM_NAME' => $params["form_name"],
		'INPUT_NAME' => $params["field_name"].'['.$key.']',
		'INPUT_VALUE' => $val,
		'SHOW_TIME' => ($params["show_time"] == 'Y' ? 'Y' : 'N'),
	),
	null,
	array('HIDE_ICONS' => 'Y')
);?>
<br>
</td></tr>
<?
	if ($params["multiple"] != "Y"):
		$params["bVarsFromForm"] = true;
		break;
	endif;
endforeach;

if (!$params["bVarsFromForm"]):
	for ($i = 0; $i < $cnt; $i++):
?>
<tr><td>
<?
		if ($i == 0 && $bInitDef):
			$val = $params["default_value"];
		else:
			$val = "";
		endif;
?>
<input name="<?=$params["field_name"]?>[n<?=($start + $i)?>]" value="<?=$val?>" size="<?=$cols?>" type="text"><?
$APPLICATION->IncludeComponent(
	'bitrix:main.calendar',
	'',
	array(
		'FORM_NAME' => $params["form_name"],
		'INPUT_NAME' => $params["field_name"].'[n'.($start + $i).']',
		'INPUT_VALUE' => $val,
		'SHOW_TIME' => ($params["show_time"] == 'Y' ? 'Y' : 'N'),
	),
	null,
	array('HIDE_ICONS' => 'Y')
);?>
<br>
</td></tr>
<?
	endfor;
endif;

if ($params["multiple"] == "Y"):
?>
	<tr><td><input type="button" value="<?=GetMessage("SF_PROPERTY_AT_PROP_ADD")?>" onClick="SFPropAddNewRow('tb<?=md5($table_id)?>')"></td></tr>
	<script type=\"text/javascript\">BX.addCustomEvent('onAutoSaveRestore', function(ob, data) {for (var i in data){if (i.substring(0,<?=(strlen($params["field_name"])+1)?>)=='<?=CUtil::JSEscape($params["field_name"])?>['){SFPropAddNewRow('tb<?=md5($table_id)?>')}}})</script>
<?endif;?>
</table>