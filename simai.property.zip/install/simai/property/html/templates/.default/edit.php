<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$cols = intval($params['cols']);
if ($cols < 1):
	$cols = 25;
elseif ($cols > 100):
	$cols = 100;
endif;

$rows = intval($params['rows']);
if ($rows < 1):
	$rows = 1;
elseif ($rows > 30):
	$rows = 30;
endif;

$MULTIPLE_CNT = intval($params['multiple_cnt']);
if ($MULTIPLE_CNT <= 0 || $MULTIPLE_CNT > 30):
	$MULTIPLE_CNT = 3;
endif;

$visual = ($params['text_type'] == 'visual');

$bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));

$cnt = ($params["multiple"] == "Y" ? $MULTIPLE_CNT + ($bInitDef ? 1 : 0) : 1);

$start = 0;


$table_id = rand();
?>
<table cellpadding="0" cellspacing="0" border="0" class="nopadding" width="100%" id="tb<?=md5($table_id)?>">
<?
if (!is_array($values)):
	$values = array($values);
endif;

foreach($values as $key => $val):
	
?>
<tr><td>
<?
	if ($visual):
		
		$LHE = new CHTMLEditor;
		$LHE->Show(array(
			'name' => $params["field_name"].'['.$key.']',
			//'id' => $id,
			'inputName' => $params["field_name"].'['.$key.']',
			'content' => $val,
			'width' => '100%',
			'minBodyWidth' => 350,
			'normalBodyWidth' => 555,
			'height' => '200',
			'bAllowPhp' => false,
			'limitPhpAccess' => false,
			'autoResize' => true,
			'autoResizeOffset' => 40,
			'useFileDialogs' => false,
			'saveOnBlur' => true,
			'showTaskbars' => false,
			'showNodeNavi' => false,
			'askBeforeUnloadPage' => true,
			'bbCode' => false,
			//'siteId' => SITE_ID,
			'controlsMap' => array(
				array('id' => 'ChangeView', 'compact' => true, 'sort' => 10),
				array('id' => 'Undo', 'compact' => false, 'sort' => 20),
				array('id' => 'Redo', 'compact' => false, 'sort' => 30),
				array('id' => 'StyleSelector', 'compact' => false, 'sort' => 40),
				array('id' => 'FontSelector', 'compact' => true, 'sort' => 50),
				array('id' => 'Bold', 'compact' => true, 'sort' => 80),
				array('id' => 'Italic', 'compact' => true, 'sort' => 90),
				array('id' => 'Underline', 'compact' => true, 'sort' => 100),
				array('id' => 'Strikeout', 'compact' => true, 'sort' => 110),
				array('id' => 'RemoveFormat', 'compact' => true, 'sort' => 120),
				array('id' => 'Color', 'compact' => true, 'sort' => 130),
				array('id' => 'FontSelector', 'compact' => false, 'sort' => 135),
				array('id' => 'FontSize', 'compact' => false, 'sort' => 140),
				array('separator' => true, 'compact' => false, 'sort' => 145),
				array('id' => 'OrderedList', 'compact' => true, 'sort' => 150),
				array('id' => 'UnorderedList', 'compact' => true, 'sort' => 160),
				array('id' => 'AlignList', 'compact' => false, 'sort' => 190),
				array('separator' => true, 'compact' => false, 'sort' => 200),
				array('id' => 'Code', 'compact' => true, 'sort' => 210),
				array('id' => 'Quote', 'compact' => true, 'sort' => 220),
				array('id' => 'InsertLink', 'compact' => true, 'sort' => 230),
				array('id' => 'InsertAnchor', 'compact' => true, 'sort' => 230),
				array('id' => 'InsertImage', 'compact' => false, 'sort' => 240),
				array('id' => 'InsertVideo', 'compact' => true, 'sort' => 250),
				array('id' => 'InsertTable', 'compact' => false, 'sort' => 260),
				array('id' => 'InsertChar', 'compact' => true, 'sort' => 270),
				array('separator' => true, 'compact' => false, 'sort' => 290),
				array('id' => 'Fullscreen', 'compact' => false, 'sort' => 310),
				array('id' => 'More', 'compact' => true, 'sort' => 400)
			),
		));
	else:
?>
<textarea name="<?=$params["field_name"]?>[<?=$key?>]" cols="<?=$cols?>" rows="<?=$rows?>"><?=$val?></textarea>
<?
	endif;
?>
<br>
</td></tr>
<?
	if ($params["multiple"] != "Y"):
		$params["bVarsFromForm"] = true;
		break;
	endif;
endforeach;

if (!$params["bVarsFromForm"]):
	for ($i = 0; $i < $cnt; $i++):
?>
<tr><td>
<?
		if ($i == 0 && $bInitDef):
			$val = $params["default_value"];
		else:
			$val = "";
		endif;
		
		if ($visual):
		
			$LHE = new CHTMLEditor;
			$LHE->Show(array(
				'name' => $params["field_name"].'[n'.($start + $i).']',
				//'id' => $id,
				'inputName' => $params["field_name"].'[n'.($start + $i).']',
				'content' => $val,
				'width' => '100%',
				'minBodyWidth' => 350,
				'normalBodyWidth' => 555,
				'height' => '200',
				'bAllowPhp' => false,
				'limitPhpAccess' => false,
				'autoResize' => true,
				'autoResizeOffset' => 40,
				'useFileDialogs' => false,
				'saveOnBlur' => true,
				'showTaskbars' => false,
				'showNodeNavi' => false,
				'askBeforeUnloadPage' => true,
				'bbCode' => false,
				//'siteId' => SITE_ID,
				'controlsMap' => array(
					array('id' => 'ChangeView', 'compact' => true, 'sort' => 10),
					array('id' => 'Undo', 'compact' => false, 'sort' => 20),
					array('id' => 'Redo', 'compact' => false, 'sort' => 30),
					array('id' => 'StyleSelector', 'compact' => false, 'sort' => 40),
					array('id' => 'FontSelector', 'compact' => true, 'sort' => 50),
					array('id' => 'Bold', 'compact' => true, 'sort' => 80),
					array('id' => 'Italic', 'compact' => true, 'sort' => 90),
					array('id' => 'Underline', 'compact' => true, 'sort' => 100),
					array('id' => 'Strikeout', 'compact' => true, 'sort' => 110),
					array('id' => 'RemoveFormat', 'compact' => true, 'sort' => 120),
					array('id' => 'Color', 'compact' => true, 'sort' => 130),
					array('id' => 'FontSelector', 'compact' => false, 'sort' => 135),
					array('id' => 'FontSize', 'compact' => false, 'sort' => 140),
					array('separator' => true, 'compact' => false, 'sort' => 145),
					array('id' => 'OrderedList', 'compact' => true, 'sort' => 150),
					array('id' => 'UnorderedList', 'compact' => true, 'sort' => 160),
					array('id' => 'AlignList', 'compact' => false, 'sort' => 190),
					array('separator' => true, 'compact' => false, 'sort' => 200),
					array('id' => 'Code', 'compact' => true, 'sort' => 210),
					array('id' => 'Quote', 'compact' => true, 'sort' => 220),
					array('id' => 'InsertLink', 'compact' => true, 'sort' => 230),
					array('id' => 'InsertAnchor', 'compact' => true, 'sort' => 230),
					array('id' => 'InsertImage', 'compact' => false, 'sort' => 240),
					array('id' => 'InsertVideo', 'compact' => true, 'sort' => 250),
					array('id' => 'InsertTable', 'compact' => false, 'sort' => 260),
					array('id' => 'InsertChar', 'compact' => true, 'sort' => 270),
					array('separator' => true, 'compact' => false, 'sort' => 290),
					array('id' => 'Fullscreen', 'compact' => false, 'sort' => 310),
					array('id' => 'More', 'compact' => true, 'sort' => 400)
				),
			));
		else:
			$val = htmlspecialcharsbx($val);
?>
<textarea name="<?=$params["field_name"]?>[n<?=($start + $i)?>]" cols="<?=$cols?>" rows="<?=$rows?>"><?=$val?></textarea>
<?
		endif;
?>
<br>
</td></tr>
<?
	endfor;
endif;

if ($params["multiple"] == "Y" && !$visual):
?>
	<tr><td><input type="button" value="<?=GetMessage("SF_PROPERTY_AT_PROP_ADD")?>" onClick="SFPropAddNewRow('tb<?=md5($table_id)?>')"></td></tr>
	<script type=\"text/javascript\">BX.addCustomEvent('onAutoSaveRestore', function(ob, data) {for (var i in data){if (i.substring(0,<?=(strlen($params["field_name"])+1)?>)=='<?=CUtil::JSEscape($params["field_name"])?>['){SFPropAddNewRow('tb<?=md5($table_id)?>')}}})</script>
<?endif;?>
</table>