<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if (!is_array($values)):
	$values = array($values);
endif;

$temp = $values;
$values = array();

foreach ($temp as $key => $val):
	
	$allow_tags = '<p><br><br /><strong><em><b><i><u><a><ul><ol><li><span><div><table><tr><th><td><caption><thead><tbody><tfoot><img><code><pre>';
	$val = strip_tags(htmlspecialcharsBack($val), $allow_tags);
	
	$Sanitizer = new \CBXSanitizer;
	$Sanitizer->SetLevel( \CBXSanitizer::SECURE_LEVEL_LOW );
	$Sanitizer->ApplyHtmlSpecChars(false);
	$val = $Sanitizer->SanitizeHtml($val);
	
	$values[$key] = $val;
	
endforeach;

unset ($temp);
?>