<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

    $cols = intval($params['cols']);
    if ($cols < 1):	$cols = 25;
    elseif ($cols > 100):$cols = 100;endif;

    $MULTIPLE_CNT = intval($params['multiple_cnt']);
    if ($MULTIPLE_CNT <= 0 || $MULTIPLE_CNT > 30):$MULTIPLE_CNT = 3;endif;

    $bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));
    $cnt = ($params["multiple"] == "Y" ? $MULTIPLE_CNT + ($bInitDef ? 1 : 0) : 1);
    $start = 0;

    use Bitrix\Main;
    use Bitrix\Main\Page\Asset;
    \SIMAI\Main\Page\Asset::getInstance()->load('sf4property');
    Asset::getInstance()->addCss('/simai/asset/simai.property/sf4/css/url/sf4/style.css');
    Asset::getInstance()->addJs('/bitrix/js/main/core/core_admin_interface.min.js');	
    require_once($_SERVER["DOCUMENT_ROOT"].'/bitrix/modules/main/interface/admin_lib.php');?>

    <?if (!is_array($values)):$values = array($values);endif;
    if (!is_array($params["variants"])):$params["variants"] = array();endif;?>



    <div class="container-url sf4_property <?if($params["inactive"] == "Y"):?>sf4_property_inactive<?endif?>" data-url="">
        <?foreach($values as $key=>$val):
            $field_id = md5($params["field_name"].'_'.$key);?>
            <div class="form-group form-inline sf4_property" data-property-field="url">
                <input
                    class="form-control mr-2"
                    data-url
                    name="<?=$params["field_name"]?>[<?=$key?>1]"
                    <?if ($params["required"] == "Y"):?>required<?endif;?>
                    id="<?=$field_id?>"
                    value="<?=$val?>"
                    size="<?=$cols?>"
                    type="text"
                    style="flex:1" />
                <div
                    checked="checked"
                    if-type="text"
                    class="d-none radio-change"
                    name="<?=$params["field_name"]?>[0]"
                    value="<?=$val?>"></div>
                <?$INSERT_VARS = array();
                if (is_array($params['insert_vars'])):
                    foreach ($params['insert_vars'] as $var_arr):
                        //if ($var_arr == 'SEPARATOR'):
                            $INSERT_VARS[] = array("SEPARATOR" => true);
                        /*elseif (is_array($var_arr)):
                            $INSERT_VARS[] = array(
                                'TEXT' => $var_arr['1'],
                                'TITLE' => '#'.$var_arr['0'].'# - '.$var_arr['1'],
                                'ONCLICK' => "SF.SFSetUrlVar('#".$var_arr['0']."#', '".$field_id."')",
                            );			
                        endif;*/
                    endforeach;
                endif;?>
                <?
                    $INSERT_VARS[] = array(
                        'TEXT' => "Директория сайта",
                        'TITLE' => '#SITE_DIR# - Директория сайта',
                        'ONCLICK' => "SF.SFSetUrlVar('#SITE_DIR#', '".$field_id."')",
                    );
                //$INSERT_VARS[] = array("SEPARATOR" => true);?>
                <?if (class_exists('CAdminPopupEx')):
                    $u = new CAdminPopupEx(
                        $field_id.'_but',
                        $INSERT_VARS,
                        array("zIndex" => 10000)
                    );
                    $u->Show();?>
                    <input type="button" class="btn btn-primary" id="<?=$field_id?>_but" value='...' />
                <?endif?>
            </div>
            <?if ($params["multiple"] != "Y"):
                $params["bVarsFromForm"] = true;
                break;
            endif;
        endforeach;?>
        <?if (!$params["bVarsFromForm"]):
            for ($i = 0; $i < $cnt; $i++):?>
                <div class="form-group form-inline sf4_property" data-property-field="url">
                    <?if ($i == 0 && $bInitDef): $val = $params["default_value"];
                    else: $val = ""; endif;
                    $field_id = md5($params["field_name"].'_n'.($start + $i));?>
                    <input
                        class="form-control mr-2"
                        data-url
                        <?if ($params["required"] == "Y"):?>required<?endif;?>
                        name="<?=$params["field_name"]?>[n<?=($start + $i)?>]"
                        value="<?=$val?>"
                        size="<?=$cols?>"
                        type="text"
                        style="flex:1"
                        id="<?=$field_id?>" />
                    <div checked="checked" if-type="text"
                        class="d-none radio-change"
                        name="<?=$params["field_name"]?>[0]"
                        value="<?=$val?>"></div>
                    <?$INSERT_VARS = array();
                    if (is_array($params['insert_vars'])):
                        foreach ($params['insert_vars'] as $var_arr):
                            if ($var_arr == 'SEPARATOR'):
                                $INSERT_VARS[] = array("SEPARATOR" => true);
                            elseif (is_array($var_arr)):
                                $INSERT_VARS[] = array(
                                    'TEXT' => $var_arr['1'],
                                    'TITLE' => '#'.$var_arr['0'].'# - '.$var_arr['1'],
                                    'ONCLICK' => "SF.SFSetUrlVar('#".$var_arr['0']."#', '".$field_id."')",
                                );			
                            endif;
                        endforeach;
                    endif;
                    if (class_exists('CAdminPopupEx')):
                        $u = new CAdminPopupEx(
                            $field_id.'_but',
                            $INSERT_VARS,
                            array("zIndex" => 10000)
                        );
                        $u->Show();?>
                        <input type="button" class="btn btn-primary" id="<?=$field_id?>_but" value='...' />
                    <?endif?>
                </div>
            <?endfor;
        endif;?>
        <?if($params["inactive"] == "Y"):?>
            <input name="<?=$params["field_name"]?>_edit" value="N" type="hidden" class="hidden-input" />
        <?endif?>
        <?if ($params["multiple"] == "Y"):?>
            <input class="btn btn-primary" data-button-property type="button" value="<?=GetMessage("SF_PROPERTY_AT_PROP_ADD")?>"/>
        <?endif;?>
    </div>