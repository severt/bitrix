<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if (defined("ADMIN_SECTION") && ADMIN_SECTION === true):

    $cols = intval($params['cols']);
    if ($cols < 1):
        $cols = 25;
    elseif ($cols > 100):
        $cols = 100;
    endif;

    $MULTIPLE_CNT = intval($params['multiple_cnt']);
    if ($MULTIPLE_CNT <= 0 || $MULTIPLE_CNT > 30):
        $MULTIPLE_CNT = 3;
    endif;

    $bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));

    $cnt = ($params["multiple"] == "Y" ? $MULTIPLE_CNT + ($bInitDef ? 1 : 0) : 1);

    $start = 0;


    $table_id = rand();
    ?>
    <table cellpadding="0" cellspacing="0" border="0" class="nopadding" width="100%" id="tb<?=md5($table_id)?>">
    <?
    if (!is_array($values)):
        $values = array($values);
    endif;

    foreach($values as $key=>$val):
        $field_id = md5($params["field_name"].'_'.$key);
    ?>
    <tr><td>
    <input name="<?=$params["field_name"]?>[<?=$key?>]" value="<?=$val?>" size="<?=$cols?>" type="text" id="<?=$field_id?>">
    <?
    $INSERT_VARS = array();
    if (is_array($params['insert_vars'])):
        foreach ($params['insert_vars'] as $var_arr):
            if ($var_arr == 'SEPARATOR'):
                $INSERT_VARS[] = array("SEPARATOR" => true);
            elseif (is_array($var_arr)):
                $INSERT_VARS[] = array(
                    'TEXT' => $var_arr['1'],
                    'TITLE' => '#'.$var_arr['0'].'# - '.$var_arr['1'],
                    'ONCLICK' => "SFSetUrlVar('#".$var_arr['0']."#', '".$field_id."')",
                );			
            endif;
        endforeach;
    endif;

    if (class_exists('CAdminPopupEx')):
        $u = new CAdminPopupEx(
            $field_id.'_but',
            $INSERT_VARS,
            array("zIndex" => 2000)
        );
        $u->Show();
    ?>
    <input type="button" id="<?=$field_id?>_but" value='...'>
    <?endif;?>
    <br>
    </td></tr>
    <?
        if ($params["multiple"] != "Y"):
            $params["bVarsFromForm"] = true;
            break;
        endif;
    endforeach;

    if (!$params["bVarsFromForm"]):
        for ($i = 0; $i < $cnt; $i++):
            ?>
            <tr><td>
            <?
                    if ($i == 0 && $bInitDef):
                        $val = $params["default_value"];
                    else:
                        $val = "";
                    endif;
                    
                    $field_id = md5($params["field_name"].'_n'.($start + $i));
            ?>
            <input name="<?=$params["field_name"]?>[n<?=($start + $i)?>]" value="<?=$val?>" size="<?=$cols?>" type="text" id="<?=$field_id?>">
            <?
            $INSERT_VARS = array();
            if (is_array($params['insert_vars'])):
                foreach ($params['insert_vars'] as $var_arr):
                    if ($var_arr == 'SEPARATOR'):
                        $INSERT_VARS[] = array("SEPARATOR" => true);
                    elseif (is_array($var_arr)):
                        $INSERT_VARS[] = array(
                            'TEXT' => $var_arr['1'],
                            'TITLE' => '#'.$var_arr['0'].'# - '.$var_arr['1'],
                            'ONCLICK' => "SFSetUrlVar('#".$var_arr['0']."#', '".$field_id."')",
                        );			
                    endif;
                endforeach;
            endif;
            
            if (class_exists('CAdminPopupEx')):
                $u = new CAdminPopupEx(
                    $field_id.'_but',
                    $INSERT_VARS,
                    array("zIndex" => 2000)
                );
                $u->Show();
            ?>
            <input type="button" id="<?=$field_id?>_but" value='...'>
            <?endif;?>
            <br>
            </td></tr>
            <?
        endfor;
    endif;
    ?>
    </table>
<?endif?>