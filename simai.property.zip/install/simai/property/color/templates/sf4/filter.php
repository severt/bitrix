<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>
<div class="form-group">
	<?$cols = intval($params['cols']);
	if ($cols < 1):
		$cols = 47;
	elseif ($cols > 100):
		$cols = 100;
	endif;

	if (is_array($values)):
		$values = current($values);
	endif;?>
	<input class="form-control" type="text" name="<?=$params["field_name"]?>" size="<?=$cols?>" value="<?=$values?>">
</div>