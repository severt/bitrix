<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

	\Bitrix\Main\Page\Asset::getInstance()->addCss('/simai/asset/simai.property/sf4/css/color/sf4/style.css', true);
	\SIMAI\Main\Page\Asset::getInstance()->load('sf4property');
	\Bitrix\Main\Page\Asset::getInstance()->addJs('/simai/asset/simai.property/sf4/js/color/sf4/script.js', true);

	$MULTIPLE_CNT = intval($params['multiple_cnt']);
	if ($MULTIPLE_CNT <= 0 || $MULTIPLE_CNT > 30): $MULTIPLE_CNT = 3;endif;

	$bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));
	$cnt = ($params["multiple"] == "Y" ? $MULTIPLE_CNT + ($bInitDef ? 1 : 0) : 1);
	$start = 0;
	$id = rand()?>

	<?if (!is_array($values)): $values = array($values);endif;?>
<section class="container-picker sf4_property form-group <?if($params["inactive"] == "Y"):?>sf4_property_inactive<?endif?> <?if($params["multiple"] == "Y"):?>d-flex flex-column mb-2" <?else:?> color_picker" data-picker=""<?endif?> >
		<?foreach($values as $key => $val):?>
			<?if($params["multiple"] == "Y"):?><div class="d-flex flex-row justify-content-between w-100 p-relative color_picker mb-2" data-picker=""><?endif?>
				<input
					value="<?=$val?>"
					class="code-color form-control color_picker__input"
					data-code
					type="text"
					id="color-<?$id?>"
					placeholder=""
					<?if ($params["required"] == "Y"):?>required<?endif;?>
					name="<?=$params["field_name"]?>[<?=$key?>1]" />
					<div <?if ($val !== ''):?>checked="checked"<?endif?> class="d-none radio-change color_picker__conditin"
						if-type="checkbox"
						name="<?=$params["field_name"]?>[0]"
						value="<?=$val?>"></div>
				<button class="selected-color ml-1 px-3 py-2 color_picker__btn" id="color-<?$id?>" data-selected>&nbsp;</button>
				<div class="set-color mt-1 al-0 color_picker__color_pallet" data-set="<?=$val?>"></div>
			<?if($params["multiple"] == "Y"):?></div><?endif?>
			<?if ($params["multiple"] != "Y"):
				$params["bVarsFromForm"] = true;
				break;
			endif;
		endforeach;

		if (!$params["bVarsFromForm"]):
			for ($i = 0; $i < $cnt; $i++):
				$key = 'n'.($start + $i);?>
				<?if($params["multiple"] == "Y"):?><div class="d-flex flex-row justify-content-between w-100 color_picker mb-2" data-picker=""><?endif?>
					<input
						value="<?=$val?>"
						class="code-color form-control color_picker__input"
						data-code
						type="text"
						placeholder=""
						id="color-<?$id?>"
						<?if ($params["required"] == "Y"):?>required<?endif;?>
						name="code-color-picker[<?=$key?>]" />
					<div <?if ($val !== ''):?>checked="checked"<?endif?> class="d-none radio-change color_picker__conditin"
						if-type="checkbox"
						name="<?=$params["field_name"]?>[0]"
						value="<?=$val?>"></div>
					<button class="selected-color ml-1 px-3 py-2 color_picker__btn" id="color-<?$id?>" data-selected>&nbsp;</button>
					<div class="set-color mt-1 al-0 color_picker__color_pallet" data-set="<?=$val?>"></div>
				<?if($params["multiple"] == "Y"):?></div><?endif?>			
			<?endfor;?>
		<?endif;?>

		<?if($params["inactive"] == "Y"):?>
			<input name="<?=$params["field_name"]?>_edit" value="N" type="hidden" class="hidden-input" />
		<?endif?>
	</section>