<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

global $APPLICATION;

$APPLICATION->SetAdditionalCSS('/simai/asset/simai.property/.default/css/color/style.css');
$APPLICATION->AddHeadScript('/simai/asset/simai.property/.default/js/jquery.js');
$APPLICATION->AddHeadScript('/simai/asset/simai.property/.default/js/color/script.js', true);

$table_id = rand();
$id = \Bitrix\Main\Security\Random::getString(4);

$MULTIPLE_CNT = intval($params['multiple_cnt']);
if ($MULTIPLE_CNT <= 0 || $MULTIPLE_CNT > 30):
	$MULTIPLE_CNT = 3;
endif;

$bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));

$cnt = ($params["multiple"] == "Y" ? $MULTIPLE_CNT + ($bInitDef ? 1 : 0) : 1);

$start = 0;
?>
<table cellpadding="0" cellspacing="0" border="0" class="nopadding" width="100%" id="tb<?=md5($table_id)?>">
<?
if (!is_array($values)):
	$values = array($values);
endif;

foreach($values as $key => $val):
?>
<tr><td>

<div class="color-wrapper">
	<input type="text" name="<?=$params["field_name"]?>[<?=$key?>]" placeholder="<?=$val?>" data-picker="<?=$id.'__'.$key.'__'?>" class="call-picker" value="<?=$val?>">
	<div class="color-holder call-picker" data-picker="<?=$id.'__'.$key.'__'?>color" style="background-color: <?=$val?>;"></div>
	<div class="color-picker" data-picker="<?=$id.'__'.$key.'__'?>" style="display:none"></div>
</div>

<script type="text/javascript">
	var picker = $('div[data-picker=<?=$id.'__'.$key.'__'?>]')
	var index = 0;
	for(var key in colorMatrix)
	{
		var strColor = "";
		if(colorMatrix[index].name == 'Misc')
			strColor = '<div>';
		else
			strColor = '<div class="stolb">';

		for(var i = 0; i < colorMatrix[index].colors.length; i++)
		{
			if(colorMatrix[index].name == 'Misc')
				strColor += '<li class="color-picker-li-big" data-hex="' + '#' + colorMatrix[index].colors[i].hex + '" style="background-color:' + '#' + colorMatrix[index].colors[i].hex + ';"></li>';
			else
				strColor += '<li class="color-item" data-hex="' + '#' + colorMatrix[index].colors[i].hex +    '" style="background-color:' + '#' + colorMatrix[index].colors[i].hex + ';"></li>';
		}
		strColor += '</div>';
		picker.append(strColor);
		index++;
	}  
</script> 

</td></tr>
<?
	if ($params["multiple"] != "Y"):
		$params["bVarsFromForm"] = true;
		break;
	endif;
endforeach;

if (!$params["bVarsFromForm"]):
	for ($i = 0; $i < $cnt; $i++):
		$key = 'n'.($start + $i);
?>
<tr><td>

<div class="color-wrapper">
	<input type="text" name="<?=$params["field_name"]?>[<?=$key?>]" placeholder="" data-picker="<?=$id.'__'.$key.'__'?>" class="call-picker" value="">
	<div class="color-holder call-picker" data-picker="<?=$id.'__'.$key.'__'?>color"></div>
	<div class="color-picker" data-picker="<?=$id.'__'.$key.'__'?>" style="display:none"></div>
</div>

<script type="text/javascript">
	var picker = $('div[data-picker=<?=$id.'__'.$key.'__'?>]')
	var index = 0;
	for(var key in colorMatrix)
	{
		var strColor = "";
		if(colorMatrix[index].name == 'Misc')
			strColor = '<div>';
		else
			strColor = '<div class="stolb">';

		for(var i = 0; i < colorMatrix[index].colors.length; i++)
		{
			if(colorMatrix[index].name == 'Misc')
				strColor += '<li class="color-picker-li-big" data-hex="' + '#' + colorMatrix[index].colors[i].hex + '" style="background-color:' + '#' + colorMatrix[index].colors[i].hex + ';"></li>';
			else
				strColor += '<li class="color-item" data-hex="' + '#' + colorMatrix[index].colors[i].hex +    '" style="background-color:' + '#' + colorMatrix[index].colors[i].hex + ';"></li>';
		}
		strColor += '</div>';
		picker.append(strColor);
		index++;
	}  
</script> 

</td></tr>
<?
	endfor;
endif;

?>
</table>