<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

global $APPLICATION;

$APPLICATION->SetAdditionalCSS('/bitrix/js/simai.property/colorpicker.css');

if (!is_array($values)):
	$values = array($values);
endif;

foreach ($values as $value):
	if ($value):
?>
<div class="color-holder" style="background-color:<?=$value?>;"></div>
<?
	endif;
endforeach;
?>