<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$params["max_length"] = intval($params["max_length"]);

$obParser = new CTextParser;

if (!is_array($values)):
	$values = array($values);
endif;

foreach ($values as $i => $value):
	
	if ($params['strip_tags'] == 'Y'):
		$value = strip_tags(htmlspecialcharsBack($value));
	endif;
	
	if ($params["max_length"] > 0):
		$value = $obParser->html_cut($value, $params["max_length"]);
	endif;
	
	$values[$i] = $value;
	
endforeach;


echo implode(' <br /> ', $values);
?>