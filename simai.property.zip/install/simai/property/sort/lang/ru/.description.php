<?
$MESS ['SF_PROPERTY_TYPE_NAME'] = "Сортируемый список";
?>