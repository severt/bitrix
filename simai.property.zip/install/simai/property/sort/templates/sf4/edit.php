<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

	use Bitrix\Main\Page\Asset;
	\SIMAI\Main\Page\Asset::getInstance()->load('sf4property');
	Asset::getInstance()->addJs('/simai/asset/simai.property/sf4/js/sort/sf4/script.js');
	Asset::getInstance()->addCss('/simai/asset/simai.property/sf4/css/sort/sf4/style.css');

	$table_id = rand();?>

	<?if (!is_array($values)): $values = explode(',', $values);endif;
	if (!is_array($params["variants"])):$params["variants"] = array();endif;?>

	<?$result = Array();
	if(!is_array($values)) {
		foreach($values as $keyV => $itemV) {
			foreach($params["variants"] as $keyPar => $itemPar) {
				if($itemV == $keyPar) {
					$result[$keyPar] = $itemPar;
				}
			}
		}
	} else {
		foreach($params["variants"] as $keyPar => $itemPar)
			$result[$keyPar] = $itemPar;
	}?>


	<ul class="property_sort <?if($params["inactive"] == "Y"):?>sf4_property_inactive<?endif?>" data-input="inp<?=$table_id?>" id="ul<?=$table_id?>">
		<?$index = 0;?>
		<?foreach($result as $keyP => $item):?>
			<li class="li<?=$table_id?> property_sort__item"
				data-code="<?=$keyP?>">
				<?=$item;?>
				<i class="far fa-arrows-alt-v property_sort__item__icon" aria-hidden="true"></i>
			</li>
			<?$index++;?>
		<?endforeach;?> 
	</ul>

	<input
		class="form-control"
		type="hidden"
		data-sort=""
		name="<?=$params["field_name"]?>[01]"
		value="<?=implode(',', $values)?>"
		id="inp<?=$table_id?>" />
	<div
		checked="checked"
		if-type="text"
		class="d-none radio-change"
		name="<?=$params["field_name"]?>[0]"
		value="<?=implode(',', $values)?>"></div>
	<?if($params["inactive"] == "Y"):?>
		<input name="<?=$params["field_name"]?>_edit" value="N" type="hidden" class="hidden-input" />
	<?endif?>
	<script type="text/javascript">
		sortable('#ul<?=$table_id?>', {
			forcePlaceholderSize: true,
			placeholderClass: 'li<?=$table_id?>',
		});
	</script>