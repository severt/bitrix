<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if (!is_array($params["variants"])):
	$params["variants"] = array();
endif;

if (!is_array($values)):
	$values = explode(',', $values);
endif;

$print_values = array();
foreach ($values as $val)
{
	$print_values[] = $params["variants"][$val];
}

echo implode(' / ', $print_values);
?>