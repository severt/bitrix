<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

global $APPLICATION;

$APPLICATION->SetAdditionalCSS('/simai/asset/simai.property/.default/css/sort/style.css');

$APPLICATION->AddHeadScript('/simai/asset/simai.property/.default/js/jquery.js');
$APPLICATION->AddHeadScript('/simai/asset/simai.property/.default/js/sort.js');

$table_id = rand();
?>

<?
if (!is_array($values)):
	$values = explode(',', $values);
endif;

if (!is_array($params["variants"])):
	$params["variants"] = array();
endif;
?>
<ul class="js-sortable sortable" data-input="inp<?=$table_id?>" id="ul<?=$table_id?>">
<?foreach($values as $value):
	if (isset($params["variants"][$value])):
?>
   <li class="li<?=$table_id?> sort-elem" data-code="<?=$value?>"><?=$params["variants"][$value]?></li>
	<?endif;
endforeach;?> 
</ul>
<input type="hidden" name="<?=$params["field_name"]?>" value="<?=implode(',', $values)?>" id="inp<?=$table_id?>">
<br>

<script type="text/javascript">
sortable('#ul<?=$table_id?>', {
	forcePlaceholderSize: true,
	placeholderClass: 'li<?=$table_id?>',
});
</script>