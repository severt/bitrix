<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

    use Bitrix\Main\Page\Asset;
    
    \SIMAI\Main\Page\Asset::getInstance()->load('sf4property');
    \SIMAI\Main\Page\Asset::getInstance()->load('jquery');
    //\Bitrix\Main\Page\Asset::getInstance()->addJs('/simai/asset/jquery/jquery-3.3.1/jquery.min.js');
    Asset::getInstance()->addJs('/simai/asset/mask/js/jquery.mask.min.js');

    $cols = intval($params['cols']);
    if ($cols < 1): $cols = 25;
    elseif ($cols > 100): $cols = 100; endif;

    $MULTIPLE_CNT = intval($params['multiple_cnt']);
    if ($MULTIPLE_CNT <= 0 || $MULTIPLE_CNT > 30): $MULTIPLE_CNT = 3; endif;

    $bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));
    $cnt = ($params["multiple"] == "Y" ? $MULTIPLE_CNT + ($bInitDef ? 1 : 0) : 1);
    $start = 0;
    $table_id = rand();?>
    
    <?if (!is_array($values)):$values = array($values);endif;?>

    <div class="container-phone sf4_property <?if($params["inactive"] == "Y"):?>sf4_property_inactive<?endif?>" data-phone="">
        <?foreach($values as $key=>$val):?>
            <div class="form-group sf4_property" data-property-field="phone">
                <input
                    class="form-control phone_mask_<?=$table_id?>"
                    data-phone="public"
                    <?if($params["required"] == "Y"):?>required<?endif?>
                    name="<?=$params["field_name"]?>[<?=$key?>1]"
                    value="<?=$val?>"
                    size="<?=$cols?>"
                    aria-label="<?=$params["name_label"]?>"
                    type="text" />
                <div
                    checked="checked"
                    if-type="text"
                    class="d-none radio-change"
                    name="<?=$params["field_name"]?>[0]"
                    value="<?=$val?>"></div>
            </div>
            <?if ($params["multiple"] != "Y"):
                $params["bVarsFromForm"] = true;
                break;
            endif;
        endforeach;?>

        <?if (!$params["bVarsFromForm"]):
            for ($i = 0; $i < $cnt; $i++):?>
                <div class="form-group sf4_property" data-property-field="phone">
                    <?if ($i == 0 && $bInitDef): $val = $params["default_value"];
                    else: $val = ""; endif;?>
                    <input
                        data-phone="public"
                        name="<?=$params["field_name"]?>[n<?=($start + $i)?>1]"
                        value="<?=$val?>"
                        size="<?=$cols?>"
                        type="text"
                        class=" form-control phone_mask_<?=$table_id?>" 
                        <?if($params["required"] == "Y"):?>required<?endif?> />
                    <div
                        checked="checked"
                        if-type="text"
                        class="d-none radio-change"
                        name="<?=$params["field_name"]?>[0]"
                        value="<?=$val?>"></div>
                </div>
            <?endfor;
        endif;?>
        <?if($params["inactive"] == "Y"):?>
            <input name="<?=$params["field_name"]?>_edit" value="N" type="hidden" class="hidden-input" />
        <?endif?>
        <?if (!$params["bVarsFromForm"]):?>
            <input class="btn btn-primary" data-button-property type="button" value="<?=GetMessage("SF_PROPERTY_AT_PROP_ADD")?>"/>
        <?endif;?>
    </div>
    <script type="text/javascript">
        jQuery(function($) {
            $('.phone_mask_<?=$table_id?>').mask('+0 (000) 000-0000',{placeholder: "+7 (___) ___-____"});
        });
    </script>