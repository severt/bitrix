<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if (!is_array($values)):
	$values = array($values);
endif;

echo implode(' <br /> ', $values);
?>