<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if (!is_array($values)):
	$values = array($values);
endif;

/*foreach ($values as $i => $val):
	$val = preg_replace("/[^0-9]/", "", $val);
	if ($val):
		$values[$i] = '+'.substr($val, 0, 1).' ('.substr($val, 1, 3).') '.substr($val, 4, 3).'-'.substr($val, 7, 2).'-'.substr($val, 9, 2);
	endif;
endforeach;*/

echo implode(' <br /> ', $values);
?>