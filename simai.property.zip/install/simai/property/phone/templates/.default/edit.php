<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

global $APPLICATION;

$APPLICATION->AddHeadScript('/simai/asset/simai.property/.default/js/jquery.js');
$APPLICATION->AddHeadScript('/simai/asset/simai.property/.default/js/phone/maskedinput.js', true);

$cols = intval($params['cols']);
if ($cols < 1):
	$cols = 25;
elseif ($cols > 100):
	$cols = 100;
endif;

$MULTIPLE_CNT = intval($params['multiple_cnt']);
if ($MULTIPLE_CNT <= 0 || $MULTIPLE_CNT > 30):
	$MULTIPLE_CNT = 3;
endif;

$bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));

$cnt = ($params["multiple"] == "Y" ? $MULTIPLE_CNT + ($bInitDef ? 1 : 0) : 1);

$start = 0;


$table_id = rand();
?>
<table cellpadding="0" cellspacing="0" border="0" class="nopadding" width="100%" id="tb<?=md5($table_id)?>">
<?
if (!is_array($values)):
	$values = array($values);
endif;

foreach($values as $key=>$val):
	/*$val = preg_replace("/[^0-9]/", "", $val);
	$val = '+'.substr($val, 0, 1).' ('.substr($val, 1, 3).') '.substr($val, 4, 3).'-'.substr($val, 7, 2).'-'.substr($val, 9, 2);*/
?>
<tr><td>
<input name="<?=$params["field_name"]?>[<?=$key?>]" value="<?=$val?>" size="<?=$cols?>" type="text" class="phone_mask_<?=$table_id?>">
<br>
</td></tr>
<?
	if ($params["multiple"] != "Y"):
		$params["bVarsFromForm"] = true;
		break;
	endif;
endforeach;

if (!$params["bVarsFromForm"]):
	for ($i = 0; $i < $cnt; $i++):
?>
<tr><td>
<?
		if ($i == 0 && $bInitDef):
			$val = $params["default_value"];
		else:
			$val = "";
		endif;
?>
<input name="<?=$params["field_name"]?>[n<?=($start + $i)?>]" value="<?=$val?>" size="<?=$cols?>" type="text" class="phone_mask_<?=$table_id?>">
<br>
</td></tr>
<?
	endfor;
endif;
?>
</table>
<script type="text/javascript">
	$('.phone_mask_<?=$table_id?>').mask('+9 (999) 999-9999');
</script>