<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$entity = $params['entity'];

$primary = \SIMAI\PropertyEntitiesType::GetPrimary($params['entity']);

if (!$primary)
{
	echo \SIMAI\PropertyEntitiesType::ShowErrWrongEntity();
	$filter_error = true;
}
else
{
	\SIMAI\PropertyEntitiesType::SetModule($entity);
}
?>