<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$cols = intval($params['cols']);
if ($cols < 1):
	$cols = 25;
elseif ($cols > 100):
	$cols = 100;
endif;

$MULTIPLE_CNT = intval($params['multiple_cnt']);
if ($MULTIPLE_CNT <= 0 || $MULTIPLE_CNT > 30):
	$MULTIPLE_CNT = 3;
endif;

$bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));

$cnt = ($params["multiple"] == "Y" ? $MULTIPLE_CNT + ($bInitDef ? 1 : 0) : 1);

$start = 0;


$table_id = rand();
?>
<table cellpadding="0" cellspacing="0" border="0" class="nopadding" width="100%" id="tb<?=md5($table_id)?>">
<?
if (!is_array($values)):
	$values = array($values);
endif;

$required_value = false;
$required_var = \SIMAI\PropertyEntitiesType::GetRequired($entity);
$required_value_str = '';

if ($required_var)
{
	if (isset($params[$required_var]))
	{	
		$required_value = preg_replace('/[^a-zA-Z0-9\\\_]/', '', $params[$required_var]);
		$required_value_str = '&amp;'.$required_var.'='.$required_value;
	}
}

$search_get_vals_str = '';

if (is_array($params['search_get_vals']))
{
	foreach ($params['search_get_vals'] as $var => $val)
	{
		$search_get_vals_str .= '&amp;'.htmlspecialchars($var).'='.$val;
	}
}

foreach($values as $key => $val):
	
	$val_view = '';
	
	$primary = $val;
	$block_id = $required_value;
	
	if ($entity == '\SIMAI\Storage\Element'):
		$var_arr = explode(':', $val);
		if ($var_arr[1]):
			$primary = intval($var_arr[0]);
			$block_id = $var_arr[1];
		endif;
	endif;
	
	$val_view_arr = \SIMAI\PropertyEntitiesType::GetViewEntityFields($entity, $primary, $block_id, LANGUAGE_ID);
	if (is_array($val_view_arr)):
		
		switch ($entity)
		{
			case '\SIMAI\Storage\Storage':
				if (isset($val_view_arr['STORAGE_ID'])):
					$val_view = $val_view_arr['PROP_TITLE'] ? $val_view_arr['PROP_TITLE'] : $val_view_arr['STORAGE_ID'];
				endif;
				break;
			
			case '\SIMAI\Storage\Element':
				if (isset($val_view_arr['ELEMENT_ID'])):
					$val_view = str_repeat('. ', $val_view_arr['DEPTH_LEVEL']).($val_view_arr['PROP_TITLE'] ? $val_view_arr['PROP_TITLE'] : $val_view_arr['ELEMENT_ID']);
				endif;
				break;

			case '\Bitrix\Iblock\Section':
				if (isset($val_view_arr['ID'])):
					$val_view = str_repeat('. ', $val_view_arr['DEPTH_LEVEL']).$val_view_arr['NAME'];
				endif;
				break;
				
			case '\Bitrix\Iblock\Element':
				if (isset($val_view_arr['ID'])):
					$val_view = $val_view_arr['NAME'];
				endif;
				break;
			
			case '\Bitrix\Main\UserTable':
				if (isset($val_view_arr['ID'])):
					$val_view = $val_view_arr['LOGIN'];
				endif;
				break;
		}
	endif;
	
	$inp_id = md5($params["field_name"].'_'.$key);
?>
<tr><td>
<input id="<?=$inp_id?>" name="<?=$params["field_name"]?>[<?=$key?>]" value="<?=$val?>" size="<?=$cols?>" type="text">
<input type="button" value="..." onClick="jsUtils.OpenWindow('/simai/admin/sf_property_entity_search.php?lang=<?=LANGUAGE_ID?>&amp;inp_id=<?=$inp_id?>&amp;entity=<?=urlencode($entity)?><?=$required_value_str.$search_get_vals_str?>', 800, 600);">
<span id="<?=$inp_id?>span"><?=$val_view?></span>
<br>
</td></tr>
<?
	if ($params["multiple"] != "Y"):
		$params["bVarsFromForm"] = true;
		break;
	endif;
endforeach;

if (!$params["bVarsFromForm"]):
	for ($i = 0; $i < $cnt; $i++):
?>
<tr><td>
<?
		if ($i == 0 && $bInitDef):
			$val = $params["default_value"];
		else:
			$val = "";
		endif;
		
		$inp_id = md5($params["field_name"]).'__n'.($start + $i).'__';
?>
<input id="<?=$inp_id?>" name="<?=$params["field_name"]?>[n<?=($start + $i)?>]" value="<?=$val?>" size="<?=$cols?>" type="text">
<input type="button" value="..." onClick="jsUtils.OpenWindow('/simai/admin/sf_property_entity_search.php?lang=<?=LANGUAGE_ID?>&amp;inp_id=<?=$inp_id?>&amp;entity=<?=urlencode($entity)?><?=$required_value_str.$search_get_vals_str?>', 800, 600);">
<span id="<?=$inp_id?>span"></span>
<br>
</td></tr>
<?
	endfor;
endif;

if ($params["multiple"] == "Y"):
?>
	<tr><td><input type="button" value="<?=GetMessage("SF_PROPERTY_AT_PROP_ADD")?>" onClick="SFPropAddNewRow('tb<?=md5($table_id)?>')"></td></tr>
	<script type=\"text/javascript\">BX.addCustomEvent('onAutoSaveRestore', function(ob, data) {for (var i in data){if (i.substring(0,<?=(strlen($params["field_name"])+1)?>)=='<?=CUtil::JSEscape($params["field_name"])?>['){SFPropAddNewRow('tb<?=md5($table_id)?>')}}})</script>
<?endif;?>
</table>