<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$language_id = $params['language_id'];
if ($language_id == ''):
	$language_id = LANGUAGE_ID;
endif;

$block_id = false;
if ($entity == '\SIMAI\Storage\Element')
{
	$block_id = $params['storage_id'];
}
$value_arr = array();
if (is_array($values))
{
	foreach ($values as $val)
	{
		$val_view = \SIMAI\PropertyEntitiesType::GetViewEntityFields($entity, $val, $block_id, $language_id);
		if (is_array($val_view))
		{
			$value_arr[] = $val_view;
		}
	}
}
else
{
	$value_arr[0] = \SIMAI\PropertyEntitiesType::GetViewEntityFields($entity, $val, $block_id, $language_id);
}

$print_values = array();

switch ($entity)
{
	case '\SIMAI\Storage\Storage':
		foreach ($value_arr as $val)
		{
			if (isset($val['STORAGE_ID']))
			{
				$print_values[] = $val['PROP_TITLE'] ? '['.$val['STORAGE_ID'].'] '.$val['PROP_TITLE'] : $val['STORAGE_ID'];
			}
		}
		break;
	
	case '\SIMAI\Storage\Element':
		foreach ($value_arr as $val)
		{
			if (isset($val['ELEMENT_ID']))
			{			
				$print_values[] = $val['PROP_TITLE'] ? '['.$val['ELEMENT_ID'].'] '.$val['PROP_TITLE'] : $val['ELEMENT_ID'];
			}
		}
		break;

	case '\Bitrix\Iblock\Section':
		foreach ($value_arr as $val)
		{
			if (isset($val['ID']))
			{
				$print_values[] = '['.$val['ID'].'] '.$val['NAME'];
			}
		}
		break;
		
	case '\Bitrix\Iblock\Element':
		foreach ($value_arr as $val)
		{
			if (isset($val['ID']))
			{
				$print_values[] = '['.$val['ID'].'] '.$val['NAME'];
			}
		}
		break;
	
	case '\Bitrix\Main\UserTable':
		foreach ($value_arr as $val)
		{
			if (isset($val['ID']))
			{
				$print_values[] = '['.$val['ID'].'] '.$val['LOGIN'];
			}
		}
		break;
	
}

echo implode(' / ', $print_values);
?>