<?
$MESS ['SF_PROPERTY_TYPE_NAME'] = "Привязка к сущности";
?>