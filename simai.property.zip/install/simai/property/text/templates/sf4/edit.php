<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
    \Bitrix\Main\Page\Asset::getInstance()->addCss('/simai/asset/simai.property/sf4/css/text/sf4/style.css');
    \SIMAI\Main\Page\Asset::getInstance()->load('sf4property');

    $cols = intval($params['cols']);
    if ($cols < 1):	$cols = 25;
    elseif ($cols > 100):$cols = 100; endif;

    $rows = intval($params['rows']);
    if ($rows < 1):	$rows = 1;
    elseif ($rows > 30):$rows = 30; endif;

    $MULTIPLE_CNT = intval($params['multiple_cnt']);
    if ($MULTIPLE_CNT <= 0 || $MULTIPLE_CNT > 30):$MULTIPLE_CNT = 3;endif;

    $visual = ($params['text_type'] == 'visual');

    $bInitDef = (!$params["bVarsFromForm"] && (strlen($params["default_value"]) > 0));
    $cnt = ($params["multiple"] == "Y" ? $MULTIPLE_CNT + ($bInitDef ? 1 : 0) : 1);
    $start = 0;?>

    <?if (!is_array($values)): $values = array($values);endif;?>

    <div class="text_property sf4_property <?if($params["inactive"] == "Y"):?>sf4_property_inactive<?endif?>" data-text>
        <?foreach($values as $key => $val):?>
            <div class="form-group sf4_property" data-property-field="text">
                <?if($visual):?>
                    <textarea
                        class="form-control text_property__field"
                        name="<?=$params["field_name"]?>[<?=$key?>1]"
                        <?if ($params["required"] == "Y"):?>required<?endif;?>
                        cols="<?=$cols?>"
                        rows="<?=$rows?>"
                        aria-label="<?=$params["name_label"]?>"><?=$val?></textarea>
                <?else:?>
                    <textarea
                        class="form-control text_property__field"
                        name="<?=$params["field_name"]?>[<?=$key?>1]"
                        <?if ($params["required"] == "Y"):?>required<?endif;?>
                        cols="<?=$cols?>"
                        rows="<?=$rows?>"
                        aria-label="<?=$params["name_label"]?>"><?=$val?></textarea>
                <?endif;?>
                <div
                    checked="checked"
                    if-type="text"
                    class="d-none radio-change"
                    name="<?=$params["field_name"]?>[0]"
                    value="<?=$val?>"></div>
            </div>
                <?if ($params["multiple"] != "Y"):
                    $params["bVarsFromForm"] = true;
                    break;
                endif;?>
            
        <?endforeach;
        if (!$params["bVarsFromForm"]):
            for ($i = 0; $i < $cnt; $i++):?>
                <?if ($i == 0 && $bInitDef): $val = $params["default_value"];
                else: $val = ""; endif;?>
                <div class="form-group sf4_property" data-property-field="text">
                    <?if ($visual):?>
                        <textarea
                            class="form-control text_property__field"
                            name="<?=$params["field_name"]?>[n<?=($start + $i)?>1]"
                            <?if ($params["required"] == "Y"):?>required<?endif;?>
                            cols="<?=$cols?>"
                            rows="<?=$rows?>"><?=$val?></textarea>
                    <?else:?>
                        <textarea
                            class="form-control text_property__field"
                            name="<?=$params["field_name"]?>[n<?=($start + $i)?>1]"
                            <?if ($params["required"] == "Y"):?>required<?endif;?>
                            cols="<?=$cols?>"
                            rows="<?=$rows?>"><?=$val?></textarea>
                    <?endif;?>
                    <div
                        checked="checked"
                        if-type="text"
                        class="d-none radio-change"
                        name="<?=$params["field_name"]?>[0]"
                        value="<?=$val?>"></div>
                </div>
            <?endfor;
        endif;?>
        <?if($params["inactive"] == "Y"):?>
            <input name="<?=$params["field_name"]?>_edit" value="N" type="hidden" class="hidden-input" />
        <?endif?>
        <?if ($params["multiple"] == "Y" && !$visual):?>
            <input class="btn btn-primary" type="button" value="<?=GetMessage("SF_PROPERTY_AT_PROP_ADD")?>" data-button-property="" />
        <?endif;?>
    </div>

