<?php

namespace SIMAI;

use Bitrix\Main;
use Bitrix\Main\Application;
//use Bitrix\Main\IO\Directory;
//use Bitrix\Main\IO\File;
use Bitrix\Main\Localization\Loc;

//use Bitrix\Main\Config\Option;

Main\Localization\Loc::loadLanguageFile(__FILE__);

//define('SF_PROPERTY_DOCUMENT_ROOT', Application::getDocumentRoot());


/**
* Class description
* @package    SIMAI
* @subpackage Storage
*/
class PropertyEntitiesType
{
    /**
    * @param string $entity
    *
    * @return true
    */
    public static function SetModule($entity)
    {
        switch ($entity) {
            case '\SIMAI\Storage\Storage':
                \Bitrix\Main\Loader::includeSharewareModule('simai.storage');
                break;
            case '\SIMAI\Storage\Element':
                \Bitrix\Main\Loader::includeSharewareModule('simai.storage');
                break;
            
                
            case '\Bitrix\Iblock\Element':
                \Bitrix\Main\Loader::includeModule('iblock');
                break;
            case '\Bitrix\Iblock\Section':
                \Bitrix\Main\Loader::includeModule('iblock');
                break;
        }
        
        return true;
    }
    
    
    /**
    * @param string $entity
    *
    * @return string / false
    */
    public static function GetTitle($entity)
    {
        switch ($entity) {
            case '\SIMAI\Storage\Storage':
                return GetMessage('SF_PROPERTY_SIMAI_STORAGES');
                break;
            case '\SIMAI\Storage\Element':
                return GetMessage('SF_PROPERTY_SIMAI_STORAGE_ELEMENTS');
                break;
                
            case '\Bitrix\Iblock\Element':
                return GetMessage('SF_PROPERTY_IBLOCK_ELEMENTS');
                break;
            case '\Bitrix\Iblock\Section':
                return GetMessage('SF_PROPERTY_IBLOCK_SECTIONS');
                break;
            
            case '\Bitrix\Main\UserTable':
                return GetMessage('SF_PROPERTY_USERS');
                break;
        }
        
        return false;
    }
    
    /**
    * @param string $entity
    *
    * @return string / false
    */
    public static function GetPrimary($entity)
    {
        switch ($entity) {
            case '\SIMAI\Storage\Storage':
                return 'STORAGE_ID';
                break;
            case '\SIMAI\Storage\Element':
                return 'ELEMENT_ID';
                break;
            
            case '\Bitrix\Iblock\Element':
                return 'ID';
                break;
            case '\Bitrix\Iblock\Section':
                return 'ID';
                break;
            
            case '\Bitrix\Main\UserTable':
                return 'ID';
                break;
        }
        
        return false;
    }
    
    /**
    * @param string $entity
    *
    * @return string / false
    */
    public static function GetRequired($entity)
    {
        switch ($entity) {
            case '\Bitrix\Iblock\Section':
                return 'IBLOCK_ID';
                break;
            
            case '\Bitrix\Iblock\Element':
                return 'IBLOCK_ID';
                break;
            
            case '\SIMAI\Storage\Element':
                return 'storage_id';
                break;
        }
        
        return false;
    }
    
    /**
    * @param string $entity
    *
    * @return array()
    */
    public static function GetSort($entity)
    {
        $return = array();
        
        switch ($entity) {
            case '\Bitrix\Iblock\Section':
                $return = array(
                    'REGULAR' => array('LEFT_MARGIN' => 'asc'),
                );
                break;
            
            case '\Bitrix\Iblock\Element':
                $return = array(
                    'REGULAR' => array('SORT' => 'asc'),
                );
                break;
            
            case '\SIMAI\Storage\Storage':
                $return = array(
                    'REGULAR' => array('SORT' => 'asc'),
                );
                break;
            
            case '\SIMAI\Storage\Element':
                $return = array(
                    'PRIORITY' => array('TYPE' => 'desc'),
                    'PRIORITY_DEPENDENT' => array('PROP_TITLE' => 'LEFT_MARGIN'),
                    'REGULAR' => array('LEFT_MARGIN' => 'asc', 'SORT' => 'asc'),
                );
                break;
                
            case '\Bitrix\Main\UserTable':
                $return = array(
                    'REGULAR' => array('ID' => 'desc'),
                );
                break;
        }
        
        return $return;
    }
    
    /**
    * @param string $entity
    *
    * @return array
    */
    public static function GetFields($entity, $block_id, $check_sites, $check_access)
    {
        switch ($entity) {
            case '\SIMAI\Storage\Storage':
                return array(
                    'STORAGE_ID' => array(
                        'title' => GetMessage('SF_PROPERTY_STORAGE_ID'),
                        'filter_type' => 'string',
                        'filter_params' => array(
                            'field_name' => 'find_storage_id',
                            'cols' => 47
                        ),
                        'filter_ar_field' => '%STORAGE_ID',
                    ),
                    'PROP_TITLE' => array(
                        'title' => GetMessage('SF_PROPERTY_TITLE'),
                        'filter_type' => 'string',
                        'filter_params' => array(
                            'field_name' => 'find_prop_title',
                            'cols' => 47
                        ),
                        'not_in_sorting' => true,
                    ),
                    'ACTIVE' => array(
                        'title' => GetMessage('SF_PROPERTY_ACTIVE'),
                        'value_titles' => array(
                            '' => GetMessage('SF_PROPERTY_ANY'),
                            'Y' => GetMessage('SF_PROPERTY_YES'),
                            'N' => GetMessage('SF_PROPERTY_NO'),
                        ),
                        'filter_type' => 'list',
                        'filter_params' => array(
                            'field_name' => 'find_active',
                            'list_type' => 'list',
                            'multiple' => 'N',
                            'rows' => 1,
                            'variants' => array(
                                '' => GetMessage('SF_PROPERTY_ANY'),
                                'Y' => GetMessage('SF_PROPERTY_YES'),
                                'N' => GetMessage('SF_PROPERTY_NO'),
                            ),
                        ),
                        'filter_ar_field' => '=ACTIVE',
                    ),
                    'SORT' => array(
                        'title' => GetMessage('SF_PROPERTY_SORT'),
                        'align' => 'right',
                    ),
                );
                break;
                
            case '\SIMAI\Storage\Element':
                return array(
                    'storage_id' => array(
                        'title' => GetMessage('SF_PROPERTY_STORAGE_ID'),
                        'filter_type' => 'list',
                        'filter_params' => array(
                            'field_name' => 'storage_id',
                            'field_id' => 'storage_id',
                            'rows' => 1,
                            'list_type' => 'list',
                            'multiple' => 'N',
                            'variants' => self::GetStoragesList($check_sites, $check_access),
                        ),
                        'default_filter_val' => '-1',
                        'reload' => true,
                        'filter_ar_field' => 'storage_id',
                        'not_show_col' => true,
                    ),
                    'TYPE' => array(
                        'title' => GetMessage('SF_PROPERTY_SIMAI_STORAGE_TYPE'),
                        'value_titles' => array(
                            '' => GetMessage('SF_PROPERTY_ANY'),
                            'S' => GetMessage('SF_PROPERTY_SIMAI_STORAGE_SECTIONS'),
                            'I' => GetMessage('SF_PROPERTY_SIMAI_STORAGE_ITEMS'),
                        ),
                        'filter_type' => 'list',
                        'filter_params' => array(
                            'field_name' => 'find_type',
                            'list_type' => 'list',
                            'multiple' => 'N',
                            'rows' => 1,
                            'variants' => array(
                                '' => GetMessage('SF_PROPERTY_ANY'),
                                'S' => GetMessage('SF_PROPERTY_SIMAI_STORAGE_SECTIONS'),
                                'I' => GetMessage('SF_PROPERTY_SIMAI_STORAGE_ITEMS'),
                            ),
                        ),
                        'filter_ar_field' => '=TYPE',
                        'not_show_col' => true,
                    ),
                    'PARENT_ID' => array(
                        'title' => GetMessage('SF_PROPERTY_PARENT_ID'),
                        'filter_type' => 'list',
                        'filter_params' => array(
                            'field_name' => 'find_parent_id',
                            'field_id' => 'find_parent_id',
                            'rows' => 1,
                            'list_type' => 'list',
                            'multiple' => 'N',
                            'variants' => self::GetStorageSectionList($block_id, $check_access),
                        ),
                        'necessary_var' => 'storage_id',
                        'default_filter_val' => 'all',
                        'not_set_value' => 'all',
                        'filter_ar_field' => '=PARENT_ID',
                        'not_show_col' => true,
                    ),
                    'ELEMENT_ID' => array(
                        'title' => GetMessage('SF_PROPERTY_ID'),
                        'filter_type' => 'number',
                        'filter_params' => array(
                            'field_name' => 'find_element_id',
                            'field_name_from' => 'find_element_id_from',
                            'field_name_to' => 'find_element_id_to',
                            'cols' => 8
                        ),
                        'filter_ar_field_from' => '>=ELEMENT_ID',
                        'filter_ar_field_to' => '<=ELEMENT_ID',
                    ),
                    'PROP_TITLE' => array(
                        'title' => GetMessage('SF_PROPERTY_TITLE_LEFT_MARGIN'),
                        'filter_type' => 'string',
                        'filter_params' => array(
                            'field_name' => 'find_prop_title',
                            'cols' => 47
                        ),
                        'filter_ar_field' => '%PROP_TITLE.PROP_TITLE',
                        'filter_ar_field_lang' => '=PROP_TITLE.LANGUAGE_ID',
                    ),
                    'ACTIVE' => array(
                        'title' => GetMessage('SF_PROPERTY_ACTIVE'),
                        'value_titles' => array(
                            '' => GetMessage('SF_PROPERTY_ANY'),
                            'Y' => GetMessage('SF_PROPERTY_YES'),
                            'N' => GetMessage('SF_PROPERTY_NO'),
                        ),
                        'filter_type' => 'list',
                        'filter_params' => array(
                            'field_name' => 'find_active',
                            'list_type' => 'list',
                            'multiple' => 'N',
                            'rows' => 1,
                            'variants' => array(
                                '' => GetMessage('SF_PROPERTY_ANY'),
                                'Y' => GetMessage('SF_PROPERTY_YES'),
                                'N' => GetMessage('SF_PROPERTY_NO'),
                            ),
                        ),
                        'filter_ar_field' => '=ACTIVE',
                    ),
                    'SORT' => array(
                        'title' => GetMessage('SF_PROPERTY_SORT'),
                        'align' => 'right',
                    ),
                );
                break;
            
            
            case '\Bitrix\Iblock\Element':
                return array(
                    'IBLOCK_ID' => array(
                        'title' => GetMessage('SF_PROPERTY_IBLOCK_ID'),
                        'filter_type' => 'list',
                        'filter_params' => array(
                            'field_name' => 'find_iblock_id',
                            'field_id' => 'find_iblock_id',
                            'rows' => 1,
                            'list_type' => 'list',
                            'multiple' => 'N',
                            'variants' => self::GetIblocksList($check_sites, $check_access),
                        ),
                        'default_filter_val' => '-1',
                        'reload' => true,
                        'filter_ar_field' => 'IBLOCK_ID',
                        'not_show_col' => true,
                    ),
                    'IBLOCK_SECTION_ID' => array(
                        'title' => GetMessage('SF_PROPERTY_IBLOCK_SECTION_ID'),
                        'filter_type' => 'list',
                        'filter_params' => array(
                            'field_name' => 'find_iblock_section_id',
                            'rows' => 1,
                            'list_type' => 'list',
                            'multiple' => 'N',
                            'variants' => self::GetIblocksSectionList($block_id, $check_access),
                        ),
                        'necessary_var' => 'find_iblock_id',
                        'default_filter_val' => 'all',
                        'not_set_value' => 'all',
                        'filter_ar_field' => 'SECTION_ID',
                        'not_show_col' => true,
                    ),
                    'ID' => array(
                        'title' => GetMessage('SF_PROPERTY_ID'),
                        'filter_type' => 'number',
                        'filter_params' => array(
                            'field_name' => 'find_id',
                            'field_name_from' => 'find_id_from',
                            'field_name_to' => 'find_id_to',
                            'cols' => 8
                        ),
                        'filter_ar_field_from' => '>=ID',
                        'filter_ar_field_to' => '<=ID',
                    ),
                    'CODE' => array(
                        'title' => GetMessage('SF_PROPERTY_CODE'),
                        'filter_type' => 'string',
                        'filter_params' => array(
                            'field_name' => 'find_code',
                            'cols' => 47
                        ),
                        'filter_ar_field' => '%CODE',
                    ),
                    'NAME' => array(
                        'title' => GetMessage('SF_PROPERTY_NAME'),
                        'filter_type' => 'string',
                        'filter_params' => array(
                            'field_name' => 'find_name',
                            'cols' => 47
                        ),
                        'filter_ar_field' => '%NAME',
                    ),
                    'ACTIVE' => array(
                        'title' => GetMessage('SF_PROPERTY_ACTIVE'),
                        'value_titles' => array(
                            '' => GetMessage('SF_PROPERTY_ANY'),
                            'Y' => GetMessage('SF_PROPERTY_YES'),
                            'N' => GetMessage('SF_PROPERTY_NO'),
                        ),
                        'filter_type' => 'list',
                        'filter_params' => array(
                            'field_name' => 'find_active',
                            'list_type' => 'list',
                            'multiple' => 'N',
                            'rows' => 1,
                            'variants' => array(
                                '' => GetMessage('SF_PROPERTY_ANY'),
                                'Y' => GetMessage('SF_PROPERTY_YES'),
                                'N' => GetMessage('SF_PROPERTY_NO'),
                            ),
                        ),
                        'filter_ar_field' => 'ACTIVE',
                    ),
                    'SORT' => array(
                        'title' => GetMessage('SF_PROPERTY_SORT'),
                        'align' => 'right',
                    ),
                );
                break;
                
            case '\Bitrix\Iblock\Section':
                return array(
                    'IBLOCK_ID' => array(
                        'title' => GetMessage('SF_PROPERTY_IBLOCK_ID'),
                        'filter_type' => 'list',
                        'filter_params' => array(
                            'field_name' => 'find_iblock_id',
                            'rows' => 1,
                            'list_type' => 'list',
                            'multiple' => 'N',
                            'variants' => self::GetIblocksList($check_sites, $check_access),
                        ),
                        'default_filter_val' => '-1',
                        'filter_ar_field' => 'IBLOCK_ID',
                        'reload' => true,
                        'not_show_col' => true,
                    ),
                    'IBLOCK_SECTION_ID' => array(
                        'title' => GetMessage('SF_PROPERTY_IBLOCK_SECTION_ID'),
                        'filter_type' => 'list',
                        'filter_params' => array(
                            'field_name' => 'find_iblock_section_id',
                            'field_id' => 'find_iblock_section_id',
                            'rows' => 1,
                            'list_type' => 'list',
                            'multiple' => 'N',
                            'variants' => self::GetIblocksSectionList($block_id, $check_access),
                        ),
                        'necessary_var' => 'find_iblock_id',
                        'default_filter_val' => 'all',
                        'not_set_value' => 'all',
                        'filter_ar_field' => 'SECTION_ID',
                        'not_show_col' => true,
                    ),
                    'ID' => array(
                        'title' => GetMessage('SF_PROPERTY_ID'),
                        'filter_type' => 'number',
                        'filter_params' => array(
                            'field_name' => 'find_id',
                            'field_name_from' => 'find_id_from',
                            'field_name_to' => 'find_id_to',
                            'cols' => 8
                        ),
                        'filter_ar_field_from' => '>=ID',
                        'filter_ar_field_to' => '<=ID',
                    ),
                    'CODE' => array(
                        'title' => GetMessage('SF_PROPERTY_CODE'),
                        'filter_type' => 'string',
                        'filter_params' => array(
                            'field_name' => 'find_code',
                            'cols' => 47
                        ),
                        'filter_ar_field' => '%CODE',
                    ),
                    'LEFT_MARGIN' => array(
                        'title' => GetMessage('SF_PROPERTY_LEFT_MARGIN'),
                    ),
                    'NAME' => array(
                        'title' => GetMessage('SF_PROPERTY_NAME'),
                        'filter_type' => 'string',
                        'filter_params' => array(
                            'field_name' => 'find_name',
                            'cols' => 47
                        ),
                        'filter_ar_field' => '%NAME',
                        'not_show_col' => true,
                    ),
                    'ACTIVE' => array(
                        'title' => GetMessage('SF_PROPERTY_ACTIVE'),
                        'value_titles' => array(
                            '' => GetMessage('SF_PROPERTY_ANY'),
                            'Y' => GetMessage('SF_PROPERTY_YES'),
                            'N' => GetMessage('SF_PROPERTY_NO'),
                        ),
                        'filter_type' => 'list',
                        'filter_params' => array(
                            'field_name' => 'find_active',
                            'list_type' => 'list',
                            'multiple' => 'N',
                            'rows' => 1,
                            'variants' => array(
                                '' => GetMessage('SF_PROPERTY_ANY'),
                                'Y' => GetMessage('SF_PROPERTY_YES'),
                                'N' => GetMessage('SF_PROPERTY_NO'),
                            ),
                        ),
                        'filter_ar_field' => 'ACTIVE',
                    ),
                    'SORT' => array(
                        'title' => GetMessage('SF_PROPERTY_SORT'),
                        'align' => 'right',
                    ),
                );
                break;
                
            case '\Bitrix\Main\UserTable':
                return array(
                    'GROUPS_ID' => array(
                        'title' => GetMessage('SF_PROPERTY_USER_GROUP'),
                        'filter_type' => 'list',
                        'filter_params' => array(
                            'field_name' => 'find_groups_id',
                            'rows' => 5,
                            'list_type' => 'list',
                            'multiple' => 'Y',
                            'variants' => self::GetUserGroups(true),
                        ),
                        'default_filter_val' => '',
                        'filter_ar_field' => 'GROUPS_ID',
                        'not_show_col' => true,
                    ),
                    'ID' => array(
                        'title' => GetMessage('SF_PROPERTY_ID'),
                        'filter_type' => 'string',
                        'filter_params' => array(
                            'field_name' => 'find_id',
                            'cols' => 47
                        ),
                        'filter_ar_field' => 'ID',
                    ),
                    'LOGIN' => array(
                        'title' => GetMessage('SF_PROPERTY_LOGIN'),
                        'filter_type' => 'string',
                        'filter_params' => array(
                            'field_name' => 'find_login',
                            'cols' => 47
                        ),
                        'filter_ar_field' => 'LOGIN',
                    ),
                    'EMAIL' => array(
                        'title' => GetMessage('SF_PROPERTY_EMAIL'),
                        'filter_type' => 'string',
                        'filter_params' => array(
                            'field_name' => 'find_email',
                            'cols' => 47
                        ),
                        'filter_ar_field' => 'EMAIL',
                    ),
                    'NAME' => array(
                        'title' => GetMessage('SF_PROPERTY_FIRST_NAME'),
                        'filter_type' => 'string',
                        'filter_params' => array(
                            'field_name' => 'find_name',
                            'cols' => 47
                        ),
                        'filter_ar_field' => 'NAME',
                    ),
                    'LAST_NAME' => array(
                        'title' => GetMessage('SF_PROPERTY_LAST_NAME'),
                        'filter_type' => 'string',
                        'filter_params' => array(
                            'field_name' => 'find_last_name',
                            'cols' => 47
                        ),
                        'filter_ar_field' => 'LAST_NAME',
                    ),
                    'ACTIVE' => array(
                        'title' => GetMessage('SF_PROPERTY_ACTIVE'),
                        'value_titles' => array(
                            '' => GetMessage('SF_PROPERTY_ANY'),
                            'Y' => GetMessage('SF_PROPERTY_YES'),
                            'N' => GetMessage('SF_PROPERTY_NO'),
                        ),
                        'filter_type' => 'list',
                        'filter_params' => array(
                            'field_name' => 'find_active',
                            'list_type' => 'list',
                            'multiple' => 'N',
                            'rows' => 1,
                            'variants' => array(
                                '' => GetMessage('SF_PROPERTY_ANY'),
                                'Y' => GetMessage('SF_PROPERTY_YES'),
                                'N' => GetMessage('SF_PROPERTY_NO'),
                            ),
                        ),
                        'filter_ar_field' => 'ACTIVE',
                    ),
                );
                break;
        }
        
        return array();
    }
    
    /**
    * @param string $entity
    *
    * @return Main\DB\Result / false
    */
    public static function GetListDbResult($entity, $block_id, $params, $check_sites, $check_access)
    {
        switch ($entity) {
            case '\SIMAI\Storage\Storage':
                return \SIMAI\Storage\Storage::getList($params, $check_sites, $check_access);
                break;
                
            case '\SIMAI\Storage\Element':
                //check storage exists and has title property
                if (\SIMAI\Storage\Storage::getList(array('select' => array('STORAGE_ID'), 'filter' => array('=STORAGE_ID' => $block_id)))->fetch()) {
                    $connection = \Bitrix\Main\Application::getConnection();
                    $data_entity_table_name = 'sf_storage_'.$block_id;
                    $data_fields_exists = $connection->getTableFields($data_entity_table_name);
                    
                    //
                    if (isset($params['filter']['=PARENT_ID'])) {
                        $parent_id = intval($params['filter']['=PARENT_ID']);
                        if ($params['filter']['INCLUDE_SUBSECTIONS'] == 'Y') {
                            if ($parent_id) {
                                $params['filter']['=PARENT_ID'] = \SIMAI\Storage\Element::get_subsections_ids('abc', $parent_id, false, false, false);
                                $params['filter']['=PARENT_ID'][] = $parent_id;
                            }
                        } else {
                            $params['filter']['=PARENT_ID'] = $parent_id;
                        }
                    }
                    unset($params['filter']['INCLUDE_SUBSECTIONS']);
                    
                    // work with title property
                    if (array_key_exists('PROP_TITLE', $data_fields_exists)) {
                        $prop_fields = array('TITLE');
                        $arFilter['=PROP_TITLE.LANGUAGE_ID'] = array('', LANGUAGE_ID);
                        $params['group'] = array('ELEMENT_ID');
                    } else {
                        $prop_fields = array();
                        if (is_array($params['filter'])) {
                            foreach ($params['filter'] as $code => $val) {
                                if (substr_count($code, 'PROP_') > 0) {
                                    unset($params['filter'][$code]);
                                }
                            }
                            foreach ($params['order'] as $code => $val) {
                                if (substr_count($code, 'PROP_') > 0) {
                                    unset($params['order'][$code]);
                                }
                            }
                        }
                    }
                }
                
                if (isset($params['filter']['storage_id'])) {
                    $block_id = $params['filter']['storage_id'];
                    unset($params['filter']['storage_id']);
                }
                
                return \SIMAI\Storage\Element::getList($block_id, $params, $prop_fields, $check_sites, $check_access);
                break;
                
            case '\Bitrix\Iblock\Element':
                if (!isset($params['limit'])) {
                    $arNavParams = false;
                } else {
                    $arNavParams = array('nPageSize' => $params['limit']);
                }
                $params['filter']['CHECK_PERMISSIONS'] = ($check_access ? 'Y' : 'N');
                if (!isset($params['order'])) {
                    $params['order'] = array('SORT' => 'asc');
                }
                return \CIBlockElement::getList($params['order'], $params['filter'], false, $arNavParams);
                break;
                
            case '\Bitrix\Iblock\Section':
                if (!isset($params['limit'])) {
                    $arNavParams = false;
                } else {
                    $arNavParams = array('nPageSize' => $params['limit']);
                }
                $params['filter']['CHECK_PERMISSIONS'] = ($check_access ? 'Y' : 'N');
                if (!isset($params['order'])) {
                    $params['order'] = array('SORT' => 'asc');
                }
                return \CIBlockSection::getList($params['order'], $params['filter'], false, array(), $arNavParams);
                break;
            
            case '\Bitrix\Main\UserTable':
                if (!isset($params['limit'])) {
                    $arNavParams = false;
                } else {
                    $arNavParams = array('nPageSize' => $params['limit']);
                }
                if (!isset($params['order'])) {
                    $params['order'] = array('ID' => 'asc');
                }
                $by = key($params['order']);
                $order = current($params['order']);
                return \CUser::GetList($by, $order, $params['filter'], array('NAV_PARAMS' => $arNavParams));
                break;
            
        }
        
        return false;
    }
    
    /**
    * @param string $entity
    * @param string $block_id
    * @param string $primary
    *
    * @return array
    */
    public static function GetModifiedCols($entity, $block_id, $primary)
    {
        $return = array();
        
        switch ($entity) {
            case '\SIMAI\Storage\Storage':
                
                $prop_codes = array('TITLE');
                $values = \SIMAI\Storage\Property::GetPropValues($primary, false, $prop_codes, LANGUAGE_ID);
                foreach ($prop_codes as $prop_code) {
                    $print_val = $values[$prop_code];
                    if (!is_array($print_val)) {
                        $print_val = array($print_val);
                    }
                    foreach ($print_val as $i => $val) {
                        $print_val[$i] = TruncateText(strip_tags($val), 50);
                    }
                    $print_val = htmlspecialcharsbx(implode(' / ', $print_val));
                    $return['PROP_'.$prop_code] = $print_val;
                }
                break;
            
            case '\SIMAI\Storage\Element':
                
                $res = \SIMAI\Storage\Element::GetById($block_id, $primary);
                if ($arr = $res->fetch()) {
                    if ($arr['TYPE'] == 'S') {
                        $return['ELEMENT_ID'] = '<span class="adm-submenu-item-link-icon adm-list-table-icon storage-section-icon"></span><span class="adm-list-table-link">'.htmlspecialcharsbx($primary).'</span>';
                    } else {
                        $return['ELEMENT_ID'] = '<span class="adm-submenu-item-link-icon adm-list-table-icon storage-item-icon"></span><span class="adm-list-table-link">'.htmlspecialcharsbx($primary).'</span>';
                    }
                    
                    $values = \SIMAI\Storage\Property::GetPropValues($block_id, $primary, array('TITLE'), LANGUAGE_ID);
                    $print_val = $values['TITLE'];
                    if (!is_array($print_val)) {
                        $print_val = array($print_val);
                    }
                    foreach ($print_val as $i => $val) {
                        $print_val[$i] = TruncateText(strip_tags($val), 50);
                    }
                    $print_val = implode(' / ', $print_val);
                    if ($arr['TYPE'] == 'S') {
                        $print_val_filter = str_repeat('. ', $arr['DEPTH_LEVEL']).'['.$arr['ELEMENT_ID'].'] '.$print_val;
                        $print_val = str_repeat('. ', $arr['DEPTH_LEVEL']).$print_val;
                    }
                    $return['PROP_TITLE'] = htmlspecialcharsbx($print_val);
                    $return['STITLE'] = htmlspecialcharsbx($print_val_filter);
                }
                
                break;
                
            case '\Bitrix\Iblock\Section':
                
                $return['ID'] = '<span class="adm-submenu-item-link-icon adm-list-table-icon storage-section-icon"></span><span class="adm-list-table-link">'.$primary.'</span>';
                
                $res = \Bitrix\Iblock\SectionTable::getList(array('select' => array('DEPTH_LEVEL', 'NAME'), 'filter' => array('=ID' => $primary)));
                if ($arr = $res->fetch()) {
                    $return['LEFT_MARGIN'] = str_repeat('. ', $arr['DEPTH_LEVEL']).$arr['NAME'];
                }
                break;
                
            case '\Bitrix\Iblock\Element':
                
                $return['ID'] = '<span class="adm-submenu-item-link-icon adm-list-table-icon storage-item-icon"></span><span class="adm-list-table-link">'.$primary.'</span>';
                break;
                
        }

        return $return;
    }
    
    
    
    /**
    * @param string $entity
    * @param string $primary
    * @param string $block_id
    *
    * @return array / false
    */
    public static function GetViewEntityFields($entity, $primary, $block_id = false, $language_id = LANGUAGE_ID)
    {
        $return = false;
        
        if ($primary) {
            switch ($entity) {
                case '\SIMAI\Storage\Storage':
                    $res = self::GetListDbResult($entity, false, array('filter' => array('=STORAGE_ID' => $primary)), false, true);
                    if ($return = $res->fetch()) {
                        $prop_codes = array('TITLE');
                        $values = \SIMAI\Storage\Property::GetPropValues($primary, false, $prop_codes, $language_id);
                        foreach ($prop_codes as $prop_code) {
                            $print_val = $values[$prop_code];
                            if (!is_array($print_val)) {
                                $print_val = array($print_val);
                            }
                            foreach ($print_val as $i => $val) {
                                $print_val[$i] = TruncateText(strip_tags($val), 50);
                            }
                            $print_val = implode(' / ', $print_val);
                            $return['PROP_'.$prop_code] = $print_val;
                        }
                    }
                    break;
                case '\SIMAI\Storage\Element':
                    $res = self::GetListDbResult($entity, $block_id, array('filter' => array('=ELEMENT_ID' => $primary)), false, true);
                    if ($return = $res->fetch()) {
                        $prop_codes = array('TITLE');
                        $values = \SIMAI\Storage\Property::GetPropValues($block_id, $primary, $prop_codes, $language_id);
                        foreach ($prop_codes as $prop_code) {
                            $print_val = $values[$prop_code];
                            if (!is_array($print_val)) {
                                $print_val = array($print_val);
                            }
                            foreach ($print_val as $i => $val) {
                                $print_val[$i] = TruncateText(strip_tags($val), 50);
                            }
                            $print_val = implode(' / ', $print_val);
                            $return['PROP_'.$prop_code] = $print_val;
                        }
                    }
                    break;
                
                case '\Bitrix\Iblock\Element':
                    if (intval($primary) <= 0) {
                        $primary = -1;
                    }
                    $res = self::GetListDbResult($entity, $block_id, array('filter' => array('ID' => $primary)), false, true);
                    $return = $res->fetch();
                    break;
                case '\Bitrix\Iblock\Section':
                    if (intval($primary) <= 0) {
                        $primary = -1;
                    }
                    $res = self::GetListDbResult($entity, $block_id, array('filter' => array('ID' => $primary)), false, true);
                    $return = $res->fetch();
                    break;
                    
                case '\Bitrix\Main\UserTable':
                    if (intval($primary) <= 0) {
                        $primary = -1;
                    }
                    $res = self::GetListDbResult($entity, $block_id, array('filter' => array('ID' => $primary)), false, true);
                    $return = $res->fetch();
                    break;
            }
        }
        
        return $return;
    }
    
    
    /**
    * @param boolean $check_sites
    * @param boolean $check_access
    *
    * @return array
    */
    public static function GetIblocksList($check_sites, $check_access)
    {
        $IBS = array('-1' => GetMessage('SF_PROPERTY_IBLOCK_NOT_SELECTED'));
        
        $IBTS = array();
        $res = \Bitrix\Iblock\TypeTable::getList();
        while ($arr = $res->fetch()) {
            $res_ = \Bitrix\Iblock\TypeLanguageTable::getList(array('filter' => array('=IBLOCK_TYPE_ID' => $arr['ID'], '=LANGUAGE_ID' => LANGUAGE_ID)));
            if ($arr_ = $res_->fetch()) {
                $IBTS[$arr['ID']] = $arr_['NAME'];
            }
        }
        
        $arFilter = array('ACTIVE' => 'Y');
        if ($check_sites) {
            $arFilter['SITE_ID'] = SITE_ID;
        }
        if ($check_access) {
            $arFilter['CHECK_PERMISSIONS'] = 'Y';
        }
        $res = \CIBlock::GetList(array('SORT' => 'asc'), $arFilter, false);
        while ($arr = $res->fetch()) {
            $IBS[$arr['ID']] = $IBTS[$arr['IBLOCK_TYPE_ID']].' :: ['.$arr['ID'].'] '.$arr['NAME'];
        }
        
        return $IBS;
    }
    
    /**
    * @param string $block_id
    * @param boolean $check_access
    *
    * @return array
    */
    public static function GetIblocksSectionList($block_id, $check_access)
    {
        $IBS = array(
            'all' => GetMessage('SF_PROPERTY_IBLOCK_SECTION_ALL'),
            'top' => GetMessage('SF_PROPERTY_IBLOCK_SECTION_TOP')
        );
        
        if ($block_id > 0) {
            $arFilter = array('GLOBAL_ACTIVE' => 'Y', 'IBLOCK_ID' => $block_id);
            if ($check_access) {
                $arFilter['CHECK_PERMISSIONS'] = 'Y';
            }
            $res = \CIBlockSection::GetList(array('LEFT_MARGIN' => 'asc'), $arFilter);
            while ($arr = $res->fetch()) {
                $IBS[$arr['ID']] = str_repeat('. ', $arr['DEPTH_LEVEL']).'['.$arr['ID'].'] '.$arr['NAME'];
            }
        }
        
        return $IBS;
    }
    
    /**
    * @param boolean $check_sites
    * @param boolean $check_access
    *
    * @return array
    */
    public static function GetStoragesList($check_sites, $check_access)
    {
        $STS = array('-1' => GetMessage('SF_PROPERTY_STORAGE_NOT_SELECTED'));
        
        $res = \SIMAI\Storage\Storage::getList(array('order' => array('SORT', 'STORAGE_ID')), $check_sites, $check_access);
        while ($arr = $res->fetch()) {
            $title = array();
            $prop_values = \SIMAI\Storage\Property::GetPropValues($arr['STORAGE_ID'], false, array('TITLE'), LANGUAGE_ID);
            if (is_array($prop_values['TITLE'])) {
                foreach ($prop_values['TITLE'] as $val) {
                    if ($val) {
                        $title[] = TruncateText($val, 50);
                    }
                }
            }
            $title = implode(' / ', $title);
            
            $STS[$arr['STORAGE_ID']] = '['.$arr['STORAGE_ID'].'] '.$title;
        }
        
        return $STS;
    }
    
    /**
    * @param string $block_id
    * @param boolean $check_access
    *
    * @return array
    */
    public static function GetStorageSectionList($block_id, $check_access)
    {
        $STS = array(
            'all' => GetMessage('SF_PROPERTY_IBLOCK_SECTION_ALL'),
            'top' => GetMessage('SF_PROPERTY_IBLOCK_SECTION_TOP')
        );
        
        if ($block_id != '') {
            $res = self::GetListDbResult('\SIMAI\Storage\Element', $block_id, array('filter' => array('=TYPE' => 'S', '=ACTIVE' => 'Y'), 'order' => array('LEFT_MARGIN' => 'asc'), 'limit' => 100), false, true);
            while ($arr = $res->fetch()) {
                $modified_cols = self::GetModifiedCols('\SIMAI\Storage\Element', $block_id, $arr['ELEMENT_ID']);
                $STS[$arr['ELEMENT_ID']] = $modified_cols['STITLE'];
            }
        }
        
        return $STS;
    }
    
    /**
    * @param boolean $only_active
    *
    * @return array
    */
    public static function GetUserGroups($only_active = false)
    {
        $groups = array('' => GetMessage('SF_PROPERTY_GROUP_NOT_SELECTED'));
        $arFilter = array();
        if ($only_active) {
            $arFilter['ACTIVE'] = 'Y';
        }
        $res = \Bitrix\Main\GroupTable::getList(array('select' => array('ID', 'NAME'), 'order' => array('C_SORT', 'ID'), 'filter' => $arFilter));
        while ($arr = $res->fetch()) {
            $groups[$arr['ID']] = $arr['NAME'].' ['.$arr['ID'].']';
        }
        
        return $groups;
    }
    
    /**
    * @return string
    */
    public static function ShowErrWrongEntity()
    {
        return GetMessage('SF_PROPERTY_WRONG_ENTITY');
    }
}
