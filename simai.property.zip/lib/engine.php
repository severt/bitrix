<?php

namespace SIMAI;

use Bitrix\Main;
use Bitrix\Main\Application;
use Bitrix\Main\IO\Directory;
use Bitrix\Main\IO\File;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Page\Asset;
use Bitrix\Main\Config\Option;

use SIMAI\PropertyEntitiesType;

Main\Localization\Loc::loadLanguageFile(__FILE__);

define('SF_PROPERTY_DOCUMENT_ROOT', Application::getDocumentRoot());

// property folder
define('SF_PROPERTY_ABS_PATH_SITE', SF_PROPERTY_DOCUMENT_ROOT.SITE_DIR.'simai.data/property');
define('SF_PROPERTY_ABS_PATH_COMMON', SF_PROPERTY_DOCUMENT_ROOT.'/simai/property');

/**
* Class description
* @package    SIMAI
* @subpackage Property
*/
class Property
{
    /**
    * @param array $array_to_safe
    *
    * @return array
    */
    public static function SP_ArrayToSafe($array_to_safe = array())
    {
        $array_set_safe = array();
        if (is_array($array_to_safe)) {
            foreach ($array_to_safe as $key => $value) {
                $key = htmlspecialcharsbx($key);
                if (is_array($value)) {
                    $array_set_safe[$key] = self::SP_ArrayToSafe($value);
                } else {
                    $array_set_safe[$key] = htmlspecialcharsbx($value);
                }
            }
        }
        return $array_set_safe;
    }
    
    /**
    * @param string $type
    *
    * @return array
    */
    private static function checkTypeTemplate($type, $template, $mode)
    {
        $return = array(
            'type_file' => false,
            'template_file' => false,
            'template_lang_file' => false
        );
        
        if (!preg_match('/^[a-z0-9_]+$/', $type)) {
            echo '{'.GetMessage('SF_PROPERTY_WRONG_TYPE_NAME').'}';
            return $return;
        }
        if ($template == '') {
            $template = '.default';
        }
        if (!preg_match('/^[a-z0-9_\-\.]+$/', $template) && $template != '.default') {
            echo '{'.GetMessage('SF_PROPERTY_WRONG_TEMPLATE_NAME').'}';
            return $return;
        }
        if (!in_array($mode, array('view', 'edit', 'filter'))) {
            echo '{'.GetMessage('SF_PROPERTY_WRONG_MODE').'}';
            return $return;
        }
        
        $type_dir = SF_PROPERTY_ABS_PATH_SITE.'/'.$type;
        
        if (!Directory::isDirectoryExists($type_dir)) {
            $type_dir = SF_PROPERTY_ABS_PATH_COMMON.'/'.$type;
        }
        
        if (!Directory::isDirectoryExists($type_dir)) {
            echo '{'.GetMessage('SF_PROPERTY_TYPE_NOT_FOUND').'}';
            return $return;
        }
        
        $type_file = $type_dir.'/'.$mode.'.php';
        if (!File::isFileExists($type_file)) {
            $type_file = false;
        }
        
        $template_file = $type_dir.'/templates/'.$template.'/'.$mode.'.php';
        if (!File::isFileExists($template_file)) {
            $template = '.default';
            $template_file = $type_dir.'/templates/'.$template.'/'.$mode.'.php';
            if (!File::isFileExists($template_file)) {
                echo '{'.GetMessage('SF_PROPERTY_TEMPLATE_FILE_NOT_FOUND').'}';
                return $return;
            }
        }
        
        $template_lang_file = $type_dir.'/templates/'.$template.'/lang/'.LANGUAGE_ID.'/'.$mode.'.php';
        if (!File::isFileExists($template_lang_file)) {
            $template_lang_file = false;
        }
        
        $return = array(
            'type_file' => $type_file,
            'template_file' => $template_file,
            'template_lang_file' => $template_lang_file
        );
        
        return $return;
    }
    
    /**
    * @param mixed $values
    *
    * @return string / array
    */
    private static function safeValues($values)
    {
        $return = false;
        if (!is_array($values)) {
            if (!is_object($values)) {
                $return = htmlspecialcharsex($values);
            }
        } else {
            $return = self::SP_ArrayToSafe($values);
        }
        return $return;
    }
    
    /**
    * @param mixed $params
    *
    * @return array
    */
    private static function safeParams($params)
    {
        $return = array();
        if (!is_array($params)) {
            $return = array();
        } else {
            $return = self::SP_ArrayToSafe($params);
        }
        return $return;
    }
    
    /**
    * @param string $type
    * @param string $template
    * @param mixed $values
    * @param array $params
    */
    public static function view($type, $template, $values = array(), $params = array(), $safe = true)
    {
        $tfiles = self::checkTypeTemplate($type, $template, 'view');
        $type_file = $tfiles['type_file'];
        $template_file = $tfiles['template_file'];
        $template_lang_file = $tfiles['template_lang_file'];
        
        if ($safe) {
            $values = self::safeValues($values);
            $params = self::safeParams($params);
        }
        
        if ($type_file) {
            @include($type_file);
        }
        
        if ($template_file) {
            if (!isset($view_error)) {
                if ($template_lang_file) {
                    Main\Localization\Loc::loadLanguageFile($template_file);
                }
                
                @include($template_file);
            }
        }
    }
    
    /**
    * @param string $type
    * @param string $template
    * @param mixed $values
    * @param array $params
    */
    public static function edit($type, $template, $values = array(), $params = array(), $safe = true)
    {
        $tfiles = self::checkTypeTemplate($type, $template, 'edit');
        $type_file = $tfiles['type_file'];
        $template_file = $tfiles['template_file'];
        $template_lang_file = $tfiles['template_lang_file'];
        
        if ($safe) {
            $values = self::safeValues($values);
            $params = self::safeParams($params);
        }
        
        if ($type_file) {
            @include($type_file);
        }
        
        if ($template_file) {
            if (!isset($edit_error)) {
                if ($template_lang_file) {
                    Main\Localization\Loc::loadLanguageFile($template_file);
                }
                
                Asset::getInstance()->addJs('/simai/asset/simai.property/.default/js/script.js');
                
                @include($template_file);
            }
        }
    }
    
    /**
    * @param string $type
    * @param string $template
    * @param mixed $values
    * @param array $params
    */
    public static function filter($type, $template, $values = array(), $params = array(), $safe = true)
    {
        $tfiles = self::checkTypeTemplate($type, $template, 'filter');
        $type_file = $tfiles['type_file'];
        $template_file = $tfiles['template_file'];
        $template_lang_file = $tfiles['template_lang_file'];
        
        if ($safe) {
            $values = self::safeValues($values);
            $params = self::safeParams($params);
        }
        
        if ($type_file) {
            @include($type_file);
        }
        
        if ($template_file) {
            if (!isset($filter_error)) {
                if ($template_lang_file) {
                    Main\Localization\Loc::loadLanguageFile($template_file);
                }
                
                @include($template_file);
            }
        }
    }
    
    /**
    * @return array
    */
    public static function types_list()
    {
        $return = array();
        $sorter = array();
        
        $types_dir = SF_PROPERTY_ABS_PATH_SITE;
        
        if (!Directory::isDirectoryExists($types_dir)) {
            $types_dir = SF_PROPERTY_ABS_PATH_COMMON;
        }
        
        $dir = new Directory($types_dir);
        $children = $dir->getChildren();
        $i = 0;
        foreach ($children as $child) {
            if (!$child->isFile()) {
                $type = $child->getName();
                if (preg_match('/^[a-z0-9_]+$/', $type)) {
                    $desc_file = $types_dir.'/'.$type.'/.description.php';
                    $desc_lang_file = $types_dir.'/'.$type.'/lang/'.LANGUAGE_ID.'/.description.php';
                    if (File::isFileExists($desc_file)) {
                        if (File::isFileExists($desc_lang_file)) {
                            Main\Localization\Loc::loadLanguageFile($desc_file);
                        }
                        @include($desc_file);
                        $name = '';
                        $sort = 500;
                        if (isset($arDescription['NAME'])) {
                            $name = htmlspecialcharsex($arDescription['NAME']);
                            $sort = intval($arDescription['SORT']);
                            if ($sort <= 0) {
                                $sort = 500;
                            }
                        }
                        $return[$i] = array(
                            'id' => $type,
                            'name' => $name,
                            'sort' => $sort
                        );
                        $sorter[$i] = $sort;
                        $i++;
                    }
                }
            }
        }
        
        array_multisort($sorter, SORT_ASC, $return);
        
        return $return;
    }
}
