<?php

\Bitrix\Main\Loader::registerAutoLoadClasses('simai.property', array(
    '\SIMAI\PropertyEntitiesType' => 'lib/entities.php',
    '\SIMAI\Property' => 'lib/engine.php',
));
