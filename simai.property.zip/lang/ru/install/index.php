<?
$MESS['SF_PROPERTY_MODULE_NAME'] = 'SIMAI: Универсальные свойства';
$MESS['SF_PROPERTY_MODULE_DESCRIPTION'] = 'Модуль для вывода универсальных свойств.';
$MESS['SF_PROPERTY_INSTALL_TITLE'] = 'Установка модуля SIMAI: Универсальные свойства';
$MESS['SF_PROPERTY_UNINSTALL_TITLE'] = 'Деинсталляция модуля SIMAI: Универсальные свойства';
?>