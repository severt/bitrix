<?php
$MESS['SF_PROPERTY_WRONG_TYPE_NAME'] = 'Неверно указан тип свойства';
$MESS['SF_PROPERTY_WRONG_TEMPLATE_NAME'] = 'Неверно указан шаблон свойства';
$MESS['SF_PROPERTY_WRONG_MODE'] = 'Неверный вызов свойства';
$MESS['SF_PROPERTY_TYPE_NOT_FOUND'] = 'Не найден тип свойства';
$MESS['SF_PROPERTY_TEMPLATE_FILE_NOT_FOUND'] = 'Не найден файл шаблона свойства';
?>