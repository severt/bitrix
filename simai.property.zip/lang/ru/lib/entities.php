<?php
$MESS['SF_PROPERTY_WRONG_ENTITY'] = 'Неверно выбрана сущность для привязки.';

$MESS['SF_PROPERTY_ID'] = 'ID';
$MESS['SF_PROPERTY_ACTIVE'] = 'Активность';
$MESS['SF_PROPERTY_ANY'] = 'Все';
$MESS['SF_PROPERTY_YES'] = 'Да';
$MESS['SF_PROPERTY_NO'] = 'Нет';
$MESS['SF_PROPERTY_SORT'] = 'Сортировка';
$MESS['SF_PROPERTY_NAME'] = 'Наименование';
$MESS['SF_PROPERTY_CODE'] = 'Символьный код';
$MESS['SF_PROPERTY_TITLE'] = 'Заголовок';
$MESS['SF_PROPERTY_TITLE_LEFT_MARGIN'] = 'Заголовок (вложенность)';
$MESS['SF_PROPERTY_LEFT_MARGIN'] = 'Наименование (вложенность)';

$MESS['SF_PROPERTY_STORAGE_ID'] = 'Код хранилища';
$MESS['SF_PROPERTY_IBLOCK_ID'] = 'Инфоблок';
$MESS['SF_PROPERTY_IBLOCK_NOT_SELECTED'] = 'Инфоблок не выбран';
$MESS['SF_PROPERTY_STORAGE_NOT_SELECTED'] = 'Хранилище не выбрано';
$MESS['SF_PROPERTY_GROUP_NOT_SELECTED'] = 'Группа не выбрана';

$MESS['SF_PROPERTY_USER_GROUP'] = 'Группы';
$MESS['SF_PROPERTY_LOGIN'] = 'Логин';
$MESS['SF_PROPERTY_EMAIL'] = 'E-mail';
$MESS['SF_PROPERTY_FIRST_NAME'] = 'Имя';
$MESS['SF_PROPERTY_LAST_NAME'] = 'Фамилия';

$MESS['SF_PROPERTY_SIMAI_STORAGE_ELEMENTS'] = 'Элементы хранилища';
$MESS['SF_PROPERTY_SIMAI_STORAGES'] = 'Хранилища';
$MESS['SF_PROPERTY_IBLOCK_ELEMENTS'] = 'Элементы инфоблока';
$MESS['SF_PROPERTY_IBLOCK_SECTIONS'] = 'Разделы инфоблока';
$MESS['SF_PROPERTY_USERS'] = 'Пользователи';

$MESS['SF_PROPERTY_SIMAI_STORAGE_TYPE'] = 'Тип элементов';
$MESS['SF_PROPERTY_SIMAI_STORAGE_SECTIONS'] = 'Разделы';
$MESS['SF_PROPERTY_SIMAI_STORAGE_ITEMS'] = 'Записи';

$MESS['SF_PROPERTY_IBLOCK_SECTION_ID'] = 'Раздел-родитель';
$MESS['SF_PROPERTY_IBLOCK_SECTION_ALL'] = '(любой)';
$MESS['SF_PROPERTY_IBLOCK_SECTION_TOP'] = 'Верхний уровень';
$MESS['SF_PROPERTY_PARENT_ID'] = 'Раздел-родитель';
?>