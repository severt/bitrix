<?
$MESS['SF_PROPERTY_MENU_SEPARATOR'] = 'SIMAI: Универсальные свойства';
$MESS['SF_PROPERTY_MENU_SETTINGS_TITLE'] = 'Визуализация свойств';
$MESS['SF_PROPERTY_TEST_FORM'] = 'Тестовая форма';
$MESS['SF_STORAGE_TEST_FORM_TITLE'] = 'Форма для демонстрации свойств';
?>