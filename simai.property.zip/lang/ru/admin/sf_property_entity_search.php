<?
$MESS['SF_PROPERTY_ELSEARCH_TITLE'] = 'Поиск элементов сущности';
$MESS['SF_PROPERTY_SELECT'] = 'Выбрать';
$MESS['SF_PROPERTY_WRONG_ENTITY'] = 'Неверно выбрана сущность для привязки.';
$MESS['SF_PROPERTY_INCLUDE_SUBSECTIONS_Y'] = 'включать подразделы';
?>