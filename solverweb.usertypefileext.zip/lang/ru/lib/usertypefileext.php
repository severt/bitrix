<?php
$MESS['SOLVERWEB_USERTYPEFILEEXT_PROP_DESCRIPTION'] = 'Файл (с поддержкой drag & drop)';
$MESS['SOLVERWEB_USERTYPEFILEEXT_PROP_SETTINGS_WITH_DESCRIPTION'] = 'Выводить поле для описания значения';