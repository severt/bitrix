<?php
$MESS['SOLVERWEB_USERTYPEFILEEXT_MODULE_NAME'] = 'Пользовательское свойство файл (с поддержкой drag & drop)';
$MESS['SOLVERWEB_USERTYPEFILEEXT_MODULE_DESCRIPTION'] = 'Портированное современное свойство инфоблоков тип «Файл»';
$MESS['SOLVERWEB_USERTYPEFILEEXT_INSTALL_TITLE'] = 'Установка модуля «Пользовательское свойство файл (с поддержкой drag & drop)»';
$MESS['SOLVERWEB_USERTYPEFILEEXT_UNINSTALL_TITLE'] = 'Деинсталляция модуля «Пользовательское свойство файл (с поддержкой drag & drop)»';
$MESS['SOLVERWEB_USERTYPEFILEEXT_PARTNER_NAME'] = 'SolverWeb';
$MESS['SOLVERWEB_USERTYPEFILEEXT_PARTNER_URI'] = 'https://solverweb.ru';