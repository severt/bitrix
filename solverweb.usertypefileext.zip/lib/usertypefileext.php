<?php
namespace SolverWeb\UserTypeFileExt;

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\UI\FileInputUtility;
use Bitrix\Main\UserField\Types\FileType;

Loc::loadMessages(__FILE__);

class UserTypeFileExt extends FileType
{
	protected static function getFieldValue($arUserField, $arAdditionalParameters = array())
	{
		if (!$arAdditionalParameters["bVarsFromForm"]) {
			if ($arUserField["ENTITY_VALUE_ID"] <= 0) {
				switch ($arUserField['USER_TYPE_ID']) {
					case \CUserTypeDate::USER_TYPE_ID:
					case \CUserTypeDateTime::USER_TYPE_ID:
						$full = $arUserField['USER_TYPE_ID'] === \CUserTypeDateTime::USER_TYPE_ID;
						if ($arUserField["SETTINGS"]["DEFAULT_VALUE"]["TYPE"] == "NOW") {
							$value = $full
								? \ConvertTimeStamp(time() + \CTimeZone::getOffset(), "FULL")
								: \ConvertTimeStamp(time(), 'SHORT');
						} else {
							$value = $full
								? str_replace(" 00:00:00", "", \CDatabase::formatDate($arUserField["SETTINGS"]["DEFAULT_VALUE"]["VALUE"], "YYYY-MM-DD HH:MI:SS", \CLang::getDateFormat("FULL")))
								: \CDatabase::formatDate($arUserField["SETTINGS"]["DEFAULT_VALUE"]["VALUE"], $full ? '' : "YYYY-MM-DD", \CLang::getDateFormat('SHORT'));
						}

						break;
					case \CUserTypeEnum::USER_TYPE_ID:
						$value = $arUserField['MULTIPLE'] === 'Y' ? array() : null;
						foreach ($arUserField['ENUM'] as $enum) {
							if ($enum['DEF'] === 'Y') {
								if ($arUserField['MULTIPLE'] === 'Y') {
									$value[] = $enum['ID'];
								} else {
									$value = $enum['ID'];
									break;
								}
							}
						}

						break;
					default:
						$value = $arUserField["SETTINGS"]["DEFAULT_VALUE"];

						break;
				}
			} else {
				$value = $arUserField["VALUE"];
			}
		} else {
			$value = $_REQUEST[$arUserField["FIELD_NAME"]];
		}

		return static::normalizeFieldValue($value);
	}

	protected static function normalizeFieldValue($value)
	{
		if (!is_array($value)) {
			$value = array($value);
		}
		if (empty($value)) {
			$value = array(null);
		}

		return $value;
	}

	/**
	 * @return array
	 */
	public static function getUserTypeDescription(): array
	{
		return array(
			'USER_TYPE_ID' => 'file_ext_solverweb',
			'CLASS_NAME' => __CLASS__,
			'DESCRIPTION' => Loc::getMessage('SOLVERWEB_USERTYPEFILEEXT_PROP_DESCRIPTION'),
			'BASE_TYPE' => 'file'
		);
	}

	/**
	 * @param array $userField
	 * @return array
	 */
	public static function PrepareSettings($userField): array
	{
		$settings = parent::PrepareSettings($userField);
		$settings['WITH_DESCRIPTION'] = isset($userField['SETTINGS']['WITH_DESCRIPTION'])
		&& in_array($userField['SETTINGS']['WITH_DESCRIPTION'], array('N', 'Y'))
			? $userField['SETTINGS']['WITH_DESCRIPTION']
			: 'N';

		return $settings;
	}

	/**
	 * @param array $userField
	 * @param array $additionalParameters
	 * @return string
	 */
	public static function getEditFormHtml(array $userField, ?array $additionalParameters): string
	{
		return static::getEditFormHTMLBase($userField, $additionalParameters);
	}

	/**
	 * @param $userField
	 * @param $additionalParameters
	 * @return string
	 */
	public static function getEditFormHtmlMulty(array $userField, ?array $additionalParameters): string
	{
		return static::getEditFormHTMLBase($userField, $additionalParameters);
	}

	/**
	 * @param array $userField
	 * @param array $additionalParameters
	 * @return string
	 */
	protected static function getEditFormHTMLBase($userField, $additionalParameters)
	{
		// global $APPLICATION;
		// ob_start();

		// $userField['USE_COMPONENT'] = 'Y';
		// $additionalParameters['mode'] = 'main.drag_n_drop';
		// $APPLICATION->IncludeComponent(
			// 'bitrix:main.field.file',
			// '',
			// [
				// 'userField' => $userField,
				// 'additionalParameters' => $additionalParameters,
			// ]
		// );

		// $result = ob_get_clean();

		// return $result;

		ob_start();
		if (!function_exists('_ShowFilePropertyField')) {
			require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/iblock/admin_tools.php';
		}

		foreach($userField['SETTINGS']['EXTENSIONS'] as $ext => $tmp_val)
		{
			$userField['SETTINGS']['EXTENSIONS'][$ext] = $ext;
		}

		\_ShowFilePropertyField(
			(
				$additionalParameters['NAME'] = str_replace('[]', '', $additionalParameters['NAME'])
			),
			array(
				'MULTIPLE' => $userField['MULTIPLE'],
				'WITH_DESCRIPTION' => $userField['SETTINGS']['WITH_DESCRIPTION'],
				'FILE_TYPE' => (is_array($userField["SETTINGS"]["EXTENSIONS"]) ? implode(",", $userField["SETTINGS"]["EXTENSIONS"]) : $userField["SETTINGS"]["EXTENSIONS"]),
			),
			(!is_array($additionalParameters['VALUE']) && !empty($additionalParameters['VALUE'])
				? array($additionalParameters['VALUE'])
				: $additionalParameters['VALUE'])
		);

		$result = ob_get_clean();

		return $result;
	}

	public static function onBeforeSave(array $userField, $value)
	{
		$valueCheck = self::getFieldValue($userField, ['bVarsFromForm' => true]);

		if (reset($valueCheck)) {
			$r = static::OnBeforeSaveAll($userField, $value);
		} else {
			$filesData = reset($value);

			$filesData['MODULE_ID'] = 'solverweb.usertypefileext';

			$r = parent::OnBeforeSave($userField, $filesData);
		}

		return $r;
	}

	/**
	 * @param array $userField
	 * @param string|array $value
	 * @return array
	 */
	public static function checkFields(array $userField, $value): array
	{
		$msg = [];
		$valueCheck = self::getFieldValue($userField, ['bVarsFromForm' => true]);

		if ($userField['MULTIPLE'] != 'Y') {
			$msg = self::checkEachField($userField, $valueCheck);
		} else {
			foreach ($valueCheck as $value) {
				$msg = array_merge($msg, self::checkEachField($userField, $value));
			}
		}

		return $msg;
	}

	public static function checkEachField(array $userField, $value): array
	{
		if(!is_array($value) && $value)
		{
			$fileInfo = \CFile::GetFileArray($value);
			if($fileInfo)
			{
				$value = \CFile::MakeFileArray($fileInfo['SRC']);
			}
		}

		$fieldName = \Bitrix\Main\Text\HtmlFilter::encode(
			empty($userField['EDIT_FORM_LABEL'])
				? $userField['FIELD_NAME']
				: $userField['EDIT_FORM_LABEL']
		);

		// if(
			// is_array($value)
			// && (!isset($value['tmp_name']) && !isset($value['old_id']) && !isset($value['type']))
		// )
		// {
			// return [
				// [
					// 'id' => $userField['FIELD_NAME'],
					// 'text' => Loc::getMessage('USER_TYPE_FILE_VALUE_IS_MULTIPLE', [
						// '#FIELD_NAME#' => $fieldName,
					// ]),
				// ],
			// ];
		// }

		$msg = [];

		if(is_array($value))
		{
			if(
				$userField['SETTINGS']['MAX_ALLOWED_SIZE'] > 0
				&&
				$value['size'] > $userField['SETTINGS']['MAX_ALLOWED_SIZE']
			)
			{
				$msg[] = [
					'id' => $userField['FIELD_NAME'],
					'text' => Loc::getMessage('USER_TYPE_FILE_MAX_SIZE_ERROR',
						[
							'#FIELD_NAME#' => $fieldName,
							'#MAX_ALLOWED_SIZE#' => $userField['SETTINGS']['MAX_ALLOWED_SIZE']
						]
					),
				];
			}

			//Extention check
			if(
				is_array($userField['SETTINGS']['EXTENSIONS'])
				&&
				count($userField['SETTINGS']['EXTENSIONS'])
			)
			{
				foreach($userField['SETTINGS']['EXTENSIONS'] as $ext => $tmp_val)
				{
					$userField['SETTINGS']['EXTENSIONS'][$ext] = $ext;
				}
				$error = \CFile::CheckFile(
					$value,
					0,
					false,
					implode(',', $userField['SETTINGS']['EXTENSIONS'])
				);
			}
			else
			{
				$error = '';
			}

			if($error)
			{
				$msg[] = [
					'id' => $userField['FIELD_NAME'],
					'text' => $error,
				];
			}

			//For user without edit php permissions we allow only pictures upload
			global $USER;
			if(!is_object($USER) || !$USER->IsAdmin())
			{
				if(HasScriptExtension($value['name']))
				{
					$msg[] = [
						'id' => $userField['FIELD_NAME'],
						'text' => Loc::getMessage('FILE_BAD_TYPE') . ' (' . $value['name'] . ').'
					];
				}
			}
		}

		return $msg;
	}

	/**
	 * @param $tmpFileName
	 * @return string
	 */
	static function getTmpFilePath($tmpFileName): string
	{
		$io = \CBXVirtualIo::GetInstance();
		$docRoot = \Bitrix\Main\Application::getDocumentRoot();

		if (strpos($tmpFileName, \CTempFile::GetAbsoluteRoot()) === 0) {
			$tempFilePath = $tmpFileName;
		} elseif (strpos($io->CombinePath($docRoot, $tmpFileName), \CTempFile::GetAbsoluteRoot()) === 0) {
			$tempFilePath = $io->CombinePath($docRoot, $tmpFileName);
		} else {
			$tempFilePath = $io->CombinePath(\CTempFile::GetAbsoluteRoot(), $tmpFileName);
		}

		return $tempFilePath;
	}

	public static function OnBeforeSaveAll($arUserField, $value)
	{
		$delFilesData = isset($_POST[$arUserField['FIELD_NAME'] . '_del']) && is_array($_POST[$arUserField['FIELD_NAME'] . '_del'])
			? $_POST[$arUserField['FIELD_NAME'] . '_del']
			: array();
		$descriptionFilesData = isset($_POST[$arUserField['FIELD_NAME'] . '_descr']) && is_array($_POST[$arUserField['FIELD_NAME'] . '_descr'])
			? $_POST[$arUserField['FIELD_NAME'] . '_descr']
			: array();
		$filesData = self::getFieldValue($arUserField, ['bVarsFromForm' => true]);
		$files = array();

		foreach ($filesData as $key => $fileData) {
			$delFile = false;

			if (is_array($fileData)) {
				$tempFile = static::getTmpFilePath($fileData['tmp_name']);
				if (!isset($fileData['error']) || !$fileData['error']) {
					$files[] = \CFile::SaveFile(
						array_merge(
							$fileData,
							array(
								'tmp_name' => $tempFile,
								'MODULE_ID' => 'solverweb.usertypefileext',
							)
						),
						'uf'
					);
				}

				@unlink($tempFile);

				@rmdir(dirname($tempFile));
			} elseif (intval($fileData) > 0) {

				if (isset($delFilesData[$key])) {
					\CFile::Delete($fileData);

					$delFile = true;
				} else {
					$files[] = $fileData;
				}
			}

			if (
				!$delFile
				&& !is_array($fileData)
				&& intval($fileData) > 0
				&& isset($descriptionFilesData[$key])
				&& strlen(trim($descriptionFilesData[$key]))
			) {
				\CFile::UpdateDesc($fileData, trim($descriptionFilesData[$key]));
			}
		}

		$files = array_values(
			array_filter(
				array_map('trim', $files)
			)
		);

		if ($arUserField['MULTIPLE'] != 'Y') {
			$files = reset($files);
		}

		return $files;
	}

	/**
	 * @param bool|false $userField
	 * @param $additionalParameters
	 * @param $varsFromForm
	 * @return string
	 */
	public static function GetSettingsHTML($userField, $additionalParameters, $varsFromForm): string
	{
		$result = '';

		if ($varsFromForm) {
			$value = htmlspecialcharsbx($GLOBALS[$additionalParameters['NAME']]['EXTENSIONS']);
			$result .= '
			<tr>
				<td>' . Loc::getMessage('USER_TYPE_FILE_EXTENSIONS') . ':</td>
				<td>
					<input type="text" size="20" name="' . $additionalParameters['NAME'] . '[EXTENSIONS]" value="' . $value . '">
				</td>
			</tr>
			';
		} else {
			if (is_array($userField)) {
				$arExt = $userField['SETTINGS']['EXTENSIONS'];
			} else {
				$arExt = '';
			}

			$value = array();

			if (is_array($arExt)) {
				foreach ($arExt as $ext => $flag) {
					$value[] = htmlspecialcharsbx($ext);
				}
			}

			$result .= '
			<tr>
				<td>' . Loc::getMessage('USER_TYPE_FILE_EXTENSIONS') . ':</td>
				<td>
					<input type="text" size="20" name="' . $additionalParameters['NAME'] . '[EXTENSIONS]" value="' . implode(', ', $value) . '">
				</td>
			</tr>
			';
		}


		if ($varsFromForm) {
			$withDescription = ($GLOBALS[$additionalParameters['NAME']]['WITH_DESCRIPTION'] == 'Y');
		} elseif (is_array($userField)) {
			$withDescription = ($userField['SETTINGS']['WITH_DESCRIPTION'] == 'Y');
		} else {
			$withDescription = false;
		}

		$result .= '
		<tr>
			<td><label>' . Loc::getMessage('SOLVERWEB_USERTYPEFILEEXT_PROP_SETTINGS_WITH_DESCRIPTION') . '</label></td>
			<td>
				<input type="hidden" name="' . $additionalParameters['NAME'] . '[WITH_DESCRIPTION]" value="N">
				<input type="checkbox" name="' . $additionalParameters['NAME'] . '[WITH_DESCRIPTION]" value="Y"' . ($withDescription ? ' checked' : '') . '>
			</td>
		</tr>
		';

		return $result;
	}

	/**
	 * @param array $userField
	 * @param array $additionalParameters
	 * @return string
	 */
	public static function GetAdminListEditHTMLMulty($userField, $additionalParameters)
	{
		return '';
	}

	/**
	 * @param array $userField
	 * @param array $additionalParameters
	 * @return string
	 */
	public static function GetAdminListEditHTML($userField, $additionalParameters)
	{
		return '';
	}

	/**
	 * @param array $userField
	 * @param array $additionalParameters
	 * @return string
	 */
	public static function GetAdminListViewHTML($userField, $additionalParameters)
	{
		return '';
	}

	/**
	 * @param array $userField
	 * @return string
	 */
	public static function OnSearchIndex($userField): ?string
	{
		return '';
	}
}