<?php
$arModuleVersion = array(
	"VERSION" => "1.0.2",
	"VERSION_DATE" => "2024-01-11 10:40:00"
);