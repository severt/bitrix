CREATE TABLE IF NOT EXISTS `b_srbaa_favorites`
(
    `ID` INT(11) AUTO_INCREMENT  NOT NULL COMMENT 'ID',
    `USER_ID` INT(11) NOT NULL COMMENT 'Пользователь',
    `SESSID` VARCHAR (255) NOT NULL COMMENT 'Сессия пользователя',
    `TITLE` TEXT NOT NULL COMMENT 'Заголовок ссылки',
    `LINK` TEXT NOT NULL COMMENT 'Ссылка',
    `CREATED_AT` TIMESTAMP NOT NULL COMMENT 'Дата создания',
    PRIMARY KEY (`ID`)
    ) COMMENT ='Таблица избранного пользователя';