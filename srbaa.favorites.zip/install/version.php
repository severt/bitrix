<?

$arModuleVersion = [
    'VERSION'      => '1.0.1',
    'VERSION_DATE' => '2023-04-04 19:34:00',
];
