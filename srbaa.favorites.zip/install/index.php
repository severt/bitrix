<?

IncludeModuleLangFile(__FILE__);

class srbaa_favorites extends CModule
{
    public $MODULE_ID = 'srbaa.favorites';
    public $MODULE_VERSION;
    public $MODULE_VERSION_DATE;
    public $MODULE_NAME;
    public $MODULE_DESCRIPTION;
    public $PARTNER_NAME;
    public $PARTNER_URI;
    private $exclusionAdminFiles = [];

    function __construct()
    {
        $arModuleVersion = [];

        $path = str_replace("\\", '/', __FILE__);
        $path = substr($path, 0, strlen($path) - strlen('/index.php'));
        include($path . '/version.php');

        $this->MODULE_VERSION = $arModuleVersion['VERSION'];
        $this->MODULE_VERSION_DATE = $arModuleVersion['VERSION_DATE'];
        $this->MODULE_NAME = GetMessage('FAV_INSTALL_NAME');
        $this->MODULE_DESCRIPTION = GetMessage('FAV_INSTALL_DESCRIPTION');
        $this->PARTNER_NAME = GetMessage('FAV_PARTNER_NAME');
        $this->PARTNER_URI = 'https://vk.com/serbinyo';

        $this->SHOW_SUPER_ADMIN_GROUP_RIGHTS = 'Y';
        $this->MODULE_GROUP_RIGHTS = 'Y';
    }

    function InstallDB($arParams = [])
    {
        global $DOCUMENT_ROOT, $DB, $DBType, $APPLICATION;

        $errors = null;

        //install tables
        $errors = $DB->RunSQLBatch(
            __DIR__ . '/db/mysql/install.sql'
        );


        if (!empty($errors)) {
            $APPLICATION->ThrowException(implode('', $errors));

            return false;
        }

        \Bitrix\Main\ModuleManager::registerModule('srbaa.favorites');

        return true;
    }

    function UnInstallDB($arParams = [])
    {
        global $APPLICATION, $DB, $DBType, $DOCUMENT_ROOT;

        if (array_key_exists('savedata', $arParams) && $arParams['savedata'] !== 'Y') {
            $errors = null;

            //uninstall tables
            $errors = $DB->RunSQLBatch(
                __DIR__ . '/db/mysql/uninstall.sql'
            );

            if (!empty($errors)) {
                $APPLICATION->ThrowException(implode('', $errors));

                return false;
            }
        }

        \Bitrix\Main\ModuleManager::unRegisterModule('srbaa.favorites');

        return true;
    }

    function InstallEvents()
    {
        return true;
    }

    function UnInstallEvents()
    {
        return true;
    }

    function InstallFiles($arParams = [])
    {
        CopyDirFiles(
            __DIR__ . '/components',
            $_SERVER['DOCUMENT_ROOT'] . '/local/components',
            true,
            true
        );

        return true;
    }

    function UnInstallFiles()
    {
        DeleteDirFilesEx(
            '/local/components/srbaa/'
        );

        return true;
    }

    function DoInstall()
    {
        global $DOCUMENT_ROOT, $APPLICATION, $step;
        $step = (int)$step;

        if ($step < 2) {
            $APPLICATION->IncludeAdminFile(
                GetMessage('FAV_INSTALL_TITLE'),
                __DIR__ . '/step1.php'
            );
        } else {
            $this->InstallFiles();
            $this->InstallDB();
            $APPLICATION->IncludeAdminFile(
                GetMessage('FAV_INSTALL_TITLE'),
                __DIR__ . '/step2.php'
            );
        }
    }

    function DoUninstall()
    {
        global $DOCUMENT_ROOT, $APPLICATION, $step, $errors;
        $step = (int)$step;

        if ($step < 2) {
            $APPLICATION->IncludeAdminFile(
                GetMessage('FAV_UNINSTALL_TITLE'),
                __DIR__ . '/unstep1.php'
            );
        } elseif ($step == 2) {
            $errors = false;

            $this->UnInstallDB(
                [
                    'savedata' => $_REQUEST['savedata'],
                ]
            );

            $this->UnInstallFiles();

            $APPLICATION->IncludeAdminFile(
                GetMessage('FAV_UNINSTALL_TITLE'),
                __DIR__ . '/unstep2.php'
            );
        }
    }
}
