<?php

declare(strict_types=1);

/**
 * @var string $templateFolder
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}
global $APPLICATION;

if (count($arResult['ITEMS']) <= 0) :?>
    <p style="color: red"><?= GetMessage('FAV_EMPTY_LIST') ?></p>
<?php
else:?>
    <form method="POST">
        <table class="table table-bordered">
            <thead>
            <tr>
                <th scope="col"><?= GetMessage('FAV_LIST_LINK_COL') ?></th>
                <th scope="col"><?= GetMessage('FAV_LIST_LINK_SOURCE') ?></th>
                <th scope="col"><?= GetMessage('FAV_LIST_LINK_DEL') ?></th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach ($arResult['ITEMS'] as $item) :?>
                <tr>
                    <td><a href="<?= $item['LINK'] ?>"
                           class="sale-order-list-accomplished-date"
                           title="Перейти к <?= $item['TITLE'] ?>"><?= $item['TITLE'] ?></td>
                    <td><?= $item['LINK'] ?></td>
                    <td>
                        <div class="custom-control custom-checkbox">
                            <input
                                type="checkbox"
                                class="custom-control-input"
                                id="<?= $item['ID'] ?>"
                                name="unfavor[]"
                                value="<?= $item['ID'] ?>"
                            >
                            <label class="custom-control-label" for="<?= $item['ID'] ?>"></label>
                        </div>
                    </td>
                </tr>
            <?php
            endforeach; ?>
            <?= bitrix_sessid_post('sessid') ?>
            </tbody>
        </table>
        <input type="submit" value="<?= GetMessage('FAV_LIST_DEL_BUTTON') ?>">
    </form>
    <?php
    $APPLICATION->IncludeComponent(
        'bitrix:main.pagenavigation',
        'modern',
        [
            'NAV_OBJECT' => $arResult['NAV'],
            'SEF_MODE'   => 'N'
        ],
        false
    );
    ?>
<?php
endif;
