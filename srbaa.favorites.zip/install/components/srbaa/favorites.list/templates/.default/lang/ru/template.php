<?
$MESS['FAV_EMPTY_LIST'] = 'Список избранного пуст';
$MESS['FAV_LIST_LINK_COL'] = 'Ссылка';
$MESS['FAV_LIST_LINK_SOURCE'] = 'Источник';
$MESS['FAV_LIST_LINK_DEL'] = 'На удаление';
$MESS['FAV_LIST_DEL_BUTTON'] = 'Удалить отмеченное';
?>