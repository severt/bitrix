<?
$MESS['FAV_EMPTY_LIST'] = 'Favorites list is empty';
$MESS['FAV_LIST_LINK_COL'] = 'Link';
$MESS['FAV_LIST_LINK_SOURCE'] = 'Source';
$MESS['FAV_LIST_LINK_DEL'] = 'For removal';
$MESS['FAV_LIST_DEL_BUTTON'] = 'Delete checked';
?>