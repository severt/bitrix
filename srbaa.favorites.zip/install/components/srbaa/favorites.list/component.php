<?php

declare(strict_types=1);

use Bitrix\Main\Application;
use Bitrix\Main\Loader;
use Srbaa\Repository\FavoriteRepository;

/**
 * @var array $arParams
 * @var array $arResult
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}
$request = Application::getInstance()->getContext()->getRequest();
/**
 * Favorites list component
 *
 * @author srbaa
 */
try {
    if (!Loader::includeModule('srbaa.favorites')) {
        throw new Exception('Error connecting module srbaa.favorites');
    }

    global $APPLICATION;
    global $USER;

    $arResult = [];

    $userId = (int)$USER->GetID();
    $sessid = bitrix_sessid();
    $favoriteRowRepository = new FavoriteRepository($userId, $sessid);
    $request = Application::getInstance()->getContext()->getRequest();

    $unfavorite = $request->getPost('unfavor');
    if (is_array($unfavorite) && count($unfavorite) > 0) {
        $sessid = $request->getPost('sessid');
        if ($sessid !== bitrix_sessid()) {
            throw new RuntimeException('Your session has expired');
        }

        $favoriteRowRepository->removeByIds($unfavorite);
    }

    $count = $favoriteRowRepository->countByUser();

    $countPage = $arParams['PAGE_SIZE'] ?? 10;
    $nav = new \Bitrix\Main\UI\PageNavigation('fav-page');

    $nav->allowAllRecords(true)
        ->setPageSize($countPage)
        ->initFromUri();

    $arResult['ITEMS'] = $favoriteRowRepository->getUserItems($nav->getLimit(), $nav->getOffset());

    $nav->setRecordCount($count);

    $arResult['NAV'] = $nav;
} catch
(Exception $exception) {
    ShowError($exception->getMessage());
    trigger_error($exception->getMessage());

    return;
}

$this->IncludeComponentTemplate();
