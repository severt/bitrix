<?

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

$arComponentParameters = [
    'GROUPS'     => [
        'PAGINATION' => [
            'NAME' => GetMessage('PAGINATION_TITLE'),
        ]
    ],
    'PARAMETERS' => [
        'PAGE_SIZE' => [
            'PARENT'  => 'PAGINATION',
            'NAME'    => GetMessage('PAGE_SIZE'),
            'DEFAULT' => 10,
        ],
    ],
];
