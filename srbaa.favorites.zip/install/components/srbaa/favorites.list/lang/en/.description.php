<?
$MESS['FAV_LIST_COMPONENT_NAME'] = 'List of favorites';
$MESS['FAV_LIST_COMPONENT_DESCRIPTION'] = 'List of favorites';
$MESS['FAV_MODULE_TITLE'] = 'Favorites';
?>