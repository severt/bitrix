<?
$MESS['PAGINATION_TITLE'] = 'Pagination';
$MESS['PAGE_SIZE'] = 'Page Size';
?>