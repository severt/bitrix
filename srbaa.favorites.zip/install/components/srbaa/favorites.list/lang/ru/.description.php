<?
$MESS['FAV_LIST_COMPONENT_NAME'] = 'Список избранного';
$MESS['FAV_LIST_COMPONENT_DESCRIPTION'] = 'Список избранного';
$MESS['FAV_MODULE_TITLE'] = 'Избранное';
?>