<?
$MESS['PAGINATION_TITLE'] = 'Постраничная навигация';
$MESS['PAGE_SIZE'] = 'Размер страницы';
?>