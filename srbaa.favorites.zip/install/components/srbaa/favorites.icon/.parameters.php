<?

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

$arComponentParameters = [
    'GROUPS'     => [
    ],
    'PARAMETERS' => [
        'NOT_AUTHORIZED_ALLOWED' => [
            'PARENT'  => 'ADDITIONAL_SETTINGS',
            'NAME'    => GetMessage('NOT_AUTHORIZED_ALLOWED'),
            'TYPE'    => 'CHECKBOX',
            'DEFAULT' => 'Y',
        ],
    ],
];

