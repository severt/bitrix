<?

use Bitrix\Main\Application;
use Bitrix\Main\Loader;

define('STOP_STATISTICS', true);
define('PUBLIC_AJAX_MODE', true);

require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_before.php');
header('Content-Type: application/x-javascript; charset=' . LANG_CHARSET);
CUtil::JSPostUnescape();
global $USER;

$result = [
    'result' => 'success',
    'error'  => ''
];

$request = Application::getInstance()->getContext()->getRequest();
$url = $request->getPost('url');
$title = $request->getPost('title');

try {
    if (!Loader::includeModule('srbaa.favorites')) {
        throw new \Exception('Favorite module connection error');
    } elseif (!check_bitrix_sessid('sessid')) {
        throw new \Exception('Your session has expired');
    } elseif ((string)$url === '') {
        throw new \Exception('Url not passed');
    } elseif ((string)$title === '') {
        throw new \Exception('Page title not passed');
    }

    $userId = (int)$USER->GetID();
    $sessid = bitrix_sessid();

    $title = preg_replace('/^\((.*?\))/is', '', trim($title));

    $result += \Srbaa\UseCase\Favorite::doAction($userId, $sessid, $title, $url);

} catch (Exception $e) {
    $result['result'] = 'error';
    $result['error'] = $e->getMessage();
}


echo CUtil::PhpToJSObject($result);

CMain::FinalActions();
die();
