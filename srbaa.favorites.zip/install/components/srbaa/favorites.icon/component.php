<?php

declare(strict_types=1);

use Bitrix\Main\Application;
use Bitrix\Main\Data\Cache;
use Bitrix\Main\Loader;
use Srbaa\Repository\FavoriteRepository;

/**
 * @var array $arParams
 * @var array $arResult
 */
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}
$request = Application::getInstance()->getContext()->getRequest();
/**
 * Component Favorites
 *
 * @author srbaa
 */
try {
    if (!Loader::includeModule('srbaa.favorites')) {
        throw new Exception('Error connecting module srbaa.favorites');
    }
    CJSCore::Init(['jquery']);

    global $APPLICATION;
    global $USER;

    $arResult['IN_FAVORITES'] = false;

    if ($arParams['NOT_AUTHORIZED_ALLOWED'] === 'N' && !$USER->IsAuthorized()) {
        return;
    }

    $userId = (int)$USER->GetID();
    $sessid = bitrix_sessid();
    $favoriteRowRepository = new FavoriteRepository($userId, $sessid);
    $arResult['IN_FAVORITES'] = $favoriteRowRepository->isExist($APPLICATION->GetCurPage());
} catch (Exception $exception) {
    ShowError($exception->getMessage());
    trigger_error($exception->getMessage());

    return;
}

$this->IncludeComponentTemplate();
