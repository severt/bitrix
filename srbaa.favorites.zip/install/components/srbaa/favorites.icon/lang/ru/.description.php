<?
$MESS['FAV_COMPONENT_DESCRIPTION'] = 'Добавление в избранное любой страницы сайта';
$MESS['FAV_COMPONENT_NAME'] = 'Добавление в избранное';
$MESS['FAV_MODULE_TITLE'] = 'Избранное';
?>
