<?
$MESS['NOT_AUTHORIZED_ALLOWED'] = 'Allow unauthorized users to add';
?>