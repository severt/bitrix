<?
$MESS['FAV_COMPONENT_DESCRIPTION'] = 'Adding any page of the site to favorites';
$MESS['FAV_COMPONENT_NAME'] = 'Adding to favorites';
$MESS['FAV_MODULE_TITLE'] = 'Favorites';
?>
