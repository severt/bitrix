<?php

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

$arComponentDescription = [
    'NAME'        => GetMessage('FAV_COMPONENT_NAME'),
    'DESCRIPTION' => GetMessage('FAV_COMPONENT_DESCRIPTION'),
    'PATH'        => [
        'NAME' => GetMessage('FAV_MODULE_TITLE'),
        'ID' => 'srbaa.favorites',
    ],
];
