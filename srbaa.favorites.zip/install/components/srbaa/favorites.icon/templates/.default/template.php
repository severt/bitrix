<?php

declare(strict_types=1);

/** @var array $arParams */
/** @var array $arResult */
/** @var string $templateFolder */
/** @var string $componentPath */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}
global $APPLICATION;
?>
<button type="button"
        class="srbaa_favorites <?= $arResult['IN_FAVORITES'] ? 'srbaa_favorites_added' : '' ?>">
    <svg class="srbaa_favorites__icon icon">
        <use xlink:href="<?= $templateFolder ?>/images/sprite.svg#favorites"></use>
    </svg>
</button>
<script>

    $(document).ready(function () {
        $('.srbaa_favorites').on('click', function (e) {
            addFavorite(this);
        });
    });

    function addFavorite(element) {
        BX.ajax.post(
            '<?=$componentPath?>/action.php',
            {
                url   : document.location.pathname,
                title : document.getElementsByTagName("title")[0].innerHTML,
                sessid: BX.bitrix_sessid()
            },
            function (data) {
                let result;
                try {
                    eval("result = " + data + ";");

                    if ('' === result.error) {
                        if ('add' === result.action) {
                            $(element).addClass('srbaa_favorites_added');
                        } else if ('remove' === result.action) {
                            $(element).removeClass('srbaa_favorites_added');
                        }
                    } else {
                        console.error(result.error);
                    }
                } catch (e) {
                    console.error(e)
                }
            }
        );
    }
</script>
