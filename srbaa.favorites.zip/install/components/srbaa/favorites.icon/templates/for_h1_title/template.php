<?php

declare(strict_types=1);

/** @var array $arParams */
/** @var array $arResult */
/** @var string $templateFolder */
/** @var string $componentPath */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}
global $APPLICATION;
?>

<script>
    let button = document.createElement('span');
    button.className = "srbaa_favorites<?= $arResult['IN_FAVORITES'] ? ' srbaa_favorites_added' : '' ?>";

    let svg = document.createElementNS("http://www.w3.org/2000/svg", 'svg');
    svg.setAttributeNS(null, "class", 'srbaa_favorites__icon');

    let img = document.createElementNS("http://www.w3.org/2000/svg", "use");
    img.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", "<?= $templateFolder ?>/images/sprite.svg#favorites");
    svg.appendChild(img);
    button.appendChild(svg);

    const hOneElement = document.getElementsByTagName('h1')[0];
    hOneElement.after(button);

    $(document).ready(function () {
        $('.srbaa_favorites').on('click', function (e) {
            addFavorite(this);
        });
    });

    function addFavorite(element) {
        BX.ajax.post(
            '<?=$componentPath?>/action.php',
            {
                url   : document.location.pathname,
                title : document.getElementsByTagName("title")[0].innerHTML,
                sessid: BX.bitrix_sessid()
            },
            function (data) {
                let result;
                try {
                    eval("result = " + data + ";");

                    if ('' === result.error) {
                        if ('add' === result.action) {
                            $(element).addClass('srbaa_favorites_added');
                        } else if ('remove' === result.action) {
                            $(element).removeClass('srbaa_favorites_added');
                        }
                    } else {
                        console.error(result.error);
                    }
                } catch (e) {
                    console.error(e)
                }
            }
        );
    }
</script>
