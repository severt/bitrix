<?

$classes = [
    '\\Srbaa\\UseCase\\Favorite' => 'classes/usecase/Favorite.php',
    '\\Srbaa\\Repository\\FavoriteRepository' => 'classes/repo/FavoriteRepository.php',
];

\Bitrix\Main\Loader::registerAutoLoadClasses('srbaa.favorites', $classes);
?>