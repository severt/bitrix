<?php

declare(strict_types=1);

namespace Srbaa\UseCase;

use Bitrix\Main\DB\SqlQueryException;
use RuntimeException;
use Srbaa\Repository\FavoriteRepository;

/**
 *
 */
class Favorite
{

    /**
     * @param int    $userId
     * @param string $sessid
     * @param string $url
     * @param string $title
     *
     * @return string[]
     */
    public static function doAction(int $userId, string $sessid, string $title, string $url): array
    {
        $favoriteRowRepository = new FavoriteRepository($userId, $sessid);
        $favIsset = $favoriteRowRepository->isExist($url);

        if ($favIsset === true) {
            $res = $favoriteRowRepository->remove($url);
            $action = 'remove';
        } else {
            $res = $favoriteRowRepository->add($url, $title);
            $action = 'add';
        }

        if ($res !== true) {
            throw new RuntimeException('Не удалось выполнить операцию добавления/удаления');
        }

        return [
            'action' => $action
        ];
    }
}
