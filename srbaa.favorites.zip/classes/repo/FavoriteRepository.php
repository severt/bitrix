<?php

declare(strict_types=1);

namespace Srbaa\Repository;

use Bitrix\Main\DB\SqlQueryException;

/**
 *
 */
class FavoriteRepository
{
    public const TABLE = 'b_srbaa_favorites';

    /**
     * @var \Bitrix\Main\Data\Connection|\Bitrix\Main\DB\Connection
     */
    private $connection;

    /**
     * @var \Bitrix\Main\DB\SqlHelper
     */
    private $sqlHelper;

    /**
     * @var int
     */
    private $userId;

    /**
     * @var string
     */
    private $sessid;

    /**
     * @param int    $userId
     * @param string $sessid
     */
    public function __construct(int $userId, string $sessid)
    {
        $this->connection = \Bitrix\Main\Application::getConnection();
        $this->sqlHelper = $this->connection->getSqlHelper();
        $this->userId = $userId;
        $this->sessid = $sessid;
    }

    /**
     * @return mixed
     * @throws SqlQueryException
     */
    public function countByUser()
    {
        if ($this->userId) {
            $sql = 'SELECT COUNT(ID) AS count FROM ' . self::TABLE . ' 
        WHERE USER_ID = \'' . $this->sqlHelper->forSql($this->userId) . '\'';
        } else {
            $sql = 'SELECT COUNT(ID) AS count FROM ' . self::TABLE . ' 
        WHERE SESSID = \'' . $this->sqlHelper->forSql($this->sessid) . '\'';
        }

        $res = $this->connection->query($sql);

        return $res->fetch()['count'];
    }

    /**
     * @throws SqlQueryException
     */
    public function isExist(string $url): bool
    {
        if ($this->userId > 0) {
            $sql = 'SELECT ID FROM ' . self::TABLE . ' 
        WHERE USER_ID = \'' . $this->sqlHelper->forSql($this->userId) . '\' 
        AND LINK = \'' . $this->sqlHelper->forSql($url) . '\'';
        } else {
            $sql = 'SELECT ID FROM ' . self::TABLE . ' 
        WHERE SESSID = \'' . $this->sqlHelper->forSql($this->sessid) . '\' 
        AND LINK = \'' . $this->sqlHelper->forSql($url) . '\'';
        }

        return (int)$this->connection->queryScalar($sql) > 0;
    }

    /**
     * @return bool
     * @throws SqlQueryException
     */
    public function remove(string $url)
    {
        if ($this->userId > 0) {
            $sql = 'DELETE FROM ' . self::TABLE . ' 
        WHERE USER_ID = \'' . $this->sqlHelper->forSql($this->userId) . '\' 
        AND LINK = \'' . $this->sqlHelper->forSql($url) . '\'';
        } else {
            $sql = 'DELETE FROM ' . self::TABLE . ' 
        WHERE SESSID = \'' . $this->sqlHelper->forSql($this->sessid) . '\' 
        AND LINK = \'' . $this->sqlHelper->forSql($url) . '\'';
        }

        $this->connection->queryExecute($sql);
        $affectedRows = $this->connection->getAffectedRowsCount();

        return $affectedRows > 0;
    }

    /**
     * @return bool
     * @throws SqlQueryException
     */
    public function removeByIds(array $ids)
    {
        $idsForSql = '';
        $lastKey = count($ids) - 1;
        foreach ($ids as $key => $id) {
            $idsForSql .= $this->sqlHelper->forSql($id);
            if ($key !== $lastKey) {
                $idsForSql .= ', ';
            }
        }

        $sql = 'DELETE FROM ' . self::TABLE . ' 
        WHERE ID IN (' . $idsForSql . ')';

        $this->connection->queryExecute($sql);
        $affectedRows = $this->connection->getAffectedRowsCount();

        return $affectedRows > 0;
    }

    /**
     * @throws SqlQueryException
     */
    public function add(string $url, string $title)
    {
        $sql = 'INSERT INTO ' . self::TABLE . " (USER_ID, SESSID, TITLE, LINK) 
        VALUES (
        '" . $this->sqlHelper->forSql($this->userId) . "',
        '" . $this->sqlHelper->forSql($this->sessid) . "',
        '" . $this->sqlHelper->forSql($title) . "',
        '" . $this->sqlHelper->forSql($url) . "'
        )";

        $this->connection->queryExecute($sql);
        $affectedRows = $this->connection->getAffectedRowsCount();

        return $affectedRows > 0;
    }

    /**
     * @throws SqlQueryException
     */
    public function getUserItems($limit = null, $offset = null): array
    {
        $result = [];

        if ($this->userId > 0) {
            $sql = 'SELECT * FROM ' . self::TABLE . ' 
        WHERE USER_ID = \'' . $this->sqlHelper->forSql($this->userId) . '\' 
        ';
        } else {
            $sql = 'SELECT * FROM ' . self::TABLE . ' 
        WHERE SESSID = \'' . $this->sqlHelper->forSql($this->sessid) . '\' 
        ';
        }

        $recordset = $this->connection->query($sql, null, $offset, $limit);

        $record = $recordset->fetch();
        while ($record) {
            $result[] = $record;
            $record = $recordset->fetch();
        }

        return $result;
    }
}