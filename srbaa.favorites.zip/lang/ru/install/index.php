<?
$MESS['FAV_INSTALL_NAME'] = 'Избранное на сайт. Универсальные компоненты';
$MESS['FAV_INSTALL_DESCRIPTION'] = 'Избранное. Модуль работы сервиса.';
$MESS['FAV_INSTALL_TITLE'] = 'Установка модуля \'Избранное\'';
$MESS['FAV_UNINSTALL_TITLE'] = 'Удаление модуля \'Избранное\'';
$MESS['FAV_PARTNER_NAME'] = 'Сербин Александр';
?>
