<?
$MESS['STAR_DIGITS_PARTNER_NAME'] = "STARt";
$MESS['STAR_DIGITS_PARTNER_URI'] = "https://startpl.ru/";
$MESS['STAR_DIGITS_MODULE_NAME'] = "Компания в цифрах: инфографика с анимированными числами";
$MESS['STAR_DIGITS_MODULE_DESC'] = "Модуль позволяет вставить на страницу блок с анимированными числами. Может использоваться, чтобы  проиллюстрировать факты о компании или характеристики какого-либо  товара";
?>