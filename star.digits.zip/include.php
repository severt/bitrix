<?
	Class StarDigits
	{
		
	}
?>
