<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arSpeed = array(
	"1" => GetMessage("STAR_SPEED1"),
	"3" => GetMessage("STAR_SPEED3"),
	"5" => GetMessage("STAR_SPEED5"),
);

$arComponentParameters = array(
	"GROUPS" => array(
		"MAIN_VALUES" => array(
			"NAME" => GetMessage("STAR_MAIN_VALUES_NAME"),
		),
	),
	"PARAMETERS" => array(
		"STAR_JQUERY"=>array(
			"PARENT" => "MAIN_VALUES",
			"NAME" => GetMessage("STAR_JQUERY"),
			"TYPE" => "CHECKBOX",
			"DEFAULT" => 'N',	
		),
		"STAR_ELEMENTS_COUNT"=>array(
			"PARENT" => "MAIN_VALUES",
			"NAME" => GetMessage("STAR_ELEMENTS_COUNT"),
			"TYPE" => "STRING",
			"REFRESH" => "Y",
			"DEFAULT" => '0',	
		),
		"STAR_ELEMENTS_IN_ROW"=>array(
			"PARENT" => "MAIN_VALUES",
			"NAME" => GetMessage("STAR_ELEMENTS_IN_ROW"),
			"TYPE" => "LIST",
			"VALUES" => array('3' => '3', '4' => '4'),
			"DEFAULT" => '0',	
		),
		"STAR_BORDER"=>array(
			"PARENT" => "MAIN_VALUES",
			"NAME" => GetMessage("STAR_BORDER"),
			"TYPE" => "CHECKBOX",
			"DEFAULT" => 'N',	
		),

		"STAR_DIGIT_COLOR"=>array(
			"PARENT" => "MAIN_VALUES",
			"NAME" => GetMessage("STAR_DIGIT_COLOR"),
			"TYPE" => "COLORPICKER",
			"DEFAULT" => "#000000",	
			"REFRESH" => "Y",
		),
		"STAR_TITLE_COLOR"=>array(
			"PARENT" => "MAIN_VALUES",
			"NAME" => GetMessage("STAR_TITLE_COLOR"),
			"TYPE" => "COLORPICKER",
			"DEFAULT" => "#000000",	
			"REFRESH" => "Y",
		),
		"STAR_BACK_COLOR"=>array(
			"PARENT" => "MAIN_VALUES",
			"NAME" => GetMessage("STAR_BACK_COLOR"),
			"TYPE" => "COLORPICKER",
			"DEFAULT" => "#fff",	
			"REFRESH" => "Y",
		),
		"STAR_DIGIT_SIZE"=>array(
			"PARENT" => "MAIN_VALUES",
			"NAME" => GetMessage("STAR_DIGIT_SIZE"),
			"TYPE" => "STRING",
			"DEFAULT" => "60",	
		),
		"STAR_TITLE_SIZE"=>array(
			"PARENT" => "MAIN_VALUES",
			"NAME" => GetMessage("STAR_TITLE_SIZE"),
			"TYPE" => "STRING",
			"DEFAULT" => "16",	
		),
		
	),
);
if($arCurrentValues["STAR_ELEMENTS_COUNT"]){

	for($i = 1; $i <= (int)$arCurrentValues["STAR_ELEMENTS_COUNT"]; $i++){

		$group_title = GetMessage("STAR_GROUP_TITLE").' '.$i;
		$digit_prop_name = 'ELEMENT_DIGIT'.$i;
		$digit_prop_title = 'ELEMENT_TITLE'.$i;
		$digit_prop_desc = 'ELEMENT_DESC'.$i;

		$arComponentParameters['GROUPS'][$digit_prop_name] = array(
			"NAME" => $group_title,
		);

		$arComponentParameters["PARAMETERS"][$digit_prop_name] = Array(
			"NAME" => GetMessage("STAR_ELEMENT_DIGIT"),
			"TYPE" => "STRING",
			"PARENT" => $digit_prop_name,
		);
		$arComponentParameters["PARAMETERS"][$digit_prop_title] = Array(
			"NAME" => GetMessage("STAR_ELEMENT_TITLE"),
			"TYPE" => "STRING",
			"PARENT" => $digit_prop_name,
		);

	}

}
?>

<script>
	window.setTimeout(function() {
		let color1 = document.querySelector('input[name="STAR_DIGIT_COLOR"]');
		if (color1 && color1.value == 'false') color1.value = '<?=$arComponentParameters["PARAMETERS"]["STAR_DIGIT_COLOR"]["DEFAULT"]?>';

		let color2 = document.querySelector('input[name="STAR_TITLE_COLOR"]');
		if (color2 && color2.value == 'false') color2.value = '<?=$arComponentParameters["PARAMETERS"]["STAR_TITLE_COLOR"]["DEFAULT"]?>';

		let color3 = document.querySelector('input[name="STAR_BACK_COLOR"]');
		if (color3 && color3.value == 'false') color3.value = '<?=$arComponentParameters["PARAMETERS"]["STAR_BACK_COLOR"]["DEFAULT"]?>';
	}, 300)
	
</script>
