<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("DIGITS_NAME"),
	"DESCRIPTION" => GetMessage("DIGITS_DESCRIPTION"),
	"CACHE_PATH" => "Y",
	"SORT" => 70,
	"PATH" => array(	
		"ID" => "star",
		"NAME" => GetMessage("STAR_COMPONENTS")
	),
);

?>