<?
$MESS['STAR_MAIN_VALUES_NAME'] = "Основные настройки";

$MESS['STAR_JQUERY'] = "Подключить jQuery";
$MESS['STAR_ELEMENTS_COUNT'] = "Количество блоков с цифрами";
$MESS['STAR_ELEMENTS_IN_ROW'] = "Элементов в ряд";

$MESS['STAR_GROUP_TITLE'] = "Настройки блока";
$MESS['STAR_ELEMENT_DIGIT'] = "Число";
$MESS['STAR_ELEMENT_TITLE'] = "Заголовок";

$MESS['STAR_DIGIT_COLOR'] = "Цвет чисел";
$MESS['STAR_TITLE_COLOR'] = "Цвет заголовков";
$MESS['STAR_BACK_COLOR'] = "Цвет фона";
$MESS['STAR_BORDER'] = "Обвести рамкой";

$MESS['STAR_DIGIT_SIZE'] = "Размер чисел (в px)";
$MESS['STAR_TITLE_SIZE'] = "Размер заголовков (в px)";


?>