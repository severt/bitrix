<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();


	if($arParams['STAR_JQUERY'] == 'Y'){
 		CJSCore::Init(array('jquery2')); 
 	}

 	$elem_count = $arParams['STAR_ELEMENTS_COUNT'];
 	if($arParams['STAR_BORDER'] == 'Y') $border = '1';
 	else $border = '2';
	
	if((int)$elem_count > 0) {?>

		<div class="star_digits_container" style="background-color: <?=$arParams['STAR_BACK_COLOR']?>">
			<div class="numbers_1867 numbers_1867_v<?=$border?> numbers_1867_rowed_<?=$arParams['STAR_ELEMENTS_IN_ROW']?>">
				<div class="numbers_1867_wrap">
					<?for($i = 1; $i <= $elem_count; $i++){?>

					<?
						$digit_param = 'ELEMENT_DIGIT'.$i;
						$title_param = 'ELEMENT_TITLE'.$i;
						$desc_param = 'ELEMENT_DESC'.$i;

						$incr_param = ceil((int)$arParams[$digit_param] / 400);
					?>

						<div class="numbers_1867_item">
							<div style="color: <?=$arParams['STAR_DIGIT_COLOR']?>; font-size: <?=$arParams['STAR_DIGIT_SIZE']?>px" class="numbers_1867_title"><span data-min='0' data-max="<?=(int)$arParams[$digit_param]?>" data-increment="<?=$incr_param?>" data-delay="2" class="numscroller">0</span></div>
							<?if($arParams[$title_param]){?>
								<div style="color: <?=$arParams['STAR_TITLE_COLOR']?>; font-size: <?=$arParams['STAR_TITLE_SIZE']?>px" class="numbers_1867_subtitle"><?=$arParams[$title_param]?></div>
							<?}?>
						</div>

					<?}?>
					<div class="numbers_1867_spacer"></div>
				</div>
			</div>
		</div>

	<?}?>
