<?
	class star_digits extends CModule {
		var $MODULE_ID = 'star.digits';
		var $MODULE_VERSION;
		var $MODULE_VERSION_DATE;
		var $MODULE_NAME;
		var $MODULE_DESCRIPTION;

		function __construct() {
			IncludeModuleLangFile(__FILE__);
			$arModuleVersion = array();
			include(dirname(__FILE__)."/version.php");

			$this->MODULE_VERSION = $arModuleVersion["VERSION"];
			$this->MODULE_VERSION_DATE = $arModuleVersion["VERSION_DATE"];

			$this->MODULE_NAME = GetMessage("STAR_DIGITS_MODULE_NAME");
			$this->MODULE_DESCRIPTION = GetMessage("STAR_DIGITS_MODULE_DESC");
			$this->PARTNER_NAME = GetMessage("STAR_DIGITS_PARTNER_NAME");
			$this->PARTNER_URI = GetMessage("STAR_DIGITS_PARTNER_URI");
		}

		function InstallFiles() {
			CopyDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/".$this->MODULE_ID."/install/components", $_SERVER["DOCUMENT_ROOT"]."/bitrix/components", true, true);
			return true;
		}

		function UnInstallFiles() {
			DeleteDirFilesEx("/bitrix/components/star/digits/");
			return true;
		}

		function DoInstall() {
			$this->InstallFiles();
			RegisterModule($this->MODULE_ID);		
		}

		function DoUninstall() {
			UnRegisterModule($this->MODULE_ID);
			$this->UnInstallFiles();		
		}
	}
?>
