<?php

use Bitrix\Main\Config\Option;
use OpenSearch\ClientBuilder;

IncludeModuleLangFile(__FILE__);

class CSearchElastic extends CSearchFullText
{
    public $arForumTopics = array();
    public $db = false;
    private static $fields = array(
        "id" => [
            'type' => 'long'
        ],
        "title" => [
            'type' => 'text',
            "analyzer" => "edge_ngram_analyzer",
            "search_analyzer" => "edge_ngram_search_analyzer",
            'fields' => [
                'ngram' => [
                    "type" => "text",
                    "analyzer" => "edge_ngram_analyzer",
                    "search_analyzer" => "edge_ngram_search_analyzer"
                ],
                'morf' => [
                    "type" => "text",
                    "analyzer" => "russian",
                    "search_analyzer" => "russian"
                ],
                'substr' => [
                    "type" => "text",
                    "analyzer" => "substring_analyzer",
                    "search_analyzer" => "substring_analyzer"
                ],
            ]
        ],
        "categories" => [
            'type' => 'text',
            'fields' => [
                'ngram' => [
                    "type" => "text",
                    "analyzer" => "edge_ngram_analyzer",
                    "search_analyzer" => "edge_ngram_search_analyzer"
                ],
                'morf' => [
                    "type" => "text",
                    "analyzer" => "russian",
                    "search_analyzer" => "russian"
                ],
                'substr' => [
                    "type" => "text",
                    "analyzer" => "substring_analyzer",
                    "search_analyzer" => "substring_analyzer"
                ],
            ]
        ],
        "body" => [
            'type' => 'text',
            'fields' => [
                'ngram' => [
                    "type" => "text",
                    "analyzer" => "edge_ngram_analyzer",
                    "search_analyzer" => "edge_ngram_search_analyzer"
                ],
                'morf' => [
                    "type" => "text",
                    "analyzer" => "russian",
                    "search_analyzer" => "russian"
                ],
            ]
        ],
        "module_id" => [
            'type' => 'long'
        ],
        "module" => [
            'type' => 'keyword',
            "index" => true,
        ],
        "url" => [
            'type' => 'keyword',
            "index" => true,
        ],
        "item_id" => [
            'type' => 'long'
        ],
        "item" => [
            'type' => 'keyword',
            "index" => true,
        ],
        "param1_id" => [
            'type' => 'long'
        ],
        "param1" => [
            'type' => 'keyword',
            "index" => true,
        ],
        "param2_id" => [
            'type' => 'long'
        ],
        "param2" => [
            'type' => 'keyword',
            "index" => true,
        ],
        "date_change" => [
            'type' => 'long'
        ],
        "date_from" => [
            'type' => 'long'
        ],
        "date_to" => [
            'type' => 'long'
        ],
        "custom_rank" => [
            'type' => 'long'
        ],
        "tags" => [
            'type' => 'keyword',
            "index" => true,
        ],
        "right" => [
            'type' => 'keyword',
            "index" => true,
        ],
        "site" => [
            'type' => 'keyword',
            "index" => true,
        ],
        "param" => [
            'type' => 'keyword',
            "index" => true,
        ],
    );
    private static $typesMap = array(
        "timestamp" => "rt_attr_timestamp",
        "string" => "rt_attr_string",
        "bigint" => "rt_attr_bigint",
        "uint" => "rt_attr_uint",
        "field" => "rt_field",
        "mva" => "rt_attr_multi",
    );
    private $errorText = "";
    private $errorNumber = 0;
    private $recodeToUtf = false;
    public $tags = "";
    public $query = "";
    public $SITE_ID = "";
    public $connectionIndex = "";
    public $indexName = "b_search_content_text";
    /**
     * @var $client \OpenSearch\Client|null
     * */
    protected $client = null;

    function __construct()
    {
        if (file_exists(__DIR__ . '/../install/vendor/autoload.php'))
            require_once __DIR__ . '/../install/vendor/autoload.php';

        $this->client = $this->getClient();
    }

    public function connect($connectionIndex, $indexName = "", $ignoreErrors = false)
    {
        global $APPLICATION;
    }

    public function truncate()
    {
        $this->client->indices()->delete(['index' => $this->indexName]);
        $this->makeIndex($this->client);
    }

    public function deleteById($ID = null)
    {
        try {
            if (! empty($ID)) {
                $this->client->delete(['index' => $this->indexName, '_id' => $ID]);
            }
        } catch (Exception | \OpenSearch\Common\Exceptions\RuntimeException $exception) {
        }
    }

    public function getReplaces($search = '')
    {
        if (! $this->client)
            return [];
        if (empty($search)) {
            $response = $this->client->search([
                'index' => 'b_replaces',
                'from' => 0,
                'size' => 10000
            ]);
        } else {
            $response = $this->client->search([
                'index' => 'b_replaces',
                'body' => [
                    'query' => [
                        "multi_match" => [
                            "query" => self::prepareQuery($search),
                            "operator" => "and",
                            "type" => "most_fields",
                            "fields" => [
                                "replaces^3",
                                "replaces.ngram^2",
                                "replaces.morf",
                            ],
                            "fuzziness" => 0
                        ]
                    ]
                ],
                'from' => 0,
                'size' => 10000
            ]);
        }

        $aReplaces = [];
        if (! empty($response['hits']['hits'])) {
            foreach ($response['hits']['hits'] as $hit) {
                $aReplaces[] = [
                    $hit['_source']['word'],
                    $hit['_source']['replaces'],
                    $hit['_id'],
                ];
            }
        }
        return $aReplaces;
    }

    public function replace($ID, $arFields)
    {
        global $DB;
        if (array_key_exists("~DATE_CHANGE", $arFields)) {
            $arFields["DATE_CHANGE"] = $arFields["~DATE_CHANGE"];
            unset($arFields["~DATE_CHANGE"]);
        } elseif (array_key_exists("LAST_MODIFIED", $arFields)) {
            $arFields["DATE_CHANGE"] = $arFields["LAST_MODIFIED"];
            unset($arFields["LAST_MODIFIED"]);
        } elseif (array_key_exists("DATE_CHANGE", $arFields)) {
            $arFields["DATE_CHANGE"] = $DB->FormatDate($arFields["DATE_CHANGE"], "DD.MM.YYYY HH:MI:SS", CLang::GetDateFormat());
        }

        if (empty($arFields['ITEM_ID']) && empty($arFields['MODULE_ID'])) {
            $rsSearch = $DB->Query("SELECT ID, ITEM_ID, MODULE_ID FROM b_search_content WHERE ID = " . $ID, false);

            if ($rsSearch->Fetch()) {
                $row = $rsSearch->Fetch();
                $arFields['ITEM_ID'] = $row['ID'];
                $arFields['MODULE_ID'] = $row['MODULE_ID'];
            }
        }

        $DATE_FROM = intval(MakeTimeStamp($arFields["DATE_FROM"]));
        if ($DATE_FROM > 0)
            $DATE_FROM -= CTimeZone::GetOffset();
        $DATE_TO = intval(MakeTimeStamp($arFields["DATE_TO"]));
        if ($DATE_TO > 0)
            $DATE_TO -= CTimeZone::GetOffset();
        $DATE_CHANGE = intval(MakeTimeStamp($arFields["DATE_CHANGE"]));
        if ($DATE_CHANGE > 0)
            $DATE_CHANGE -= CTimeZone::GetOffset();

        $BODY = CSearch::KillEntities($arFields["BODY"]) . "\r\n" . $arFields["TAGS"];

        $aBody = [
            'id' => $ID,
            'module_id' => intval(sprintf("%u", crc32($arFields["MODULE_ID"]))),
            'module' => $this->Escape($arFields["MODULE_ID"]),
            'url' => ($arFields["URL"]),
            'item_id' => intval(sprintf("%u", crc32($arFields["ITEM_ID"]))),
            'item' => $this->Escape($arFields["ITEM_ID"]),
            'param1_id' => intval(sprintf("%u", crc32($arFields["PARAM1"]))),
            'param1' => $this->Escape($arFields["PARAM1"]),
            'param2_id' => intval(sprintf("%u", crc32($arFields["PARAM2"]))),
            'param2' => $this->Escape($arFields["PARAM2"]),
            'date_change' => $DATE_CHANGE,
            'date_from' => $DATE_FROM,
            'date_to' => $DATE_TO,
            'custom_rank' => intval($arFields["CUSTOM_RANK"]),
            'tags' => $this->tags($arFields["SITE_ID"], $arFields["TAGS"]),
            'right' => intval($this->rights($arFields["PERMISSIONS"])),
            'site' => intval($this->sites($arFields["SITE_ID"])),
            'param' => $this->params($arFields["PARAMS"]),
            'title' => $this->recodeTo(($arFields["TITLE"])),
            'body' => $this->recodeTo(($BODY)),
        ];

        if ($arFields['MODULE_ID'] == 'iblock') {
            $groups = (new CIBlockElement())->GetElementGroups($arFields["ITEM_ID"]);
            $aSections = [];
            while ($aSection = $groups->Fetch()) {
                $aSections[$aSection['ID']] = $aSection['NAME'];
                $sectionFullPath = CIBlockSection::GetNavChain(false, $aSection['ID']);
                while ($arSectionPath = $sectionFullPath->GetNext()) {
                    $aSections[$arSectionPath['ID']] = $arSectionPath['NAME'];
                }
            }
            if (! empty($aSections)) {
                $aBody['categories'] = implode(', ', $aSections);
            }
        }

        try {
            $this->client->delete([
                'index' => $this->indexName,
                'id' => $ID
            ]);
        } catch (Exception | \OpenSearch\Common\Exceptions\RuntimeException $exception) {
        }


        $this->client->index([
            'index' => $this->indexName,
            'id' => $ID,
            'routing' => 1,
            'body' => $aBody
        ]);
    }

    public function replaceAll($arItems)
    {
        $aData = [];
        foreach ($arItems as $arFields) {
            global $DB;
            if (array_key_exists("~DATE_CHANGE", $arFields)) {
                $arFields["DATE_CHANGE"] = $arFields["~DATE_CHANGE"];
                unset($arFields["~DATE_CHANGE"]);
            } elseif (array_key_exists("LAST_MODIFIED", $arFields)) {
                $arFields["DATE_CHANGE"] = $arFields["LAST_MODIFIED"];
                unset($arFields["LAST_MODIFIED"]);
            } elseif (array_key_exists("DATE_CHANGE", $arFields)) {
                $arFields["DATE_CHANGE"] = $DB->FormatDate($arFields["DATE_CHANGE"], "DD.MM.YYYY HH:MI:SS", CLang::GetDateFormat());
            }

            $DATE_FROM = intval(MakeTimeStamp($arFields["DATE_FROM"]));
            if ($DATE_FROM > 0)
                $DATE_FROM -= CTimeZone::GetOffset();
            $DATE_TO = intval(MakeTimeStamp($arFields["DATE_TO"]));
            if ($DATE_TO > 0)
                $DATE_TO -= CTimeZone::GetOffset();
            $DATE_CHANGE = intval(MakeTimeStamp($arFields["DATE_CHANGE"]));
            if ($DATE_CHANGE > 0)
                $DATE_CHANGE -= CTimeZone::GetOffset();

            $BODY = CSearch::KillEntities($arFields["BODY"]) . "\r\n" . $arFields["TAGS"];

            $aBody = [
                'id' => $arFields['ID'],
                'module_id' => intval(sprintf("%u", crc32($arFields["MODULE_ID"]))),
                'module' => $this->Escape($arFields["MODULE_ID"]),
                'url' => ($arFields["URL"]),
                'item_id' => intval(sprintf("%u", crc32($arFields["ITEM_ID"]))),
                'item' => $this->Escape($arFields["ITEM_ID"]),
                'param1_id' => intval(sprintf("%u", crc32($arFields["PARAM1"]))),
                'param1' => $this->Escape($arFields["PARAM1"]),
                'param2_id' => intval(sprintf("%u", crc32($arFields["PARAM2"]))),
                'param2' => $this->Escape($arFields["PARAM2"]),

                'date_change' => $DATE_CHANGE,
                'date_from' => $DATE_FROM,
                'date_to' => $DATE_TO,
                'custom_rank' => intval($arFields["CUSTOM_RANK"]),
                'tags' => $this->tags($arFields["SITE_ID"], $arFields["TAGS"]),
                'right' => intval($this->rights($arFields["PERMISSIONS"])),
                'site' => intval($this->sites($arFields["SITE_ID"])),
                'param' => $this->params($arFields["PARAMS"]),
                'title' => $this->recodeTo(($arFields["TITLE"])),
                'body' => $this->recodeTo(($BODY)),
            ];

            if ($arFields['MODULE_ID'] == 'iblock') {
                $groups = (new CIBlockElement())->GetElementGroups($arFields["ITEM_ID"]);
                $iblockElement = CIBlockElement::GetByID($arFields['ITEM_ID'])->Fetch();
                $aBody['param3_id'] = intval(sprintf("%u", crc32($iblockElement['IBLOCK_ID'])));
                $aBody['param3'] = $this->Escape($iblockElement['IBLOCK_ID']);
                $aSections = [];
                while ($aSection = $groups->Fetch()) {
                    $aSections[$aSection['ID']] = $aSection['NAME'];
                    $sectionFullPath = CIBlockSection::GetNavChain(false, $aSection['ID']);
                    while ($arSectionPath = $sectionFullPath->GetNext()) {
                        $aSections[$arSectionPath['ID']] = $arSectionPath['NAME'];
                    }
                }
                if (! empty($aSections)) {
                    $aBody['categories'] = implode(', ', $aSections);
                }
            }

            $aData[] = $aBody;
        }

        $this->client->bulk([
            'index' => $this->indexName,
            'body' => $aData
        ]);
    }

    public function update($ID, $arFields)
    {
        $this->replace($ID, $arFields);
    }

    public function search($arParams, $aSort, $aParamsEx, $bTagsCloud)
    {
        if (! $this->client)
            return [];
        $this->errorText = "";
        $this->errorNumber = 0;

        $this->tags = trim($arParams["TAGS"]);

        if (is_array($aParamsEx) && isset($aParamsEx["LIMIT"])) {
            $limit = intval($aParamsEx["LIMIT"]);
            unset($aParamsEx["LIMIT"]);
        }

        $offset = 0;
        if (is_array($aParamsEx) && isset($aParamsEx["OFFSET"])) {
            $offset = intval($aParamsEx["OFFSET"]);
            unset($aParamsEx["OFFSET"]);
        }

        if (is_array($aParamsEx) && ! empty($aParamsEx)) {
            $aParamsEx["LOGIC"] = "OR";
            $arParams[] = $aParamsEx;
        }

        $this->SITE_ID = $arParams["SITE_ID"];

        $arParams['QUERY'] = trim($arParams['QUERY']);

        if (empty($arParams['QUERY'])) {
            return [];
        }

        $queryItems = explode(' ', $arParams['QUERY']);

        $aQueries = [];

        foreach ($queryItems as &$queryItem) {
            $resp = $this->getReplaces($queryItem);
            if (! empty($resp)) {
                foreach ($resp as $item) {
                    $queryItem = $item[0];
                }
            }
            $aQueries[] = $queryItem;
        }
        $queryPhrase = self::prepareQuery(implode(' ', $aQueries));
        $response = $this->queryToElasticFull($queryPhrase, $offset, $limit, $arParams);

        $queryPhrase = $this->transliterate($queryPhrase);
        $response2 = $this->queryToElasticFull($queryPhrase, $offset, $limit, $arParams);

        if (! empty($response2['hits']['hits'])) {
            if (empty($response['hits']['hits']))
                $response['hits']['hits'] = [];
            $response['hits']['hits'] = array_merge($response['hits']['hits'], $response2['hits']['hits']);
        }

        $aResult = [];
        global $DB;
        if (! empty($response['hits']['hits'])) {
            foreach ($response['hits']['hits'] as $hit) {
                $data = [
                    'ID' => $hit['_source']['id'],
                    'DATE_CHANGE' => date('Y-m-d H:i:s', $hit['_source']['date_change']),
                    'MODULE_ID' => $hit['_source']['module'],
                    'ITEM_ID' => $hit['_source']['item'],
                    'CUSTOM_RANK' => $hit['_score'],
                    'RANK' => $hit['_score'],
                    'URL' => $hit['_source']['url'],
                    'TITLE' => $hit['_source']['title'],
                    'BODY' => $hit['_source']['body'],
                    'TAGS' => $hit['_source']['tags'],
                    'PARAM1' => $hit['_source']['param1'],
                    'PARAM2' => $hit['_source']['param2'],
                ];

                $aResult[$hit['_source']['id']] = $data;
            }
        }

        return $aResult;
    }

    function searchTitle($phrase = "", $arPhrase = array(), $nTopCount = 5, $arParams = array(), $bNotFilter = false, $order = "")
    {
        if (! $this->client)
            return [];


        $queryItems = explode(' ', $phrase);

        $aQueries = [];

        foreach ($queryItems as &$queryItem) {
            $resp = $this->getReplaces($queryItem);
            if (! empty($resp)) {
                foreach ($resp as $item) {
                    $queryItem = $item[0];
                }
            }
            $aQueries[] = $queryItem;
        }
        $queryPhrase = self::prepareQuery(implode(' ', $aQueries));
        $response = $this->queryToElasticTitle($queryPhrase, $nTopCount, $arParams);

        $queryPhrase = $this->transliterate($queryPhrase);
        $response2 = $this->queryToElasticTitle($queryPhrase, $nTopCount, $arParams);

        if (! empty($response2['hits']['hits'])) {
            if (empty($response['hits']['hits']))
                $response['hits']['hits'] = [];
            $response['hits']['hits'] = array_merge($response['hits']['hits'], $response2['hits']['hits']);
        }

        global $DB;
        $ids = [];
        if (! empty($response['hits']['hits'])) {
            foreach ($response['hits']['hits'] as $hit) {
                $ids[] = $hit['_source']['id'];
            }
        }

        return $ids;
    }

    public function getErrorText()
    {
        return "";
    }

    public function getErrorNumber()
    {
        return 0;
    }

    function getRowFormatter()
    {
        return null;
    }

    protected static function prepareQuery($query)
    {
        $query = preg_replace('#\s+#', ' ', $query);
        return str_replace(['"', "'"], '', mb_strtolower(trim($query)));
    }

    function transliterate($textcyr = null)
    {
        $cyr = array(
            'ж', 'ч', 'щ', 'ш', 'ю', 'а', 'б', 'в', 'г', 'д', 'е', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у', 'ф', 'х', 'ц', 'ъ', 'ь', 'я',
            'Ж', 'Ч', 'Щ', 'Ш', 'Ю', 'А', 'Б', 'В', 'Г', 'Д', 'Е', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ъ', 'Ь', 'Я');
        $lat = array(
            'zh', 'ch', 'sht', 'sh', 'yu', 'a', 'b', 'v', 'g', 'd', 'e', 'z', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'r', 's', 't', 'u', 'f', 'h', 'c', 'y', 'x', 'q',
            'Zh', 'Ch', 'Sht', 'Sh', 'Yu', 'A', 'B', 'V', 'G', 'D', 'E', 'Z', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'U', 'F', 'H', 'c', 'Y', 'X', 'Q');

        $newWord = '';
        foreach (mb_str_split($textcyr) as $sign) {
            $newSign = str_replace($cyr, $lat, $sign);
            if ($newSign == $sign) {
                $newSign = str_replace($lat, $cyr, $sign);
            }

            $newWord .= $newSign;
        }

        return $newWord;
    }

    protected function getClient()
    {
        $hosts = [
            [
                'host' => Option::get('abr.elasticsearch', 'HOST', 'localhost'),
                'port' => Option::get('abr.elasticsearch', 'PORT', '9200'),
                'scheme' => Option::get('abr.elasticsearch', 'USE_HTTPS_PROTOCOL', 'N') === 'Y' ? 'https' : 'http',
                'user' => Option::get('abr.elasticsearch', 'USER', ''),
                'pass' => Option::get('abr.elasticsearch', 'PASSWORD', '')
            ]
        ];

        $client = ClientBuilder::create()
            ->setHosts($hosts);


        if (Option::get('abr.elasticsearch', 'USE_HTTPS_PROTOCOL') === 'Y') {
            $client->setSSLVerification(false);
        }


        try {
            $client = $client->build();


            if (! $client->ping())
                return false;

            if (! $client->indices()->exists(['index' => $this->indexName])) {
                $this->makeIndex($client);
            }
            if (! $client->indices()->exists(['index' => 'b_replaces'])) {
                $params = [
                    'index' => 'b_replaces',
                    'body' => [
                        'settings' => [
                            "number_of_shards" => 3,
                            'index.mapping.nested_fields.limit' => 200,
                            'analysis' => [
                                "filter" => [
                                    'russian_stop' => [
                                        'type' => 'stop',
                                        'stopwords' => '_russian_'
                                    ],
                                    'russian_keywords' => [
                                        'type' => 'keyword_marker',
                                        'keywords' => [Option::get('abr.elasticsearch', 'EXCLUDED_WORDS', '')] //слова-исключения
                                    ],
                                    "russian_stemmer" => [
                                        "type" => "stemmer",
                                        "language" => "russian"
                                    ],
                                    "substring" => [
                                        "type" => "ngram",
                                        "language" => "russian",
                                        'min_gram' => 2,
                                        'max_gram' => 15,
                                    ]
                                ],
                                'analyzer' => [
                                    "edge_ngram_analyzer" => [
                                        "filter" => [
                                            "lowercase"
                                        ],
                                        "tokenizer" => "edge_ngram_tokenizer"
                                    ],
                                    "edge_ngram_search_analyzer" => [
                                        "tokenizer" => "standard",
                                        "filter" => [
                                            "lowercase"
                                        ]
                                    ],
                                    'russian' => [
                                        'type' => 'custom',
                                        'tokenizer' => 'standard',
                                        "filter" => ["lowercase", "russian_stop", "russian_keywords", "russian_stemmer"],
                                    ],
                                    'substring_analyzer' => [
                                        'tokenizer' => 'standard',
                                        "filter" => ["lowercase", "substring"]
                                    ]
                                ],
                                "tokenizer" => [
                                    "edge_ngram_tokenizer" => [
                                        "type" => "edge_ngram",
                                        "min_gram" => 2,
                                        "max_gram" => 20,
                                        "token_chars" => [
                                            "letter", "digit"
                                        ]
                                    ]
                                ]
                            ],
                            "max_ngram_diff" => "50"
                        ],
                    ]
                ];
                $client->indices()->create($params);

                $mapParams = [
                    'index' => 'b_replaces',
                    'body' => [
                        "_source" => ["enabled" => true],
                        'properties' => [
                            "word" => [
                                'type' => 'text',
                                'fields' => [
                                    'ngram' => [
                                        "type" => "text",
                                        "analyzer" => "edge_ngram_analyzer",
                                        "search_analyzer" => "edge_ngram_search_analyzer"
                                    ],
                                    'morf' => [
                                        "type" => "text",
                                        "analyzer" => "russian",
                                        "search_analyzer" => "russian"
                                    ],
                                ]
                            ],
                            "replaces" => [
                                'type' => 'text',
                                'fields' => [
                                    'ngram' => [
                                        "type" => "text",
                                        "analyzer" => "edge_ngram_analyzer",
                                        "search_analyzer" => "edge_ngram_search_analyzer"
                                    ],
                                    'morf' => [
                                        "type" => "text",
                                        "analyzer" => "russian",
                                        "search_analyzer" => "russian"
                                    ],
                                ]
                            ],
                        ]
                    ]
                ];
                $client->indices()->putMapping($mapParams);
            }

            return $client;
        } catch (Exception $exception) {
            return null;
        }
    }

    protected function makeIndex($client)
    {
        $params = [
            'index' => $this->indexName,
            'body' => [
                'settings' => [
                    "number_of_shards" => 3,
                    'index.mapping.nested_fields.limit' => 200,
                    'analysis' => [
                        "filter" => [
                            'russian_stop' => [
                                'type' => 'stop',
                                'stopwords' => '_russian_'
                            ],
                            'russian_keywords' => [
                                'type' => 'keyword_marker',
                                'keywords' => [Option::get('abr.elasticsearch', 'EXCLUDED_WORDS', '')] //слова-исключения
                            ],
                            "russian_stemmer" => [
                                "type" => "stemmer",
                                "language" => "russian"
                            ],
                            "substring" => [
                                "type" => "ngram",
                                "language" => "russian",
                                'min_gram' => 2,
                                'max_gram' => 15,
                            ],
                        ],
                        'analyzer' => [
                            "edge_ngram_analyzer" => [
                                "filter" => [
                                    "lowercase"
                                ],
                                "tokenizer" => "edge_ngram_tokenizer"
                            ],
                            "edge_ngram_search_analyzer" => [
                                "tokenizer" => "standard",
                                "filter" => [
                                    "lowercase"
                                ]
                            ],
                            'russian' => [
                                'type' => 'custom',
                                'tokenizer' => 'standard',
                                "filter" => ["lowercase", "russian_stop", "russian_keywords", "russian_stemmer", "snowball"],
                            ],
                            'substring_analyzer' => [
                                'tokenizer' => 'standard',
                                "filter" => ["lowercase", "substring"]
                            ]
                        ],
                        "tokenizer" => [
                            "edge_ngram_tokenizer" => [
                                "type" => "edge_ngram",
                                "min_gram" => 2,
                                "max_gram" => 20,
                                "token_chars" => [
                                    "letter", "digit"
                                ]
                            ],
                        ]
                    ],
                    "max_ngram_diff" => "50"
                ],
            ]
        ];
        $client->indices()->create($params);

        $mapParams = [
            'index' => $this->indexName,
            'body' => [
                "_source" => ["enabled" => true],
                'properties' => self::$fields
            ]
        ];
        $client->indices()->putMapping($mapParams);

        $settingsParams = [
            'index' => $this->indexName,
            'body' => [
                "max_result_window" => 500000,
            ]
        ];
        $client->indices()->putSettings($settingsParams);
    }

    public function Escape($str)
    {
        static $search = array(
            "\\",
            "'",
            "/",
            ")",
            "(",
            "$",
            "~",
            "!",
            "@",
            "^",
            "-",
            "|",
            "<",
            "\x0",
            "=",
        );
        static $replace = array(
            "\\\\",
            "\\'",
            "\\\\/",
            "\\\\)",
            "\\\\(",
            "\\\\\$",
            "\\\\~",
            "\\\\!",
            "\\\\@",
            "\\\\^",
            "\\\\-",
            "\\\\|",
            "\\\\<",
            " ",
            " ",
        );

        $str = str_replace($search, $replace, $str);

        $stat = count_chars($str, 1);
        if (isset($stat[ord('"')]) && $stat[ord('"')] % 2 === 1)
            $str = str_replace('"', '\\\"', $str);

        return $str;
    }

    public function Escape2($str)
    {
        static $search = array(
            "\\",
            "'",
            "\"",
            "\x0",
        );
        static $replace = array(
            "\\\\",
            "\\'",
            "\\\\\"",
            " ",
        );
        return str_replace($search, $replace, $str);
    }

    function tags($arLID, $sContent)
    {
        $tags = array();
        if (is_array($arLID)) {
            foreach ($arLID as $site_id => $url) {
                $arTags = tags_prepare($sContent, $site_id);
                foreach ($arTags as $tag) {
                    $tags[] = sprintf("%u", crc32($tag));
                }
            }
        }
        return implode(",", $tags);
    }

    function rights($arRights)
    {
        $rights = array();
        if (is_array($arRights)) {
            foreach ($arRights as $group_id) {
                if (is_numeric($group_id))
                    $rights[$group_id] = sprintf("%u", crc32("G" . intval($group_id)));
                else
                    $rights[$group_id] = sprintf("%u", crc32($group_id));
            }
        }
        return implode(",", $rights);
    }

    function sites($arSites)
    {
        $sites = array();
        if (is_array($arSites)) {
            foreach ($arSites as $site_id => $url) {
                $sites[$site_id] = sprintf("%u", crc32($site_id));
            }
        } else {
            $sites[$arSites] = sprintf("%u", crc32($arSites));
        }
        return implode(",", $sites);
    }

    function params($arParams)
    {
        $params = array();
        if (is_array($arParams)) {
            foreach ($arParams as $k1 => $v1) {
                $name = trim($k1);
                if ($name != "") {
                    if (! is_array($v1))
                        $v1 = array($v1);

                    foreach ($v1 as $v2) {
                        $value = trim($v2);
                        if ($value != "") {
                            $params[] = sprintf("%u", crc32(urlencode($name) . "=" . urlencode($value)));
                        }
                    }
                }
            }
        }
        return implode(",", $params);
    }

    public function recodeTo($text)
    {
        if ($this->recodeToUtf) {
            $error = "";
            $result = \Bitrix\Main\Text\Encoding::convertEncoding($text, SITE_CHARSET, "UTF-8", $error);
            if (! $result && ! empty($error))
                #$this->ThrowException($error, "ERR_CHAR_BX_CONVERT");
                return $text;

            return $result;
        } else {
            return $text;
        }
    }

    public function addReplace($id, $word, $replace)
    {
        if (! empty($id)) {
            $this->client->index([
                'index' => 'b_replaces',
                'id' => $id,
                'routing' => 1,
                'body' => [
                    'word' => $word,
                    'replaces' => $replace
                ]
            ]);
        } else {
            $this->client->index([
                'index' => 'b_replaces',
                'routing' => 1,
                'body' => [
                    'word' => $word,
                    'replaces' => $replace
                ]
            ]);
        }
    }

    public function delReplace($id)
    {
        if (! empty($id)) {
            $resp = $this->client->delete([
                'index' => 'b_replaces',
                'id' => html_entity_decode($id),
                'routing' => "1"
            ]);
        }
    }

    public function isClient()
    {
        if (! empty($this->client)) {
            return true;
        } else {
            return false;
        }
    }

    private function queryToElasticFull($queryPhrase, $offset, $limit, $params = [])
    {
        $requestBody = COption::GetOptionString('abr.elasticsearch', 'body_query', '{
            "query": {
                "multi_match": {
                    "query": "#QUERY#",
                    "operator": "and",
                    "type": "most_fields",
                    "fields": [
                        "title^6",
                        "body",
                        "title.ngram^4",
                        "body.ngram",
                        "title.morf^3",
                        "categories.morf",
                        "categories.ngram",
                        "categories"
                    ],
                    "fuzziness": 1
                }
            }
        }');

        if (empty(json_decode($requestBody))) {
            COption::SetOptionString('abr.elasticsearch', 'body_query', '{
    "query": {
        "multi_match": {
            "query": "#QUERY#",
            "operator": "and",
            "type": "most_fields",
            "fields": [
                "title^6",
                "body",
                "title.ngram^4",
                "body.ngram",
                "title.morf^3"
            ],
            "fuzziness": 1
        }
    }
}');
            $requestBody = COption::GetOptionString('abr.elasticsearch', 'body_query');
        }


        $requestBody = str_replace('#QUERY#', $queryPhrase, $requestBody);
        $aRequestBody = json_decode($requestBody, true);

        if (! empty($aSort['CUSTOM_RANK']) || ! empty($aSort['RANK'])) {
            $sort = ['_score:desc'];
        } else {
            $sort = ['_score'];
        }

        $aRequestBody['query'] = [
            "bool" => [
                "must" => [
                    $aRequestBody['query']
                ],
            ]
        ];

        if (! empty($params)) {
            if (! empty($params['SITE_ID'])) {
                $aRequestBody['query']['bool']['filter']['bool']['must'][] = [
                    "term" => [
                        'site' => intval($this->sites($params["SITE_ID"]))
                    ]
                ];
            }
            if (! empty($params['MODULE_ID'])) {
                $aRequestBody['query']['bool']['filter']['bool']['must'][] = [
                    "term" => [
                        'module_id' => intval(sprintf("%u", crc32($params['MODULE_ID'])))
                    ]
                ];
                ;
            }
            if (! empty($params['PARAM1'])) {
                $aRequestBody['query']['bool']['filter']['bool']['must'][] = [
                    "term" => [
                        'param1_id' => intval(sprintf("%u", crc32($params['PARAM1'])))
                    ]
                ];
                ;
            }
            if (! empty($params[0])) {
                foreach ($params[0] as $k => $param) {
                    if(!is_numeric($k)) continue;

                    if (! empty($param['=MODULE_ID'])) {
                        $aRequestBody['query']['bool']['filter']['bool']['should'][$k]['bool']['must'][] = [
                            "term" => [
                                'module_id' => intval(sprintf("%u", crc32($param["=MODULE_ID"])))
                            ]
                        ];
                    }
                    if (! empty($param['PARAM1'])) {
                        $aRequestBody['query']['bool']['filter']['bool']['should'][$k]['bool']['must'][] = [
                            "term" => [
                                'param1_id' => intval(sprintf("%u", crc32($param['PARAM1'])))
                            ]
                        ];
                    }
                }

                $aRequestBody['query']['bool']['filter']['bool']['should'] = array_values($aRequestBody['query']['bool']['filter']['bool']['should']);
                $aRequestBody['query']['bool']['filter']['bool']['minimum_should_match'] = 1;
            }
        }

        $data = [
            'hits' => [
                'hits' => []
            ]
        ];

        $limit = $limit ?? 100;

        $data = $this->client->search([
            'index' => $this->indexName,
            'body' => $aRequestBody,
            'from' => 0,
            'size' => $limit,
            'sort' => $sort
        ]);

        return $data;
    }

    private function queryToElasticTitle($queryPhrase, $limit, $params = [])
    {
        $requestBody = COption::GetOptionString('abr.elasticsearch', 'body_title_query', '{
            "query": {
                "multi_match": {
                    "query": "#QUERY#",
                    "operator": "and",
                    "type": "most_fields",
                    "fields": [
                        "title^6",
                        "body",
                        "title.ngram^4",
                        "body.ngram",
                        "title.morf^3",
                        "categories.morf",
                        "categories.ngram",
                        "categories"
                    ],
                    "fuzziness": 1
                }
            }
        }');

        $requestBody = str_replace('#QUERY#', $queryPhrase, $requestBody);
        $aRequestBody = json_decode($requestBody, true);

        if (! empty($aSort['CUSTOM_RANK']) || ! empty($aSort['RANK'])) {
            $sort = ['_score:desc'];
        } else {
            $sort = ['_score'];
        }

        $aRequestBody['query'] = [
            "bool" => [
                "must" => [
                    $aRequestBody['query']
                ],
            ]
        ];
        if (! empty($params)) {
            if (! empty($params['SITE_ID'])) {
                $aRequestBody['query']['bool']['filter'][] = [
                    "term" => [
                        'site' => intval($this->sites($params["SITE_ID"]))
                    ]
                ];
            }
            if (! empty($params['MODULE_ID'])) {
                $aRequestBody['query']['bool']['filter'][] = [
                    "term" => [
                        'module_id' => intval(sprintf("%u", crc32($params["MODULE_ID"])))
                    ]
                ];
            }
            if (! empty($params['PARAM1'])) {
                $aRequestBody['query']['bool']['filter'][] = [
                    "term" => [
                        'param1_id' => intval(sprintf("%u", crc32($params["PARAM1"])))
                    ]
                ];
            }
        }
        if (! empty($params[0])) {
            foreach ($params[0] as $k => $param) {
                if(!is_numeric($k)) continue;

                if (! empty($param['=MODULE_ID'])) {
                    $aRequestBody['query']['bool']['filter']['bool']['should'][$k]['bool']['must'][] = [
                        "term" => [
                            'module_id' => intval(sprintf("%u", crc32($param["=MODULE_ID"])))
                        ]
                    ];
                }
                if (! empty($param['PARAM1'])) {
                    $aRequestBody['query']['bool']['filter']['bool']['should'][$k]['bool']['must'][] = [
                        "term" => [
                            'param1_id' => intval(sprintf("%u", crc32($param['PARAM1'])))
                        ]
                    ];
                }
            }

            $aRequestBody['query']['bool']['filter']['bool']['should'] = array_values($aRequestBody['query']['bool']['filter']['bool']['should']);
            $aRequestBody['query']['bool']['filter']['bool']['minimum_should_match'] = 1;
        }
        $data = [
            'hits' => [
                'hits' => []
            ]
        ];

        $limit = $limit ?? 100;

        $data = $this->client->search([
            'index' => $this->indexName,
            'body' => $aRequestBody,
            'from' => 0,
            'size' => $limit,
            'sort' => $sort
        ]);

        return $data;
    }
}

if (! function_exists('mb_str_split')) {
    function mb_str_split($string = '', $length = 1, $encoding = null)
    {
        if (! empty($string)) {
            $split = array();
            $mb_strlen = mb_strlen($string, $encoding);
            for ($pi = 0; $pi < $mb_strlen; $pi += $length) {
                $substr = mb_substr($string, $pi, $length, $encoding);
                if (! empty($substr)) {
                    $split[] = $substr;
                }
            }
        }
        return $split;
    }
}