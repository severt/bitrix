<?php
$MESS["abr.elasticsearchSEARCH_PRIMER"] = "пример";
?>