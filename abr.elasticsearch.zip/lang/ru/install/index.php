<?php
$MESS["abr.elasticsearch_MODULE_NAME"] = "Умный поиск Absteam";
$MESS["abr.elasticsearch_MODULE_DESC"] = "Умный поиск Absteam расширяет возможности стандартного полнотекстового поиска и позволяет производить улучшенный поиск без сложных настроек.";
$MESS["abr.elasticsearch_PARTNER_NAME"] = "АБР";
$MESS["abr.elasticsearch_PARTNER_URI"] = "https://www.absteam.ru/";
$MESS["abr.elasticsearch_PHAR_ERROR"] = "Необходимо установить и активировать библиотеку PHP Phar https://www.php.net/manual/ru/phar.installation.php";
?>