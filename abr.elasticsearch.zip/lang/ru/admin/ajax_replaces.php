<?php
$MESS['ABR_ELASTIC_COMPLETE_UPLOAD'] = 'Загрузка файла завершена!';
?>