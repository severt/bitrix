<?
$MESS["SEARCH_REINDEX_REINDEX_CHANGED"] = "Переиндексировать только измененные:";
$MESS["SEARCH_REINDEX_REINDEX_BUTTON"] = "Переиндексировать";
$MESS["SEARCH_REINDEX_TOTAL"] = "Проиндексировано документов:";
$MESS["SEARCH_REINDEX_COMPLETE"] = "Переиндексация закончена.";
$MESS["SEARCH_REINDEX_STEP"] = "Шаг:";
$MESS["SEARCH_REINDEX_STEP_sec"] = "секунд";
$MESS["SEARCH_REINDEX_TITLE"] = "Переиндексация сайта";
$MESS["SEARCH_REINDEX_TAB"] = "Переиндексация";
$MESS["SEARCH_REINDEX_TAB_TITLE"] = "Параметры переиндексации";
$MESS["SEARCH_REINDEX_SITE"] = "Сайт:";
$MESS["SEARCH_REINDEX_ALL"] = "(все)";
$MESS["SEARCH_REINDEX_MODULE"] = "Модуль:";
$MESS["SEARCH_REINDEX_MAIN"] = "Статические файлы";
$MESS["SEARCH_REINDEX_CONTINUE"] = "Продолжить";
$MESS["SEARCH_REINDEX_STOP"] = "Остановить";
$MESS["SEARCH_REINDEX_IN_PROGRESS"] = "Переиндексация...";
$MESS["SEARCH_REINDEX_NEXT_STEP"] = "Следующий шаг";
$MESS["SEARCH_REINDEX_SOCNET_WARNING"] = "Установлен модуль социальной сети.";
$MESS["SEARCH_REINDEX_SOCNET_WARN_DETAILS"] = "После индексации модулем поиска, требуется переиндексация социальной сети из компонента, размещенного в публичном разделе.";
$MESS["SEARCH_REINDEX_SOCNET_MESSAGE"] = "Внимание! После выполнения переиндексации <b>модуль социальной сети</b> должен быть переиндексирован отдельно из публичного раздела. Перейдите в режиме разработки в разделы социальной сети (где установлены компоненты <i>socialnetwork, socialnetwork_group, socialnetwork_user</i>) и нажмите на кнопку \"Индексация\" в панели инструментов. <br><br><img src=\"/bitrix/images/search/socnet_reindex_ru.png\">";
$MESS["SEARCH_REINDEX_CLEAR_SUGGEST"] = "Удалить поисковые фразы для подсказки:";
?>