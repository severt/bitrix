<?php
$MESS["abr.elasticsearch_ADMIN_MAIN"] = "Управление модулем ElsasticSearch";
$MESS["abr.elasticsearch_ADMIN_TITLE"] = "Управление модулем ElsasticSearch";
?>