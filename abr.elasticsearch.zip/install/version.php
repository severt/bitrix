<?
$arModuleVersion = array(
    "VERSION" => "1.6.8",
    "VERSION_DATE" => "2024-09-19 10:35:18"
);
?>