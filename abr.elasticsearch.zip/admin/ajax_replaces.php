<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_before.php';

$type=!empty($_REQUEST['type'])?$_REQUEST['type']:'';
$el = new CSearchElastic();

if(!$el->isClient()) {
    echo json_encode(['data' => []]);
    die();
}
if($type == 'add'){
    $id = $_REQUEST['word'];
    $el->addReplace((translit($_REQUEST['word'])), $_REQUEST['word'], $_REQUEST['replace']);
}elseif($type == 'del'){
    $id = $_REQUEST['id'];
    $el->delReplace($id);
}elseif($type == 'upload'){
    $replacesFile = $_FILES['replaces'];
    $csvFile = file($replacesFile['tmp_name']);
    foreach ($csvFile as $line) {
        $line = iconv('windows-1251', 'utf-8', $line);
        $data = str_getcsv($line, ';');
        $el->addReplace((translit($data[0])), $data[0], $data[1]);
    }
    echo GetMessage('ABR_ELASTIC_COMPLETE_UPLOAD');
    die();
}elseif($type == 'download'){
    $replaces = $el->getReplaces();
    $aReplaces = [];
    foreach ($replaces as $replace){
        $aReplaces[] = [
            iconv('UTF-8', 'windows-1251', $replace[0]),
            iconv('UTF-8', 'windows-1251', $replace[1])
        ];
    }
    array_to_csv_download($aReplaces);
    die();
}else{
    $replaces = $el->getReplaces();
    foreach ($replaces as &$replace){
        $replace[2] = '<a  class="btn-action btn-del" data-id="'.$replace[2].'" href="javascript:void(0)">
                            <i class="fas fa-trash"></i>
                        </a>';
    }
    echo json_encode([
        'data' => $replaces
    ]);
}

function translit($value)
{
    $value = CUtil::translit($value, 'ru', [
        'replace_space' => '-',
        'replace_other' => '-',
    ]);
    return $value;
}

function array_to_csv_download($array, $filename = "replaces.csv", $delimiter=";") {
    header('Content-Type: application/csv');
    header('Content-Disposition: attachment; filename="'.$filename.'";');

    // open the "output" stream
    // see http://www.php.net/manual/en/wrappers.php.php#refsect2-wrappers.php-unknown-unknown-unknown-descriptioq
    $f = fopen('php://output', 'w');

    foreach ($array as $line) {
        fputcsv($f, $line, $delimiter);
    }
}
?>