<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_before.php';

if (!CModule::IncludeModule("search")) {
    echo json_encode(['data' => ['ОШИБКА:', 'Модуль поиска не установлен']]);
    return;
}

$query = !empty($_REQUEST['q']) ? trim(htmlspecialchars($_REQUEST['q'])) : '';

if ($query === '') {
    echo json_encode(['data' => [['ОШИБКА:', 'Пустой запрос!']]]);
    return;
}

//Формируем фильтр для поиска
$arFilter = array(
    "QUERY" => $query,
);

//по какому сайту искать
$sid = !empty($_REQUEST['sid']) ? trim(htmlspecialchars($_REQUEST['sid'])) : '';
if ($sid !== 'NOT_REF' && $sid !== '')
    $arFilter["SITE_ID"] = $sid;

//в коком модуле искать
$module_id = !empty($_REQUEST['module_id']) ? trim(htmlspecialchars($_REQUEST['module_id'])) : '';
if ($module_id !== 'all' && $module_id !== '')
    $arFilter["MODULE_ID"] = $module_id;

//если выбран модуль ИБ, то в каком именно ИБ производить поиск
if ($module_id === "iblock") {
    $iblock = !empty($_REQUEST['iblock']) ? trim(htmlspecialchars($_REQUEST['iblock'])) : '';
    if ($iblock !== '' && $iblock !== 'all') {
        $arFilter["PARAM1"] = $iblock;
    }
}

//Производим поисковый запрос
$obSearch = new CSearch();
$obSearch->Search($arFilter);

$arResult = array();
if ($obSearch->errorno == 0) {
    $obSearch->Statistic = new CSearchStatistic($obSearch->strQueryText, $obSearch->strTagsText);
    $obSearch->Statistic->PhraseStat($obSearch->NavRecordCount, $obSearch->NavPageNomer);

    while ($ar = $obSearch->GetNext()) {
        $arResult[] = [$ar['TITLE_FORMATED'], $ar['BODY_FORMATED']];
    }
} else {
    $arResult[] = [$obSearch->errorno, $obSearch->error];
}

$total = count($arResult);

//возвращем либо результат, либо ошибку. + в любом случае, для удобства, возвращаем параметры поиска (фильтр)
$arResult[] = ['<b>FILTER:</b>', implode(', ', $arFilter)];
echo json_encode(['data' => $arResult, 'total' => $total]);
?>