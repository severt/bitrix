<?php

use Bitrix\Main\Config\Option;
use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;

require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/search/prolog.php");

$module_id = 'abr.elasticsearch';
global $USER, $APPLICATION;
Loader::includeModule($module_id);
Loader::includeModule('iblock');
Loader::includeModule('catalog');
Loader::includeModule('sale');

if (!$USER->IsAdmin()) {
    $APPLICATION->authForm('Nope');
}

Loc::loadMessages($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/options.php");

Loc::loadMessages(__FILE__);
$request = \Bitrix\Main\HttpApplication::getInstance()->getContext()->getRequest();
$defaultSettings = \Bitrix\Main\Config\Option::getDefaults($module_id);

$arAllOptions = [
    Loc::getMessage('ABR_ELASTIC_COMMON'),
    [
        "USE_ELASTIC",
        Loc::getMessage('ABR_ELASTIC_USE_MODULE'),
        false,
        [
            'checkbox',
            false
        ]
    ],
    Loc::getMessage('ABR_ELASTIC_CONNECTION'),
    [
        "USE_HTTPS_PROTOCOL",
        Loc::getMessage('ABR_ELASTIC_USE_HTTPS'),
        false,
        [
            'checkbox',
            false
        ]
    ],
    [
        "HOST",
        Loc::getMessage('ABR_ELASTIC_HOST'),
        'localhost',
        [
            'text',
            5
        ]
    ],
    [
        "PORT",
        Loc::getMessage('ABR_ELASTIC_PORT'),
        '9200',
        [
            'text',
            5
        ]
    ],
    [
        "USER",
        Loc::getMessage('ABR_ELASTIC_LOGIN'),
        '',
        [
            'text',
            5
        ]
    ],
    [
        "PASSWORD",
        Loc::getMessage('ABR_ELASTIC_PASSWORD'),
        '',
        [
            'password',
            5
        ]
    ],
    [
        "body_query",
        Loc::getMessage('ABR_ELASTIC_BODY'),
        '{
    "query": {
        "multi_match": {
            "query": "#QUERY#",
            "operator": "and",
            "type": "most_fields",
            "fields": [
                "title^6",
                "body",
                "title.ngram^4",
                "body.ngram",
                "title.morf^3",
            ],
            "fuzziness": 1
        }
    }
}',
        [
            'textarea',
            25,
            50
        ]
    ],
    [
        "body_title_query",
        Loc::getMessage('ABR_ELASTIC_BODY_TITLE'),
        '{
    "query": {
        "multi_match": {
            "query": "#QUERY#",
            "operator": "and",
            "type": "most_fields",
            "fields": [
                "title^4",
                "title.substr^3",
                "title.ngram^2",
                "title.morf"
            ],
            "fuzziness": 1
        }
    }
}',
        [
            'textarea',
            25,
            50
        ]
    ],
];

$aTabs = [
    [
        "DIV" => "edit1",
        "TAB" => Loc::getMessage("MAIN_TAB_SET"),
        "OPTIONS" => $arAllOptions,
        "TITLE" => Loc::getMessage("MAIN_TAB_TITLE_SET"),
    ],
    [
        "DIV" => "edit3",
        "TAB" => Loc::getMessage("ABR_ELASTIC_REPLACES_CONTROL"),
        "TITLE" => Loc::getMessage("ABR_ELASTIC_REPLACES_CONTROL"),
    ],
    [
        "DIV" => "edit4",
        "TAB" => Loc::getMessage("ABR_ELASTIC_REPLACES_UPLOAD"),
        "TITLE" => Loc::getMessage("ABR_ELASTIC_REPLACES_UPLOAD"),
    ],
    [
        "DIV" => "edit2",
        "TAB" => Loc::getMessage("MAIN_TAB_RIGHTS"),
        "TITLE" => Loc::getMessage("MAIN_TAB_TITLE_RIGHTS"),
    ],
    [
        "DIV" => "edit5",
        "TAB" => Loc::getMessage("ABR_ELASTIC_TEST_SEARCH"),
        "TITLE" => Loc::getMessage("ABR_ELASTIC_TEST_SEARCH"),
    ],
];

$tabControl = new \CAdminTabControl("tabControl", $aTabs);

if ($request->isPost() && $request['Update'] && check_bitrix_sessid()) {

    foreach ($aTabs as $aTab) {
        foreach ($aTab['OPTIONS'] as $arOption) {

            if (!is_array($arOption))
                continue;

            if ($arOption['note'])
                continue;

            $optionName = $arOption[0];

            $optionValue = $request->getPost($optionName);

            Option::set($module_id, $optionName, is_array($optionValue) ? implode(",", $optionValue) : $optionValue);
            if ($optionName == 'EXCHANGE_TYPE' && $optionValue == 'SITE') {
                $now = new Bitrix\Main\Type\Datetime();
                $now->add('+5 min');
                $formattedTime = $now->toString(new \Bitrix\Main\Context\Culture(array("FORMAT_DATETIME" => "d.m.Y H:i:s")));
            }
        }
    }
    LocalRedirect($APPLICATION->GetCurPage() . '?mid=' . htmlspecialcharsbx($request['mid']) . '&amp;lang=' . $request['lang']);
}
$tabControl->Begin(); ?>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script src="https://kit.fontawesome.com/8508e2ef4b.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<div class="adm-info-message-wrap" style="position: relative;">
    <div class="adm-info-message" style="margin: 0 auto; display: block;">
        <?php echo Loc::getMessage("ABR_ELASTIC_ATTENTION"); ?>
    </div>
</div>
<form method='post'
      action='<?= $APPLICATION->GetCurPage(); ?>?mid=<?= htmlspecialcharsbx($request['mid']) ?>&amp;lang=<?= $request['lang'] ?>'
      name='absteam_elastic_settings'>

    <?php foreach ($aTabs as $aTab):
        if ($aTab['OPTIONS']): ?>
            <?php $tabControl->BeginNextTab(); ?>
            <?php __AdmSettingsDrawList($module_id, $aTab['OPTIONS']); ?>

        <?php endif;
    endforeach; ?>
    <td>
        <input type="submit" name="Update" value="<?php echo GetMessage('MAIN_SAVE') ?>">
        <input type="reset" name="Reset" value="<?php echo GetMessage('MAIN_RESET') ?>">
        <?= bitrix_sessid_post(); ?>
    </td>
    <?
    $tabControl->BeginNextTab();
    ?>

    <td>
        <button id="add-replace"><?php echo Loc::getMessage("ABR_ELASTIC_ADD_REPLACE"); ?></button>
        <table id="replace-table" class="display" style="width:100%">
            <thead>
            <tr>
                <th><?php echo Loc::getMessage("ABR_ELASTIC_WORD"); ?></th>
                <th><?php echo Loc::getMessage("ABR_ELASTIC_REPLACES"); ?></th>
                <th><?php echo Loc::getMessage("ABR_ELASTIC_ACTIONS"); ?></th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td>Tiger Nixon</td>
                <td>System Architect</td>
                <td>
                    <a class="btn-action" href="javascript:void(0)">
                        <i class="fas fa-pen"></i>
                    </a>
                    <a class="btn-action" href="javascript:void(0)">
                        <i class="fas fa-trash"></i>
                    </a>
                </td>
            </tr>
            </tbody>
        </table>
        <div id="dialog-form" title="<?php echo Loc::getMessage("ABR_ELASTIC_REPLACES_CONTROL"); ?>">

            <form>
                <fieldset>
                    <label for="name"><?php echo Loc::getMessage("ABR_ELASTIC_WORD"); ?></label>
                    <input type="text" required name="word" id="word" class="text ui-widget-content ui-corner-all">
                    <label for="email"><?php echo Loc::getMessage("ABR_ELASTIC_REPLACES_Z"); ?></label>
                    <textarea style="width: 100%; height: 100px; resize: none" required name="replace" id="replace"
                              class="text ui-widget-content ui-corner-all"></textarea>

                    <!-- Allow form submission with keyboard without duplicating the dialog button -->
                    <input type="submit" tabindex="-1" style="position:absolute; top:-1000px">
                </fieldset>
            </form>
        </div>
    </td>

    <?php
    $tabControl->BeginNextTab();
    ?>
    <td>
        <form>
            <a href="/bitrix/admin/abr.elasticsearch_ajax_replaces.php?type=download"
               target="_blank"><?php echo GetMessage('ABR_ELASTIC_REPLACES_DOWNLOAD'); ?></a>
            <br><br>
            <input type="file" accept="text/csv" name="replaces">
            <br><br>
            <input type="button" onclick="return uploadFile();"
                   value="<?php echo GetMessage('ABR_ELASTIC_REPLACES_UPLOAD_BUTTON') ?>">
        </form>
    </td>
    <?php
    $tabControl->BeginNextTab(); ?>
    <?php

    require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/admin/group_rights.php");
    ?>
    <td>
        <input type="submit" name="Update" value="<?php echo GetMessage('MAIN_SAVE') ?>">
        <input type="reset" name="Reset" value="<?php echo GetMessage('MAIN_RESET') ?>">
        <?= bitrix_sessid_post(); ?>
    </td>


    <!-- ========================== ТЕСТОВЫЙ ПОИСК НАЧАЛО ========================== -->

    <?
    $tabControl->BeginNextTab();
    ?>
    <div id="search-form-container">
        <div class="" id="module-option">
            <label for="LID"><?= GetMessage("ABR_ELASTIC_TEST_SEARCH_SITE") ?></label>
            <? echo CLang::SelectBox("SID", $str_LID, GetMessage("ABR_ELASTIC_TEST_SEARCH_ALL"), "", "id=\"SID\""); ?>

            <label for="module"><?= GetMessage("ABR_ELASTIC_TEST_SEARCH_MODULE") ?></label>
            <select name="module" id="module" onchange="onSelectModule(this)">
                <option value="all"><?= GetMessage("ABR_ELASTIC_TEST_SEARCH_ALL") ?></option>
                <option value="main"><?= GetMessage("ABR_ELASTIC_TEST_SEARCH_MAIN") ?></option>
                <? foreach (CSearchParameters::GetModulesList() as $m_id => $module_name): ?>
                    <option value="<? echo $m_id ?>"><? echo htmlspecialcharsbx($module_name) ?></option>
                <? endforeach; ?>
            </select>

            <label for="iblocks"><?= GetMessage("ABR_ELASTIC_TEST_SEARCH_IBS") ?></label>
            <select name="iblocks" id="iblocks" disabled>
                <option value="all"><?= GetMessage("ABR_ELASTIC_TEST_SEARCH_ALL") ?></option>
                <?php
                $iblockResult = \Bitrix\Iblock\TypeTable::getList();
                while ($iblock = $iblockResult->fetch()) {
                    echo '<option value="' . $iblock['ID'] . '">' . $iblock['ID'] . '</option>';
                }
                ?>
            </select>
        </div>
        <div id="search-form">
            <input type="search" name="q" id="search-input" value=""
                   placeholder="<?= GetMessage("ABR_ELASTIC_TEST_SEARCH_PLSHLDR") ?>">
            <input type="button" value="<?= GetMessage("ABR_ELASTIC_TEST_SEARCH_BTN") ?>" onclick="doSearch()">
        </div>
    </div>

    <td>
        <table id="search-table" class="display">
            <thead>
            <tr>
                <th style="width: 30%;"><?php echo Loc::getMessage("ABR_ELASTIC_TEST_SEARCH_RESULT_TITLE"); ?></th>
                <th><?php echo Loc::getMessage("ABR_ELASTIC_TEST_SEARCH_RESULT_BODY"); ?></th>
            </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
    </td>

    <!-- ========================== ТЕСТОВЫЙ ПОИСК КОНЕЦ ========================== -->

    <?php
    $tabControl->EndTab(); ?>
</form>

<?php $tabControl->End(); ?>

<script>

    /**
     * Отрпавляет поисковый запрос к БД и обновляет таблицу
     */
    function doSearch() {
        const query = new URLSearchParams({
            q: $('#search-input').val(),
            sid: $('#SID').val(),
            module_id: $('#module').val(),
            iblock: $('#iblocks').val()
        });

        const searchTable = $('#search-table').DataTable({
            destroy: true, // пересоздавать объект при обновлении
            ajax: "/bitrix/admin/<?= $module_id ?>_ajax_search.php?" + query.toString(),
            info: true,
            paging: true,
            searching: true
        });
    }

    /**
     * Вкл/выкл выпадающего списка типов ИБ, при выборе модуля ИБ
     */
    function onSelectModule(obj) {
        if ($(obj).val() === 'iblock') {
            $('#iblocks').prop('disabled', false);
            return
        }
        $('#iblocks').prop('disabled', true);
    }


    var dTable;

    function uploadFile() {
        var input = document.querySelector('input[type="file"][name="replaces"]');
        var formData = new FormData();
        var file = input.files[0];
        formData.append('replaces', file);


        $.ajax({
            url: '/bitrix/admin/abr.elasticsearch_ajax_replaces.php?type=upload',
            type: 'POST',
            data: formData,
            processData: false,  // tell jQuery not to process the data
            contentType: false,  // tell jQuery not to set contentType
            success: function (data) {
                // console.log(data);
                alert(data);
                try {
                    dTable.ajax.reload();
                } catch (e) {

                }
            }
        });

        // $.post('/bitrix/admin/abr.elasticsearch_ajax_replaces.php?type=upload', formData, function (){
        //
        // });
        return false;
    }

    $(document).ready(function () {
        dTable = $('#replace-table').DataTable({
            ajax: "/bitrix/admin/abr.elasticsearch_ajax_replaces.php"
        });

        var dialog, form,

            // From http://www.whatwg.org/specs/web-apps/current-work/multipage/states-of-the-type-attribute.html#e-mail-state-%28type=email%29
            emailRegex = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,
            replace = $("#replace"),
            word = $("#word"),
            allFields = $([]).add(replace).add(word),
            tips = $(".validateTips");

        function updateTips(t) {
            tips
                .text(t)
                .addClass("ui-state-highlight");
            setTimeout(function () {
                tips.removeClass("ui-state-highlight", 1500);
            }, 500);
        }

        function checkLength(o, n, min, max) {
            if (o.val().length > max || o.val().length < min) {
                o.addClass("ui-state-error");
                updateTips("Length of " + n + " must be between " +
                    min + " and " + max + ".");
                return false;
            } else {
                return true;
            }
        }

        function checkRegexp(o, regexp, n) {
            if (!(regexp.test(o.val()))) {
                o.addClass("ui-state-error");
                updateTips(n);
                return false;
            } else {
                return true;
            }
        }

        function addUser() {
            var valid = true;
            allFields.removeClass("ui-state-error");

            valid = valid && checkLength(word, "word", 2, 999);
            valid = valid && checkLength(replace, "replace", 2, 9999);

            console.log(word.val(), replace.val(), valid)

            if (valid) {
                $.get('/bitrix/admin/abr.elasticsearch_ajax_replaces.php?type=add&word=' + word.val() + '&replace=' + replace.val(), function () {
                    dialog.dialog("close");
                    setTimeout(function () {
                        dTable.ajax.reload(null, false);
                    }, 500);
                    form.trigger('reset');
                });
            }
            return valid;
        }

        dialog = $("#dialog-form").dialog({
            autoOpen: false,
            height: 400,
            width: 350,
            modal: true,
            buttons: {
                "<?php echo Loc::getMessage("ABR_ELASTIC_REPLACES_SAVE"); ?>": addUser,
                "<?php echo Loc::getMessage("ABR_ELASTIC_REPLACES_CANCEL"); ?>": function () {
                    dialog.dialog("close");
                }
            },
            close: function () {
                form.trigger('reset');
                allFields.removeClass("ui-state-error");
            }
        });

        form = dialog.find("form").on("submit", function (event) {
            event.preventDefault();
            addUser();
        });

        $("#add-replace").button().on("click", function () {
            dialog.dialog("open");

            return false;
        });
        $("#add-replace-file").button().on("click", function () {
            dialog.dialog("open");

            return false;
        });
        $('body').on('click', '.btn-del', function () {
            if (confirm('<?php echo Loc::getMessage("ABR_ELASTIC_REPLACES_CONFIRM"); ?>')) {
                var id = $(this).data('id');
                $.get('/bitrix/admin/abr.elasticsearch_ajax_replaces.php?type=del&id=' + id, function () {
                    setTimeout(function () {
                        dTable.ajax.reload(null, false);
                    }, 1500);
                });
            }
        })
    });
</script>
<style>
	.btn-action {
		text-decoration: none;
	}

	label,
	input {
		display: block;
	}

	input.text {
		margin-bottom: 12px;
		width: 95%;
		padding: .4em;
	}

	fieldset {
		padding: 0;
		border: 0;
		margin-top: 25px;
	}

	h1 {
		font-size: 1.2em;
		margin: .6em 0;
	}

	div#users-contain {
		width: 350px;
		margin: 20px 0;
	}

	div#users-contain table {
		margin: 1em 0;
		border-collapse: collapse;
		width: 100%;
	}

	div#users-contain table td,
	div#users-contain table th {
		border: 1px solid #eee;
		padding: .6em 10px;
		text-align: left;
	}

	.ui-dialog .ui-state-error {
		padding: .3em;
	}

	.validateTips {
		border: 1px solid transparent;
		padding: 0.3em;
	}

	#search-form-container select {
		margin-right: 20px;
	}

	#search-form-container label {
		padding-top: 4px;
		margin-right: 3px;
	}

	#search-form-container input {
		height: 25px;
		margin-top: 1px;
		margin-right: 3px;
	}

	#search-form {
		padding-top: 10px;
	}

	#module-option,
	#search-form {
		display: flex;
	}

	#search-table {
		width: 100%;
		margin-top: 10px;
	}

	.dataTables_wrapper {
		margin-top: 10px;
	}
</style>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">