<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

if (!$USER->IsAdmin())
    return;


\CJSCore::Init(array("jquery"));

IncludeModuleLangFile($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/options.php");
IncludeModuleLangFile(__FILE__);

$chars = "qazxswedcvfrtgbnhyujmkiolp1234567890QAZXSWEDCVFRTGBNHYUJMKIOLP";
$max = 20;
$size = StrLen($chars)-1;
$password_key = null;
while ($max--) $password_key .= $chars[rand(0,$size)];


$arAllOptions = array(
    array("search_page_url", GetMessage("SIMAI_P4IB_SPU"), "#SITE_DIR#search/?tags=#TAG#", array("text", 50)),

    array("newtab"),

    array("heading", GetMessage('SP4I_NOTIF_PASS')),

    array("act",
        GetMessage('SP4I_ACT'),
        "0",
        array("select", array(
            "0" => GetMessage('SP4I_ACT0'),
            "1" => GetMessage('SP4I_ACT1'),
            "2" => GetMessage('SP4I_ACT2'),
        ))),
    array("class_act"),

    array("admin_check", GetMessage('SP4I_ADMINCHECK'), "", array("checkbox", 0), ""),

    array("method_send",
            GetMessage('SP4I_METHOD'),
            "message",
            array("select", array(
                "message" => GetMessage('SP4I_METHOD0'),
                "mail" => GetMessage('SP4I_METHOD1'),
    ))),

    array("install_im", GetMessage('SP4I_IM')),
    array("inp_idchat", GetMessage('SP4I_ID'), "1", array("text", 50), "web-message"),
    array('adm-info', GetMessage('SP4I_ID_INFO'), "", array("adm-info")),
    array("send_message",
            GetMessage('SP4I_SEND'),
            "system",
            array("select", array(
                "system" => GetMessage('SP4I_SEND0'),
                "user" => GetMessage('SP4I_SEND1'),
            )),
            "web-message"),
    array("user_message", GetMessage('SP4I_SENDER'), "", array("user", 50), "web-message__user"),
    array("mail_chat", GetMessage('SP4I_MAIL'), COption::GetOptionString("main", "email_from"), array("text", 50), "e-mail"),
    array("macros", GetMessage('SP4I_TEMPLATE'), GetMessage('SP4I_MACROS'), array("textarea", 3, 60), "web-message3"),
    array("macros2", GetMessage('SP4I_TEMPLATE2'), GetMessage('SP4I_MACROS2'), array("textarea", 3, 60), "web-message2"),
    array("macros3", GetMessage('SP4I_TEMPLATE3'), GetMessage('SP4I_MACROS3'), array("textarea", 3, 60), "web-message2"),
    array("macros4", GetMessage('SP4I_TEMPLATE4'), GetMessage('SP4I_MACROS4'), array("textarea", 3, 60), "web-message"),

    array("class_endact"),
);

$aTabs = array(
    array("DIV" => "edit1", "TAB" => GetMessage("OPTIONS_TAB_1"), "ICON" => "ib_settings", "TITLE" => GetMessage("OPTIONS_TAB_1_TITLE")),
    array('DIV' => 'edit2', 'TAB' => GetMessage('OPTIONS_TAB_2'), 'ICON' => 'ib_settings', 'TITLE' => GetMessage('OPTIONS_TAB_2_TITLE')),
);
$tabControl = new CAdminTabControl("tabControl", $aTabs);

if (($_REQUEST["Update"] || $_REQUEST["RestoreDefaults"]) && check_bitrix_sessid()) {
    if ($_REQUEST["RestoreDefaults"]) {
        COption::RemoveOption("simai.property4iblock");
        COption::SetOptionString("simai.property4iblock", "search_page_url", "#SITE_DIR#search/?tags=#TAG#");
        COption::SetOptionString("simai.property4iblock", "method_send", "message");
        COption::SetOptionString("simai.property4iblock", "inp_idchat", "1");
        COption::SetOptionString("simai.property4iblock", "send_message", "system");
        COption::SetOptionString("simai.property4iblock", "user_message", "");
        COption::SetOptionString("simai.property4iblock", "user_message2", "");
        COption::SetOptionString("simai.property4iblock", "user_message3", "");
        COption::SetOptionString("simai.property4iblock", "mail_chat", "");
        COption::SetOptionString("simai.property4iblock", "macros", GetMessage('SP4I_MACROS'));
        COption::SetOptionString("simai.property4iblock", "macros2", GetMessage('SP4I_MACROS2'));
        COption::SetOptionString("simai.property4iblock", "macros3", GetMessage('SP4I_MACROS3'));
        COption::SetOptionString("simai.property4iblock", "macros4", GetMessage('SP4I_MACROS4'));
    } else {
        foreach ($arAllOptions as $arOption) {
            $name = $arOption[0];
            $val = $_REQUEST[$name];
            if ($arOption[2][0] == "checkbox" && $val != "Y")
                $val = "N";
            COption::SetOptionString("simai.property4iblock", $name, $val, $arOption[1]);
        }
    }
    if ($_REQUEST["Update"] && strlen($_REQUEST["back_url_settings"]) > 0)
        LocalRedirect($_REQUEST["back_url_settings"]);
    else
        LocalRedirect($APPLICATION->GetCurPage() . "?mid=" . urlencode($mid) . "&lang=" . urlencode(LANGUAGE_ID) . "&back_url_settings=" . urlencode($_REQUEST["back_url_settings"]) . "&" . $tabControl->ActiveTabParam());
}


$tabControl->Begin();
?>
<form method="post"
      action="<? echo $APPLICATION->GetCurPage() ?>?mid=<?= urlencode($mid) ?>&amp;lang=<? echo LANGUAGE_ID ?>">
    <? $tabControl->BeginNextTab(); ?>
    <?
    foreach ($arAllOptions as $arOption):
        if ($arOption[0] == "newtab") $tabControl->BeginNextTab();
        if ($arOption[0] == "class_act") echo "<tbody class='st-act'>";


        $val = COption::GetOptionString("simai.property4iblock", $arOption[0], $arOption[2]);
        $type = $arOption[3];

        ?>
        <? if ($arOption[0] == "heading") { ?>
            <tr class="heading">
                <td colspan="2">
                    <?=$arOption[1]?>
                </td>
            </tr>
        <? } else if ($arOption[0] == "adm-info") { ?>
        <tr>
            <td colspan="2" align="center">
                <div class="adm-info-message-wrap" align="center">
                    <div class="adm-info-message">
                        <?=$arOption[1]?>
                    </div>
                </div>
            </td>
        </tr>
        <? } else if ($arOption[0] == "install_im") { ?>
            <? if (!CModule::IncludeModule("im")) {?>
                <tr class="web-message">
                    <td colspan="2" align="center">
                        <div class="adm-info-message-wrap adm-info-message-red" align="center">
                            <div class="adm-info-message">
                                <?=$arOption[1]?>
                                <div class="adm-info-message-icon"></div>
                            </div>
                        </div>
                    </td>
                </tr>
            <? } ?>
        <? } else { ?>
        <tr <?=(!empty($arOption[4]))?'class="'.$arOption[4].'"':'';?>>
            <td valign="middle" width="50%"><?
                if ($type[0] == "checkbox")
                    echo "<label for=\"" . htmlspecialcharsbx($arOption[0]) . "\">" . $arOption[1] . "</label>";
                else if (!empty($arOption[1])):
                    echo $arOption[1];?>:
                <?endif;?>
            </td>
            <td valign="middle" width="50%">
                <? if ($type[0] == "checkbox"):?>
                    <input type="checkbox" id="<? echo htmlspecialcharsbx($arOption[0]) ?>"
                           name="<? echo htmlspecialcharsbx($arOption[0]) ?>"
                           value="Y"<? if ($val == "Y") echo " checked"; ?>>
                <? elseif ($type[0] == "text"):?>
                    <input type="text" size="<? echo $type[1] ?>" maxlength="255"
                           value="<? echo htmlspecialcharsbx($val) ?>" name="<? echo htmlspecialcharsbx($arOption[0]) ?>">
                <? elseif ($type[0] == "textarea"):?>
                    <textarea rows="<? echo $type[1] ?>" cols="<? echo $type[2] ?>" style="vertical-align: text-bottom;"
                              name="<? echo htmlspecialcharsbx($arOption[0]) ?>" class="<? echo $arOption[4] ?>"><? echo htmlspecialcharsbx($val) ?></textarea>
                <? elseif ($type[0] == "select"):?>
                    <select style="width:300px" name="<? echo htmlspecialcharsbx($arOption[0]) ?>" id="id_<? echo htmlspecialcharsbx($arOption[0]) ?>">
                        <? foreach ($arOption[3][1] as $key=>$option) { ?>
                            <option value="<?=$key?>" <?=($val==$key)?'selected':'';?>><?=$option?></option>
                        <? } ?>
                    </select>
                <? elseif ($type[0] == "number"):?>
                    <input type="number"
                           value="<? echo htmlspecialcharsbx($val) ?>" name="<? echo htmlspecialcharsbx($arOption[0]) ?>">
                <? elseif ($type[0] == "note"):?>
                    <input type="text" size="<? echo $type[1] ?>" id="id_<? echo htmlspecialcharsbx($arOption[0]) ?>"
                           value="<? echo $val ?>" name="<? echo htmlspecialcharsbx($arOption[0]) ?>" readonly>
                <? elseif ($type[0] == "button"):?>
                    <input type="button" id="id_<? echo htmlspecialcharsbx($arOption[0]) ?>"
                           value="<? echo htmlspecialcharsbx($val) ?>" name="<? echo htmlspecialcharsbx($arOption[0]) ?>">
                <? elseif ($type[0] == "user"):?>
                <?
                    $user_selector = ( is_dir($_SERVER["DOCUMENT_ROOT"] . "/bitrix/components/bitrix/main.user.selector") );
                    
                    if ($user_selector):
                    
                        $GLOBALS["APPLICATION"]->IncludeComponent(
                            'bitrix:main.user.selector',
                            ' ',
                            [
                                "ID" => "mail_client_config_queue",
                                "API_VERSION" => 3,
                                "LIST" => array(htmlspecialcharsbx($val)),
                                "INPUT_NAME" => htmlspecialcharsbx($arOption[0]),
                                "USE_SYMBOLIC_ID" => true,
                                "BUTTON_SELECT_CAPTION" => GetMessage('SP4I_USER_EDIT'),
                                "SELECTOR_OPTIONS" =>
                                    [
                                        "departmentSelectDisable" => "Y",
                                        'context' => 'MAIL_CLIENT_CONFIG_QUEUE',
                                        'contextCode' => 'U',
                                        'enableAll' => 'N',
                                        'userSearchArea' => 'I'
                                    ]
                            ]
                        );
                        
                    else:
                    ?>
                    
                    <input type="text" name="<?=htmlspecialcharsbx($arOption[0])?>" value="<?=htmlspecialcharsbx($val)?>">
                    
                    <?
                    endif;
                ?>
                <? endif ?>

                <?

                if(CRsaSecurity::Possible())
                {
                    $sec = new CRsaSecurity();
                    $arKeys = $sec->LoadKeys();

                    $mess = ($arKeys === false? GetMessage("MAIN_OPT_SECURE_KEY_NOT_FOUND") : GetMessage("MAIN_OPT_SECURE_KEY", array("#KEYLEN#"=>$arKeys["chunk"]*8)));
                    $mess .= '<br><br><input type="button" name="" value="'.GetMessage("MAIN_OPT_SECURE_GENKEY").'" onclick="window.location=\'/bitrix/admin/settings.php?GenKey=Y&lang='.LANGUAGE_ID.'&mid='.urlencode($mid).'&'.bitrix_sessid_get().'&tabControl_active_tab=edit6\'">';

                    $arAllOptions["auth"][] = Array("", GetMessage("MAIN_OPT_SECURE_KEY_LABEL"), $mess, Array("statichtml"));

                    if($sec->GetLib() == 'bcmath')
                        $arAllOptions["auth"][] = array("note"=>GetMessage("MAIN_OPT_SECURE_NOTE"));
                }
                else
                {
                    $arAllOptions["auth"][] = array("note"=>GetMessage("MAIN_OPT_EXT_NOTE"));
                }

                ?>



            </td>
        </tr>
        <? } ?>


        <? if ($arOption[0] == "class_endact") echo "</tbody>"; ?>
    <? endforeach ?>

    <? $tabControl->Buttons(); ?>
    <input type="submit" name="Update" value="<?= GetMessage("MAIN_SAVE") ?>"
           title="<?= GetMessage("MAIN_OPT_SAVE_TITLE") ?>">
    <input type="submit" name="RestoreDefaults" title="<? echo GetMessage("MAIN_HINT_RESTORE_DEFAULTS") ?>"
           OnClick="confirm('<? echo AddSlashes(GetMessage("MAIN_HINT_RESTORE_DEFAULTS_WARNING")) ?>')"
           value="<? echo GetMessage("MAIN_RESTORE_DEFAULTS") ?>">
    <?= bitrix_sessid_post(); ?>
    <? $tabControl->End(); ?>


</form>


<script>
    BX.ready(function(){


            [].forEach.call(document.querySelectorAll(".st-modul"), function (el) {
                el.style.display  = "table-row";
            });

            if (BX("id_act").value == "0") {
                [].forEach.call(document.querySelectorAll(".st-act"), function (el) {
                    el.style.display  = "none";
                });
            } else {
                [].forEach.call(document.querySelectorAll(".st-act"), function (el) {
                    el.style.display  = "table-row-group";
                });
            }

            if (BX("id_act").value == "2") {
                [].forEach.call(document.querySelectorAll(".web-message2"), function (el) {
                    el.style.display  = "none";
                });
                [].forEach.call(document.querySelectorAll(".web-message3"), function (el) {
                    el.style.display  = "table-row";
                });
            } else {
                [].forEach.call(document.querySelectorAll(".web-message2"), function (el) {
                    el.style.display  = "table-row";
                });
                [].forEach.call(document.querySelectorAll(".web-message3"), function (el) {
                    el.style.display  = "none";
                });
            }


            if (BX("id_method_send").value == "message") {
                [].forEach.call(document.querySelectorAll(".web-message"), function (el) {
                    el.style.display  = "table-row";
                });
                [].forEach.call(document.querySelectorAll(".e-mail"), function (el) {
                    el.style.display  = "none";
                });
                [].forEach.call(document.querySelectorAll(".web-message__user"), function (el) {
                    el.style.display  = "table-row";
                });
            } else {
                [].forEach.call(document.querySelectorAll(".web-message"), function (el) {
                    el.style.display  = "none";
                });
                [].forEach.call(document.querySelectorAll(".e-mail"), function (el) {
                    el.style.display  = "table-row";
                });
                [].forEach.call(document.querySelectorAll(".web-message__user"), function (el) {
                    el.style.display  = "none";
                });
            }

            if (BX("id_send_message").value == "system") {
                [].forEach.call(document.querySelectorAll(".web-message__user"), function (el) {
                    el.style.display  = "none";
                });
            } else {
                [].forEach.call(document.querySelectorAll(".web-message__user"), function (el) {
                    el.style.display  = "table-row";
                });
            }


        BX.bind(
            BX("id_act"),
            "change",
            function()
            {
                if (BX("id_act").value == "0") {
                    [].forEach.call(document.querySelectorAll(".st-act"), function (el) {
                        el.style.display  = "none";
                    });
                } else {
                    [].forEach.call(document.querySelectorAll(".st-act"), function (el) {
                        el.style.display  = "table-row-group";
                    });
                }
                if (BX("id_act").value == "2") {
                    [].forEach.call(document.querySelectorAll(".web-message2"), function (el) {
                        el.style.display  = "none";
                    });
                    [].forEach.call(document.querySelectorAll(".web-message3"), function (el) {
                        el.style.display  = "table-row";
                    });
                } else {
                    [].forEach.call(document.querySelectorAll(".web-message2"), function (el) {
                        el.style.display  = "table-row";
                    });
                    [].forEach.call(document.querySelectorAll(".web-message3"), function (el) {
                        el.style.display  = "none";
                    });
                }
            }
        );
        BX.bind(
            BX("id_send_message"),
            "change",
            function()
            {
                if (BX("id_send_message").value == "system") {
                    [].forEach.call(document.querySelectorAll(".web-message__user"), function (el) {
                        el.style.display  = "none";
                    });
                } else {
                    [].forEach.call(document.querySelectorAll(".web-message__user"), function (el) {
                        el.style.display  = "table-row";
                    });
                }
            }
        );
        BX.bind(
            BX("id_method_send"),
            "change",
            function()
            {
                if (BX("id_method_send").value == "message") {
                    [].forEach.call(document.querySelectorAll(".web-message"), function (el) {
                        el.style.display  = "table-row";
                    });
                    [].forEach.call(document.querySelectorAll(".e-mail"), function (el) {
                        el.style.display  = "none";
                    });
                    if (BX("id_send_message").value != "system") {
                        [].forEach.call(document.querySelectorAll(".web-message__user"), function (el) {
                            el.style.display  = "table-row";
                        });
                    }
                } else {
                    [].forEach.call(document.querySelectorAll(".web-message"), function (el) {
                        el.style.display  = "none";
                    });
                    [].forEach.call(document.querySelectorAll(".e-mail"), function (el) {
                        el.style.display  = "table-row";
                    });
                    [].forEach.call(document.querySelectorAll(".web-message__user"), function (el) {
                        el.style.display  = "none";
                    });
                }
            }
        );

    });
</script>