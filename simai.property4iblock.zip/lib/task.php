<?php
IncludeModuleLangFile(__FILE__);

use Bitrix\Iblock;
use Bitrix\Main\Application;
use Bitrix\Main\IO;
use Bitrix\Main\File\Image;
use Bitrix\Main\Loader;

class CCustomTypeSimaiTask
{
    public static function GetUserTypeDescription()
    {
        return array(
            'PROPERTY_TYPE' => 'N',
            'USER_TYPE' => 'simai_task',
            'DESCRIPTION' => GetMessage('SMPI_TASK_PROP'),
            'PrepareSettings' => array('CCustomTypeSimaiTask', 'PrepareSettings'),
            'GetSettingsHTML' => array('CCustomTypeSimaiTask', 'GetSettingsHTML'),
            'GetPropertyFieldHtml' => array('CCustomTypeSimaiTask', 'GetPropertyFieldHtml'),
            'GetPropertyFieldHtmlMulty' => array('CCustomTypeSimaiTask', 'GetPropertyFieldHtmlMulty'),
            'GetPublicEditHTML' => array('CCustomTypeSimaiTask', 'GetPublicEditHTML'),
            'ConvertToDB' => array('CCustomTypeSimaiTask', 'ConvertToDB'),
            'ConvertFromDB' => array('CCustomTypeSimaiTask', 'ConvertFromDB'),
            'GetPublicViewHTML' => array('CCustomTypeSimaiTask', 'GetPublicViewHTML'),
            'GetSearchContent' => array('CCustomTypeSimaiTask', 'GetSearchContent'),
            'GetAdminFilterHTML' => array('CCustomTypeSimaiTask', 'GetAdminFilterHTML'),
            'GetAdminListViewHTML' => array('CCustomTypeSimaiTask', 'GetAdminListViewHTML'),
        );
    }

    public static function PrepareSettings($arFields)
    {
        //return array("TASK_URL_TEMPLATE" => trim($arFields["USER_TYPE_SETTINGS"]["TASK_URL_TEMPLATE"]));
        return array();
    }

    public static function GetSettingsHTML($arProperty, $strHTMLControlName, &$arPropertyFields)
    {
        $arPropertyFields = array(
            "HIDE" => array("ROW_COUNT", "COL_COUNT", "DEFAULT_VALUE", "WITH_DESCRIPTION", "SEARCHABLE", "SMART_FILTER", "DISPLAY_TYPE", "EXPANDED"),
            "SET" => array("FILTRABLE" => "Y", "SEARCHABLE" => "Y", "SMART_FILTER" => "N", "MULTIPLE_CNT" => "1"),
            //"USER_TYPE_SETTINGS_TITLE" => GetMessage('SMPI_SELECT_SUBPROPS')
        );

        $return = "";

        /*$return .= '
        <tr>
        <td>'.GetMessage('SMPI_TASK_URL_TEMPLATE').':</td>
        <td>
        <input type="text" name="'.$strHTMLControlName["NAME"].'[TASK_URL_TEMPLATE]" style="width:270px;" value="'.$arProperty["USER_TYPE_SETTINGS"]["TASK_URL_TEMPLATE"].'">
        <br /><small>'.GetMessage('SMPI_TASK_URL_TEMPLATE_HINT').'<small>
        </td>
        </tr>';*/

        return $return;
    }

    public static function GetPropertyFieldHtml($arProperty, $value, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION;

        $TASK_URL_TEMPLATE = COption::GetOptionString("tasks", "paths_task_user_entry", "");

        ob_start();

        if ($_REQUEST['mode'] == 'frame') {
            ?>
            <input type="text" name="<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>" size="4"
                   value="<?= htmlspecialchars($value["VALUE"]) ?>"/>
            <?
        } else {
            if (!is_array($value) || isset($value['VALUE']))
                $value = array($value);

            $vals = array();

            foreach ($value as $key => $val) {
                if (isset($val['VALUE']))
                    $vals[$key] = $val['VALUE'];
                else
                    $vals[$key] = $val;
            }

            $APPLICATION->IncludeComponent(
                "simai:task.selector", ".default", array(
                "MULTIPLE" => "N",
                "VALUE" => $vals,
                "PATH_TO_TASKS_TASK" => $TASK_URL_TEMPLATE,
                "SITE_ID" => SITE_ID,
                "PROPERTY_ID" => $arProperty["ID"],
            ), null, array("HIDE_ICONS" => "Y")
            );

        }

        $strResult = ob_get_contents();
        ob_end_clean();

        return $strResult;
    }

    public static function GetPropertyFieldHtmlMulty($arProperty, $value, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION;

        $TASK_URL_TEMPLATE = COption::GetOptionString("tasks", "paths_task_user_entry", "");

        ob_start();

        if ($_REQUEST['mode'] == 'frame') {
            foreach ($value as $key => $val) {
                ?>
                <input type="text" name="<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>[<?= $key ?>]" size="4"
                       value="<?= htmlspecialchars($val["VALUE"]) ?>"/><br/>
                <?
            }
            for ($i = 0; $i < 3; $i++) {
                ?>
                <input type="text" name="<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>[n<?= $i ?>]" size="4"
                       value=""/><br/>
                <?
            }
        } else {
            if (!is_array($value))
                $value = array($value);

            $vals = array();

            foreach ($value as $key => $val) {
                if (isset($val['VALUE']))
                    $vals[$key] = $val['VALUE'];
                else
                    $vals[$key] = $val;
            }

            $APPLICATION->IncludeComponent(
                "simai:task.selector", ".default", array(
                "MULTIPLE" => "Y",
                "VALUE" => $vals,
                "PATH_TO_TASKS_TASK" => $TASK_URL_TEMPLATE,
                "SITE_ID" => SITE_ID,
                "PROPERTY_ID" => $arProperty["ID"],
            ), null, array("HIDE_ICONS" => "Y")
            );
        }

        $strResult = ob_get_contents();
        ob_end_clean();

        return $strResult;
    }

    public static function GetPublicEditHTML($arProperty, $value, $strHTMLControlName)
    {
        global $APPLICATION;

        $TASK_URL_TEMPLATE = COption::GetOptionString("tasks", "paths_task_user_entry", "");

        ob_start();

        if ($arProperty["MULTIPLE"] != "Y"):

            $APPLICATION->SetAdditionalCSS('/bitrix/components/simai/task.selector/templates/public_mult/style.css');
            $APPLICATION->AddHeadScript('/bitrix/components/simai/task.selector/templates/public_mult/clr.js');
            ?>
            <div class="spi4ib">
            <span>
            <? if ($value["VALUE"] > 0):
                if (CModule::IncludeModule("tasks")):
                    $rsTask = CTasks::GetByID($value['VALUE']);
                    if ($arTask = $rsTask->GetNext()):?>
                        <div class="finder-box-selected-item-icon" onclick="S4IBClearMField(this)"
                             id="task-unselect-<?= intval($value["VALUE"]) ?>"></div><a
                                href="<?= str_replace('#user_id#', $arTask["RESPONSIBLE_ID"], str_replace('#task_id#', $arTask["ID"], $TASK_URL_TEMPLATE)) ?>"
                                target="_blank" class="finder-box-selected-item-text"><?= $arTask["TITLE"] ?></a>&nbsp;
                    <?endif;
                endif;
            endif ?>
            </span>
                <input type="hidden" name="<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>"
                       value="<?= htmlspecialchars($value["VALUE"]) ?>"/>
                <input type="button" value="...<?//=GetMessage('SMPI_SELECT_TASK')
                ?>"
                       onclick="jsUtils.OpenWindow('/simai/admin/simai_p4ib_public_mult.php?t=<?= time() ?>&inp=<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>&value=&prop_id=<?= htmlspecialchars($arProperty["ID"]) ?>', 500, 500)">
            </div>
        <?

        else:

            $APPLICATION->SetAdditionalCSS('/bitrix/components/simai/task.selector/templates/public_mult/style.css');
            $APPLICATION->AddHeadScript('/bitrix/components/simai/task.selector/templates/public_mult/clr.js');
            ?>
            <div class="spi4ib">
            <span>
            <? if ($value["VALUE"] > 0):
                if (CModule::IncludeModule("tasks")):
                    $rsTask = CTasks::GetByID($value['VALUE']);
                    if ($arTask = $rsTask->GetNext()):?>
                        <div class="finder-box-selected-item-icon" onclick="S4IBClearMField(this)"
                             id="task-unselect-<?= intval($value["VALUE"]) ?>"></div><a
                                href="<?= str_replace('#user_id#', $arTask["RESPONSIBLE_ID"], str_replace('#task_id#', $arTask["ID"], $TASK_URL_TEMPLATE)) ?>"
                                target="_blank" class="finder-box-selected-item-text"><?= $arTask["TITLE"] ?></a>&nbsp;
                    <?endif;
                endif;
            endif ?>
            </span>
                <input type="hidden" name="<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>"
                       value="<?= htmlspecialchars($value["VALUE"]) ?>"/>
                <input type="button" value="...<?//=GetMessage('SMPI_SELECT_TASK')
                ?>"
                       onclick="jsUtils.OpenWindow('/simai/admin/simai_p4ib_public_mult.php?t=<?= time() ?>&inp=<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>&value=&prop_id=<?= htmlspecialchars($arProperty["ID"]) ?>', 500, 500)">
            </div>
        <?
        endif;

        $strResult = ob_get_contents();
        ob_end_clean();

        return $strResult;
    }

    public static function ConvertToDB($arProperty, $value)
    {
        return $value;
    }

    public static function ConvertFromDB($arProperty, $value)
    {
        return $value;
    }

    public static function GetPublicViewHTML($arProperty, $value, $strHTMLControlName)
    {
        if ($value['VALUE'] > 0) {
            if (CModule::IncludeModule("tasks")) {
                $TASK_URL_TEMPLATE = COption::GetOptionString("tasks", "paths_task_user_entry", "");

                $rsTask = CTasks::GetByID($value['VALUE']);
                if ($arTask = $rsTask->GetNext()) {
                    return '[' . $arTask["ID"] . ']&nbsp;<a target="_blank" href="' . str_replace('#user_id#', $arTask["RESPONSIBLE_ID"], str_replace('#task_id#', $arTask["ID"], $TASK_URL_TEMPLATE)) . '">' . $arTask["TITLE"] . '</a>';
                }
            }
        }

        return '';
    }

    public static function GetSearchContent($arProperty, $value, $strHTMLControlName)
    {
        if ($value['VALUE'] > 0) {
            if (CModule::IncludeModule("tasks")) {
                $TASK_URL_TEMPLATE = COption::GetOptionString("tasks", "paths_task_user_entry", "");

                $rsTask = CTasks::GetByID($value['VALUE']);
                if ($arTask = $rsTask->GetNext()) {
                    return $arTask["ID"] . ' ' . $arTask["TITLE"];
                }
            }
        }

        return '';
    }

    public static function GetAdminFilterHTML($arProperty, $strHTMLControlName)
    {
        global $APPLICATION;

        $TASK_URL_TEMPLATE = COption::GetOptionString("tasks", "paths_task_user_entry", "");

        $APPLICATION->SetAdditionalCSS('/bitrix/components/simai/task.selector/templates/public_mult/style.css');
        $APPLICATION->AddHeadScript('/bitrix/components/simai/task.selector/templates/public_mult/clr.js');

        ob_start();
        ?>
        <div class="spi4ib spi4ib_a" style="padding-left:20px;">
        <span>
        <?
        $value = $GLOBALS[$strHTMLControlName["VALUE"]];
        if ($value > 0):
            if (CModule::IncludeModule("tasks")):
                $rsTask = CTasks::GetByID($value);
                if ($arTask = $rsTask->GetNext()):?>
                    <div class="finder-box-selected-item-icon" onclick="S4IBClearMField(this)"
                         id="task-unselect-<?= intval($value) ?>"></div><a
                            href="<?= str_replace('#user_id#', $arTask["RESPONSIBLE_ID"], str_replace('#task_id#', $arTask["ID"], $TASK_URL_TEMPLATE)) ?>"
                            target="_blank" class="finder-box-selected-item-text"><?= $arTask["TITLE"] ?></a>&nbsp;
                <?endif;
            endif;
        endif ?>
        </span>
            <input type="text" name="<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>" size="2"
                   value="<?= htmlspecialchars($value) ?>" style="display:none"/>
            <input type="button" value="...<?//=GetMessage('SMPI_SELECT_TASK')
            ?>"
                   onclick="jsUtils.OpenWindow('/bitrix/admin/simai_p4ib_public_mult.php?t=<?= time() ?>&inp=<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>&value=&prop_id=<?= htmlspecialchars($arProperty["ID"]) ?>', 500, 500)">
        </div>
        <?

        $strResult = ob_get_contents();
        ob_end_clean();

        return $strResult;
    }

    public static function GetAdminListViewHTML($arProperty, $value, $strHTMLControlName)
    {
        if ($value['VALUE'] > 0) {
            if (CModule::IncludeModule("tasks")) {
                $TASK_URL_TEMPLATE = COption::GetOptionString("tasks", "paths_task_user_entry", "");

                $rsTask = CTasks::GetByID($value['VALUE']);
                if ($arTask = $rsTask->GetNext()) {
                    return '[' . $arTask["ID"] . ']&nbsp;<a target="_blank" href="' . str_replace('#user_id#', $arTask["RESPONSIBLE_ID"], str_replace('#task_id#', $arTask["ID"], $TASK_URL_TEMPLATE)) . '">' . $arTask["TITLE"] . '</a>';
                }
            }
        }

        return '';
    }

    public static function GetPublicFilterHTML($arProperty, $strHTMLControlName)
    {
        global $APPLICATION;

        $TASK_URL_TEMPLATE = COption::GetOptionString("tasks", "paths_task_user_entry", "");

        $APPLICATION->SetAdditionalCSS('/bitrix/components/simai/task.selector/templates/public_mult/style.css');
        $APPLICATION->AddHeadScript('/bitrix/components/simai/task.selector/templates/public_mult/clr.js');

        $value = $_REQUEST[$strHTMLControlName["VALUE"]];

        ob_start();

        ?>
        <div class="spi4ib">
        <span>
        <?
        $value = $GLOBALS[$strHTMLControlName["VALUE"]];
        if ($value > 0):
            if (CModule::IncludeModule("tasks")):
                $rsTask = CTasks::GetByID($value);
                if ($arTask = $rsTask->GetNext()):?>
                    <div class="finder-box-selected-item-icon" onclick="S4IBClearMField(this)"
                         id="task-unselect-<?= intval($value) ?>"></div><a
                            href="<?= str_replace('#user_id#', $arTask["RESPONSIBLE_ID"], str_replace('#task_id#', $arTask["ID"], $TASK_URL_TEMPLATE)) ?>"
                            target="_blank" class="finder-box-selected-item-text"><?= $arTask["TITLE"] ?></a>&nbsp;
                <?endif;
            endif;
        endif ?>
        </span>
            <input type="text" name="<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>" size="2"
                   value="<?= htmlspecialchars($value) ?>" style="display:none"/>
            <input type="button" value="...<?//=GetMessage('SMPI_SELECT_TASK')
            ?>"
                   onclick="jsUtils.OpenWindow('/simai/admin/simai_p4ib_public_mult.php?t=<?= time() ?>&inp=<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>&value=&prop_id=<?= htmlspecialchars($arProperty["ID"]) ?>', 500, 500)">
        </div>
        <?

        $strResult = ob_get_contents();
        ob_end_clean();

        return $strResult;
    }
}
