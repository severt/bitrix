<?php
IncludeModuleLangFile(__FILE__);

use Bitrix\Iblock;
use Bitrix\Main\Application;
use Bitrix\Main\IO;
use Bitrix\Main\File\Image;
use Bitrix\Main\Loader;

class CCustomTypeSimaiUser
{
    public static function GetUserTypeDescription()
    {
        return array(
            'PROPERTY_TYPE' => 'N',
            'USER_TYPE' => 'simai_user',
            'DESCRIPTION' => GetMessage('SMPI_USER_PROP'),
            'PrepareSettings' => array('CCustomTypeSimaiUser', 'PrepareSettings'),
            'GetSettingsHTML' => array('CCustomTypeSimaiUser', 'GetSettingsHTML'),
            'GetPropertyFieldHtml' => array('CCustomTypeSimaiUser', 'GetPropertyFieldHtml'),
            'GetPropertyFieldHtmlMulty' => array('CCustomTypeSimaiUser', 'GetPropertyFieldHtmlMulty'),
            'GetPublicEditHTML' => array('CCustomTypeSimaiUser', 'GetPublicEditHTML'),
            'ConvertToDB' => array('CCustomTypeSimaiUser', 'ConvertToDB'),
            'ConvertFromDB' => array('CCustomTypeSimaiUser', 'ConvertFromDB'),
            'GetPublicViewHTML' => array('CCustomTypeSimaiUser', 'GetPublicViewHTML'),
            'GetSearchContent' => array('CCustomTypeSimaiUser', 'GetSearchContent'),
            'GetAdminFilterHTML' => array('CCustomTypeSimaiUser', 'GetAdminFilterHTML'),
            'GetAdminListViewHTML' => array('CCustomTypeSimaiUser', 'GetAdminListViewHTML'),
        );
    }

    public static function PrepareSettings($arFields)
    {
        //return array("TASK_URL_TEMPLATE" => trim($arFields["USER_TYPE_SETTINGS"]["TASK_URL_TEMPLATE"]));
        return array();
    }

    public static function GetSettingsHTML($arProperty, $strHTMLControlName, &$arPropertyFields)
    {
        $arPropertyFields = array(
            "HIDE" => array("ROW_COUNT", "COL_COUNT", "DEFAULT_VALUE", "WITH_DESCRIPTION", "SEARCHABLE", "SMART_FILTER", "DISPLAY_TYPE", "EXPANDED"),
            "SET" => array("FILTRABLE" => "Y", "SEARCHABLE" => "Y", "SMART_FILTER" => "N", "MULTIPLE_CNT" => "1"),
            //"USER_TYPE_SETTINGS_TITLE" => GetMessage('SMPI_SELECT_SUBPROPS')
        );

        $return = "";

        /*$return .= '
        <tr>
        <td>'.GetMessage('SMPI_TASK_URL_TEMPLATE').':</td>
        <td>
        <input type="text" name="'.$strHTMLControlName["NAME"].'[TASK_URL_TEMPLATE]" style="width:270px;" value="'.$arProperty["USER_TYPE_SETTINGS"]["TASK_URL_TEMPLATE"].'">
        <br /><small>'.GetMessage('SMPI_TASK_URL_TEMPLATE_HINT').'<small>
        </td>
        </tr>';*/

        return $return;
    }

    public static function GetPropertyFieldHtml($arProperty, $value, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION;



        ob_start();

       if ($_REQUEST['mode'] == 'frame') {
            foreach ($value as $key => $val) {

                ?>
                <input type="text" name="<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>[<?= $key ?>]" size="4"
                       value="<?= htmlspecialchars($val["VALUE"]) ?>"/><br/>
                <?
            }
            for ($i = 0; $i < 3; $i++) {
                ?>
                <input type="text" name="<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>[n<?= $i ?>]" size="4"
                       value=""/><br/>
                <?
            }
        } else {
           //CModule::IncludeModule('support');
            if (!is_array($value))
                $value = array($value);

            $vals = array();
            foreach ($value as $key => $val) {
                if (isset($val['VALUE']))
                    $vals[$key] = $val['VALUE'];
                else
                    $vals[$key] = $val;
            }
            $i = 1;
            foreach ($vals as $k => $user) {
                if ($k == "VALUE") :
                    if ($user) :
                        $rsUser = CUser::GetByID($user);

                        if ($arUser = $rsUser->GetNext()):?>
                            <input type="hidden" id="selectedUserInput" value="<?=$arUser['ID']?>" name=<?=htmlspecialchars($strHTMLControlName["VALUE"])?> 
                                style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
                            <a href="#modal_window" onclick="choiceProp('choiceUser', 'modal_window_user');">Выбрать</a>
                            <span id="selectedUser"><i>[<?=$arUser['ID']?>] </i><?=$arUser['LOGIN']?></span>
                            <?$i++;
                        endif;
                    else :?>
                        <input type="hidden" id="selectedUserInput" value="" name=<?=htmlspecialchars($strHTMLControlName["VALUE"])?> 
                            style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
                        <a href="#modal_window" onclick="choiceProp('choiceUser', 'modal_window_user');">Выбрать</a>
                        <span id="selectedUser"> </span>
                    <?endif;
                endif;
            }

            $by = "id";
            $order = "asc";
            $arFilter = array();
            $rs = CUser::GetList($by, $order, $arFilter); 
            $users = [];
            while($ar = $rs->GetNext())
            {
                $users[] = ['str' => '[' . $ar['ID'] . '] ' . $ar['LOGIN'] . '<br>', 'id' => $ar['ID']];

            }
            CJSCore::Init(array("jquery"));
            ?>

            <div id="modal_window_user" style="display:none">
                <input class="type-search  finder-box-search-textbox" placeholder="Поиск" type="text" id="searchInputUser" value="" style="width:400px;"/><br>
                <span id="listUser">
                <?foreach ($users as $user) :?>
                    <span>
                        <i style="cursor: pointer;" onclick="
                            setProp('<?=$user['id']?>', '<?=$user['str']?>', 'selectedUser', 'selectedUserInput');
                            "><?=$user['str']?></i>
                    </span>
                <?endforeach;?>
                </span>
            </div>

            <?require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.property4iblock/admin/simai_p4ib_script.php");?>
            <script>
                search('#listUser', '#searchInputUser');
            </script>
        <?
        }

        $strResult = ob_get_contents();
        ob_end_clean();

        return $strResult;
    }

    public static function GetPropertyFieldHtmlMulty($arProperty, $value, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION;

        ob_start();

        CJSCore::Init(array("jquery"));
        if ($_REQUEST['mode'] == 'frame') {
            foreach ($value as $key => $val) {
                ?>
                <input type="text" name="<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>[<?= $key ?>]" size="4"
                       value="<?= htmlspecialchars($val["VALUE"]) ?>"/><br/>
                <?
            }
            for ($i = 0; $i < 3; $i++) {
                ?>
                <input type="text" name="<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>[n<?= $i ?>]" size="4"
                       value=""/><br/>
                <?
            }
        } else {
            //CModule::IncludeModule('support');
            if (!is_array($value))
                $value = array($value);

            $vals = array();

            foreach ($value as $key => $val) {
                if (isset($val['VALUE']))
                    $vals[$key] = $val['VALUE'];
                else
                    $vals[$key] = $val;
            }
            $i = 1;?>
            <div class="choiceUs">
                <?foreach ($vals as $user) {
                    $rsUser = CUser::GetByID($user);
                    if ($arUser = $rsUser->GetNext()):?>
                        <input type="hidden" id="selectedUserInput<?=$i?>" value="<?=$arUser['ID']?>" name=<?=htmlspecialchars($strHTMLControlName["VALUE"]).'[]'?> 
                            style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;"
                            class="inputUsers">
                        <div class="finder-box-selected-item-icon" id="removeUser<?=$i?>" style="cursor: pointer;" title="Убрать" 
                            onclick="removePropMulti('<?=$i?>', 'selectedUser', 'selectedUserInput', 'removeUser');"></div>
                        <span id="selectedUser<?=$i?>" data-cl=""><i>[<?=$arUser['ID']?>] </i><?=$arUser['LOGIN']?></span>
                        <br>
                        <?$i++;
                    endif;
                }?>
                    <input type="hidden" id="selectedUserInput<?=$i?>" value="" name=<?=htmlspecialchars($strHTMLControlName["VALUE"]).'[]'?> 
                        style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;"
                        class="inputUsers">
                    <div class="finder-box-selected-item-icon" id="removeUser<?=$i?>" 
                        style="cursor: pointer; display:none" title="Убрать" 
                        onclick="removePropMulti('<?=$i?>', 'selectedUser', 'selectedUserInput', 'removeUser');"></div>
                    <a class="addUserInput" href="#modal_window" 
                        onclick="choicePropMulti('<?=$i?>', 'choiceUser', 'modal_window_user', 'selectedUser', 'selectedUserInput', 'data-cl');">Добавить</a>
                    <span id="selectedUser<?=$i?>"> </span>
                    <div id="addUser"></div>
                <?
                $by = "id";
                $order = "asc";
                $arFilter = array();
                $rs = CUser::GetList($by, $order, $arFilter); 
                $users = [];
                while($ar = $rs->GetNext())
                {
                    $users[] = ['str' => '[' . $ar['ID'] . '] ' . $ar['LOGIN'] . '<br>', 'id' => $ar['ID']];
                }

                ?>
            </div>
            <div id="modal_window_user" style="display:none">
                <input class="type-search  finder-box-search-textbox" placeholder="Поиск" type="text" id="searchInputUser" value="" style="width:400px;"/><br>
                <span id="list_user_multi">
                <?$arIds = [];
                foreach ($users as $user) :?>
                    <span>
                        <i style="cursor: pointer;" onclick="
                            setUser('<?=$user['id']?>', '<?=$user['str']?>');
                            "><?=$user['str']?></i>
                    </span>
                <?$arIds[] = $user['id'];
                endforeach;?>
                </span>
            </div>

            <?require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.property4iblock/admin/simai_p4ib_script.php");?>
            <script>
                search('#list_user_multi', '#searchInputUser');
            </script>

            <script>

                function addRow(i, selectedUser, selectedUserInput, removeUser, inputUsers, addUserInput, modal_window_user, addUser, choiceUser, dataCl) {
                    const div = document.createElement('div');
                    div.className = 'row';
                    <?$i++;?>
                    div.innerHTML = `
                    <input type="hidden" id="`+selectedUserInput+i+`" value="" name=<?=htmlspecialchars($strHTMLControlName["VALUE"]).'[]'?> 
                        style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;"
                        class="`+inputUsers+`">
                    <div class="finder-box-selected-item-icon" id="`+removeUser+i+`" 
                        style="cursor: pointer; display:block" title="Убрать" 
                            onclick="removePropMulti(`+i+`, `+selectedUser+`, `+selectedUserInput+`, `+removeUser+`);"></div>
                    <span id="`+selectedUser+i+`"> </a>
                    <a class="`+addUserInput+`" href="#`+modal_window_user+`" 
                        onclick="choicePropMulti(`+i+`, 'choiceUser', 'modal_window_user', 'selectedUser', 'selectedUserInput', 'dataCl');">Добавить</a>
                    `;
            
                  document.getElementById(addUser).appendChild(div);
                }

                var j = "<?=$i?>";
                j--;

                function setUser(id, str) {
                    var arr = document.getElementsByClassName('inputUsers');
                    for (var i = 0; i < arr.length; i++) {
                        if (i < 1) {
                            var x = [];
                        }
                        x[i] = arr[i].value;
                    }

                        var doc1 = document.getElementById('selectedUser');
                    var class1 = doc1.getAttribute("data-cl");
                        doc1.id = class1;
                        doc1.setAttribute("data-cl", '');
                        var doc2 = document.getElementById('selectedUserInput');
                        var class2 = doc2.getAttribute("data-cl");
                        doc2.id = class2;
                        doc2.setAttribute("data-cl", '');
                    if (x.indexOf(id) < 0) {
                        doc1.innerHTML = str;
                        doc2.setAttribute('value', id);

                        const boxes = Array.from(document.getElementsByClassName('addUserInput'));
                        for (var i = 0; i < boxes.length; i++) {
                            boxes[i].remove();
                        }

                        document.getElementById('removeUser' + j).style.display = 'block';
                        j++;
                        addRow(j, 'selectedUser', 'selectedUserInput', 'removeUser', 'inputUsers', 'addUserInput', 'modal_window_user', 'addUser', 'choiceUser', 'data-cl');
                        $(".popup-window-close-icon").click();
                        document.getElementById('removeUser' + j).style.display = 'none';
                        /*
                        const tickets = Array.from(document.getElementsByClassName('inputTickets'));
                        var n = tickets.length;
                        addRow(n + 1);
                        $(".popup-window-close-icon").click();
*/
                    } else {
                        alert('Такой пользователь уже есть');
                    }
                }
            </script>

        <?
        }

        $strResult = ob_get_contents();
        ob_end_clean();

        return $strResult;
    }

    public static function GetPublicEditHTML($arProperty, $value, $strHTMLControlName)
    {
        global $APPLICATION;

        ob_start();
        //CModule::IncludeModule('support');
        CJSCore::Init(array("jquery"));

        ?>
        <div id="addUser"></div>
        <?
        $by = "id";
        $order = "asc";
        $arFilter = array();
        $rs = CUser::GetList($by, $order, $arFilter); 
        $users = [];
        while($ar = $rs->GetNext())
        {
            $users[] = ['str' => '[' . $ar['ID'] . '] ' . $ar['LOGIN'] . '<br>', 'id' => $ar['ID']];

        }
        CJSCore::Init(array("jquery"));
        ?>

        <div id="modal_window_multi_user" style="display:none">
            <input class="type-search  finder-box-search-textbox" placeholder="Поиск" type="text" id="searchInputMultiUser" value="" style="width:400px;"/><br>
            <span id="list_multi_user">
                <?$arIds = [];
                foreach ($users as $user) :?>
                    <span>
                        <i style="cursor: pointer;" onclick="
                        setPropMulti('<?=$user['id']?>', '<?=$user['str']?>', 'inputUsers', 'selectedUser', 'data-cl', 'selectedUserInput');
                        "><?=$user['str']?></i>
                    </span>
                    <?$arIds[] = $user['id'];
                endforeach;?>
            </span>
        </div>

        <?require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.property4iblock/admin/simai_p4ib_script.php");?>
        <script>
            search('#list_multi_user', '#searchInputMultiUser');
        </script>

        <?
        if ($arProperty["MULTIPLE"] == "Y"):

            if (!is_array($value))
                $value = array($value);

            $vals = array();

            foreach ($value as $key => $val) {
                if (isset($val['VALUE']))
                    $vals[$key] = $val['VALUE'];
                else
                    $vals[$key] = $val;
            }
            $i = 1;
            ?>
            <?//foreach ($vals as $ticket) {?>
            <div class="choiceUs">
                <?if (!empty($vals['VALUE'])) :
                    $rsUser = CUser::GetByID($vals['VALUE']);
                    if ($arUser = $rsUser->GetNext()):?>
                        <input type="hidden" id="selectedUserInput<?=$arUser['ID']?>" value="<?=$arUser['ID']?>" name=<?=htmlspecialchars($strHTMLControlName["VALUE"])?> 
                            style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;"
                            class="inputUsers">
                        <div class="finder-box-selected-item-icon" id="removeUser<?=$arUser['ID']?>" style="cursor: pointer;" title="Убрать" 
                            onclick="removePropMulti('<?=$arUser['ID']?>', 'selectedUser', 'selectedUserInput', 'removeUser', 'addUserInput');"></div>
                        <span id="selectedUser<?=$arUser['ID']?>" data-cl=""><i>[<?=$arUser['ID']?>] </i><?=$arUser['LOGIN']?></span>
                        <a id="addUserInput<?=$arUser['ID']?>" class="addUserInput" href="#modal_window" 
                            onclick="choicePropMulti('<?=$arUser['ID']?>', 'choiceUser', 'modal_window_multi_user', 'selectedUser', 'selectedUserInput', 'data-cl');">Выбрать</a>
                        <br>
                        <?$i++;
                    endif;

                else :?>
                    <input type="hidden" id="selectedUserInput<?=htmlspecialchars($strHTMLControlName["VALUE"])?>" value="<?=$arUser['ID']?>" name=<?=htmlspecialchars($strHTMLControlName["VALUE"])?> 
                            style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;"
                            class="inputUsers">
                    <div class="finder-box-selected-item-icon" id="removeUser<?=htmlspecialchars($strHTMLControlName["VALUE"])?>" style="cursor: pointer;" title="Убрать" 
                        onclick="removePropMulti('<?=htmlspecialchars($strHTMLControlName["VALUE"])?>', 'selectedUser', 'selectedUserInput', 'removeUser', 'addUserInput');"></div>
                    <span id="selectedUser<?=htmlspecialchars($strHTMLControlName["VALUE"])?>" data-cl=""><i>[<?=$arUser['ID']?>] </i><?=$arUser['LOGIN']?></span>
                    <a id="addUserInput<?=htmlspecialchars($strHTMLControlName["VALUE"])?>" class="addUserInput" href="#modal_window" 
                        onclick="choicePropMulti('<?=htmlspecialchars($strHTMLControlName["VALUE"])?>', 'choiceUser', 'modal_window_multi_user', 'selectedUser', 'selectedUserInput', 'data-cl');">Выбрать</a>
                    <br>
                <?endif;?>
            </div>
        <?
        else :
        ?>
            <div class="spi4ib">
                <span>
                    <?if ($value["VALUE"] > 0):
                        if (CModule::IncludeModule("support")):
                            $rsUser = CUser::GetByID($value['VALUE']);
                            if ($arUser = $rsUser->GetNext()):?>
                                <input type="hidden" id="selectedUserInput" value="<?=$arUser['ID']?>" name=<?=htmlspecialchars($strHTMLControlName["VALUE"])?> 
                                    style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
                                <a href="#modal_window_user" onclick="choiceProp('choiceUser', 'modal_window_user');">Выбрать</a>
                                <span id="selectedUser"><i>[<?=$arUser['ID']?>] </i><?=$arUser['LOGIN']?></span>
                            <?endif;
                        endif;
                    else :?>
                        <input type="hidden" id="selectedUserInput" value="" name=<?=htmlspecialchars($strHTMLControlName["VALUE"])?> 
                            style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
                        <a href="#modal_window_user" onclick="choiceProp('choiceUser', 'modal_window_user');">Выбрать</a>
                        <span id="selectedUser"></span>
                    <?endif; ?>
                </span>

                <?//CModule::IncludeModule('support');
                $by = "id";
                $order = "asc";
                $arFilter = array();
                $rs = CUser::GetList($by, $order, $arFilter); 
                $users = [];
                while($ar = $rs->GetNext())
                {
                    $users[] = ['str' => '[' . $ar['ID'] . '] ' . $ar['LOGIN'] . '<br>', 'id' => $ar['ID']];

                }

                ?>

                <div id="modal_window_user" style="display:none;">
                    <input class="type-search  finder-box-search-textbox" placeholder="Поиск" type="text" id="searchInputUser" value="" style="width:400px;"/><br>
                    <span id="listUser">
                    <?$count = 0;?>
                    <?foreach ($users as $user) :?>
                        <span>
                            <i style="cursor: pointer;" onclick="
                                setProp('<?=$user['id']?>', '<?=$user['str']?>', 'selectedUser', 'selectedUserInput');
                                "><?=$user['str']?></i>
                        </span>
                        <?$count++;?>
                    <?endforeach;?>
                    </span>
                </div>
            </div>

            <?require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.property4iblock/admin/simai_p4ib_script.php");?>
            <script>

                search('#listUser', '#searchInputUser');
            </script>

        <?endif;

        $strResult = ob_get_contents();
        ob_end_clean();

        return $strResult;
    }


    public static function ConvertToDB($arProperty, $value)
    {
        return $value;
    }

    public static function ConvertFromDB($arProperty, $value)
    {
        return $value;
    }

    public static function GetPublicViewHTML($arProperty, $value, $strHTMLControlName)
    {
        if ($value["VALUE"] > 0):
            if (CModule::IncludeModule("support")):

                $rsUser = CUser::GetByID($value['VALUE']);
                if ($arUser = $rsUser->GetNext()):
                    return '[' . $arUser["ID"] . ']&nbsp;<span >' . $arUser["LOGIN"] . '</span>';
                endif;
            endif;
        endif;

        return '';
    }

    public static function GetSearchContent($arProperty, $value, $strHTMLControlName)
    {
        if ($value['VALUE'] > 0) {
            if (CModule::IncludeModule("support")) {

                $rsUser = CUser::GetByID($value['VALUE']);
                if ($arUser = $rsUser->GetNext()) {
                    return $arUser["ID"] . ' ' . $arUser["LOGIN"];
                }
            }
        }

        return '';
    }

    public static function GetAdminFilterHTML($arProperty, $strHTMLControlName)
    {
        global $APPLICATION;

        ob_start();
        ?>
        <div class="spi4ib spi4ib_a" style="padding-left:20px;">
        <span>
        <?
        $value = $GLOBALS[$strHTMLControlName["VALUE"]];
        if ($value > 0):
            if (CModule::IncludeModule("support")):
                $rsUser = CUser::GetByID($value);
                if ($arUser = $rsUser->GetNext()):?>
                            <input type="text" id="selectedUserInput" value="<?=$arUser['ID']?>" name=<?=htmlspecialchars($strHTMLControlName["VALUE"])?> 
                                style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
                            <a href="#modal_window" onclick="choiceProp('choiceUser', 'modal_window_user');">Выбрать</a>
                            <span id="selectedUser"><i>[<?=$arUser['ID']?>] </i><?=$arUser['LOGIN']?></span>
                        <?endif;
                    endif;
                else :?>
                    <input type="text" id="selectedUserInput" value="" name=<?=htmlspecialchars($strHTMLControlName["VALUE"])?> 
                        style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
                    <a href="#modal_window" onclick="choiceProp('choiceUser', 'modal_window_user');">Выбрать</a>
                    <span id="selectedUser"></span>
                <?endif; ?>
            </span>

            <?//CModule::IncludeModule('support');
            $by = "id";
            $order = "asc";
            $arFilter = array();
            $rs = CUser::GetList($by, $order, $arFilter); 
            $users = [];
            while($ar = $rs->GetNext())
            {
                $users[] = ['str' => '[' . $ar['ID'] . '] ' . $ar['LOGIN'] . '<br>', 'id' => $ar['ID']];

            }
            CJSCore::Init(array("jquery"));
            ?>

            <div id="modal_window_user" style="display:none">
                <input class="type-search  finder-box-search-textbox" placeholder="Поиск" type="text" id="searchInputUser" value="" style="width:400px;"/><br>
                <span id="listUser">
                <?foreach ($users as $user) :?>
                    <span>
                        <i style="cursor: pointer;" onclick="
                            setProp('<?=$user['id']?>', '<?=$user['str']?>', 'selectedUser', 'selectedUserInput');
                            "><?=$user['str']?></i>
                    </span>
                <?endforeach;?>
                </span>
            </div>
        </div>

        <?require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.property4iblock/admin/simai_p4ib_script.php");?>
        <script>
            search('#listUser', '#searchInputUser');
        </script>
        <?
        $strResult = ob_get_contents();
        ob_end_clean();

        return $strResult;
    }

    public static function GetAdminListViewHTML($arProperty, $value, $strHTMLControlName)
    {
        if ($value["VALUE"] > 0):
            if (CModule::IncludeModule("support")):

                $rsUser = CUser::GetByID($value['VALUE']);
                if ($arUser = $rsUser->GetNext()):
                    return '[' . $arUser["ID"] . ']&nbsp;<span>' . $arUser["LOGIN"] . '</span>';
                endif;
            endif;
        endif;

        return '';
    }

    public static function GetPublicFilterHTML($arProperty, $strHTMLControlName)
    {
        global $APPLICATION;

        ob_start();
        ?>
        <div class="spi4ib spi4ib_a" style="padding-left:20px;">
        <span>
        <?
        $value = $GLOBALS[$strHTMLControlName["VALUE"]];
        if ($value > 0):
            if (CModule::IncludeModule("support")):
                $rsUser = CUser::GetByID($value);
                if ($arUser = $rsUser->GetNext()):?>
                            <input type="text" id="selectedUserInput" value="<?=$arUser['ID']?>" name=<?=htmlspecialchars($strHTMLControlName["VALUE"])?> 
                                style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
                            <a href="#modal_window" onclick="choiceProp('choiceUser', 'modal_window_user');">Выбрать</a>
                            <span id="selectedUser"><i>[<?=$arUser['ID']?>] </i><?=$arUser['LOGIN']?></span>
                        <?endif;
                    endif;
                else :?>
                    <input type="text" id="selectedUserInput" value="" name=<?=htmlspecialchars($strHTMLControlName["VALUE"])?> 
                        style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
                    <a href="#modal_window" onclick="choiceProp('choiceUser', 'modal_window_user');">Выбрать</a>
                    <span id="selectedUser"></span>
                <?endif; ?>
            </span>

            <?//CModule::IncludeModule('support');
            $by = "id";
            $order = "asc";
            $arFilter = array();
            $rs = CUser::GetList($by, $order, $arFilter); 
            $users = [];
            while($ar = $rs->GetNext())
            {
                $users[] = ['str' => '[' . $ar['ID'] . '] ' . $ar['LOGIN'] . '<br>', 'id' => $ar['ID']];

            }
            CJSCore::Init(array("jquery"));
            ?>

            <div id="modal_window_user" style="display:none">
                <input class="type-search  finder-box-search-textbox" placeholder="Поиск" type="text" id="searchInputUser" value="" style="width:400px;"/><br>
                <span id="listUser">
                <?foreach ($users as $user) :?>
                    <span>
                        <i style="cursor: pointer;" onclick="
                            setProp('<?=$user['id']?>', '<?=$user['str']?>', 'selectedUser', 'selectedUserInput');
                            "><?=$user['str']?></i>
                    </span>
                <?endforeach;?>
                </span>
            </div>
        </div>
        <?require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.property4iblock/admin/simai_p4ib_script.php");?>
        <script>
            search('#listUser', '#searchInputUser');
        </script>
        <?
        $strResult = ob_get_contents();
        ob_end_clean();

        return $strResult;
    }
}
