<?php
IncludeModuleLangFile(__FILE__);

use Bitrix\Iblock;
use Bitrix\Main\Application;
use Bitrix\Main\IO;
use Bitrix\Main\File\Image;
use Bitrix\Main\Loader;

class CCustomTypeSimaiTicket
{
    public static function GetUserTypeDescription()
    {
        return array(
            'PROPERTY_TYPE' => 'N',
            'USER_TYPE' => 'simai_ticket',
            'DESCRIPTION' => GetMessage('SMPI_TICKET_PROP'),
            'PrepareSettings' => array('CCustomTypeSimaiTicket', 'PrepareSettings'),
            'GetSettingsHTML' => array('CCustomTypeSimaiTicket', 'GetSettingsHTML'),
            'GetPropertyFieldHtml' => array('CCustomTypeSimaiTicket', 'GetPropertyFieldHtml'),
            'GetPropertyFieldHtmlMulty' => array('CCustomTypeSimaiTicket', 'GetPropertyFieldHtmlMulty'),
            'GetPublicEditHTML' => array('CCustomTypeSimaiTicket', 'GetPublicEditHTML'),
            'ConvertToDB' => array('CCustomTypeSimaiTicket', 'ConvertToDB'),
            'ConvertFromDB' => array('CCustomTypeSimaiTicket', 'ConvertFromDB'),
            'GetPublicViewHTML' => array('CCustomTypeSimaiTicket', 'GetPublicViewHTML'),
            'GetSearchContent' => array('CCustomTypeSimaiTicket', 'GetSearchContent'),
            'GetAdminFilterHTML' => array('CCustomTypeSimaiTicket', 'GetAdminFilterHTML'),
            'GetAdminListViewHTML' => array('CCustomTypeSimaiTicket', 'GetAdminListViewHTML'),
        );
    }

    public static function PrepareSettings($arFields)
    {
        //return array("TASK_URL_TEMPLATE" => trim($arFields["USER_TYPE_SETTINGS"]["TASK_URL_TEMPLATE"]));
        return array();
    }

    public static function GetSettingsHTML($arProperty, $strHTMLControlName, &$arPropertyFields)
    {
        $arPropertyFields = array(
            "HIDE" => array("ROW_COUNT", "COL_COUNT", "DEFAULT_VALUE", "WITH_DESCRIPTION", "SEARCHABLE", "SMART_FILTER", "DISPLAY_TYPE", "EXPANDED"),
            "SET" => array("FILTRABLE" => "Y", "SEARCHABLE" => "Y", "SMART_FILTER" => "N", "MULTIPLE_CNT" => "1"),
            //"USER_TYPE_SETTINGS_TITLE" => GetMessage('SMPI_SELECT_SUBPROPS')
        );

        $return = "";

        /*$return .= '
        <tr>
        <td>'.GetMessage('SMPI_TASK_URL_TEMPLATE').':</td>
        <td>
        <input type="text" name="'.$strHTMLControlName["NAME"].'[TASK_URL_TEMPLATE]" style="width:270px;" value="'.$arProperty["USER_TYPE_SETTINGS"]["TASK_URL_TEMPLATE"].'">
        <br /><small>'.GetMessage('SMPI_TASK_URL_TEMPLATE_HINT').'<small>
        </td>
        </tr>';*/

        return $return;
    }

    public static function GetPropertyFieldHtml($arProperty, $value, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION;
        
        if (CModule::IncludeModule("support") == false)
        {
            return '';
        }
        
        ob_start();

       if ($_REQUEST['mode'] == 'frame') {
            foreach ($value as $key => $val) {

                ?>
                <input type="text" name="<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>[<?= $key ?>]" size="4"
                       value="<?= htmlspecialchars($val["VALUE"]) ?>"/><br/>
                <?
            }
            for ($i = 0; $i < 3; $i++) {
                ?>
                <input type="text" name="<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>[n<?= $i ?>]" size="4"
                       value=""/><br/>
                <?
            }
        } else {
            CModule::IncludeModule('support');
            if (!is_array($value))
                $value = array($value);

            $vals = array();
            foreach ($value as $key => $val) {
                if (isset($val['VALUE']))
                    $vals[$key] = $val['VALUE'];
                else
                    $vals[$key] = $val;
            }
			$i = 1;

			foreach ($vals as $k => $ticket) {
				if ($k == "VALUE") :
					if ($ticket) :
						$rsTicket = CTicket::GetByID($ticket);

						if ($arTicket = $rsTicket->GetNext()):?>
							<input type="hidden" id="selectedTicketInput" value="<?=$arTicket['ID']?>" name=<?=htmlspecialchars($strHTMLControlName["VALUE"])?> 
								style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
							<a href="#modal_window" 
								onclick="choiceProp('choiceTicket', 'modal_window');">Выбрать</a>
<a target="_blank" id="selectedTicket" href="/support/?ID=<?=$arTicket['ID']?>&edit=<?=$arTicket['ID']?>"> Tiket <i>[<?=$arTicket['ID']?>] </i><?=$arTicket['TITLE']?></a>
							<?$i++;
						endif;
					else :?>
						<input type="hidden" id="selectedTicketInput" value="" name=<?=htmlspecialchars($strHTMLControlName["VALUE"])?> 
							style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
						<a href="#modal_window" 
							onclick="choiceProp('choiceTicket', 'modal_window');">Выбрать</a>
<a target="_blank" id="selectedTicket" href="/support/?ID=<?=$arTicket['ID']?>&edit=<?=$arTicket['ID']?>"> </a>
					<?endif;
				endif;
			}


			$by = "id";
			$order = "asc";
			$arFilter = array();
			$rs = CTicket::GetList($by, $order, $arFilter); 
			$tickets = [];
			while($ar = $rs->GetNext())
			{
				$tickets[] = ['str' => '[' . $ar['ID'] . '] ' . $ar['TITLE'] . '<br>', 'id' => $ar['ID']];
	
			}
			CJSCore::Init(array("jquery"));
			?>

			<div id="modal_window" style="display:none">
				<input class="type-search  finder-box-search-textbox" placeholder="Поиск" type="text" id="searchInput" value="" style="width:400px;"/><br>
				<span id="list">
				<?foreach ($tickets as $ticket) :?>
					<span>
						<i style="cursor: pointer;" onclick="
							setTicket('<?=$ticket['id']?>', '<?=$ticket['str']?>');
							"><?=$ticket['str']?></i>
					</span>
				<?endforeach;?>
				</span>
			</div>

			<script>
				function setTicket(id, str) {
					var selectedTicket = document.getElementById('selectedTicket');
					selectedTicket.innerHTML = str;
					selectedTicket.setAttribute('href', "/support/?ID="+id+"&edit="+id);
					document.getElementById('selectedTicketInput').setAttribute('value', id);
					$(".popup-window-close-icon").click();
				}
				/*
				function setTicket(id, str) {
					var doc1 = document.getElementById('selectedTicket')
					doc1.innerHTML = str;
					var class1 = doc1.getAttribute('class');
					doc1.id = class1;
					var doc2 = document.getElementById('selectedTicketInput')
					doc2.setAttribute('value', id);
					var class2 = doc2.getAttribute('class');
					doc2.id = class2;
				}
*/
				function choiceTicket(i) {
					singlePopupSingle_RhbmTg = new BX.PopupWindow("choiceTicket", this, {
					offsetTop: 1,
					autoHide: true,
					content: document.getElementById('modal_window'),
					zIndex: 3000
					});
					var doc1 = document.getElementById('selectedTicket' + i);
					doc1.id = "selectedTicket";
					doc1.classList.add('selectedTicket' + i);
					var doc1 = document.getElementById('selectedTicketInput' + i);
					doc1.id = "selectedTicketInput";
					doc1.classList.add('selectedTicketInput' + i);
					document.getElementById('modal_window').style.display = 'block';
					singlePopupSingle_RhbmTg.show();
				}
			</script>

		<?require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.property4iblock/admin/simai_p4ib_script.php");?>
		<script>
			search('#list', '#searchInput');
		</script>
		<?
        }

        $strResult = ob_get_contents();
        ob_end_clean();

        return $strResult;
    }

    public static function GetPropertyFieldHtmlMulty($arProperty, $value, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION;
        
        if (CModule::IncludeModule("support") == false)
        {
            return '';
        }
        
        ob_start();

        if ($_REQUEST['mode'] == 'frame') {
            foreach ($value as $key => $val) {
                ?>
                <input type="text" name="<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>[<?= $key ?>]" size="4"
                       value="<?= htmlspecialchars($val["VALUE"]) ?>"/><br/>
                <?
            }
            for ($i = 0; $i < 3; $i++) {
                ?>
                <input type="text" name="<?= htmlspecialchars($strHTMLControlName["VALUE"]) ?>[n<?= $i ?>]" size="4"
                       value=""/><br/>
                <?
            }
        } else {
            CModule::IncludeModule('support');
            if (!is_array($value))
                $value = array($value);

            $vals = array();

            foreach ($value as $key => $val) {
                if (isset($val['VALUE']))
                    $vals[$key] = $val['VALUE'];
                else
                    $vals[$key] = $val;
            }
			$i = 1;?>
			<div class="choiceTik">
				<?foreach ($vals as $ticket) {
					$rsTicket = CTicket::GetByID($ticket);
					if ($arTicket = $rsTicket->GetNext()):?>
						<input type="hidden" id="selectedTicketInput<?=$i?>" value="<?=$arTicket['ID']?>" name=<?=htmlspecialchars($strHTMLControlName["VALUE"]).'[]'?> 
							style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;"
							class="inputTickets">
						<div class="finder-box-selected-item-icon" id="removeTicket<?=$i?>" style="cursor: pointer;" title="Убрать" 
							onclick="removePropMulti('<?=$i?>', 'selectedTicket', 'selectedTicketInput', 'removeTicket');"></div>
						<a target="_blank" id="selectedTicket<?=$i?>" href="<?=SITE_DIR?>support/?ID=<?=$arTicket['ID']?>&edit=<?=$arTicket['ID']?>" data-cl=""><i>[<?=$arTicket['ID']?>] </i><?=$arTicket['TITLE']?></a>
						<br>
						<?$i++;
					endif;
				}?>
					<input type="hidden" id="selectedTicketInput<?=$i?>" value="" name=<?=htmlspecialchars($strHTMLControlName["VALUE"]).'[]'?> 
						style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;"
						class="inputTickets">
					<div class="finder-box-selected-item-icon" id="removeTicket<?=$i?>" 
						style="cursor: pointer; display:none" title="Убрать" 
						onclick="removePropMulti('<?=$i?>', 'selectedTicket', 'selectedTicketInput', 'removeTicket');"></div>
					<a class="addTicketInput" href="#modal_window" 
						onclick="choicePropMulti('<?=$i?>', 'choiceTicket', 'modal_window', 'selectedTicket', 'selectedTicketInput', 'data-cl');">Добавить</a>
					<a target="_blank" id="selectedTicket<?=$i?>" href="<?=SITE_DIR?>support/?ID=<?=$arTicket['ID']?>&edit=<?=$arTicket['ID']?>"> </a>
					<br>
					<div id="addTicket"></div>
				<?//choicePropMulti(i, divId, modalId, selectedUser, selectedUserInput, dataCl)
				$by = "id";
				$order = "asc";
				$arFilter = array();
				$rs = CTicket::GetList($by, $order, $arFilter); 
				$tickets = [];
				while($ar = $rs->GetNext())
				{
					$tickets[] = ['str' => '[' . $ar['ID'] . '] ' . $ar['TITLE'] . '<br>', 'id' => $ar['ID']];

				}
				CJSCore::Init(array("jquery"));
				?>
			</div>
			<div id="modal_window" style="display:none">
				<input class="type-search  finder-box-search-textbox" placeholder="Поиск" type="text" id="searchInput" value="" style="width:400px;"/><br>
				<span id="list">
				<?$arIds = [];
				foreach ($tickets as $ticket) :?>
					<span>
						<i style="cursor: pointer;" onclick="
							setTicket('<?=$ticket['id']?>', '<?=$ticket['str']?>');
							"><?=$ticket['str']?></i>
					</span>
				<?$arIds[] = $ticket['id'];
				endforeach;?>
				</span>
			</div>

			<script>
				var j = "<?=$i?>";

				function addRow(i) {
				  const div = document.createElement('div');
				  div.className = 'row';
					<?$i++;?>
				  div.innerHTML = `
					<input type="hidden" id="selectedTicketInput`+i+`" value="" name=<?=htmlspecialchars($strHTMLControlName["VALUE"]).'[]'?> 
						style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;"
						class="inputTickets">
					<a class="addTicketInput" href="#modal_window" 
						onclick="choicePropMulti(`+i+`, 'choiceTicket', 'modal_window', 'selectedTicket', 'selectedTicketInput', 'data-cl');">Добавить</a>
					<div class="finder-box-selected-item-icon" id="removeTicket`+i+`" 
						style="cursor: pointer; display:none" title="Убрать" 
						onclick="removePropMulti(`+i+`, 'selectedTicket', 'selectedTicketInput', 'removeTicket');"></div>
					<a target="_blank" id="selectedTicket`+i+`" href="<?=SITE_DIR?>support/?ID=<?=$arTicket['ID']?>&edit=<?=$arTicket['ID']?>"> </a>
					<br>
				  `;
					//removePropMulti(i, selectedUser, selectedUserInput, removeUser, addUserInput = false)
				  document.getElementById('addTicket').appendChild(div);
				}

				function setTicket(id, str) {
					var arr = document.getElementsByClassName('inputTickets');
					for (var i = 0; i < arr.length; i++) {
						if (i < 1) {
							var x = [];
						}
						x[i] = arr[i].value;
					}

						var doc1 = document.getElementById('selectedTicket');
					var class1 = doc1.getAttribute("data-cl");
						doc1.id = class1;
						doc1.setAttribute("data-cl", '');
						var doc2 = document.getElementById('selectedTicketInput');
						var class2 = doc2.getAttribute("data-cl");
						doc2.id = class2;
						doc2.setAttribute("data-cl", '');
					if (x.indexOf(id) < 0) {
						doc1.innerHTML = str;
						doc2.setAttribute('value', id);

						const boxes = Array.from(document.getElementsByClassName('addTicketInput'));
						for (var i = 0; i < boxes.length; i++) {
							boxes[i].remove();
						}
						document.getElementById('removeTicket' + j).style.display = 'block';
						j++;
						addRow(j);
						$(".popup-window-close-icon").click();
					} else {
						alert('Такой тикет уже есть');
					}
				}
			</script>

		<?require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.property4iblock/admin/simai_p4ib_script.php");?>
		<script>
			search('#list', '#searchInput');
		</script>
		<?
        }

        $strResult = ob_get_contents();
        ob_end_clean();

        return $strResult;
    }

    public static function GetPublicEditHTML($arProperty, $value, $strHTMLControlName)
    {
        global $APPLICATION;
        
        if (CModule::IncludeModule("support") == false)
        {
            return '';
        }
        
        ob_start();
		CJSCore::Init(array("jquery"));
		?>

		<div id="addTicket"></div>
		<?
		$by = "id";
		$order = "asc";
		$arFilter = array();
		$rs = CTicket::GetList($by, $order, $arFilter); 
		$tickets = [];
		while($ar = $rs->GetNext())
		{
			$tickets[] = ['str' => '[' . $ar['ID'] . '] ' . $ar['TITLE'] . '<br>', 'id' => $ar['ID']];

		}
		CJSCore::Init(array("jquery"));
		?>

		<div id="modal_window_multi" style="display:none">
			<input class="type-search  finder-box-search-textbox" placeholder="Поиск" type="text" id="searchInputMulti" value="" style="width:400px;"/><br>
			<span id="list_multi">
				<?$arIds = [];
				foreach ($tickets as $ticket) :?>
					<span>
						<i style="cursor: pointer;" onclick="
						setPropMulti('<?=$ticket['id']?>', '<?=$ticket['str']?>', 'inputTickets', 'selectedTicket', 'data-cl', 'selectedTicketInput');
						"><?=$ticket['str']?></i>
					</span>
					<?$arIds[] = $ticket['id'];
				endforeach;?>
			</span>
		</div>

		<script>
			var j = "<?=$i?>";

			function addRowMulti(i) {
			  const div = document.createElement('div');
			  div.className = 'row';
				<?$i++;?>
				i +=1;
			  div.innerHTML = `
				<input type="hidden" id="selectedTicketInput`+i+`" value="" name=<?=htmlspecialchars($strHTMLControlName["VALUE"]).'[]'?> 
					style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;"
					class="inputTickets">
				<a class="addTicketInput" href="#modal_window" 
					onclick="choicePropMulti(`+i+`, 'choiceTicket', 'modal_window_multi', 'selectedTicket', 'selectedTicketInput', 'data-cl');">Добавить</a>
				<div class="finder-box-selected-item-icon" id="removeTicket`+i+`" 
					style="cursor: pointer; display:none" title="Убрать" 
					onclick="removePropMulti(`+i+`, 'selectedTicket', 'selectedTicketInput', 'removeTicket', 'addTicketInput');"></div>
				<a target="_blank" id="selectedTicket`+i+`" href="<?=SITE_DIR?>support/?ID=<?=$arTicket['ID']?>&edit=<?=$arTicket['ID']?>"> </a>
				<br>
			  `;

			  document.getElementById('addTicket').appendChild(div);

			search('#list_multi', '#searchInputMulti');
			}
		</script>
		<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.property4iblock/admin/simai_p4ib_script.php");?>


		<?
		if ($arProperty["MULTIPLE"] == "Y"):

			if (!is_array($value))
                $value = array($value);

            $vals = array();

            foreach ($value as $key => $val) {
                if (isset($val['VALUE']))
                    $vals[$key] = $val['VALUE'];
                else
                    $vals[$key] = $val;
            }
			$i = 1;
			?>
			<?//foreach ($vals as $ticket) {?>
			<div class="choiceTik">
				<?if (!empty($vals['VALUE'])) :
					$rsTicket = CTicket::GetByID($vals['VALUE']);
					if ($arTicket = $rsTicket->GetNext()):?>
						<input type="hidden" id="selectedTicketInput<?=$arTicket['ID']?>" value="<?=$arTicket['ID']?>" name=<?=htmlspecialchars($strHTMLControlName["VALUE"])?> 
							style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;"
							class="inputTickets">
						<div class="finder-box-selected-item-icon" id="removeTicket<?=$arTicket['ID']?>" style="cursor: pointer;" title="Убрать" 
							onclick="removePropMulti('<?=$arTicket['ID']?>', 'selectedTicket', 'selectedTicketInput', 'removeTicket', 'addTicketInput');"></div>
						<a target="_blank" id="selectedTicket<?=$arTicket['ID']?>" href="<?=SITE_DIR?>support/?ID=<?=$arTicket['ID']?>&edit=<?=$arTicket['ID']?>" data-cl=""><i>[<?=$arTicket['ID']?>] </i><?=$arTicket['TITLE']?></a>
						<a id="addTicketInput<?=$arTicket['ID']?>" class="addTicketInput" href="#modal_window" 
							onclick="choicePropMulti('<?=$arTicket['ID']?>', 'choiceTicket', 'modal_window_multi', 'selectedTicket', 'selectedTicketInput', 'data-cl');">Выбрать</a>
						<br>
						<?$i++;
					endif;

				else :?>
					<input type="hidden" id="selectedTicketInput<?=htmlspecialchars($strHTMLControlName["VALUE"])?>" value="<?=$arTicket['ID']?>" name=<?=htmlspecialchars($strHTMLControlName["VALUE"])?> 
							style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;"
							class="inputTickets">
					<div class="finder-box-selected-item-icon" id="removeTicket<?=htmlspecialchars($strHTMLControlName["VALUE"])?>" style="cursor: pointer;" title="Убрать" 
						onclick="removePropMulti('<?=htmlspecialchars($strHTMLControlName["VALUE"])?>', 'selectedTicket', 'selectedTicketInput', 'removeTicket', 'addTicketInput');"></div>
					<a target="_blank" id="selectedTicket<?=htmlspecialchars($strHTMLControlName["VALUE"])?>" href="<?=SITE_DIR?>support/?ID=<?=$arTicket['ID']?>&edit=<?=$arTicket['ID']?>" data-cl=""><i>[<?=$arTicket['ID']?>] </i><?=$arTicket['TITLE']?></a>
					<a id="addTicketInput<?=htmlspecialchars($strHTMLControlName["VALUE"])?>" class="addTicketInput" href="#modal_window" 
						onclick="choicePropMulti('<?=htmlspecialchars($strHTMLControlName["VALUE"])?>', 'choiceTicket', 'modal_window_multi', 'selectedTicket', 'selectedTicketInput', 'data-cl');">Выбрать</a>
					<br>
				<?endif;?>
			</div>
		<?
		else :
		?>
			<div class="spi4ib">
				<span>
					<?//добавлена проверка
					?>
					<?if (is_array($value))
						$value = $value["VALUE"];
						?>
					<?if ($value > 0):
						if (CModule::IncludeModule("support")):
							$rsTicket = CTicket::GetByID($value);
							if ($arTicket = $rsTicket->GetNext()):?>
								<input type="hidden" id="selectedTicketInput" value="<?=$arTicket['ID']?>" name="PROPERTY_3024" 
									style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
								<a href="#modal_window" onclick="choiceProp('choiceTicket', 'modal_window');">Выбрать</a>
								<a target="_blank" id="selectedTicket" href="<?=SITE_DIR?>support/?ID=<?=$arTicket['ID']?>&edit=<?=$arTicket['ID']?>"> Tiket <i>[<?=$arTicket['ID']?>] </i><?=$arTicket['TITLE']?></a>
							<?endif;
						endif;
					else :?>
						<input type="hidden" id="selectedTicketInput" value="" name="PROPERTY_3024" 
							style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
						<a href="#modal_window" onclick="choiceProp('choiceTicket', 'modal_window');">Выбрать</a>
						<a target="_blank" id="selectedTicket" href=""></a>
					<?endif; ?>
				</span>
	
				<?CModule::IncludeModule('support');
				$by = "id";
				$order = "asc";
				$arFilter = array();
				$rs = CTicket::GetList($by, $order, $arFilter); 
				$tickets = [];
				while($ar = $rs->GetNext())
				{
					$tickets[] = ['str' => '[' . $ar['ID'] . '] ' . $ar['TITLE'] . '<br>', 'id' => $ar['ID']];
		
				}
	
				?>

				<div id="modal_window" style="display:none">
					<input class="type-search  finder-box-search-textbox" placeholder="Поиск" type="text" id="searchInput" value="" style="width:400px;"/><br>
					<span id="list">
					<?foreach ($tickets as $ticket) :?>
						<span>
							<i style="cursor: pointer;" onclick="
								setProp('<?=$ticket['id']?>', '<?=$ticket['str']?>', 'selectedTicket', 'selectedTicketInput');
								"><?=$ticket['str']?></i>
						</span>
					<?endforeach;?>
					</span>
				</div>
			</div>

			<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.property4iblock/admin/simai_p4ib_script.php");?>
			<script>
				search('#list', '#searchInput');
			</script>

		<?endif;

		$strResult = ob_get_contents();
		ob_end_clean();

		return $strResult;
    }

    public static function ConvertToDB($arProperty, $value)
    {
        return $value;
    }

    public static function ConvertFromDB($arProperty, $value)
    {
        return $value;
    }

    public static function GetPublicViewHTML($arProperty, $value, $strHTMLControlName)
    {
		if ($value["VALUE"] > 0):
			if (CModule::IncludeModule("support")):

				$rsTicket = CTicket::GetByID($value['VALUE']);
				if ($arTicket = $rsTicket->GetNext()):
					return '[' . $arTicket["ID"] . ']&nbsp;<a target="_blank" href="' . SITE_DIR . 'support/?ID=' . $arTicket['ID'] . '&edit=' . $arTicket['ID'] . '">' . $arTicket["TITLE"] . '</a>';
				endif;
			endif;
		endif;

        return '';
    }

    public static function GetSearchContent($arProperty, $value, $strHTMLControlName)
    {
        if ($value['VALUE'] > 0) {
            if (CModule::IncludeModule("support")) {

                $rsTicket = CTicket::GetByID($value['VALUE']);
                if ($arTicket = $rsTicket->GetNext()) {
                    return $arTicket["ID"] . ' ' . $arTicket["TITLE"];
                }
            }
        }

        return '';
    }

    public static function GetAdminFilterHTML($arProperty, $strHTMLControlName)
    {
        global $APPLICATION;

        ob_start();
        ?>
        <div class="spi4ib spi4ib_a" style="padding-left:20px;">
        <span>
        <?
        $value = $GLOBALS[$strHTMLControlName["VALUE"]];
        if ($value > 0):
            if (CModule::IncludeModule("support")):
                $rsTicket = CTicket::GetByID($value);
                if ($arTicket = $rsTicket->GetNext()):?>
							<input type="hidden" id="selectedTicketInput" value="<?=$arTicket['ID']?>" name="PROPERTY_3024" 
								style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
							<a href="#modal_window" onclick="choiceProp('choiceTicket', 'modal_window');">Выбрать</a>
							<a target="_blank" id="selectedTicket" href="<?=SITE_DIR?>support/?ID=<?=$arTicket['ID']?>&edit=<?=$arTicket['ID']?>"> Tiket <i>[<?=$arTicket['ID']?>] </i><?=$arTicket['TITLE']?></a>
						<?endif;
					endif;
				else :?>
					<input type="hidden" id="selectedTicketInput" value="" name="PROPERTY_3024" 
						style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
					<a href="#modal_window" onclick="choiceProp('choiceTicket', 'modal_window');">Выбрать</a>
					<a target="_blank" id="selectedTicket" href=""></a>
				<?endif; ?>
			</span>

			<?CModule::IncludeModule('support');
			$by = "id";
			$order = "asc";
			$arFilter = array();
			$rs = CTicket::GetList($by, $order, $arFilter); 
			$tickets = [];
			while($ar = $rs->GetNext())
			{
				$tickets[] = ['str' => '[' . $ar['ID'] . '] ' . $ar['TITLE'] . '<br>', 'id' => $ar['ID']];
	
			}
			CJSCore::Init(array("jquery"));
			?>

			<div id="modal_window" style="display:none">
				<input class="type-search  finder-box-search-textbox" placeholder="Поиск" type="text" id="searchInput" value="" style="width:400px;"/><br>
				<span id="list">
				<?foreach ($tickets as $ticket) :?>
					<span>
						<i style="cursor: pointer;" onclick="
							setProp('<?=$ticket['id']?>', '<?=$ticket['str']?>', 'selectedTicket', 'selectedTicketInput');
							"><?=$ticket['str']?></i>
					</span>
				<?endforeach;?>
				</span>
			</div>
		</div>

			<?require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.property4iblock/admin/simai_p4ib_script.php");?>
			<script>
				search('#list', '#searchInput');
			</script>
		<?
        $strResult = ob_get_contents();
        ob_end_clean();

        return $strResult;
    }

    public static function GetAdminListViewHTML($arProperty, $value, $strHTMLControlName)
    {
		if ($value["VALUE"] > 0):
			if (CModule::IncludeModule("support")):

				$rsTicket = CTicket::GetByID($value['VALUE']);
				if ($arTicket = $rsTicket->GetNext()):
					return '[' . $arTicket["ID"] . ']&nbsp;<a target="_blank" href="' . SITE_DIR . 'support/?ID=' . $arTicket['ID'] . '&edit=' . $arTicket['ID'] . '">' . $arTicket["TITLE"] . '</a>';
				endif;
			endif;
		endif;

        return '';
    }

    public static function GetPublicFilterHTML($arProperty, $strHTMLControlName)
    {
        global $APPLICATION;

        ob_start();
        ?>
        <div class="spi4ib spi4ib_a" style="padding-left:20px;">
        <span>
        <?
        $value = $GLOBALS[$strHTMLControlName["VALUE"]];
        if ($value > 0):
            if (CModule::IncludeModule("support")):
                $rsTicket = CTicket::GetByID($value);
                if ($arTicket = $rsTicket->GetNext()):?>
							<input type="hidden" id="selectedTicketInput" value="<?=$arTicket['ID']?>" name="PROPERTY_3024" 
								style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
							<a href="#modal_window" onclick="choiceProp('choiceTicket', 'modal_window');">Выбрать</a>
							<a target="_blank" id="selectedTicket" href="<?=SITE_DIR?>support/?ID=<?=$arTicket['ID']?>&edit=<?=$arTicket['ID']?>"> Tiket <i>[<?=$arTicket['ID']?>] </i><?=$arTicket['TITLE']?></a>
						<?endif;
					endif;
				else :?>
					<input type="hidden" id="selectedTicketInput" value="" name="PROPERTY_3024" 
						style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
					<a href="#modal_window" onclick="choiceProp('choiceTicket', 'modal_window');">Выбрать</a>
					<a target="_blank" id="selectedTicket" href=""></a>
				<?endif; ?>
			</span>

			<?CModule::IncludeModule('support');
			$by = "id";
			$order = "asc";
			$arFilter = array();
			$rs = CTicket::GetList($by, $order, $arFilter); 
			$tickets = [];
			while($ar = $rs->GetNext())
			{
				$tickets[] = ['str' => '[' . $ar['ID'] . '] ' . $ar['TITLE'] . '<br>', 'id' => $ar['ID']];
	
			}
			CJSCore::Init(array("jquery"));
			?>

			<div id="modal_window" style="display:none">
				<input class="type-search  finder-box-search-textbox" placeholder="Поиск" type="text" id="searchInput" value="" style="width:400px;"/><br>
				<span id="list">
				<?foreach ($tickets as $ticket) :?>
					<span>
						<i style="cursor: pointer;" onclick="
							setProp('<?=$ticket['id']?>', '<?=$ticket['str']?>', 'selectedTicket', 'selectedTicketInput');
							"><?=$ticket['str']?></i>
					</span>
				<?endforeach;?>
				</span>
			</div>
		</div>

			<?require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.property4iblock/admin/simai_p4ib_script.php");?>
			<script>
				search('#list', '#searchInput');
			</script>
		<?
        $strResult = ob_get_contents();
        ob_end_clean();

        return $strResult;
    }
}
