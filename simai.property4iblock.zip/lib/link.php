<?php
IncludeModuleLangFile(__FILE__);

use Bitrix\Iblock;
use Bitrix\Main\Application;
use Bitrix\Main\IO;
use Bitrix\Main\File\Image;
use Bitrix\Main\Loader;

class CCustomTypeSimaiLink
{
    public static function GetUserTypeDescription()
    {
        return array(
            'PROPERTY_TYPE' => 'S',
            'USER_TYPE' => 'simai_link',
            'DESCRIPTION' => GetMessage('SMPI_LINK_PROP'),
            'PrepareSettings' => array('CCustomTypeSimaiLink', 'PrepareSettings'),
            'GetSettingsHTML' => array('CCustomTypeSimaiLink', 'GetSettingsHTML'),
            'GetPropertyFieldHtml' => array('CCustomTypeSimaiLink', 'GetPropertyFieldHtml'),
            'GetPropertyFieldHtmlMulty' => array('CCustomTypeSimaiLink', 'GetPropertyFieldHtmlMulty'),
            //'ConvertToDB' => array('CCustomTypeSimaiLink', 'ConvertToDB'),
            //'ConvertFromDB' => array('CCustomTypeSimaiLink', 'ConvertFromDB'),
            'GetSearchContent' => array('CCustomTypeSimaiLink', 'GetSearchContent'),
            'GetAdminListViewHTML' => array('CCustomTypeSimaiLink', 'GetAdminListViewHTML'),
            'GetPublicEditHTML' => array('CCustomTypeSimaiLink', 'GetPublicEditHTML'),
            'GetPublicViewHTML' => array('CCustomTypeSimaiLink', 'GetPublicViewHTML'),
        );
    }

    public static function PrepareSettings($arFields)
    {
        if (isset($arFields["USER_TYPE_SETTINGS"]["_BLANK"]))
            $res = array("_BLANK" => ($arFields["USER_TYPE_SETTINGS"]["_BLANK"] == "Y" ? "Y" : "N"));
        else
            $res = array("_BLANK" => "N");
        
        return $res;
    }

    public static function GetSettingsHTML($arProperty, $strHTMLControlName, &$arPropertyFields)
    {
        $arPropertyFields = array(
            "HIDE" => array("DEFAULT_VALUE", "DISPLAY_TYPE", "EXPANDED", "PROPERTY_FILTER_HINT"),
            "SET" => array("FILTRABLE" => "Y", "SEARCHABLE" => "Y", "SMART_FILTER" => "N"),
            "USER_TYPE_SETTINGS_TITLE" => GetMessage('SMPI_LINK_SETTINGS')
        );

        $return = '';

        $return .= '
        <tr>
        <td>' . GetMessage('SMPI_LINK_BLANK') . ':</td>
        <td>
            <input type="hidden" name="' . $strHTMLControlName["NAME"] . '[_BLANK]" value="N">
            <input type="checkbox" name="' . $strHTMLControlName["NAME"] . '[_BLANK]" value="Y"' . ($arProperty["USER_TYPE_SETTINGS"]["_BLANK"] == "Y" ? " checked" : "") . '>
        </td>
        </tr>';

        return $return;
    }

    public static function GetPropertyFieldHtml($arProperty, $arValue, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION;
        $strResult = '';

        $inpid = md5('link_' . rand(0, 999));

        if ($_REQUEST['mode'] == 'frame') {
            $strResult .= '<div><input type="text" name="' . $strHTMLControlName["VALUE"] . '" size="10" value="' . htmlspecialchars($arValue["VALUE"]) . '" />';
            if ($arProperty['WITH_DESCRIPTION'] == 'Y') {
                $strResult .= '&nbsp;<input type="text" name="' . $strHTMLControlName["DESCRIPTION"] . '" size="8" value="' . htmlspecialchars($arValue["DESCRIPTION"]) . '" /></div>';
            }
        } else {
            $strResult .= '<select id="pro' . $inpid . '">';
            $strResult .= '<option value="http://">http://</option>';
            $strResult .= '<option value="https://">https://</option>';
            $strResult .= '<option value="/">/ (local from root)</option>';
            $strResult .= '<option value="./">./ (local from current)</option>';
            $strResult .= '<option value="../">../ (local from parent)</option>';
            $strResult .= '</select>&nbsp;';
            $strResult .= '<input id="link' . $inpid . '" value="' . htmlspecialcharsex($arValue['VALUE']) . '" size="15" type="text">';
            $strResult .= '<input id="full' . $inpid . '" type="hidden" name="' . $strHTMLControlName["VALUE"] . '" value="' . htmlspecialcharsex($arValue['VALUE']) . '">';
            if ($arProperty['WITH_DESCRIPTION'] == 'Y') {
                $strResult .= ' <span>' . GetMessage("SMPI_LINK_NAME") . '<input name="' . $strHTMLControlName["DESCRIPTION"] . '" value="' . htmlspecialcharsex($arValue['DESCRIPTION']) . '" size="15" type="text"></span>';
            }
            $strResult .= "<br>";

            $strResult .= '
<script type="text/javascript">
    BX.bind(
        BX("link' . $inpid . '"),
        "bxchange",
        function()
        {
            var linkval = BX("link' . $inpid . '").value;
            linkval = linkval.trim();
            var linkval_ = linkval.toLowerCase();
            if (linkval_.substr(0, 8) == "https://")
            {
                BX("pro' . $inpid . '").value = "https://";
                linkval = linkval.substr(8);
                while (linkval.substr(0, 1) == "/")
                {
                    linkval = linkval.substr(1);
                }
                BX("link' . $inpid . '").value = linkval;
                BX("full' . $inpid . '").value = "https://" + linkval;
            }
            else if (linkval_.substr(0, 7) == "http://")
            {
                BX("pro' . $inpid . '").value = "http://";
                linkval = linkval.substr(7);
                while (linkval.substr(0, 1) == "/")
                {
                    linkval = linkval.substr(1);
                }
                BX("link' . $inpid . '").value = linkval;
                BX("full' . $inpid . '").value = "http://" + linkval;
            }
            else if (linkval_.substr(0, 2) == "//")
            {
                BX("pro' . $inpid . '").value = "http://";
                while (linkval.substr(0, 1) == "/")
                {
                    linkval = linkval.substr(1);
                }
                BX("link' . $inpid . '").value = linkval;
                BX("full' . $inpid . '").value = "http://" + linkval;
            }
            else if (linkval_.substr(0, 1) == "/")
            {
                BX("pro' . $inpid . '").value = "/";
                while (linkval.substr(0, 1) == "/")
                {
                    linkval = linkval.substr(1);
                }
                BX("link' . $inpid . '").value = linkval;
                BX("full' . $inpid . '").value = "/" + linkval;
            }
            else if (linkval_.substr(0, 2) == "./")
            {
                BX("pro' . $inpid . '").value = "./";
                while (linkval.substr(0, 2) == "./")
                {
                    linkval = linkval.substr(2);
                }
                BX("link' . $inpid . '").value = linkval;
                BX("full' . $inpid . '").value = "./" + linkval;
            }
            else if (linkval_.substr(0, 3) == "../")
            {
                BX("pro' . $inpid . '").value = "../";
                while (linkval.substr(0, 3) == "../")
                {
                    linkval = linkval.substr(3);
                }
                BX("link' . $inpid . '").value = linkval;
                BX("full' . $inpid . '").value = "../" + linkval;
            }
            else if (linkval.length > 0)
            {
                BX("full' . $inpid . '").value = BX("pro' . $inpid . '").value + linkval;
            }
            else
            {
                BX("full' . $inpid . '").value = "";
            }
        }
    );
    
    BX.bind(
        BX("pro' . $inpid . '"),
        "bxchange",
        function()
        {
            var protocol_ = BX("pro' . $inpid . '").value;
            var linkval = BX("link' . $inpid . '").value;
            linkval = linkval.trim();
            while (linkval.substr(0, 1) == "/")
            {
                linkval = linkval.substr(1);
            }
            var linkval_ = linkval.toLowerCase();
            if (linkval_.substr(0, 8) == "https://")
            {
                BX("link' . $inpid . '").value = linkval.substr(8);
                BX("full' . $inpid . '").value = protocol_ + linkval.substr(8);
            }
            else if (linkval_.substr(0, 7) == "http://")
            {
                BX("link' . $inpid . '").value = linkval.substr(7);
                BX("full' . $inpid . '").value = protocol_ + linkval.substr(7);
            }
            else if (linkval_.substr(0, 2) == "./")
            {
                BX("link' . $inpid . '").value = linkval.substr(2);
                BX("full' . $inpid . '").value = protocol_ + linkval.substr(2);
            }
            else if (linkval_.substr(0, 3) == "../")
            {
                BX("link' . $inpid . '").value = linkval.substr(3);
                BX("full' . $inpid . '").value = protocol_ + linkval.substr(3);
            }
            else if (linkval.length > 0)
            {
                BX("full' . $inpid . '").value = protocol_ + linkval;
            }
            else
            {
                BX("full' . $inpid . '").value = "";
            }
        }
    );
    
    var linkval = BX("link' . $inpid . '").value;
    linkval = linkval.trim();
    var linkval_ = linkval.toLowerCase();
    if (linkval_.substr(0, 8) == "https://")
    {
        BX("pro' . $inpid . '").value = "https://";
        linkval = linkval.substr(8);
        while (linkval.substr(0, 1) == "/")
        {
            linkval = linkval.substr(1);
        }
        BX("link' . $inpid . '").value = linkval;
        BX("full' . $inpid . '").value = "https://" + linkval;
    }
    else if (linkval_.substr(0, 7) == "http://")
    {
        BX("pro' . $inpid . '").value = "http://";
        linkval = linkval.substr(7);
        while (linkval.substr(0, 1) == "/")
        {
            linkval = linkval.substr(1);
        }
        BX("link' . $inpid . '").value = linkval;
        BX("full' . $inpid . '").value = "http://" + linkval;
    }
    else if (linkval_.substr(0, 2) == "//")
    {
        BX("pro' . $inpid . '").value = "http://";
        while (linkval.substr(0, 1) == "/")
        {
            linkval = linkval.substr(1);
        }
        BX("link' . $inpid . '").value = linkval;
        BX("full' . $inpid . '").value = "http://" + linkval;
    }
    else if (linkval_.substr(0, 1) == "/")
    {
        BX("pro' . $inpid . '").value = "/";
        while (linkval.substr(0, 1) == "/")
        {
            linkval = linkval.substr(1);
        }
        BX("link' . $inpid . '").value = linkval;
        BX("full' . $inpid . '").value = "/" + linkval;
    }
    else if (linkval_.substr(0, 2) == "./")
    {
        BX("pro' . $inpid . '").value = "./";
        while (linkval.substr(0, 2) == "./")
        {
            linkval = linkval.substr(2);
        }
        BX("link' . $inpid . '").value = linkval;
        BX("full' . $inpid . '").value = "./" + linkval;
    }
    else if (linkval_.substr(0, 3) == "../")
    {
        BX("pro' . $inpid . '").value = "../";
        while (linkval.substr(0, 3) == "../")
        {
            linkval = linkval.substr(3);
        }
        BX("link' . $inpid . '").value = linkval;
        BX("full' . $inpid . '").value = "../" + linkval;
    }
    else if (linkval.length > 0)
    {
        BX("full' . $inpid . '").value = BX("pro' . $inpid . '").value + linkval;
    }
    else
    {
        BX("full' . $inpid . '").value = "";
    }
</script>
            ';
        }

        return $strResult;
    }

    public static function GetPropertyFieldHtmlMulty($arProperty, $arValues, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION;

        $APPLICATION->AddHeadScript('/bitrix/js/simai.property4iblock/edit.js');

        $inpid = md5('link_' . rand(0, 999));

        //print_r($strHTMLControlName);

        $strResult = '';

        if ($_REQUEST['mode'] == 'frame') {
            foreach ($arValues as $intPropertyValueID => $arValue) {
                $strResult .= '<div><input type="text" name="' . $strHTMLControlName["VALUE"] . '[' . $intPropertyValueID . '][VALUE]" size="10" value="' . htmlspecialchars($arValue["VALUE"]) . '" />';
                if ($arProperty['WITH_DESCRIPTION'] == 'Y') {
                    $strResult .= '&nbsp;<input type="text" name="' . $strHTMLControlName["VALUE"] . '[' . $intPropertyValueID . '][DESCRIPTION]" size="8" value="' . htmlspecialchars($arValue["DESCRIPTION"]) . '" /></div>';
                }
            }
            for ($i = 0; $i < 3; $i++) {
                $intPropertyValueID = 'n' . $i;
                $strResult .= '<div><input type="text" name="' . $strHTMLControlName["VALUE"] . '[' . $intPropertyValueID . '][VALUE]" size="10" value="" />';
                if ($arProperty['WITH_DESCRIPTION'] == 'Y') {
                    $strResult .= '&nbsp;<input type="text" name="' . $strHTMLControlName["VALUE"] . '[' . $intPropertyValueID . '][DESCRIPTION]" size="8" value="" /></div>';
                }
            }
        } else {
            $strResult .= '<table cellpadding="0" cellspacing="0" border="0" class="nopadding" width="100%" id="tb' . $inpid . '">';

            foreach ($arValues as $intPropertyValueID => $arValue) {
                $strResult .= '<tr><td>';
                $strResult .= '<select class="sf_link_protocol" id="pro' . $inpid . '_' . $intPropertyValueID . '" rel="' . $inpid . '_' . $intPropertyValueID . '">';
                $strResult .= '<option value="http://">http://</option>';
                $strResult .= '<option value="https://">https://</option>';
                $strResult .= '<option value="/">/ (local from root)</option>';
                $strResult .= '<option value="./">./ (local from current)</option>';
                $strResult .= '<option value="../">../ (local from parent)</option>';
                $strResult .= '</select>&nbsp;';
                $strResult .= '<input class="sf_link_input" id="link' . $inpid . '_' . $intPropertyValueID . '" rel="' . $inpid . '_' . $intPropertyValueID . '" value="' . htmlspecialcharsex($arValue['VALUE']) . '" size="15" type="text">';
                $strResult .= '<input id="full' . $inpid . '_' . $intPropertyValueID . '" type="hidden" name="' . $strHTMLControlName["VALUE"] . '[' . $intPropertyValueID . '][VALUE]" value="' . htmlspecialcharsex($arValue['VALUE']) . '">';
                if ($arProperty['WITH_DESCRIPTION'] == 'Y') {
                    $strResult .= ' <span>' . GetMessage("SMPI_LINK_NAME") . '<input name="' . $strHTMLControlName["VALUE"] . '[' . $intPropertyValueID . '][DESCRIPTION]" value="' . htmlspecialcharsex($arValue['DESCRIPTION']) . '" size="15" type="text"></span>';
                }
                $strResult .= "</td></tr>";
            }

            if (!$bVarsFromForm && (int)$arProperty['MULTIPLE_CNT'] > 0) {
                for ($i = 0; $i < $arProperty['MULTIPLE_CNT']; $i++) {
                    $intPropertyValueID = 'n' . $i;

                    $strResult .= '<tr><td>';
                    $strResult .= '<select class="sf_link_protocol" id="pro' . $inpid . '__' . $intPropertyValueID . '__" rel="' . $inpid . '__' . $intPropertyValueID . '__">';
                    $strResult .= '<option value="http://">http://</option>';
                    $strResult .= '<option value="https://">https://</option>';
                    $strResult .= '<option value="/">(local from root) /</option>';
                    $strResult .= '<option value="./">(local from current) ./</option>';
                    $strResult .= '<option value="../">(local from parent) ../</option>';
                    $strResult .= '</select>&nbsp;';
                    $strResult .= '<input class="sf_link_input" id="link' . $inpid . '__' . $intPropertyValueID . '__" rel="' . $inpid . '__' . $intPropertyValueID . '__" value="" size="15" type="text">';
                    $strResult .= '<input id="full' . $inpid . '__' . $intPropertyValueID . '__" type="hidden" name="' . $strHTMLControlName["VALUE"] . '[' . $intPropertyValueID . '][VALUE]" value="">';
                    if ($arProperty['WITH_DESCRIPTION'] == 'Y') {
                        $strResult .= ' <span>' . GetMessage("SMPI_LINK_NAME") . '<input name="' . $strHTMLControlName["VALUE"] . '[' . $intPropertyValueID . '][DESCRIPTION]" value="" size="15" type="text"></span>';
                    }
                    $strResult .= "</td></tr>";
                }
            }

            $strResult .= '<tr><td><input type="button" value="' . GetMessage("IBLOCK_AT_PROP_ADD") . '" onClick="addNewRowSFPIB(\'tb' . $inpid . '\')"></td></tr>';
            $strResult .= "<script type=\"text/javascript\">BX.addCustomEvent('onAutoSaveRestore', function(ob, data) {for (var i in data){if (i.substring(0," . (strlen($strHTMLControlName["VALUE"]) + 1) . ")=='" . CUtil::JSEscape($strHTMLControlName["VALUE"]) . "['){addNewRowSFPIB('tb" . $inpid . "')}}})</script>";

            $strResult .= "</table>";

            $strResult .= '
<script type="text/javascript">
    BX.bindDelegate(
        BX("tb' . $inpid . '"),
        "bxchange",
        {
            "tag" : "input",
            "class" : "sf_link_input"
        },
        function()
        {
            var link_md5_id = this.getAttribute("rel");
            var linkval = BX("link" + link_md5_id).value;
            linkval = linkval.trim();
            var linkval_ = linkval.toLowerCase();
            if (linkval_.substr(0, 8) == "https://")
            {
                BX("pro" + link_md5_id).value = "https://";
                linkval = linkval.substr(8);
                while (linkval.substr(0, 1) == "/")
                {
                    linkval = linkval.substr(1);
                }
                BX("link" + link_md5_id).value = linkval;
                BX("full" + link_md5_id).value = "https://" + linkval;
            }
            else if (linkval_.substr(0, 7) == "http://")
            {
                BX("pro" + link_md5_id).value = "http://";
                linkval = linkval.substr(7);
                while (linkval.substr(0, 1) == "/")
                {
                    linkval = linkval.substr(1);
                }
                BX("link" + link_md5_id).value = linkval;
                BX("full" + link_md5_id).value = "http://" + linkval;
            }
            else if (linkval_.substr(0, 2) == "//")
            {
                BX("pro" + link_md5_id).value = "http://";
                while (linkval.substr(0, 1) == "/")
                {
                    linkval = linkval.substr(1);
                }
                BX("link" + link_md5_id).value = linkval;
                BX("full" + link_md5_id).value = "http://" + linkval;
            }
            else if (linkval_.substr(0, 3) == "../")
            {
                BX("pro" + link_md5_id).value = "../";
                while (linkval.substr(0, 3) == "../")
                {
                    linkval = linkval.substr(3);
                }
                BX("link" + link_md5_id).value = linkval;
                BX("full" + link_md5_id).value = "../" + linkval;
            }
            else if (linkval_.substr(0, 2) == "./")
            {
                BX("pro" + link_md5_id).value = "./";
                while (linkval.substr(0, 2) == "./")
                {
                    linkval = linkval.substr(2);
                }
                BX("link" + link_md5_id).value = linkval;
                BX("full" + link_md5_id).value = "./" + linkval;
            }
            else if (linkval_.substr(0, 1) == "/")
            {
                BX("pro" + link_md5_id).value = "/";
                while (linkval.substr(0, 1) == "/")
                {
                    linkval = linkval.substr(1);
                }
                BX("link" + link_md5_id).value = linkval;
                BX("full" + link_md5_id).value = "/" + linkval;
            }
            else if (linkval.length > 0)
            {
                BX("full" + link_md5_id).value = BX("pro" + link_md5_id).value + linkval;
            }
            else
            {
                BX("full" + link_md5_id).value = "";
            }
        }
    );
    
    
    BX.bindDelegate(
        BX("tb' . $inpid . '"),
        "bxchange",
        {
            "tag" : "select",
            "class" : "sf_link_protocol"
        },
        function()
        {
            var link_md5_id = this.getAttribute("rel");
            var protocol_ = BX("pro" + link_md5_id).value;
            var linkval = BX("link" + link_md5_id).value;
            linkval = linkval.trim();
            while (linkval.substr(0, 1) == "/")
            {
                linkval = linkval.substr(1);
            }
            var linkval_ = linkval.toLowerCase();
            if (linkval_.substr(0, 8) == "https://")
            {
                BX("link" + link_md5_id).value = linkval.substr(8);
                BX("full" + link_md5_id).value = protocol_ + linkval.substr(8);
            }
            else if (linkval_.substr(0, 7) == "http://")
            {
                BX("link" + link_md5_id).value = linkval.substr(7);
                BX("full" + link_md5_id).value = protocol_ + linkval.substr(7);
            }
            else if (linkval_.substr(0, 2) == "./")
            {
                BX("link" + link_md5_id).value = linkval.substr(2);
                BX("full" + link_md5_id).value = protocol_ + linkval.substr(2);
            }
            else if (linkval_.substr(0, 3) == "../")
            {
                BX("link" + link_md5_id).value = linkval.substr(3);
                BX("full" + link_md5_id).value = protocol_ + linkval.substr(3);
            }
            else if (linkval.length > 0)
            {
                BX("full" + link_md5_id).value = protocol_ + linkval;
            }
            else
            {
                BX("full" + link_md5_id).value = "";
            }
            
        }
    );
    
    
    var obPT = BX.findChildren(BX("tb' . $inpid . '"), 
        {
            "tag" : "input",
            "class" : "sf_link_input"
        }, 
        true
    );
    
    obPT.forEach(function(el) 
    {
        var link_md5_id = el.getAttribute("rel");
        var linkval = BX("link" + link_md5_id).value;
        linkval = linkval.trim();
        var linkval_ = linkval.toLowerCase();
        if (linkval_.substr(0, 8) == "https://")
        {
            BX("pro" + link_md5_id).value = "https://";
            linkval = linkval.substr(8);
            while (linkval.substr(0, 1) == "/")
            {
                linkval = linkval.substr(1);
            }
            BX("link" + link_md5_id).value = linkval;
            BX("full" + link_md5_id).value = "https://" + linkval;
        }
        else if (linkval_.substr(0, 7) == "http://")
        {
            BX("pro" + link_md5_id).value = "http://";
            linkval = linkval.substr(7);
            while (linkval.substr(0, 1) == "/")
            {
                linkval = linkval.substr(1);
            }
            BX("link" + link_md5_id).value = linkval;
            BX("full" + link_md5_id).value = "http://" + linkval;
        }
        else if (linkval_.substr(0, 2) == "//")
        {
            BX("pro" + link_md5_id).value = "http://";
            while (linkval.substr(0, 1) == "/")
            {
                linkval = linkval.substr(1);
            }
            BX("link" + link_md5_id).value = linkval;
            BX("full" + link_md5_id).value = "http://" + linkval;
        }
        else if (linkval_.substr(0, 1) == "/")
        {
            BX("pro" + link_md5_id).value = "/";
            while (linkval.substr(0, 1) == "/")
            {
                linkval = linkval.substr(1);
            }
            BX("link" + link_md5_id).value = linkval;
            BX("full" + link_md5_id).value = "/" + linkval;
        }
        else if (linkval_.substr(0, 2) == "./")
        {
            BX("pro" + link_md5_id).value = "./";
            while (linkval.substr(0, 2) == "./")
            {
                linkval = linkval.substr(2);
            }
            BX("link" + link_md5_id).value = linkval;
            BX("full" + link_md5_id).value = "./" + linkval;
        }
        else if (linkval_.substr(0, 3) == "../")
        {
            BX("pro" + link_md5_id).value = "../";
            while (linkval.substr(0, 3) == "../")
            {
                linkval = linkval.substr(3);
            }
            BX("link" + link_md5_id).value = linkval;
            BX("full" + link_md5_id).value = "../" + linkval;
        }
        else if (linkval.length > 0)
        {
            BX("full" + link_md5_id).value = BX("pro" + link_md5_id).value + linkval;
        }
        else
        {
            BX("full" + link_md5_id).value = "";
        }
    });
</script>
            ';
        }
        return $strResult;
    }

    public static function GetPublicEditHTML($arProperty, $arValue, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION;

        $APPLICATION->AddHeadScript('/bitrix/js/simai.property4iblock/link.js');

        $strResult = '';

        $inpid = $strHTMLControlName["VALUE"];

        $strResult .= '<select id="pro' . $inpid . '" onchange="SFIBChangeProptocol(\'' . $inpid . '\')">';
        $strResult .= '<option value="http://">http://</option>';
        $strResult .= '<option value="https://">https://</option>';
        $strResult .= '<option value="/">/ (local from root)</option>';
        $strResult .= '<option value="./">./ (local from current)</option>';
        $strResult .= '<option value="../">../ (local from parent)</option>';
        $strResult .= '</select>&nbsp;';
        $strResult .= '<input id="link' . $inpid . '" value="' . htmlspecialcharsex($arValue['VALUE']) . '" size="15" type="text" onchange="SFIBParseUrl(\'' . $inpid . '\')" oncut="SFIBParseUrl(\'' . $inpid . '\')" onpaste="SFIBParseUrl(\'' . $inpid . '\')" ondrop="SFIBParseUrl(\'' . $inpid . '\')" onkeyup="SFIBParseUrl(\'' . $inpid . '\')">';
        $strResult .= '<input id="full' . $inpid . '" type="hidden" name="' . $strHTMLControlName["VALUE"] . '" value="' . htmlspecialcharsex($arValue['VALUE']) . '">';
        if ($arProperty['WITH_DESCRIPTION'] == 'Y') {
            $strResult .= ' <span>' . GetMessage("SMPI_LINK_NAME") . '<input name="' . str_replace('[VALUE]', '[DESCRIPTION]', $strHTMLControlName["VALUE"]) . '" value="' . htmlspecialcharsex($arValue['DESCRIPTION']) . '" size="15" type="text"></span>';
        }
        $strResult .= '
        <script>SFIBParseUrl(\'' . $inpid . '\');</script>
        <br>';

        return $strResult;
    }

    public static function GetPublicViewHTML($arProperty, $arValue, $strHTMLControlName)
    {
        $arSettings = self::PrepareSettings($arProperty);

        $arVals = array();
        if (!is_array($arProperty['VALUE'])) {
            $arProperty['VALUE'] = array($arProperty['VALUE']);
            $arProperty['DESCRIPTION'] = array($arProperty['DESCRIPTION']);
        }
        foreach ($arProperty['VALUE'] as $i => $value) {
            $arVals[$value] = $arProperty['DESCRIPTION'][$i];
        }

        $strResult = '';
        $strResult = '<a ' . ($arSettings["_BLANK"] == 'Y' ? 'target="_blank"' : '') . ' href="' . trim($arValue['VALUE']) . '">' . (trim($arVals[$arValue['VALUE']]) ? trim($arVals[$arValue['VALUE']]) : trim($arValue['VALUE'])) . '</a>';
        return $strResult;
    }

    public static function GetAdminListViewHTML($arProperty, $arValue, $strHTMLControlName)
    {
        $arSettings = self::PrepareSettings($arProperty);

        $strResult = '';
        $strResult = '<a ' . ($arSettings["_BLANK"] == 'Y' ? 'target="_blank"' : '') . ' href="' . trim($arValue['VALUE']) . '">' . (trim($arValue['DESCRIPTION']) ? trim($arValue['DESCRIPTION']) : trim($arValue['VALUE'])) . '</a>';
        return $strResult;
    }

    public static function GetSearchContent($arProperty, $value, $strHTMLControlName)
    {
        if (trim($value['VALUE']) != '') {
            return $value['VALUE'] . ' ' . $value['DESCRIPTION'];
        }

        return '';
    }
}