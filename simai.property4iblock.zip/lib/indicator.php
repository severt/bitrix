
<?php
IncludeModuleLangFile(__FILE__);

use Bitrix\Iblock;
use Bitrix\Main\Application;
use Bitrix\Main\IO;
use Bitrix\Main\File\Image;
use Bitrix\Main\Loader;

class CCustomTypeSimaiIndicator
{
    public static function GetUserTypeDescription()
    {
        return array(
            'PROPERTY_TYPE' => 'L',
            'USER_TYPE' => 'simai_indicator',
            'DESCRIPTION' => GetMessage('SMPI_INDICATOR_PROP'),
            'PrepareSettings' => array('CCustomTypeSimaiIndicator', 'PrepareSettings'),
            'GetSettingsHTML' => array('CCustomTypeSimaiIndicator', 'GetSettingsHTML'),
            'GetPropertyFieldHtml' => array('CCustomTypeSimaiIndicator', 'GetPropertyFieldHtml'),
            'GetPropertyFieldHtmlMulty' => array('CCustomTypeSimaiIndicator', 'GetPropertyFieldHtmlMulty'),
            //'ConvertToDB' => array('CCustomTypeSimaiIndicator', 'ConvertToDB'),
            //'ConvertFromDB' => array('CCustomTypeSimaiIndicator', 'ConvertFromDB'),
            'GetSearchContent' => array('CCustomTypeSimaiIndicator', 'GetSearchContent'),
            //'GetAdminListViewHTML' => array('CCustomTypeSimaiIndicator', 'GetAdminListViewHTML'),
            //'GetPublicFilterHTML' => array('CCustomTypeSimaiIndicator', 'GetPublicFilterHTML'),
            'GetPublicEditHTML' => array('CCustomTypeSimaiIndicator', 'GetPublicEditHTML'),
            'GetPublicViewHTML' => array('CCustomTypeSimaiIndicator', 'GetPublicViewHTML'),
        );
    }

    public static function PrepareSettings($arFields)
    {
        return array('MULTIPLE' => 'N', 'USER_TYPE_SETTINGS' => $arFields["USER_TYPE_SETTINGS"]);
    }

    public static function GetSettingsHTML($arProperty, $strHTMLControlName, &$arPropertyFields)
    {
        global $APPLICATION;

        $arPropertyFields = array(
            "HIDE" => array("DEFAULT_VALUE", "DISPLAY_TYPE", "EXPANDED", "PROPERTY_FILTER_HINT", "MULTIPLE"),
            "SET" => array("FILTRABLE" => "Y", "SEARCHABLE" => "Y", "SMART_FILTER" => "N", "MULTIPLE" => "N"),
        );

        $return = '<tr><td colspan="2" style="font-weight:bold; text-align:left;">' . GetMessage('SP4IB_COLORS_INDICATOR') . '</td></tr>';

        $i = 0;
        $enums = array();
        if ($arProperty["ID"]) {
            $res = CIBlockPropertyEnum::GetList(array("SORT" => "ASC"), array("IBLOCK_ID" => $arProperty["IBLOCK_ID"], "PROPERTY_ID" => $arProperty["ID"]));
            while ($enum = $res->GetNext()) {
                $i++;
                $enums[$i] = $enum;
            }
        }

        foreach ($enums as $enum) {
            $color = htmlspecialcharsbx($arProperty["USER_TYPE_SETTINGS"]["COLORS"][$enum['ID']]);

            $return .= '
            <tr>
            <td>' . $enum['VALUE'] . ':</td>
            <td>
            <script type="text/javascript">
            function ColorPick' . $enum['ID'] . '(color)
            {
                if (color == false)
                {
                    BX("bx_btn_colorpick' . $enum['ID'] . '").style.background = "#BFEBFB";
                    BX("colorpick_inp_' . $enum['ID'] . '").value = "";
                }
                else
                {
                    BX("bx_btn_colorpick' . $enum['ID'] . '").style.background = color;
                    BX("colorpick_inp_' . $enum['ID'] . '").value = color;
                }
            }
            </script> 
            
            <input type="text" size="12" id="colorpick_inp_' . $enum['ID'] . '" name="' . $strHTMLControlName["NAME"] . '[COLORS][' . $enum['ID'] . ']" value="' . $color . '" style="float:left; margin-right:6px;">
            ';
            ob_start();
            $APPLICATION->IncludeComponent(
                "bitrix:main.colorpicker",
                "",
                array(
                    "COMPOSITE_FRAME_MODE" => "A",
                    "COMPOSITE_FRAME_TYPE" => "AUTO",
                    "ID" => "colorpick" . $enum['ID'],
                    "NAME" => "",
                    "ONSELECT" => "ColorPick" . $enum['ID'],
                    "SHOW_BUTTON" => "Y"
                ),
                false,
                array("HIDE_ICONS" => "Y")
            );
            $return .= ob_get_contents();
            ob_end_clean();
            $return .= '<script type="text/javascript">BX.ready(function() {ColorPick' . $enum['ID'] . '("' . $color . '")});</script>';
            $return .= '
            </td>
            </tr>';
        }

        return $return;
    }

    public static function GetPropertyFieldHtml($arProperty, $arValue, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION, $ID;

        ob_start();
        if ($_REQUEST['mode'] != 'frame') {
            _ShowListPropertyField('PROP[' . $arProperty["ID"] . ']', $arProperty, $arValue, (!$bVarsFromForm && $ID <= 0), false);
        }
        $return .= ob_get_contents();
        ob_end_clean();

        return $return;
    }

    public static function GetPropertyFieldHtmlMulty($arProperty, $arValues, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION, $ID;

        /*if (is_array($arValues))
        {
            foreach ($arValues as $i => $arValue)
            {
                $arValues[$i]['VALUE'] = current($arValue['VALUE']);
            }
        }*/

        ob_start();
        if ($_REQUEST['mode'] != 'frame') {
            _ShowListPropertyField('PROP[' . $arProperty["ID"] . ']', $arProperty, $arValues, (!$bVarsFromForm && $ID <= 0), false);
        }
        $return .= ob_get_contents();
        ob_end_clean();

        return $return;
    }

    public static function ConvertFromDB($arProperty, $value)
    {
        /*if ($arProperty['PROPERTY_VALUE_ID'] > 0 && !is_array($value['VALUE']))
        {
            $value['VALUE'] = array($arProperty['PROPERTY_VALUE_ID'] => $value['VALUE']);
        }*/

        return $value;
    }

    public static function GetPublicEditHTML($arProperty, $arValue, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION, $DB;

        $value = $arValue['VALUE'];

        if ($arProperty['VALUE_ENUM_ID'])
            $value = $arProperty['VALUE_ENUM_ID'];

        if ($arProperty['PROPERTY_VALUE_ID'])
            $value_id = $arProperty['PROPERTY_VALUE_ID'];

        if (is_array($value))
            $value = current($value);

        if (is_array($value_id))
            $value_id = current($value_id);

        if ($arProperty['ELEMENT_ID']) {
            $element_id = $arProperty['ELEMENT_ID'];
        } elseif (strpos($value_id, ':')) {
            $element_id = intval($value_id);
        } elseif ($value_id > 0) {
            $res = $DB->Query('select * from `b_iblock_element_property` where `ID`=' . intval($value_id));
            if ($arr = $res->fetch())
                $element_id = $arr['IBLOCK_ELEMENT_ID'];
        }

        $bInitDef = (!$value && !$element_id);

        $strResult = '';

        $bNoValue = true;
        $prop_enums = CIBlockProperty::GetPropertyEnum($arProperty['ID']);
        while ($ar_enum = $prop_enums->Fetch()) {
            if ($bInitDef)
                $sel = ($ar_enum["DEF"] == "Y");
            elseif (is_array($value))
                $sel = in_array($ar_enum["ID"], $value);
            else
                $sel = ($ar_enum["ID"] == $value);
            if ($sel)
                $bNoValue = false;
            $strResult .= '<option value="' . htmlspecialcharsbx($ar_enum["ID"]) . '"' . ($sel ? " selected" : "") . '>' . htmlspecialcharsex($ar_enum["VALUE"]) . '</option>';
        }

        $strResult = '<select name="' . $strHTMLControlName["VALUE"] . '">' .
            '<option value=""' . ($bNoValue ? ' selected' : '') . '>' . htmlspecialcharsex(($def_text ? $def_text : GetMessage("IBLOCK_AT_PROP_NA"))) . '</option>' .
            $strResult .
            '</select>';

        return $strResult;
    }


    public static function GetPublicViewHTML($arProperty, $arValue, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION, $DB;
        $APPLICATION->SetAdditionalCSS('/bitrix/themes/.default/simai.property4iblock.css');

        $value = $arValue['VALUE'];
        $title = '';
        if ($arProperty['VALUE_ENUM_ID']) {
            $value = $arProperty['VALUE_ENUM_ID'];
        }
        if (is_array($value))
            $value = current($value);

        $color = '';
        if ($value) {
            $color = '#BFEBFB';
            
            if (isset($arProperty["USER_TYPE_SETTINGS"]["COLORS"]))
            {
                if (is_array($arProperty["USER_TYPE_SETTINGS"]["COLORS"]))
                {
                    if ($arProperty["USER_TYPE_SETTINGS"]["COLORS"][$value])
                        $color = $arProperty["USER_TYPE_SETTINGS"]["COLORS"][$value];
                }
            }

            $title = CIBlockPropertyEnum::GetByID($value);
            $title = $title['VALUE'];
        }

        $strResult = '<span title="' . htmlspecialcharsbx($title) . '" class="sp4ib-indicator" style="' . ($color ? 'background-color:' . htmlspecialcharsbx($color) : 'border:1px solid #C5C9CE') . '"></span>';

        return $strResult;
    }

    public static function GetPublicFilterHTML($arProperty, $strHTMLControlName)
    {
        $filterOption = new \Bitrix\Main\UI\Filter\Options($strHTMLControlName["GRID_ID"]);
        $filterData = $filterOption->getFilter(array());

        $values = $filterData[$strHTMLControlName["VALUE"]];

        $enums = array();
        $property_enums = CIBlockPropertyEnum::GetList(array("DEF" => "DESC", "SORT" => "ASC"), array("IBLOCK_ID" => $arProperty["IBLOCK_ID"], "PROPERTY_ID" => $arProperty["ID"]));
        while ($enum_fields = $property_enums->GetNext()) {
            $enums[$enum_fields["ID"]] = $enum_fields["VALUE"];
        }

        $strResult .= '<input id="ind_' . htmlspecialcharsbx($strHTMLControlName['VALUE']) . '" type="hidden" name="' . htmlspecialcharsbx($strHTMLControlName['VALUE']) . '" value="' . htmlspecialcharsbx($values) . '">';

        $strResult .= '<select name="' . htmlspecialcharsbx($strHTMLControlName['VALUE']) . '" onchange="document.getElementById(\'ind_' . htmlspecialcharsbx($strHTMLControlName['VALUE']) . '\').value=this.value;">';
        $strResult .= '<option></option>';
        foreach ($enums as $key => $value) {
            $strResult .= '<option value="' . htmlspecialcharsbx($key) . '"' . (in_array($key, $values) ? ' selected' : '') . '>' . htmlspecialcharsbx($value) . '</option>';
        }
        $strResult .= '</select>';

        return $strResult;
    }

    public static function GetAdminListViewHTML($arProperty, $arValue, $strHTMLControlName)
    {
        $strResult = $arValue['VALUE'];
        return $strResult;
    }

    public static function GetSearchContent($arProperty, $value, $strHTMLControlName)
    {
        return '';
    }
}
