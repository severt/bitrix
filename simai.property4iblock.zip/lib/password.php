
<?php
IncludeModuleLangFile(__FILE__);

use Bitrix\Iblock;
use Bitrix\Main\Application;
use Bitrix\Main\IO;
use Bitrix\Main\File\Image;
use Bitrix\Main\Loader;

class CCustomTypeSimaiPassword
{
    public static function GetUserTypeDescription()
    {
        return array(
            'PROPERTY_TYPE' => 'S',
            'USER_TYPE' => 'simai_password',
            'DESCRIPTION' => GetMessage('SMPI_PASSWORD_PROP'),
            'PrepareSettings' => array('CCustomTypeSimaiPassword', 'PrepareSettings'),
            'GetSettingsHTML' => array('CCustomTypeSimaiPassword', 'GetSettingsHTML'),
            'GetPropertyFieldHtml' => array('CCustomTypeSimaiPassword', 'GetPropertyFieldHtml'),
//            'GetPropertyFieldHtmlMulty' => array('CCustomTypeSimaiPassword', 'GetPropertyFieldHtmlMulty'),
            'ConvertToDB' => array('CCustomTypeSimaiPassword', 'ConvertToDB'),
            //'ConvertFromDB' => array('CCustomTypeSimaiPassword', 'ConvertFromDB'),
            'GetSearchContent' => array('CCustomTypeSimaiPassword', 'GetSearchContent'),
            'GetAdminListViewHTML' => array('CCustomTypeSimaiPassword', 'GetAdminListViewHTML'),
            'GetPublicEditHTML' => array('CCustomTypeSimaiPassword', 'GetPublicEditHTML'),
            'GetPublicViewHTML' => array('CCustomTypeSimaiPassword', 'GetPublicViewHTML'),
        );
    }

    public static function ConvertToDB($arProperty, $value)
    {
        $db_iblock_id = intval($arProperty["IBLOCK_ID"]);
        $db_element_id = intval($arProperty["ELEMENT_ID"]);
        $db_prop_id = htmlspecialcharsex($arProperty["ID"]);
        
        $ib_find = false;
        
        if ($db_iblock_id > 0 && $db_element_id > 0 && !empty($db_prop_id)) {
            $old_res = CIBlockElement::GetProperty($db_iblock_id, $db_element_id, array("sort" => "asc"), array("ID" => $db_prop_id));

            while ($ob_value_res = $old_res->GetNext())
            {
                $ib_find = true;
                
                if ($ob_value_res['PROPERTY_VALUE_ID'] == $value['PROPERTY_VALUE_ID']) {
                    $old_value = $ob_value_res;
                }
            }
        }

        if ($value["DESCRIPTION"] == "UPDATE") {
            return $value;
        } else {
            if ($value["DESCRIPTION"] != "EMPTY" || $value["VALUE"] == "************")
                return $old_value['VALUE'];
        }
        
        return $value;
    }

    public static function PrepareSettings($arFields)
    {
        return array(
            "S_CHECK" => ($arFields["USER_TYPE_SETTINGS"]["S_CHECK"] == "Y" ? "Y" : "N"),
            "ACT" => ($arFields["USER_TYPE_SETTINGS"]["ACT"]),
            "METHOD_SEND" => ($arFields["USER_TYPE_SETTINGS"]["METHOD_SEND"]),
            "INP_IDCHAT" => ($arFields["USER_TYPE_SETTINGS"]["INP_IDCHAT"]),
            "USER_MESSAGE" => ($arFields["USER_TYPE_SETTINGS"]["USER_MESSAGE"]),
            "MACROS" => ($arFields["USER_TYPE_SETTINGS"]["MACROS"]),
            "MACROS2" => ($arFields["USER_TYPE_SETTINGS"]["MACROS2"]),
            "MACROS3" => ($arFields["USER_TYPE_SETTINGS"]["MACROS3"]),
            "MACROS4" => ($arFields["USER_TYPE_SETTINGS"]["MACROS4"]),
            "ADMIN_CHECK" => ($arFields["USER_TYPE_SETTINGS"]["ADMIN_CHECK"]),
            "SEND_MESSAGE" => ($arFields["USER_TYPE_SETTINGS"]["SEND_MESSAGE"]),
            "MAIL_CHAT" => ($arFields["USER_TYPE_SETTINGS"]["MAIL_CHAT"]),
        );
    }

    public static function GetSettingsHTML($arProperty, $strHTMLControlName, &$arPropertyFields)
    {
        global $APPLICATION;
        $arPropertyFields = array(
            "HIDE" => array("DEFAULT_VALUE", "DISPLAY_TYPE", "EXPANDED", "PROPERTY_FILTER_HINT"),
            "SET" => array("FILTRABLE" => "N", "SEARCHABLE" => "N", "SMART_FILTER" => "N"),
        );
        $APPLICATION->SetAdditionalCSS('/bitrix/themes/.default/simai.property4iblock.css');

        $inpid = rand(99, 9999);

        $return = '';

        if (!CModule::IncludeModule("im")) {
            $error_module = '
            <tr class="web-message">
                <td></td>
                <td align="left">
                    <span class="required">'.GetMessage("SP4I_IM").'</span>
                </td>
            </tr>';
        } else {
            $error_module = '';
        }



        $return .= '
        <tr>
            <td>'.GetMessage("SP4I_USE_MODUL").'</td>
            <td>
                <input type="hidden" name="' . $strHTMLControlName["NAME"] . '[S_CHECK]" value="N">
                <input type="checkbox" id="s_check_' . $inpid . '" name="' . $strHTMLControlName["NAME"] . '[S_CHECK]" ' . ($arProperty["USER_TYPE_SETTINGS"]["S_CHECK"] == "Y" ? " checked" : "") . ' value="Y">
            </td>
        </tr>
        <tr class="st-modul">
            <td>'.GetMessage("SP4I_ACT").'</td>
            <td>
                <select style="width:300px" id="id_act" name="' . $strHTMLControlName["NAME"] . '[ACT]">
                        <option value="0" '. (($arProperty["USER_TYPE_SETTINGS"]["ACT"]==0)?"selected":"") .'>'.GetMessage("SP4I_ACT0").'</option>
                        <option value="1" '. (($arProperty["USER_TYPE_SETTINGS"]["ACT"]==1)?"selected":"") .'>'.GetMessage("SP4I_ACT1").'</option>
                        <option value="2" '. (($arProperty["USER_TYPE_SETTINGS"]["ACT"]==2)?"selected":"") .'>'.GetMessage("SP4I_ACT2").'</option>
                </select>
            </td>
        </tr>
        <tbody class="st-act" style="display: table-row-group;">

        <tr>
            <td class="adm-detail-content-cell-l bx-field-name">'.GetMessage("SP4I_ADMINCHECK").'</td>
            <td class="adm-detail-content-cell-r">
                <input type="hidden" name="' . $strHTMLControlName["NAME"] . '[ADMIN_CHECK]" value="N">
                <input type="checkbox" id="admin_check_' . $inpid . '" name="' . $strHTMLControlName["NAME"] . '[ADMIN_CHECK]" ' . ($arProperty["USER_TYPE_SETTINGS"]["ADMIN_CHECK"] == "Y" ? " checked" : "") . ' value="Y">
            </td>
        </tr>
        <tr>
            <td class="adm-detail-content-cell-l bx-field-name">'.GetMessage("SP4I_METHOD").'</td>
            <td class="adm-detail-content-cell-r">
                <select style="width:300px" name="' . $strHTMLControlName["NAME"] . '[METHOD_SEND]" id="id_method_send">
                    <option value="message" '. (($arProperty["USER_TYPE_SETTINGS"]["METHOD_SEND"]=="message")?"selected":"") .'>'.GetMessage("SP4I_METHOD0").'</option>
                    <option value="mail" '. (($arProperty["USER_TYPE_SETTINGS"]["METHOD_SEND"]=="mail")?"selected":"") .'>'.GetMessage("SP4I_METHOD1").'</option>
                </select>
            </td>
        </tr>
        '.$error_module.'
        <tr class="web-message" style="display: table-row;">
            <td class="adm-detail-content-cell-l bx-field-name">'.GetMessage("SP4I_ID").'</td>
            <td class="adm-detail-content-cell-r">
                <input type="text" size="50" maxlength="255" value="'. $arProperty["USER_TYPE_SETTINGS"]["INP_IDCHAT"] .'" name="' . $strHTMLControlName["NAME"] . '[INP_IDCHAT]">
                '.GetMessage("SP4I_ID_INFO").'
            </td>
        </tr>
        <tr class="web-message" style="display: table-row;">
            <td class="adm-detail-content-cell-l bx-field-name">'.GetMessage("SP4I_SEND").'</td>
            <td class="adm-detail-content-cell-r">
                <select style="width:300px" name="' . $strHTMLControlName["NAME"] . '[SEND_MESSAGE]" id="id_send_message">
                    <option value="system" '. (($arProperty["USER_TYPE_SETTINGS"]["SEND_MESSAGE"]=="system")?"selected":"") .'>'.GetMessage("SP4I_SEND0").'</option>
                    <option value="user" '. (($arProperty["USER_TYPE_SETTINGS"]["SEND_MESSAGE"]=="user")?"selected":"") .'>'.GetMessage("SP4I_SEND1").'</option>
                </select>
            </td>
        </tr>
        <tr class="web-message__user" style="display: table-row;">
            <td class="adm-detail-content-cell-l bx-field-name">'.GetMessage("SP4I_SENDER").'</td>
            <td class="adm-detail-content-cell-r">
                ';
        ob_start();
        $APPLICATION->IncludeComponent(
            'bitrix:main.user.selector',
            ' ',
            [
                "ID" => "mail_client_config_queue",
                "API_VERSION" => 3,
                "LIST" => array($arProperty["USER_TYPE_SETTINGS"]["USER_MESSAGE"]),
                "INPUT_NAME" => $strHTMLControlName["NAME"] . '[USER_MESSAGE]',
                "USE_SYMBOLIC_ID" => true,
                "BUTTON_SELECT_CAPTION" => GetMessage("SP4I_USER_EDIT"),
                "SELECTOR_OPTIONS" =>
                    [
                        "departmentSelectDisable" => "Y",
                        'context' => 'MAIL_CLIENT_CONFIG_QUEUE',
                        'contextCode' => 'U',
                        'enableAll' => 'N',
                        'userSearchArea' => 'I'
                    ]
            ]
        );
        $return .= ob_get_contents();
        ob_end_clean();
        $return .='

            </td>
        </tr>
       <tr class="e-mail" style="display: none;">
            <td class="adm-detail-content-cell-l bx-field-name">'.GetMessage("SP4I_MAIL").'</td>
            <td class="adm-detail-content-cell-r">
                <input type="text" size="50" maxlength="255" value="'. $arProperty["USER_TYPE_SETTINGS"]["MAIL_CHAT"] .'" name="' . $strHTMLControlName["NAME"] . '[MAIL_CHAT]">
            </td>
       </tr>
       <tr class="web-message3" style="display: none;">
            <td class="adm-detail-content-cell-l bx-field-name">'.GetMessage("SP4I_TEMPLATE").'</td>
            <td class="adm-detail-content-cell-r">
                <textarea rows="3" cols="60" name="' . $strHTMLControlName["NAME"] . '[MACROS]" class="web-message3" style="display: none;">'. ((empty($arProperty["USER_TYPE_SETTINGS"]["MACROS"]))?GetMessage('SP4I_MACROS'):$arProperty["USER_TYPE_SETTINGS"]["MACROS"]) .'</textarea>
            </td>
       </tr>
       <tr class="web-message2" style="display: table-row;">
            <td class="adm-detail-content-cell-l bx-field-name">'.GetMessage("SP4I_TEMPLATE2").'</td>
            <td class="adm-detail-content-cell-r">
                <textarea rows="3" cols="60" name="' . $strHTMLControlName["NAME"] . '[MACROS2]" class="web-message2" style="display: inline-block;">'. ((empty($arProperty["USER_TYPE_SETTINGS"]["MACROS2"]))?GetMessage('SP4I_MACROS2'):$arProperty["USER_TYPE_SETTINGS"]["MACROS2"]) .'</textarea>
            </td>
       </tr>
       <tr class="web-message2" style="display: table-row;">
            <td class="adm-detail-content-cell-l bx-field-name">'.GetMessage("SP4I_TEMPLATE3").'</td>
            <td class="adm-detail-content-cell-r">
                <textarea rows="3" cols="60" name="' . $strHTMLControlName["NAME"] . '[MACROS3]" class="web-message2" style="display: inline-block;">'. ((empty($arProperty["USER_TYPE_SETTINGS"]["MACROS3"]))?GetMessage('SP4I_MACROS3'):$arProperty["USER_TYPE_SETTINGS"]["MACROS3"]) .'</textarea>
            </td>
        </tr>
       <tr class="web-message" style="display: table-row;">
            <td class="adm-detail-content-cell-l bx-field-name">'.GetMessage("SP4I_TEMPLATE4").'</td>
            <td class="adm-detail-content-cell-r">
                <textarea rows="3" cols="60" name="' . $strHTMLControlName["NAME"] . '[MACROS4]" class="web-message" style="display: inline-block;">'. ((empty($arProperty["USER_TYPE_SETTINGS"]["MACROS4"]))?GetMessage('SP4I_MACROS4'):$arProperty["USER_TYPE_SETTINGS"]["MACROS4"]) .'</textarea>
            </td>
        </tr>
        <tr>
            <td class="adm-detail-content-cell-l"></td>
            <td class="adm-detail-content-cell-r"></td>
        </tr>
        </tbody>
        
        <script>
            BX.ready(function(){
                
                BX.bind(
                    BX("s_check_' . $inpid . '"),
                    "change",
                    function()
                    {
                        if (BX("s_check_' . $inpid . '").checked) {
                            [].forEach.call(document.querySelectorAll(".st-modul"), function (el) {
                                el.style.display  = "none";
                            });
                            [].forEach.call(document.querySelectorAll(".st-act"), function (el) {
                                el.style.display  = "none";
                            });
                        } else {
                            [].forEach.call(document.querySelectorAll(".st-modul"), function (el) {
                                el.style.display  = "table-row";
                            });
                            if (BX("id_act").value == "0") {
                                [].forEach.call(document.querySelectorAll(".st-act"), function (el) {
                                  el.style.display  = "none";
                                });
                            } else {
                                [].forEach.call(document.querySelectorAll(".st-act"), function (el) {
                                  el.style.display  = "table-row-group";
                                });
                            }
                        }
                    }
                );
                
                
                if (BX("s_check_' . $inpid . '").checked) {
                    [].forEach.call(document.querySelectorAll(".st-modul"), function (el) {
                      el.style.display  = "none";
                    });
                    [].forEach.call(document.querySelectorAll(".st-act"), function (el) {
                      el.style.display  = "none";
                    });
                } else {
                    [].forEach.call(document.querySelectorAll(".st-modul"), function (el) {
                        el.style.display  = "table-row";
                    });
                    
                    if (BX("id_act").value == "0") {
                        [].forEach.call(document.querySelectorAll(".st-act"), function (el) {
                          el.style.display  = "none";
                        });
                    } else {
                        [].forEach.call(document.querySelectorAll(".st-act"), function (el) {
                          el.style.display  = "table-row-group";
                        });
                    }
        
                    if (BX("id_act").value == "2") {
                        [].forEach.call(document.querySelectorAll(".web-message2"), function (el) {
                          el.style.display  = "none";
                        });
                        [].forEach.call(document.querySelectorAll(".web-message3"), function (el) {
                          el.style.display  = "table-row";
                        });
                    } else {
                        [].forEach.call(document.querySelectorAll(".web-message2"), function (el) {
                          el.style.display  = "table-row";
                        });
                        [].forEach.call(document.querySelectorAll(".web-message3"), function (el) {
                          el.style.display  = "none";
                        });
                    }
            
            
            
                    if (BX("id_method_send").value == "message") {
                        [].forEach.call(document.querySelectorAll(".web-message"), function (el) {
                          el.style.display  = "table-row";
                        });
                        [].forEach.call(document.querySelectorAll(".e-mail"), function (el) {
                          el.style.display  = "none";
                        });
                        [].forEach.call(document.querySelectorAll(".web-message__user"), function (el) {
                          el.style.display  = "table-row";
                        });
                    } else {
                        [].forEach.call(document.querySelectorAll(".web-message"), function (el) {
                          el.style.display  = "none";
                        });
                        [].forEach.call(document.querySelectorAll(".e-mail"), function (el) {
                          el.style.display  = "table-row";
                        });
                        [].forEach.call(document.querySelectorAll(".web-message__user"), function (el) {
                          el.style.display  = "none";
                        });
                    }
                    
                    if (BX("id_send_message").value == "system") {
                        [].forEach.call(document.querySelectorAll(".web-message__user"), function (el) {
                          el.style.display  = "none";
                        });
                    } else {
                        [].forEach.call(document.querySelectorAll(".web-message__user"), function (el) {
                          el.style.display  = "table-row";
                        });
                    }
                
                }
        
                
                BX.bind(
                    BX("id_act"),
                    "change",
                    function()
                    {
                        if (BX("id_act").value == "0") {
                            [].forEach.call(document.querySelectorAll(".st-act"), function (el) {
                              el.style.display  = "none";
                            });
                        } else {
                            [].forEach.call(document.querySelectorAll(".st-act"), function (el) {
                              el.style.display  = "table-row-group";
                            });
                        }
                        if (BX("id_act").value == "2") {
                            [].forEach.call(document.querySelectorAll(".web-message2"), function (el) {
                              el.style.display  = "none";
                            });
                            [].forEach.call(document.querySelectorAll(".web-message3"), function (el) {
                              el.style.display  = "table-row";
                            });
                        } else {
                            [].forEach.call(document.querySelectorAll(".web-message2"), function (el) {
                              el.style.display  = "table-row";
                            });
                            [].forEach.call(document.querySelectorAll(".web-message3"), function (el) {
                              el.style.display  = "none";
                            });
                        }
                    }
                );
                BX.bind(
                    BX("id_send_message"),
                    "change",
                    function()
                    {
                        if (BX("id_send_message").value == "system") {
                            [].forEach.call(document.querySelectorAll(".web-message__user"), function (el) {
                              el.style.display  = "none";
                            });
                        } else {
                            [].forEach.call(document.querySelectorAll(".web-message__user"), function (el) {
                              el.style.display  = "table-row";
                            });
                        }
                    }
                );    
                BX.bind(
                    BX("id_method_send"),
                    "change",
                    function()
                    {
                        if (BX("id_method_send").value == "message") {
                            [].forEach.call(document.querySelectorAll(".web-message"), function (el) {
                              el.style.display  = "table-row";
                            });
                            [].forEach.call(document.querySelectorAll(".e-mail"), function (el) {
                              el.style.display  = "none";
                            });
                            if (BX("id_send_message").value != "system") {
                                [].forEach.call(document.querySelectorAll(".web-message__user"), function (el) {
                                  el.style.display  = "table-row";
                                });
                            }
                        } else {
                            [].forEach.call(document.querySelectorAll(".web-message"), function (el) {
                              el.style.display  = "none";
                            });
                            [].forEach.call(document.querySelectorAll(".e-mail"), function (el) {
                              el.style.display  = "table-row";
                            });
                            [].forEach.call(document.querySelectorAll(".web-message__user"), function (el) {
                              el.style.display  = "none";
                            });
                        }
                    }
                );
        
            });


        </script>
            
            
            ';


        return $return;
    }

    public static function GetPropertyFieldHtml($arProperty, $arValue, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION, $DB, $USER;

        $APPLICATION->AddHeadScript('/bitrix/js/simai.property4iblock/edit.js');

        CJSCore::Init(array('clipboard'));
        $APPLICATION->SetAdditionalCSS('/bitrix/themes/.default/simai.property4iblock.css');

        $arSettings = self::PrepareSettings($arProperty);
        if ($arSettings["S_CHECK"] == "Y") {
            $SET_PASS = array(
                "ACT" => COption::GetOptionString("simai.property4iblock", "act", ""),
                "ADMIN_CHECK" => COption::GetOptionString("simai.property4iblock", "admin_check", "")
            );
        } else {
            $SET_PASS = array(
                "ACT" => $arSettings["ACT"],
                "ADMIN_CHECK" => $arSettings["ADMIN_CHECK"],
            );
        }

        if ($SET_PASS["ADMIN_CHECK"] == "Y" && $USER->IsAdmin()) {
            $SET_PASS["ACT"] = 0;
        }

        $strResult = ''; //$arValue['VALUE'];



        if (!empty($arValue["VALUE"])) {
            $open_pass = "************";
        } else {
            $open_pass = "";
        }
        if ($SET_PASS["ACT"] == 0) {
            $open_pass = htmlspecialchars($arValue["VALUE"]);
        }

        $inpid = $strHTMLControlName["VALUE"];

        $cols = intval($arProperty["COL_COUNT"]);
        if ($cols <= 3 || $cols > 100) {
            $cols = 30;
        }



        $iblock_id = intval($arProperty["IBLOCK_ID"]);
        $prop_id = intval($arProperty['ID']);
        $element_id = intval($_GET['ID']);



            $id_props = CIBlockElement::GetProperty($iblock_id, $element_id, array("sort" => "asc"), Array("ID"=>$prop_id));
            while ($ob_id_props = $id_props->GetNext())
            {
                if ($ob_id_props['VALUE'] == $arValue["VALUE"]) {
                    $idprop = $ob_id_props["PROPERTY_VALUE_ID"];
                }
            }

        if ($arValue["VALUE"] != "") {
            $inppass = '<input id="s_bulls_' . $inpid . '" data-view="1" type="password" size="' . ($cols+2) . '" value="************" class="sp4ib-password-edit" /> ';
        } else {
            $inppass = '';
        }


        if ($_REQUEST['mode'] != 'frame') {

            if (empty($arValue["VALUE"]) || $SET_PASS["ACT"] != 2) {
                $strResult .= '
            <div class="sp4ib-password-container-edit">
                
                '.$inppass.'
                <input id="s_vis_' . $inpid . '" onchange="updPass(\'' . $inpid . '\')" type="password" name="' . $strHTMLControlName["VALUE"] . '" size="' . ($cols+2) . '" value="' . $open_pass . '" autocomplete="off" style="'.(($arValue["VALUE"] != "")?"display:none":"").'"/> 
                <input id="s_des_' . $inpid . '" name="' . str_replace('[VALUE]', '[DESCRIPTION]', $strHTMLControlName["VALUE"]) . '" value="'.((!empty($arValue["VALUE"]))?"":"EMPTY").'" type="hidden" >
                <input id="s_pro_' . $inpid . '__' . str_replace('[VALUE]', '[PROPERTY_VALUE_ID]', $strHTMLControlName["VALUE"]) . '" name="' . str_replace('[VALUE]', '[PROPERTY_VALUE_ID]', $strHTMLControlName["VALUE"]) . '" value="'.$idprop.'" type="hidden" >
                <img class="sp4ib-password-eye 31" data-view="1" id="s_eye_' . $inpid . '" src="/bitrix/themes/.default/icons/simai4ib_view.svg" width="16" width="16" onclick="viewPass(\'' . $inpid . '\')"> 
                <span class="span-mess-copy" style="'.((!empty($arValue["VALUE"]))?"":"display: none;").'"><span id="repeat_copy_' . $inpid . '"></span><img class="sp4ib-password-copy" data-view="2" id="s_copy_' . $inpid . '" src="/bitrix/themes/.default/icons/simai4ib_copy.svg" width="16"></span></div>
            
            <script type="text/javascript">
            var act = "' . $SET_PASS["ACT"] . '";
            
            if (act == 1 || act == 2)  {
                
                var vis = [];
                vis["'. $inpid .'"] = 0;
                BX.bind(
                    BX("s_vis_' . $inpid . '"),
                    "change",
                    function()
                    {
                        BX("s_des_' . $inpid . '").value = "UPDATE";
                        if (vis["'. $inpid .'"] == 0) {
                            BX.ajax({
                                method: "POST",
                                cache: false,
                                url: "/simai/admin/simai_p4ib_ajax_edit_password.php",
                                data: {       
                                        PROPERTY_VALUE_ID : "' . $idprop . '",           
                                        PROP_ID : "' . $arProperty['ID'] . '",
                                        ELEMENT_ID : "' . $element_id . '",
                                        IBLOCK_ID : "' . $arProperty["IBLOCK_ID"] . '",
                                      },
                                onfailure: 
                                    function() {
                                        alert("fail");
                                    }
                            });
                            vis["'. $inpid .'"] = 1;
                        }
                    }
                );
            
                BX.bind(
                    BX("s_eye_' . $inpid . '"),
                    "click",
                    function()
                    {
                        if (BX("s_des_' . $inpid . '").value != "UPDATE") {
                            var dataView = 1;
                            BX.ajax({
                                method: "POST",
                                cache: false,
                                url: "/simai/admin/simai_p4ib_ajax_notification.php",
                                data: { 
                                        PROPERTY_VALUE_ID : "' . $idprop . '",
                                        VIEW : dataView,
                                        PROP_ID : "' . $arProperty['ID'] . '",
                                        ELEMENT_ID : "' . $element_id . '",
                                        IBLOCK_ID : "' . $arProperty["IBLOCK_ID"] . '",
                                        
                                      },
                                onsuccess: 
                                    function(response) {
                            console.log(response);
                                        BX("s_vis_' . $inpid . '").value = decodeURIComponent(escape(window.atob(response)));
                                        
                                        if (dataView == "2") {
                                            BX.fireEvent(BX("repeat_copy_' . $inpid . '"), "click");
                                        }
                                    },    
                                onfailure: 
                                    function() {
                                        alert("fail");
                                    }
                            });     
                        }
                    }
                );
                BX.bind(
                    BX("s_bulls_' . $inpid . '"),
                    "click",
                    function()
                    {
                            var dataView = 1;
                            BX.ajax({
                                method: "POST",
                                cache: false,
                                url: "/simai/admin/simai_p4ib_ajax_notification.php",
                                data: { 
                                        PROPERTY_VALUE_ID : "' . $idprop . '",
                                        VIEW : dataView,
                                        PROP_ID : "' . $arProperty['ID'] . '",
                                        ELEMENT_ID : "' . $element_id . '",
                                        IBLOCK_ID : "' . $arProperty["IBLOCK_ID"] . '",
                                        
                                      },
                                onsuccess: 
                                    function(response) {
                                        BX("s_vis_' . $inpid . '").value = decodeURIComponent(escape(window.atob(response)));
                                        
                                        if (dataView == "2") {
                                            BX.fireEvent(BX("repeat_copy_' . $inpid . '"), "click");
                                        }
                                    },    
                                onfailure: 
                                    function() {
                                        alert("fail");
                                    }
                            });     
                    
                        if (BX("s_vis_' . $inpid . '").style.display == "none")
                        {
                            BX("s_vis_' . $inpid . '").style.display = "inline-block";
                            BX("s_bulls_' . $inpid . '").style.display = "none";
                        }
                    }
                );
                BX.bind(
                    BX("s_copy_' . $inpid . '"),
                    "click",
                    function()
                    {
                        if (BX("s_des_' . $inpid . '").value != "UPDATE") {
                        
                            var dataView = 2;
                            BX.ajax({
                                method: "POST",
                                cache: false,
                                url: "/simai/admin/simai_p4ib_ajax_notification.php",
                                data: { 
                                        PROPERTY_VALUE_ID : "' . $idprop . '",
                                        VIEW : dataView,
                                        PROP_ID : "' . $arProperty['ID'] . '",
                                        ELEMENT_ID : "' . $element_id . '",
                                        IBLOCK_ID : "' . $arProperty["IBLOCK_ID"] . '",
                                        
                                      },
                                onsuccess: 
                                    function(response) {
                                    
                                        BX("s_vis_' . $inpid . '").value = decodeURIComponent(escape(window.atob(response)));
                                        
                                        if (dataView == "2") {
                                            BX.fireEvent(BX("repeat_copy_' . $inpid . '"), "click");
                                        }
                                    },    
                                onfailure: 
                                    function() {
                                        alert("fail");
                                    }
                            });     
                        }
                        else
                            BX.fireEvent(BX("repeat_copy_' . $inpid . '"), "click");
                    }
                );
            
            }
            
            if (act == 0) {
            
                BX.bind(
                    BX("s_bulls_' . $inpid . '"),
                    "click",
                    function()
                    {
                            if (BX("s_vis_' . $inpid . '").style.display == "none")
                            {
                                BX("s_des_' . $inpid . '").value = "UPDATE";
                                BX("s_vis_' . $inpid . '").style.display = "inline-block";
                                BX("s_bulls_' . $inpid . '").style.display = "none";
                            }
                    }
                    
                );
                
                
                BX.clipboard.bindCopyClick(
                    BX("s_copy_' . $inpid . '"), 
                    {
                        text: BX("s_vis_' . $inpid . '")
                    }
                );
            } else {
                BX.clipboard.bindCopyClick(
                    BX("repeat_copy_' . $inpid . '"), 
                    {
                        text: BX("s_vis_' . $inpid . '")
                    }
                );
            }
            
            
            </script>
            ';

            } else {


                $strResult .= '
            <div class="sp4ib-password-container-edit">
                <input type="button" id="show_password_' . $inpid . '" value="'.GetMessage("SP4I_SHOW_PASSWORD").'" style="'.((!empty($_SESSION["CODE_".$idprop]))?"display: none;":"").'">
                <input type="text" size="14" id="enter_code_' . $inpid . '" style="'.((!empty($_SESSION["CODE_".$idprop]))?"inline-block":"display: none;").'" placeholder="'.GetMessage("SP4I_PLACEHOLDER_CODE").'">
                <a href="javascript:void(0)" id="submit_code_' . $inpid . '" style="'.((!empty($_SESSION["CODE_".$idprop]))?"inline-block;":"display: none;").'align-items: center"><img class="sp4ib-password-unlock" src="/bitrix/themes/.default/icons/simai4ib_unlock.svg" width="16" alt="lock" title="Подтвердить код"></a>
                <a href="javascript:void(0)" id="repeat_code_' . $inpid . '" style="'.((!empty($_SESSION["CODE_".$idprop]))?"inline-block;":"display: none;").'align-items: center"><img class="sp4ib-password-unlock" src="/bitrix/themes/.default/icons/simai4ib_key.svg" width="16" alt="key" title="Выслать новый код"></a>
                
                <input id="s_bulls_' . $inpid . '" data-view="1" type="password" size="' . ($cols+2) . '" value="************" class="sp4ib-password-edit" style="display:none"/> 
                <input id="s_vis_' . $inpid . '" onchange="updPass(\'' . $inpid . '\')" type="password" name="' . $strHTMLControlName["VALUE"] . '" size="' . ($cols+2) . '" value="" autocomplete="off" style="display:none"/> 
                <input id="s_des_' . $inpid . '" name="' . str_replace('[VALUE]', '[DESCRIPTION]', $strHTMLControlName["VALUE"]) . '" value="'.((!empty($arValue["VALUE"]))?"":"EMPTY").'" type="hidden" >
                <input id="s_pro_' . $inpid . '" name="' . str_replace('[VALUE]', '[PROPERTY_VALUE_ID]', $strHTMLControlName["VALUE"]) . '" value="'.$idprop.'" type="hidden" >
                <img class="sp4ib-password-eye 3" id="s_eye_' . $inpid . '" src="/bitrix/themes/.default/icons/simai4ib_view.svg" style="display:none" width="16"> 
                <span class="span-mess-copy"><span id="repeat_copy_' . $inpid . '"></span><img class="sp4ib-password-copy" data-view="2" id="s_copy_' . $inpid . '" src="/bitrix/themes/.default/icons/simai4ib_copy.svg" style="display:none" width="16"></span></div>

            </div>
            
            <script type="text/javascript">
            
                var enjoyForm = 0;
                document.getElementById("enter_code_' . $inpid . '").addEventListener("keydown", function(e) {
                    if (e.keyCode === 13) {
                            e.preventDefault();
                            BX.fireEvent(BX("submit_code_' . $inpid . '"), "click");
                    }
                });
                
                var act = "' . $SET_PASS["ACT"] . '";
                BX.bind(
                    BX("show_password_' . $inpid . '"),
                    "click",
                    function()
                    {
                        var dataView = "2";
                        BX("enter_code_' . $inpid . '").style.display = "inline-block";
                        BX("submit_code_' . $inpid . '").style.display = "inline-block";
                        BX("repeat_code_' . $inpid . '").style.display = "inline-block";
                        BX("show_password_' . $inpid . '").style.display = "none";
                        
                        BX.ajax({
                            method: "POST",
                            cache: false,
                            url: "/simai/admin/simai_p4ib_ajax_send_mail.php",
                            data: {         
                                    PROPERTY_VALUE_ID : "'.$idprop.'",         
                                    VIEW : dataView,
                                    PROP_ID : "'.$arProperty['ID'].'",
                                    ELEMENT_ID : "'.$element_id.'",
                                    IBLOCK_ID : "'.$arProperty["IBLOCK_ID"].'",
                                  },
                            onsuccess: function(response) {
                                if (response=="good") {
                                    enjoyForm = 1;
                                }
                            },
                            onfailure: function() {
                                alert("fail");
                            }
                        });
                    }
                );
                
                BX.bind(
                    BX("repeat_code_' . $inpid . '"),
                    "click",
                    function()
                    {
                        BX.ajax({
                            method: "POST",
                            cache: false,
                            url: "/simai/admin/simai_p4ib_ajax_send_mail.php",
                            data: { 
                                PROPERTY_VALUE_ID : "'.$idprop.'",
                                PROP_ID : "' . $arProperty['ID'] . '",
                                ELEMENT_ID : "' . $element_id . '",
                                IBLOCK_ID : "' . $arProperty["IBLOCK_ID"] . '",
                            },
                            onsuccess: 
                                function(response) {
                                    alert("' . GetMessage("SP4I_NEW_CODE") . '");
                                },
                            onfailure: 
                                function() {
                                    alert("fail");
                                }
                        });
                    }
                );
                BX.bind(
                    BX("submit_code_' . $inpid . '"),
                    "click",
                    function()
                    {
                        BX.ajax({
                            method: "POST",
                            cache: false,
                            url: "/simai/admin/simai_p4ib_ajax_checked_code.php",
                            data: {   
                                PROPERTY_VALUE_ID : "'.$idprop.'",     
                                CHECK_CODE : BX("enter_code_' . $inpid . '").value,
                                PROP_ID : "'.$arProperty['ID'].'",
                                ELEMENT_ID : "'.$element_id.'",
                                IBLOCK_ID : "'.$arProperty["IBLOCK_ID"].'",
                                },
                            onsuccess: function(response) {
                            
                                if (response.replace(/\s/g, "")=="badcode") {
                                    alert("'.GetMessage("SP4I_ERROR_CODE").'"); 
                                } else {
                                    BX.hide(BX("show_password_' . $inpid . '"));
                                    BX.hide(BX("enter_code_' . $inpid . '"));
                                    BX.hide(BX("submit_code_' . $inpid . '"));
                                    BX.hide(BX("repeat_code_' . $inpid . '"));
                                    BX.style(BX("s_bulls_' . $inpid . '"), "display", "inline-block");
                                    BX.style(BX("s_eye_' . $inpid . '"), "display", "inline-block");
                                    BX.style(BX("s_copy_' . $inpid . '"), "display", "inline-block");
                                    BX("s_vis_' . $inpid . '").value = decodeURIComponent(escape(window.atob(response)));
                                    enjoyForm = 0;
                                }
                            },
                            onfailure: function() {
                                alert("fail");
                            }
                        });
                    }
                );
                
                
                BX.bind(
                    BX("s_vis_' . $inpid . '"),
                    "change",
                    function()
                    {
                        BX("s_des_' . $inpid . '").value = "UPDATE";
                    }
                );
                
                BX.bind(
                    BX("s_bulls_' . $inpid . '"),
                    "click",
                    function()
                    {
                        if (BX("s_vis_' . $inpid . '").style.display == "none")
                        {
                            BX("s_des_' . $inpid . '").value = "UPDATE";
                            BX("s_vis_' . $inpid . '").style.display = "inline-block";
                            BX("s_bulls_' . $inpid . '").style.display = "none";
                        }
                    }
                );
                
                BX.bind(
                    BX("s_copy_' . $inpid . '"),
                    "click",
                    function()
                    {
                        BX.fireEvent(BX("repeat_copy_' . $inpid . '"), "click");
                    }
                );
                
                BX.bind(
                    BX("s_eye_' . $inpid . '"),
                    "click",
                    function()
                    {
                        var passType = document.getElementById("s_vis_' . $inpid . '");
                        
                        if (passType.getAttribute("type") == "text") 
                        {
                            BX.adjust(BX("s_vis_' . $inpid . '"), {attrs: {type: "password"}});
                            BX.adjust(BX("s_eye_' . $inpid . '"), {attrs: {src: "/bitrix/themes/.default/icons/simai4ib_hidden.svg"}});
                        } else {
                            BX.adjust(BX("s_vis_' . $inpid . '"), {attrs: {type: "text"}});
                            BX.adjust(BX("s_eye_' . $inpid . '"), {attrs: {src: "/bitrix/themes/.default/icons/simai4ib_view.svg"}});
                        }
                        
                        if (BX("s_vis_' . $inpid . '").style.display == "none")
                        {
                            BX("s_vis_' . $inpid . '").style.display = "inline-block";
                            BX("s_bulls_' . $inpid . '").style.display = "none";
                        }
                    }
                    
                );

                BX.clipboard.bindCopyClick(
                    BX("repeat_copy_' . $inpid . '"), 
                    {
                        text: BX("s_vis_' . $inpid . '")
                    }
                );
            </script>
            
            ';
            }
        }

        return $strResult;
    }

    public static function GetPublicEditHTML($arProperty, $arValue, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION, $DB, $USER;

        $APPLICATION->AddHeadScript('/bitrix/js/simai.property4iblock/edit.js');
        
        CJSCore::Init(array('clipboard'));
        $APPLICATION->SetAdditionalCSS('/bitrix/themes/.default/simai.property4iblock.css');

        $arSettings = self::PrepareSettings($arProperty);
        if ($arSettings["S_CHECK"] == "Y") {
            $SET_PASS = array(
                "ACT" => COption::GetOptionString("simai.property4iblock", "act", ""),
                "ADMIN_CHECK" => COption::GetOptionString("simai.property4iblock", "admin_check", "")
            );
        } else {
            $SET_PASS = array(
                "ACT" => $arSettings["ACT"],
                "ADMIN_CHECK" => $arSettings["ADMIN_CHECK"],
            );
        }

        if ($SET_PASS["ADMIN_CHECK"] == "Y" && $USER->IsAdmin()) {
            $SET_PASS["ACT"] = 0;
        }

        $strResult = ''; //$arValue['VALUE'];


        if (!empty($arValue["VALUE"])) {
            $open_pass = "************";
        } else {
            $open_pass = "";
        }

        if ($SET_PASS["ACT"] == 0) {
            $open_pass = htmlspecialchars($arValue["VALUE"]);
        }

        $inpid = $strHTMLControlName["VALUE"];

        $cols = intval($arProperty["COL_COUNT"]);
        if ($cols <= 3 || $cols > 100) {
            $cols = 30;
        } 

        $iblock_id = intval($arProperty["IBLOCK_ID"]);
        $prop_id = intval($arProperty['ID']);
        $element_id = intval($arProperty['ELEMENT_ID']);



            $id_props = CIBlockElement::GetProperty($iblock_id, $element_id, array("sort" => "asc"), Array("ID"=>$prop_id));
            while ($ob_id_props = $id_props->GetNext())
            {
                if ($ob_id_props['VALUE'] == $arValue["VALUE"]) {
                    $idprop = $ob_id_props["PROPERTY_VALUE_ID"];
                }
            }

        if ($arValue["VALUE"] != "") {
            $inppass = '<input id="s_bulls_' . $inpid . '" data-view="1" type="password" size="' . ($cols+2) . '" value="************" class="sp4ib-password-edit" /> ';
        } else {
            $inppass = '';
        }


        if (empty($arValue["VALUE"]) || $SET_PASS["ACT"] != 2) {
            $strResult .= '
            <div class="sp4ib-password-container-edit">
                
                '.$inppass.'
                <input id="s_vis_' . $inpid . '" onchange="updPass(\'' . $inpid . '\')" type="password" name="' . $strHTMLControlName["VALUE"] . '" size="' . ($cols+2) . '" value="' . $open_pass . '" autocomplete="off" style="'.(($arValue["VALUE"] != "")?"display:none":"").'"/> 
                <input id="s_des_' . $inpid . '" name="' . str_replace('[VALUE]', '[DESCRIPTION]', $strHTMLControlName["VALUE"]) . '" value="'.((!empty($arValue["VALUE"]))?"":"EMPTY").'" type="hidden" >
                <input id="s_pro_' . $inpid . '__' . str_replace('[VALUE]', '[PROPERTY_VALUE_ID]', $strHTMLControlName["VALUE"]) . '" name="' . str_replace('[VALUE]', '[PROPERTY_VALUE_ID]', $strHTMLControlName["VALUE"]) . '" value="'.$idprop.'" type="hidden" >
                <img class="sp4ib-password-eye 313" data-view="1" id="s_eye_' . $inpid . '" src="/bitrix/themes/.default/icons/simai4ib_view.svg" width="16" onclick="viewPass(\'' . $inpid . '\')"> 
                <span class="span-mess-copy" style="'.((!empty($arValue["VALUE"]))?"":"display: none;").'"><span id="repeat_copy_' . $inpid . '"></span><img class="sp4ib-password-copy" data-view="2" id="s_copy_' . $inpid . '" src="/bitrix/themes/.default/icons/simai4ib_copy.svg" width="16"></span></div>
             
            <script type="text/javascript">
            var act = "' . $SET_PASS["ACT"] . '";
            var elem = "'. $element_id .'";
            
            console.log(elem);
            if ((act == 1 || act == 2) && elem!=0)  {
            
                var vis = [];
                vis["'. $inpid .'"] = 0;
                BX.bind(
                    BX("s_vis_' . $inpid . '"),
                    "change",
                    function()
                    {
                        BX("s_des_' . $inpid . '").value = "UPDATE";
                        console.log(vis["'. $inpid .'"]);
                        if (vis["'. $inpid .'"] == 0) {
                            BX.ajax({
                                method: "POST",
                                cache: false,
                                url: "/simai/admin/simai_p4ib_ajax_edit_password.php",
                                data: {    
                                        PROPERTY_VALUE_ID : "' . $idprop . '",          
                                        PROP_ID : "' . $arProperty['ID'] . '",
                                        ELEMENT_ID : "' . $arProperty["ELEMENT_ID"] . '",
                                        IBLOCK_ID : "' . $arProperty["IBLOCK_ID"] . '",
                                      },
                                onfailure: 
                                    function() {
                                        alert("fail");
                                    }
                            });
                            vis["'. $inpid .'"] = 1;
                        }
                    }
                );

                BX.bind(
                    BX("s_eye_' . $inpid . '"),
                    "click",
                    function()
                    {
                        if (BX("s_des_' . $inpid . '").value != "UPDATE") {
                            var dataView = 1;
                            BX.ajax({
                                method: "POST",
                                cache: false,
                                url: "/simai/admin/simai_p4ib_ajax_notification.php",
                                data: { 
                                        PROPERTY_VALUE_ID : "' . $idprop . '",
                                        VIEW : dataView,
                                        PROP_ID : "' . $arProperty['ID'] . '",
                                        ELEMENT_ID : "' . $arProperty["ELEMENT_ID"] . '",
                                        IBLOCK_ID : "' . $arProperty["IBLOCK_ID"] . '",
                                        
                                      },
                                onsuccess: 
                                    function(response) {
                                        BX("s_vis_' . $inpid . '").value = decodeURIComponent(escape(window.atob(response)));
                                       
                                    },    
                                onfailure: 
                                    function() {
                                        alert("fail");
                                    }
                            }); 
                        }
                            
                    }
                );
                BX.bind(
                    BX("s_bulls_' . $inpid . '"),
                    "click",
                    function()
                    {
                        var dataView = 1;
                        BX.ajax({
                            method: "POST",
                            cache: false,
                            url: "/simai/admin/simai_p4ib_ajax_notification.php",
                            data: { 
                                    PROPERTY_VALUE_ID : "' . $idprop . '",
                                    VIEW : dataView,
                                    PROP_ID : "' . $arProperty['ID'] . '",
                                    ELEMENT_ID : "' . $arProperty["ELEMENT_ID"] . '",
                                    IBLOCK_ID : "' . $arProperty["IBLOCK_ID"] . '",
                                    
                                  },
                            onsuccess: 
                                function(response) {
                                    BX("s_vis_' . $inpid . '").value = decodeURIComponent(escape(window.atob(response)));

                                },    
                            onfailure: 
                                function() {
                                    alert("fail");
                                }
                        }); 
                    
                        if (BX("s_vis_' . $inpid . '").style.display == "none")
                        {
                            BX("s_vis_' . $inpid . '").style.display = "inline-block";
                            BX("s_bulls_' . $inpid . '").style.display = "none";
                        }
                    }
                );
                                            
                BX.bind(
                    BX("s_copy_' . $inpid . '"),
                    "click",
                    function()
                    {
                        if (BX("s_des_' . $inpid . '").value != "UPDATE") {
                            var dataView = 2;
                            BX.ajax({
                                method: "POST",
                                cache: false,
                                url: "/simai/admin/simai_p4ib_ajax_notification.php",
                                data: { 
                                        PROPERTY_VALUE_ID : "' . $idprop . '",
                                        VIEW : dataView,
                                        PROP_ID : "' . $arProperty['ID'] . '",
                                        ELEMENT_ID : "' . $arProperty["ELEMENT_ID"] . '",
                                        IBLOCK_ID : "' . $arProperty["IBLOCK_ID"] . '",
                                        
                                      },
                                onsuccess: 
                                    function(response) {
                                        BX("s_vis_' . $inpid . '").value = decodeURIComponent(escape(window.atob(response)));
                                        
                                        if (dataView == "2") {
                                            console.log("xaxaxss");
                                            BX.fireEvent(BX("repeat_copy_' . $inpid . '"), "click");
                                        }
                                    },    
                                onfailure: 
                                    function() {
                                        alert("fail");
                                    }
                            }); 
                        } else {
                                            console.log("xaxax2");
                            BX.fireEvent(BX("repeat_copy_' . $inpid . '"), "click");
                        }
                    }
                );
                
            }
            if (act == 0) {
            
                BX.bind(
                    BX("s_bulls_' . $inpid . '"),
                    "click",
                    function()
                    {
                            if (BX("s_vis_' . $inpid . '").style.display == "none")
                            {
                                BX("s_des_' . $inpid . '").value = "UPDATE";
                                BX("s_vis_' . $inpid . '").style.display = "inline-block";
                                BX("s_bulls_' . $inpid . '").style.display = "none";
                            }
                    }
                    
                );
                
                
                BX.clipboard.bindCopyClick(
                    BX("s_copy_' . $inpid . '"), 
                    {
                        text: BX("s_vis_' . $inpid . '")
                    }
                );
            } else {
                BX.clipboard.bindCopyClick(
                    BX("repeat_copy_' . $inpid . '"), 
                    {
                        text: BX("s_vis_' . $inpid . '")
                    }
                );
            }
            
            
            </script>
            ';

        } else {


            $strResult .= '
            <div class="sp4ib-password-container-edit">
                <input type="button" id="show_password_' . $inpid . '" value="'.GetMessage("SP4I_SHOW_PASSWORD").'" style="'.((!empty($_SESSION["CODE_".$idprop]))?"display: none;":"").'">
                <input type="text" size="12" id="enter_code_' . $inpid . '" style="'.((!empty($_SESSION["CODE_".$idprop]))?"inline-block":"display: none;").'" placeholder="'.GetMessage("SP4I_PLACEHOLDER_CODE").'">
                <a href="javascript:void(0)" id="submit_code_' . $inpid . '" style="'.((!empty($_SESSION["CODE_".$idprop]))?"inline-block;":"display: none;").'align-items: center"><img class="sp4ib-password-unlock" src="/bitrix/themes/.default/icons/simai4ib_unlock.svg" width="16" alt="lock" title="Подтвердить код"></a>
                <a href="javascript:void(0)" id="repeat_code_' . $inpid . '" style="'.((!empty($_SESSION["CODE_".$idprop]))?"inline-block;":"display: none;").'align-items: center"><img class="sp4ib-password-unlock" src="/bitrix/themes/.default/icons/simai4ib_key.svg" width="16" alt="key" title="Выслать новый код"></a>
                
                <input id="s_bulls_' . $inpid . '" data-view="1" type="password" size="' . ($cols+2) . '" value="************" class="sp4ib-password-edit" style="display:none"/> 
                <input id="s_vis_' . $inpid . '" onchange="updPass(\'' . $inpid . '\')" type="password" name="' . $strHTMLControlName["VALUE"] . '" size="' . ($cols+2) . '" value="' . $open_pass . '" autocomplete="off" style="display:none"/> 
                <input id="s_des_' . $inpid . '" name="' . str_replace('[VALUE]', '[DESCRIPTION]', $strHTMLControlName["VALUE"]) . '" value="'.((!empty($arValue["VALUE"]))?"":"EMPTY").'" type="hidden" >
                <input id="s_pro_' . $inpid . '" name="' . str_replace('[VALUE]', '[PROPERTY_VALUE_ID]', $strHTMLControlName["VALUE"]) . '" value="'.$idprop.'" type="hidden" >
                <img class="sp4ib-password-eye 3" id="s_eye_' . $inpid . '" src="/bitrix/themes/.default/icons/simai4ib_view.svg" style="display:none" width="16"> 
                <span class="span-mess-copy"><span id="repeat_copy_' . $inpid . '"></span><img class="sp4ib-password-copy" data-view="2" id="s_copy_' . $inpid . '" src="/bitrix/themes/.default/icons/simai4ib_copy.svg" style="display:none" width="16"></span></div>

            </div>
            
            <script type="text/javascript">
            
                var enjoyForm = 0;
                
                document.getElementById("enter_code_' . $inpid . '").addEventListener("keydown", function(e) {
                    if (e.keyCode === 13) {
                            e.preventDefault();
                            BX.fireEvent(BX("submit_code_' . $inpid . '"), "click");
                    }
                });
                
                var act = "' . $SET_PASS["ACT"] . '";
                BX.bind(
                    BX("show_password_' . $inpid . '"),
                    "click",
                    function()
                    {
                        BX("enter_code_' . $inpid . '").style.display = "inline-block";
                        BX("submit_code_' . $inpid . '").style.display = "inline-block";
                        BX("repeat_code_' . $inpid . '").style.display = "inline-block";
                        BX("show_password_' . $inpid . '").style.display = "none";
                        
                        BX.ajax({
                            method: "POST",
                            cache: false,
                            url: "/simai/admin/simai_p4ib_ajax_send_mail.php",
                            data: {        
                                    PROPERTY_VALUE_ID : "'.$idprop.'",   
                                    PROP_ID : "'.$arProperty['ID'].'",
                                    ELEMENT_ID : "'.$arProperty["ELEMENT_ID"].'",
                                    IBLOCK_ID : "'.$arProperty["IBLOCK_ID"].'",
                                  },
                            onsuccess: function(response) {
                                if (response=="good") {
                                    enjoyForm = 1;
                                }
                            },
                            onfailure: function() {
                                alert("fail");
                            }
                        });
                    }
                );
                
                BX.bind(
                    BX("repeat_code_' . $inpid . '"),
                    "click",
                    function()
                    {
                        BX.ajax({
                            method: "POST",
                            cache: false,
                            url: "/simai/admin/simai_p4ib_ajax_send_mail.php",
                            data: { 
                                PROPERTY_VALUE_ID : "'.$idprop.'",
                                PROP_ID : "' . $arProperty['ID'] . '",
                                ELEMENT_ID : "' . $element_id . '",
                                IBLOCK_ID : "' . $arProperty["IBLOCK_ID"] . '",
                            },
                            onsuccess: 
                                function(response) {
                                    alert("' . GetMessage("SP4I_NEW_CODE") . '");
                                },
                            onfailure: 
                                function() {
                                    alert("fail");
                                }
                        });
                    }
                );
                BX.bind(
                    BX("submit_code_' . $inpid . '"),
                    "click",
                    function()
                    {
                        BX.ajax({
                            method: "POST",
                            cache: false,
                            url: "/simai/admin/simai_p4ib_ajax_checked_code.php",
                            data: {    
                                PROPERTY_VALUE_ID : "'.$idprop.'",
                                CHECK_CODE : BX("enter_code_' . $inpid . '").value,
                                PROP_ID : "'.$arProperty['ID'].'",
                                ELEMENT_ID : "'.$arProperty["ELEMENT_ID"].'",
                                IBLOCK_ID : "'.$arProperty["IBLOCK_ID"].'",
                                },
                            onsuccess: function(response) {
                                if (response.replace(/\s/g, "")=="badcode") {
                                    alert("'.GetMessage("SP4I_ERROR_CODE").'"); 
                                } else {
                                    BX.hide(BX("show_password_' . $inpid . '"));
                                    BX.hide(BX("enter_code_' . $inpid . '"));
                                    BX.hide(BX("submit_code_' . $inpid . '"));
                                    BX.hide(BX("repeat_code_' . $inpid . '"));
                                    BX.style(BX("s_bulls_' . $inpid . '"), "display", "inline-block");
                                    BX.style(BX("s_eye_' . $inpid . '"), "display", "inline-block");
                                    BX.style(BX("s_copy_' . $inpid . '"), "display", "inline-block");
                                    BX("s_vis_' . $inpid . '").value = decodeURIComponent(escape(window.atob(response)));
                                    
                                    enjoyForm = 0;
                                }
                            },
                            onfailure: function() {
                                alert("fail");
                            }
                        });
                    }
                );
                
                BX.bind(
                    BX("s_vis_' . $inpid . '"),
                    "change",
                    function()
                    {
                        BX("s_des_' . $inpid . '").value = "UPDATE";
                    }
                );
                BX.bind(
                    BX("s_bulls_' . $inpid . '"),
                    "click",
                    function()
                    {
                        if (BX("s_vis_' . $inpid . '").style.display == "none")
                        {
                            BX("s_vis_' . $inpid . '").style.display = "inline-block";
                            BX("s_bulls_' . $inpid . '").style.display = "none";
                        }
                    }
                );
                BX.bind(
                    BX("s_copy_' . $inpid . '"),
                    "click",
                    function()
                    {
                                            console.log("xaxax3");
                        BX.fireEvent(BX("repeat_copy_' . $inpid . '"), "click");
                    }
                );
                
                BX.bind(
                    BX("s_eye_' . $inpid . '"),
                    "click",
                    function()
                    {
                        var passType = document.getElementById("s_vis_' . $inpid . '");
                        
                        if (passType.getAttribute("type") == "text") 
                        {
                            BX.adjust(BX("s_vis_' . $inpid . '"), {attrs: {type: "password"}});
                            BX.adjust(BX("s_eye_' . $inpid . '"), {attrs: {src: "/bitrix/themes/.default/icons/simai4ib_hidden.svg"}});
                        } else {
                            BX.adjust(BX("s_vis_' . $inpid . '"), {attrs: {type: "text"}});
                            BX.adjust(BX("s_eye_' . $inpid . '"), {attrs: {src: "/bitrix/themes/.default/icons/simai4ib_view.svg"}});
                        }
                        
                        if (BX("s_vis_' . $inpid . '").style.display == "none")
                        {
                            BX("s_vis_' . $inpid . '").style.display = "inline-block";
                            BX("s_bulls_' . $inpid . '").style.display = "none";
                        }
                    }
                    
                );

                BX.clipboard.bindCopyClick(
                    BX("repeat_copy_' . $inpid . '"), 
                    {
                        text: BX("s_vis_' . $inpid . '")
                    }
                );
            </script>
            
            ';
        }

        return $strResult;
    }

    public static function GetPublicViewHTML($arProperty, $arValue, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION, $DB, $USER;

        CJSCore::Init(array('clipboard'));
        $APPLICATION->SetAdditionalCSS('/bitrix/themes/.default/simai.property4iblock.css');


        $arSettings = self::PrepareSettings($arProperty);
        if ($arSettings["S_CHECK"] == "Y") {
            $SET_PASS = array(
                "ACT" => COption::GetOptionString("simai.property4iblock", "act", ""),
                "ADMIN_CHECK" => COption::GetOptionString("simai.property4iblock", "admin_check", "")
            );
        } else {
            $SET_PASS = array(
                "ACT" => $arSettings["ACT"],
                "ADMIN_CHECK" => $arSettings["ADMIN_CHECK"],
            );
        }

        if ($SET_PASS["ADMIN_CHECK"] == "Y" && $USER->IsAdmin()) {
            $SET_PASS["ACT"] = 0;
        }

        $value = $arValue['VALUE'];

        if ($arProperty['VALUE_ENUM_ID'])
            $value = $arProperty['VALUE_ENUM_ID'];

        if ($arProperty['PROPERTY_VALUE_ID'])
            $value_id = $arProperty['PROPERTY_VALUE_ID'];

        if (is_array($value))
            $value = current($value);

        if (is_array($value_id))
            $value_id = current($value_id);

        if (is_array($arValue) && $arValue['ELEMENT_ID']) {
            $element_id = $arValue['ELEMENT_ID'];
        } elseif (strpos($value_id, ':')) {
            $element_id = intval($value_id);
        } elseif ($value_id > 0) {
            $res = $DB->Query('select * from `b_iblock_element_property` where `ID`=' . intval($value_id));
            if ($arr = $res->fetch())
                $element_id = $arr['IBLOCK_ELEMENT_ID'];
        }
        if ($element_id == "") $element_id = intval($arProperty["ELEMENT_ID"]);


        $strResult = ''; //$arValue['VALUE'];

        if (!empty($arValue["VALUE"])) {
            $open_pass = "************";
        } else {
            $open_pass = "";
        }
        if ($SET_PASS["ACT"] == 0) {
            $open_pass = htmlspecialchars($arValue["VALUE"]);
        }


        $iblock_id = intval($arProperty["IBLOCK_ID"]);
        $prop_id = intval($arProperty['ID']);


            $id_props = CIBlockElement::GetProperty($iblock_id, $element_id, array("sort" => "asc"), Array("ID"=>$prop_id));
            while ($ob_id_props = $id_props->GetNext())
            {
                if ($ob_id_props['VALUE'] == $arValue["VALUE"]) {
                    $idprop = $ob_id_props["PROPERTY_VALUE_ID"];
                }
            }

        $inpid = rand(99, 9999);

        if (empty($arValue["VALUE"]) || $SET_PASS["ACT"] != 2) {
            $strResult .= '
            <div class="sp4ib-password-container-view">
                <span id="s_bulls_' . $inpid . '" class="sp4ib-password-dots" style="'.((!empty($arValue["VALUE"]))?"":"display: none;").'">&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;</span>
                <span id="s_vis_' . $inpid . '" class="sp4ib-password-vis-pass" style="display:none">' . $open_pass . '</span>
                <img class="sp4ib-password-eye 4" data-view="1" id="s_eye_' . $inpid . '" src="/bitrix/themes/.default/icons/simai4ib_view.svg" width="16" style="'.((!empty($arValue["VALUE"]))?"":"display: none;").'"> 
                <span class="span-mess-copy" style="'.((!empty($arValue["VALUE"]))?"":"display: none;").'"><span id="repeat_copy_' . $inpid . '"></span><img class="sp4ib-password-copy" data-view="2" id="s_copy_' . $inpid . '" src="/bitrix/themes/.default/icons/simai4ib_copy.svg" width="16"></span></div>
            <script type="text/javascript">
            var act = "' . $SET_PASS["ACT"] . '";
            
            BX.bind(
                BX("s_eye_' . $inpid . '"),
                "click",
                function()
                {
                    dataView = 1;
                    BX.ajax({
                        method: "POST",
                        cache: false,
                        url: "/simai/admin/simai_p4ib_ajax_notification.php",
                        data: { 
                                PROPERTY_VALUE_ID : "'.$idprop.'",
                                VIEW : dataView,
                                PROP_ID : "'.$arProperty['ID'].'",
                                ELEMENT_ID : "'.$element_id.'",
                                IBLOCK_ID : "'.$arProperty["IBLOCK_ID"].'",
                                
                              },
                        onsuccess: function(response) {
                        console.log(response);
                            BX("s_vis_' . $inpid . '").innerText = decodeURIComponent(escape(window.atob(response)));

                        },
                        onfailure: function(response) {
                            alert("fail");
                            console.log(response);
                        }
                    });
                
                    if (BX("s_vis_' . $inpid . '").style.display == "none")
                    {
                        BX("s_vis_' . $inpid . '").style.display = "block";
                        BX("s_bulls_' . $inpid . '").style.display = "none";
                        BX.adjust(BX("s_eye_' . $inpid . '"), {attrs: {src: "/bitrix/themes/.default/icons/simai4ib_hidden.svg"}});
                    }
                    else
                    {
                        BX("s_vis_' . $inpid . '").style.display = "none";
                        BX("s_bulls_' . $inpid . '").style.display = "block";
                        BX.adjust(BX("s_eye_' . $inpid . '"), {attrs: {src: "/bitrix/themes/.default/icons/simai4ib_view.svg"}});
                    }
                }
            );
            
            BX.bind(
                BX("s_copy_' . $inpid . '"),
                "click",
                function()
                {
                    dataView = 2;
                    BX.ajax({
                        method: "POST",
                        cache: false,
                        url: "/simai/admin/simai_p4ib_ajax_notification.php",
                        data: { 
                                PROPERTY_VALUE_ID : "'.$idprop.'",
                                VIEW : dataView,
                                PROP_ID : "'.$arProperty['ID'].'",
                                ELEMENT_ID : "'.$element_id.'",
                                IBLOCK_ID : "'.$arProperty["IBLOCK_ID"].'",
                                
                              },
                        onsuccess: function(response) {
                        console.log(response);
                            BX("s_vis_' . $inpid . '").innerText = decodeURIComponent(escape(window.atob(response)));
                            if (dataView == "2") {
                                            console.log("xaxax4");
                                BX.fireEvent(BX("repeat_copy_' . $inpid . '"), "click");
                            }
                        },
                        onfailure: function(response) {
                            alert("fail");
                            console.log(response);
                        }
                    });
                }
            );
            if (act == 0) {
                BX.clipboard.bindCopyClick(
                    BX("s_copy_' . $inpid . '"), 
                    {
                        text: BX("s_vis_' . $inpid . '")
                    }
                );
            } else {
                BX.clipboard.bindCopyClick(
                    BX("repeat_copy_' . $inpid . '"), 
                    {
                        text: BX("s_vis_' . $inpid . '")
                    }
                );
            }
            </script>
            ';
        } else {

            $strResult .= '
            <div class="sp4ib-password-container-view">
                <input type="button" id="show_password_' . $inpid . '" value="'.GetMessage("SP4I_SHOW_PASSWORD").'" style="'.((!empty($_SESSION["CODE_".$idprop]))?"display: none;":"").'">
                <input type="text" id="enter_code_' . $inpid . '" style="'.((!empty($_SESSION["CODE_".$idprop]))?"inline-block":"display: none;").'" class="sp4ib-password-input" placeholder="'.GetMessage("SP4I_PLACEHOLDER_CODE").'">
                <a href="javascript:void(0)" id="submit_code_' . $inpid . '" style="'.((!empty($_SESSION["CODE_".$idprop]))?"inline-flex;":"display: none;").'height:32px;align-items: center"><img class="sp4ib-password-unlock" src="/bitrix/themes/.default/icons/simai4ib_unlock.svg" width="16" alt="lock" title="Подтвердить код"></a>
                <a href="javascript:void(0)" id="repeat_code_' . $inpid . '" style="'.((!empty($_SESSION["CODE_".$idprop]))?"inline-flex;":"display: none;").'height:32px;align-items: center"><img class="sp4ib-password-unlock" src="/bitrix/themes/.default/icons/simai4ib_key.svg" width="16" alt="key" title="Выслать новый код"></a>
                
                <span id="s_bulls_' . $inpid . '" class="sp4ib-password-dots 34" style="display:none">&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;</span>
                <span id="s_vis_' . $inpid . '" class="sp4ib-password-vis-pass" style="display:none"></span>
                <img class="sp4ib-password-eye" id="s_eye_' . $inpid . '" src="/bitrix/themes/.default/icons/simai4ib_view.svg" style="display:none" width="16"> 
                <span class="span-mess-copy"><span id="repeat_copy_' . $inpid . '"></span><img class="sp4ib-password-copy" data-view="2" id="s_copy_' . $inpid . '" src="/bitrix/themes/.default/icons/simai4ib_copy.svg" style="display:none" width="16"></span>
            </div>
            
            <script type="text/javascript">
    
            document.getElementById("enter_code_' . $inpid . '").addEventListener("keydown", function(e) {
                if (e.keyCode === 13) {
                    BX.fireEvent(BX("submit_code_' . $inpid . '"), "click");
                }
            });
            
            var act = "' . $SET_PASS["ACT"] . '";
            var mas_pass = ' . json_encode($SET_PASS) .';
                BX.bind(
                    BX("show_password_' . $inpid . '"),
                    "click",
                    function()
                    {
                        BX("enter_code_' . $inpid . '").style.display = "inline-block";
                        BX("submit_code_' . $inpid . '").style.display = "inline-flex";
                        BX("repeat_code_' . $inpid . '").style.display = "inline-flex";
                        BX("show_password_' . $inpid . '").style.display = "none";

                        BX.ajax({
                            method: "POST",
                            cache: false,
                            url: "/simai/admin/simai_p4ib_ajax_send_mail.php",
                            data: { 
                                PROPERTY_VALUE_ID : "'.$idprop.'",
                                PROP_ID : "' . $arProperty['ID'] . '",
                                ELEMENT_ID : "' . $element_id . '",
                                IBLOCK_ID : "' . $arProperty["IBLOCK_ID"] . '",
                            },
                            onsuccess: 
                                function(response) {
                                    console.log(response);
                                },
                            onfailure: 
                                function() {
                                    alert("fail");
                                }
                        });
                    }
                );
                
                
                BX.bind(
                    BX("repeat_code_' . $inpid . '"),
                    "click",
                    function()
                    {
                        BX.ajax({
                            method: "POST",
                            cache: false,
                            url: "/simai/admin/simai_p4ib_ajax_send_mail.php",
                            data: { 
                                PROPERTY_VALUE_ID : "'.$idprop.'",
                                PROP_ID : "' . $arProperty['ID'] . '",
                                ELEMENT_ID : "' . $element_id . '",
                                IBLOCK_ID : "' . $arProperty["IBLOCK_ID"] . '",
                            },
                            onsuccess: 
                                function(response) {
                                    alert("' . GetMessage("SP4I_NEW_CODE") . '");
                                },
                            onfailure: 
                                function() {
                                    alert("fail");
                                }
                        });
                    }
                );
                BX.bind(
                    BX("submit_code_' . $inpid . '"),
                    "click",
                    function()
                    {
                        console.log("'.$idprop.'");
                        BX.ajax({
                            method: "POST",
                            cache: false,
                            url: "/simai/admin/simai_p4ib_ajax_checked_code.php",
                            data: { 
                                PROPERTY_VALUE_ID : "'.$idprop.'",
                                CHECK_CODE : BX("enter_code_' . $inpid . '").value,
                                PROP_ID : "'.$arProperty["ID"].'",
                                ELEMENT_ID : "'.$element_id.'",
                                IBLOCK_ID : "'.$arProperty["IBLOCK_ID"].'",
                            },
                            onsuccess: 
                                function(response) {
                                    if (response.replace(/\s/g, "")=="badcode") {
                                        alert("' . GetMessage("SP4I_ERROR_CODE") . '");
                                    } else {
                                        BX.hide(BX("show_password_' . $inpid . '"));
                                        BX.hide(BX("enter_code_' . $inpid . '"));
                                        BX.hide(BX("submit_code_' . $inpid . '"));
                                        BX.hide(BX("repeat_code_' . $inpid . '"));
                                        BX.style(BX("s_bulls_' . $inpid . '"), "display", "inline-block");
                                        BX.style(BX("s_eye_' . $inpid . '"), "display", "inline-block");
                                        BX.style(BX("s_copy_' . $inpid . '"), "display", "inline-block");
                                        BX("s_vis_' . $inpid . '").innerText = decodeURIComponent(escape(window.atob(response)));
                                    }
                                },
                            onfailure: function() {
                                alert("fail");
                            }
                        });
                    }
                );
                
                
                BX.bind(
                    BX("s_eye_' . $inpid . '"),
                    "click",
                    function()
                    {
                        if (BX("s_vis_' . $inpid . '").style.display == "none")
                        {
                            BX("s_vis_' . $inpid . '").style.display = "block";
                            BX("s_bulls_' . $inpid . '").style.display = "none";
                            BX.adjust(BX("s_eye_' . $inpid . '"), {attrs: {src: "/bitrix/themes/.default/icons/simai4ib_hidden.svg"}});
                        }
                        else
                        {
                            BX("s_vis_' . $inpid . '").style.display = "none";
                            BX("s_bulls_' . $inpid . '").style.display = "block";
                            BX.adjust(BX("s_eye_' . $inpid . '"), {attrs: {src: "/bitrix/themes/.default/icons/simai4ib_view.svg"}});
                        }
                    }
                );

                BX.bind(
                    BX("s_copy_' . $inpid . '"),
                    "click",
                    function()
                    {
                                            console.log("xaxax4");
                        BX.fireEvent(BX("repeat_copy_' . $inpid . '"), "click");
                    }
                );
                BX.clipboard.bindCopyClick(
                    BX("repeat_copy_' . $inpid . '"), 
                    {
                        text: BX("s_vis_' . $inpid . '")
                    }
                );
            </script>
            
            ';
        }

        return $strResult;
    }

    public static function GetAdminListViewHTML($arProperty, $arValue, $strHTMLControlName)
    {
        $strResult = ''; //$arValue['VALUE'];

        $strResult .= '&bull;&bull;&bull;&bull;&bull;&bull;';

        return $strResult;
    }

    public static function GetSearchContent($arProperty, $value, $strHTMLControlName)
    {
        return '';
    }
}
