<?php
IncludeModuleLangFile(__FILE__);

use Bitrix\Iblock;
use Bitrix\Main\Application;
use Bitrix\Main\IO;
use Bitrix\Main\File\Image;
use Bitrix\Main\Loader;

class CCustomTypeSimaiIBElement
{
    public static function GetUserTypeDescription()
    {
        return array(
            'PROPERTY_TYPE' => 'S',
            'USER_TYPE' => 'simai_ib_element',
            'DESCRIPTION' => GetMessage('SMPI_IBE_PROP'),
            'PrepareSettings' => array('CCustomTypeSimaiIBElement', 'PrepareSettings'),
            'GetSettingsHTML' => array('CCustomTypeSimaiIBElement', 'GetSettingsHTML'),
            'GetPropertyFieldHtml' => array('CCustomTypeSimaiIBElement', 'GetPropertyFieldHtml'),
            'GetPropertyFieldHtmlMulty' => array('CCustomTypeSimaiIBElement', 'GetPropertyFieldHtmlMulty'),
            'ConvertToDB' => array('CCustomTypeSimaiIBElement', 'ConvertToDB'),
            'ConvertFromDB' => array('CCustomTypeSimaiIBElement', 'ConvertFromDB'),
            'GetAdminListViewHTML' => array('CCustomTypeSimaiIBElement', 'GetAdminListViewHTML'),
            'GetPublicEditHTML' => array('CCustomTypeSimaiIBElement', 'GetPublicEditHTML'),
            'GetPublicViewHTML' => array('CCustomTypeSimaiIBElement', 'GetPublicViewHTML'),
        );
    }

    public static function PrepareSettings($arFields)
    {
        return array("LINK_IBLOCK_CODE" => trim($arFields["USER_TYPE_SETTINGS"]["LINK_IBLOCK_CODE"]));
    }

    public static function GetAllIblocks()
    {
        $TYPES = array();
        $IBLOCKS = array();
        $res = CIBlockType::GetList();
        while ($arr = $res->GetNext()) {
            if ($arIBType = CIBlockType::GetByIDLang($arr["ID"], LANGUAGE_ID)) {
                $arr['NAME'] = $arIBType["NAME"];
            }
            $TYPES[$arr["ID"]] = $arr;
        }
        $res = CIBlock::GetList(array("sort" => "asc", "name" => "asc"), array("ACTIVE" => "Y", "!CODE" => false));
        while ($arr = $res->Fetch()) {
            $IBLOCKS[$arr["IBLOCK_TYPE_ID"]][] = $arr;
        }
        return array("TYPES" => $TYPES, "IBLOCKS" => $IBLOCKS);
    }

    public static function GetSettingsHTML($arProperty, $strHTMLControlName, &$arPropertyFields)
    {
        global $DB;

        $arPropertyFields = array(
            "HIDE" => array("ROW_COUNT", "COL_COUNT", "DEFAULT_VALUE", "WITH_DESCRIPTION", "SEARCHABLE", "SMART_FILTER", "DISPLAY_TYPE", "EXPANDED"),
            "SET" => array("FILTRABLE" => "Y", "SEARCHABLE" => "Y", "SMART_FILTER" => "N", "MULTIPLE_CNT" => "1"),
            "USER_TYPE_SETTINGS_TITLE" => GetMessage('SMPI_SELECT_IBLOCK')
        );

        $return = '';

        $AR_IBLOCKS = self::GetAllIblocks();

        $return .= '
        <tr>
        <td>' . GetMessage('SMPI_SELECT_IBLOCK') . ':</td>
        <td>
            <select name="' . $strHTMLControlName["NAME"] . '[LINK_IBLOCK_CODE]" style="width:270px;">';
        foreach ($AR_IBLOCKS["TYPES"] as $type) {
            $ibs = $AR_IBLOCKS["IBLOCKS"][$type["ID"]];
            $return .= '<optgroup label="' . $type["NAME"] . '">';
            foreach ($ibs as $ibs => $ib) {
                $return .= '<option value="' . $ib['CODE'] . '"' . ($arProperty["USER_TYPE_SETTINGS"]["LINK_IBLOCK_CODE"] == $ib['CODE'] ? " selected" : "") . '>' . $ib['NAME'] . '</option>';
            }
            $return .= '</optgroup>';
        }
        $return .= '</select>
        </td>
        </tr>';

        return $return;
    }

    public static function GetPropertyFieldHtml($arProperty, $arValue, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION;

        $arSettings = self::PrepareSettings($arProperty);

        $LINK_IBLOCK_ID = 0;
        if ($arSettings["LINK_IBLOCK_CODE"]) {
            $res = CIBlock::GetList(array(), array("CODE" => $arSettings["LINK_IBLOCK_CODE"]), false);
            if ($arr = $res->fetch()) {
                $LINK_IBLOCK_ID = $arr['ID'];
            }
        }

        $fixIBlock = $LINK_IBLOCK_ID > 0;
        $windowTableId = 'iblockprop-' . Iblock\PropertyTable::TYPE_ELEMENT . '-' . $arProperty['ID'] . '-' . $LINK_IBLOCK_ID;

        $mxElement = CIBlockElement::GetById($arValue['VALUE'])->fetch();

        $strResult = '<input type="text" name="' . $strHTMLControlName["VALUE"] . '" id="' . $strHTMLControlName["VALUE"] . '" value="' . $arValue['VALUE'] . '" size="5">' .
            '<input type="button" value="..." onClick="jsUtils.OpenWindow(\'/bitrix/admin/sf_iblock_element_search.php?lang=' . LANGUAGE_ID . '&amp;IBLOCK_ID=' . $LINK_IBLOCK_ID . '&amp;n=' . urlencode($strHTMLControlName["VALUE"]) . ($fixIBlock ? '&amp;iblockfix=y' : '') . '&amp;tableId=' . $windowTableId . '\', 900, 700);">' .
            '&nbsp;<span id="sp_' . $strHTMLControlName["VALUE"] . '" >' . ($mxElement['CODE'] ? '[' . $mxElement['CODE'] . ']' : '') . ' ' . $mxElement['NAME'] . '</span>';

        return $strResult;
    }

    public static function GetPropertyFieldHtmlMulty($arProperty, $arValues, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION;

        $APPLICATION->AddHeadScript('/bitrix/js/simai.property4iblock/edit.js');

        $arSettings = static::PrepareSettings($arProperty);

        $LINK_IBLOCK_ID = 0;
        if ($arSettings["LINK_IBLOCK_CODE"]) {
            $res = CIBlock::GetList(array(), array("CODE" => $arSettings["LINK_IBLOCK_CODE"]), false);
            if ($arr = $res->fetch()) {
                $LINK_IBLOCK_ID = $arr['ID'];
            }
        }

        $fixIBlock = $LINK_IBLOCK_ID > 0;
        $windowTableId = 'iblockprop-' . Iblock\PropertyTable::TYPE_ELEMENT . '-' . $arProperty['ID'] . '-' . $LINK_IBLOCK_ID;

        $strResult = '';

        $inpid = md5('link_' . rand(0, 999));

        $strResult .= '<table cellpadding="0" cellspacing="0" border="0" class="nopadding" width="100%" id="tb' . $inpid . '">';

        foreach ($arValues as $intPropertyValueID => $arOneValue) {
            $mxElement = CIBlockElement::GetById($arOneValue['VALUE'])->fetch();
            if (is_array($mxElement)) {
                $strResult .= '<tr><td><input type="text" name="' . $strHTMLControlName["VALUE"] . '[' . $intPropertyValueID . ']" id="' . $strHTMLControlName["VALUE"] . '[' . $intPropertyValueID . ']" value="' . $arOneValue['VALUE'] . '" size="5">' .
                    '<input type="button" value="..." onClick="jsUtils.OpenWindow(\'/bitrix/admin/sf_iblock_element_search.php?lang=' . LANGUAGE_ID . '&amp;IBLOCK_ID=' . $LINK_IBLOCK_ID . '&amp;n=' . urlencode($strHTMLControlName["VALUE"] . '[' . $intPropertyValueID . ']') . ($fixIBlock ? '&amp;iblockfix=y' : '') . '&amp;tableId=' . $windowTableId . '\', 900, 700);">' .
                    '&nbsp;<span id="sp_' . $strHTMLControlName["VALUE"] . '[' . $intPropertyValueID . ']" >' . ($mxElement['CODE'] ? '[' . $mxElement['CODE'] . ']' : '') . ' ' . $mxElement['NAME'] . '</span></td></tr>';
            }
        }

        if (!$bVarsFromForm && (int)$arProperty['MULTIPLE_CNT'] > 0) {
            for ($i = 0; $i < $arProperty['MULTIPLE_CNT']; $i++) {
                $strResult .= '<tr><td><input type="text" name="' . $strHTMLControlName["VALUE"] . '[n' . $i . ']" id="' . $strHTMLControlName["VALUE"] . '[n' . $i . ']" value="" size="5">' .
                    '<input type="button" value="..." onClick="jsUtils.OpenWindow(\'/bitrix/admin/sf_iblock_element_search.php?lang=' . LANGUAGE_ID . '&amp;IBLOCK_ID=' . $LINK_IBLOCK_ID . '&amp;n=' . urlencode($strHTMLControlName["VALUE"] . '[n' . $i . ']') . ($fixIBlock ? '&amp;iblockfix=y' : '') . '&amp;tableId=' . $windowTableId . '\', 900, 700);">' .
                    '&nbsp;<span id="sp_' . $strHTMLControlName["VALUE"] . '[n' . $i . ']" ></span></td></tr>';
            }
        }

        $strResult .= '<tr><td><input type="button" value="' . GetMessage("IBLOCK_AT_PROP_ADD") . '" onClick="addNewRowSFPIB(\'tb' . $inpid . '\')"></td></tr>';
        $strResult .= "<script type=\"text/javascript\">BX.addCustomEvent('onAutoSaveRestore', function(ob, data) {for (var i in data){if (i.substring(0," . (strlen($strHTMLControlName["VALUE"]) + 1) . ")=='" . CUtil::JSEscape($strHTMLControlName["VALUE"]) . "['){addNewRowSFPIB('tb" . $inpid . "')}}})</script>";

        $strResult .= "</table>";

        return $strResult;
    }

    public static function GetPublicEditHTML($arProperty, $arValue, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION;

        $arSettings = self::PrepareSettings($arProperty);

        $LINK_IBLOCK_ID = 0;
        if ($arSettings["LINK_IBLOCK_CODE"]) {
            $res = CIBlock::GetList(array(), array("CODE" => $arSettings["LINK_IBLOCK_CODE"]), false);
            if ($arr = $res->fetch()) {
                $LINK_IBLOCK_ID = $arr['ID'];
            }
        }

        $fixIBlock = $LINK_IBLOCK_ID > 0;
        $windowTableId = 'iblockprop-' . Iblock\PropertyTable::TYPE_ELEMENT . '-' . $arProperty['ID'] . '-' . $LINK_IBLOCK_ID;

        $mxElement = CIBlockElement::GetById($arValue['VALUE'])->fetch();

        $strResult = '<input type="text" name="' . $strHTMLControlName["VALUE"] . '" id="' . $strHTMLControlName["VALUE"] . '" value="' . $arValue['VALUE'] . '" size="5">' .
            '<input type="button" value="..." onClick="jsUtils.OpenWindow(\'/simai/admin/sf_iblock_element_search.php?lang=' . LANGUAGE_ID . '&amp;IBLOCK_ID=' . $LINK_IBLOCK_ID . '&amp;n=' . urlencode($strHTMLControlName["VALUE"]) . ($fixIBlock ? '&amp;iblockfix=y' : '') . '&amp;tableId=' . $windowTableId . '\', 900, 700);">' .
            '&nbsp;<span id="sp_' . $strHTMLControlName["VALUE"] . '" >' . ($mxElement['CODE'] ? '[' . $mxElement['CODE'] . ']' : '') . ' ' . $mxElement['NAME'] . '</span>';

        return $strResult;
    }

    public static function ConvertToDB($arProperty, $value)
    {
        if (is_array($value["VALUE"])) {
            $val = array();

            $val["ELEMENT_CODE"] = preg_replace("/[^a-zA-Z0-9_\\-]/", "", $value["VALUE"]["ELEMENT_CODE"]);

            if (isset($value["VALUE"]["IBLOCK_CODE"])) {
                $val["IBLOCK_CODE"] = preg_replace("/[^a-zA-Z0-9_\\-]/", "", $value["VALUE"]["IBLOCK_CODE"]);
            }

            if ($val["ELEMENT_CODE"]) {
                $value["VALUE"] = $val["ELEMENT_CODE"]; //serialize($val);
            } else {
                $value["VALUE"] = false;
            }
        } elseif (is_numeric($value["VALUE"])) {
            $res = CIBlockElement::GetById($value["VALUE"]);
            if ($arr = $res->fetch()) {
                if ($arr['CODE']) {
                    $value["VALUE"] = $arr['CODE'];
                } else
                    $value["VALUE"] = false;
            } else
                $value["VALUE"] = false;
        } elseif (strlen($value["VALUE"]) > 0) {
            $value["VALUE"] = preg_replace("/[^a-zA-Z0-9_\\-]/", "", $value["VALUE"]);
        } else
            $value["VALUE"] = false;

        return $value;
    }

    public static function ConvertFromDB($arProperty, $value)
    {
        global $DB;

        if (strlen($value["VALUE"]) > 0) {
            if (substr_count($value["VALUE"], '{') > 0) {
                $value_us = unserialize($value["VALUE"]);

                if (is_array($value_us)) {
                    $el_code = $value_us["ELEMENT_CODE"];
                    $ib_code = $value_us["IBLOCK_CODE"];
                }
            } else {
                $el_code = $value["VALUE"];
                $ib_code = false;
            }

            $value["VALUE"] = false;

            if (isset($arProperty['USER_TYPE_SETTINGS'])) {
                
                if (is_array($arProperty['USER_TYPE_SETTINGS']))
                    $settings = $arProperty['USER_TYPE_SETTINGS'];
                else
                    $settings = unserialize($arProperty['USER_TYPE_SETTINGS']);
                
                if (is_array($settings))
                {
                    if ($settings['LINK_IBLOCK_CODE'])
                        $ib_code = $settings['LINK_IBLOCK_CODE'];
               }
            }

            if ($ib_code) {
                $res = $DB->Query("select `ID` from `b_iblock` where `CODE`='" . $DB->ForSQL($ib_code) . "'");
                if ($arr = $res->fetch()) {
                    $res = $DB->Query("select `ID` from `b_iblock_element` where `CODE`='" . $DB->ForSQL($el_code) . "' and `IBLOCK_ID`=" . intval($arr['ID']));
                    if ($arr = $res->fetch()) {
                        $value["VALUE"] = $arr['ID'];
                    }
                }
            } else {
                $res = $DB->Query("select `ID` from `b_iblock_element` where `CODE`='" . $DB->ForSQL($el_code) . "'");
                if ($arr = $res->fetch()) {
                    $value["VALUE"] = $arr['ID'];
                }
            }
        } else {
            $value["VALUE"] = false;
        }

        return $value;
    }

    public static function GetPublicViewHTML($arProperty, $arValue, $strHTMLControlName)
    {
        static $cache = array();

        $arSettings = self::PrepareSettings($arProperty);

        $LINK_IBLOCK_ID = 0;
        if ($arSettings["LINK_IBLOCK_CODE"]) {
            $res = CIBlock::GetList(array(), array("CODE" => $arSettings["LINK_IBLOCK_CODE"]), false);
            if ($arr = $res->fetch()) {
                $LINK_IBLOCK_ID = $arr['ID'];
            }
        }

        $strResult = '';
        $arValue['VALUE'] = intval($arValue['VALUE']);
        if (0 < $arValue['VALUE']) {
            if (!isset($cache[$arValue['VALUE']])) {
                $arFilter = array();
                $intIBlockID = intval($LINK_IBLOCK_ID);
                if (0 < $intIBlockID) $arFilter['IBLOCK_ID'] = $intIBlockID;
                $arFilter['ID'] = $arValue['VALUE'];
                $arFilter["ACTIVE"] = "Y";
                $arFilter["ACTIVE_DATE"] = "Y";
                $arFilter["CHECK_PERMISSIONS"] = "Y";
                $rsElements = CIBlockElement::GetList(array(), $arFilter, false, false, array("ID", "IBLOCK_ID", "NAME", "DETAIL_PAGE_URL"));
                $cache[$arValue['VALUE']] = $rsElements->GetNext(true, false);
            }
            if (is_array($cache[$arValue['VALUE']])) {
                if (isset($strHTMLControlName['MODE']) && 'CSV_EXPORT' == $strHTMLControlName['MODE']) {
                    $strResult = $cache[$arValue['VALUE']]['ID'];
                } elseif (isset($strHTMLControlName['MODE']) && ('SIMPLE_TEXT' == $strHTMLControlName['MODE'] || 'ELEMENT_TEMPLATE' == $strHTMLControlName['MODE'])) {
                    $strResult = $cache[$arValue['VALUE']]["NAME"];
                } else {
                    $strResult = '<a href="' . $cache[$arValue['VALUE']]["DETAIL_PAGE_URL"] . '">' . $cache[$arValue['VALUE']]["NAME"] . '</a>';;
                }
            }
        }
        return $strResult;
    }

    public static function GetAdminListViewHTML($arProperty, $value, $strHTMLControlName)
    {
        $strResult = '';
        $mxResult = CIBlockElement::GetById($value['VALUE'])->fetch();
        if (is_array($mxResult)) {
            $strResult = $mxResult['NAME'] . ' [<a href="/bitrix/admin/' .
                CIBlock::GetAdminElementEditLink(
                    $mxResult['IBLOCK_ID'],
                    $mxResult['ID'],
                    array(
                        'WF' => 'Y'
                    )
                ) . '">' . ($mxResult['CODE'] ? $mxResult['CODE'] : $mxResult['ID']) . '</a>]';
        }
        return $strResult;
    }
}