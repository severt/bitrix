<?php
IncludeModuleLangFile(__FILE__);

use Bitrix\Iblock;
use Bitrix\Main\Application;
use Bitrix\Main\IO;
use Bitrix\Main\File\Image;
use Bitrix\Main\Loader;

class CCustomTypeSimaiStadia
{


    public static function GetUserTypeDescription()
    {
        return array(
            'PROPERTY_TYPE' => 'L',
            'USER_TYPE' => 'simai_stadia',
            'DESCRIPTION' => GetMessage('SMPI_STADIA_PROP'),
            'PrepareSettings' => array('CCustomTypeSimaiStadia', 'PrepareSettings'),
            'GetSettingsHTML' => array('CCustomTypeSimaiStadia', 'GetSettingsHTML'),
            'GetPropertyFieldHtml' => array('CCustomTypeSimaiStadia', 'GetPropertyFieldHtml'),
            'GetPropertyFieldHtmlMulty' => array('CCustomTypeSimaiStadia', 'GetPropertyFieldHtmlMulty'),
            //'ConvertToDB' => array('CCustomTypeSimaiStadia', 'ConvertToDB'),
            //'ConvertFromDB' => array('CCustomTypeSimaiStadia', 'ConvertFromDB'),
            'GetSearchContent' => array('CCustomTypeSimaiStadia', 'GetSearchContent'),
            //'GetAdminListViewHTML' => array('CCustomTypeSimaiStadia', 'GetAdminListViewHTML'),
            //'GetAdminFilterHTML' => array('CCustomTypeSimaiStadia', 'GetAdminFilterHTML'),
            'GetUIFilterProperty' => array('CCustomTypeSimaiStadia', 'GetUIFilterProperty'),
            'GetPublicFilterHTML' => array('CCustomTypeSimaiStadia', 'GetPublicFilterHTML'),
            'GetPublicEditHTML' => array('CCustomTypeSimaiStadia', 'GetPublicEditHTML'),
            'GetPublicViewHTML' => array('CCustomTypeSimaiStadia', 'GetPublicViewHTML'),
        );
    }



    public static function PrepareSettings($arFields)
    {
        return array('MULTIPLE' => 'N', 'USER_TYPE_SETTINGS' => $arFields["USER_TYPE_SETTINGS"]);


    }

    public static function GetSettingsHTML($arProperty, $strHTMLControlName, &$arPropertyFields)
    {
        global $APPLICATION;

        $arPropertyFields = array(
            "HIDE" => array("DEFAULT_VALUE", "DISPLAY_TYPE", "EXPANDED", "PROPERTY_FILTER_HINT", "MULTIPLE"),
            "SET" => array("FILTRABLE" => "Y", "SEARCHABLE" => "Y", "SMART_FILTER" => "N", "MULTIPLE" => "N"),
        );

        $return = '<tr><td colspan="2" style="font-weight:bold; text-align:left;">' . GetMessage('SP4IB_COLORS_STADIA') . '</td></tr>';

        $i = 0;
        $enums = array();
        if ($arProperty["ID"]) {
            $res = CIBlockPropertyEnum::GetList(array("SORT" => "ASC"), array("IBLOCK_ID" => $arProperty["IBLOCK_ID"], "PROPERTY_ID" => $arProperty["ID"]));
            while ($enum = $res->GetNext()) {
                $i++;
                $enums[$i] = $enum;
            }
        }

        foreach ($enums as $enum) {
            $color = htmlspecialcharsbx($arProperty["USER_TYPE_SETTINGS"]["COLORS"][$enum['ID']]);

            $return .= '
            <tr>
            <td>' . $enum['VALUE'] . ':</td>
            <td>
            <script type="text/javascript">
            function ColorPick' . $enum['ID'] . '(color)
            {
                if (color == false)
                {
                    BX("bx_btn_colorpick' . $enum['ID'] . '").style.background = "#BFEBFB";
                    BX("colorpick_inp_' . $enum['ID'] . '").value = "";
                }
                else
                {
                    BX("bx_btn_colorpick' . $enum['ID'] . '").style.background = color;
                    BX("colorpick_inp_' . $enum['ID'] . '").value = color;
                }
            }
            </script> 
            
            <input type="text" size="12" id="colorpick_inp_' . $enum['ID'] . '" name="' . $strHTMLControlName["NAME"] . '[COLORS][' . $enum['ID'] . ']" value="' . $color . '" style="float:left; margin-right:6px;">
            ';
            ob_start();
            $APPLICATION->IncludeComponent(
                "bitrix:main.colorpicker",
                "",
                array(
                    "COMPOSITE_FRAME_MODE" => "A",
                    "COMPOSITE_FRAME_TYPE" => "AUTO",
                    "ID" => "colorpick" . $enum['ID'],
                    "NAME" => "",
                    "ONSELECT" => "ColorPick" . $enum['ID'],
                    "SHOW_BUTTON" => "Y"
                ),
                false,
                array("HIDE_ICONS" => "Y")
            );
            $return .= ob_get_contents();
            ob_end_clean();
            $return .= '<script type="text/javascript">BX.ready(function() {ColorPick' . $enum['ID'] . '("' . $color . '")});</script>';
            $return .= '
            </td>
            </tr>';
        }

        return $return;
    }

    public static function GetPropertyFieldHtml($arProperty, $arValue, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION, $ID;

        ob_start();
        if ($_REQUEST['mode'] != 'frame') {
            _ShowListPropertyField('PROP[' . $arProperty["ID"] . ']', $arProperty, $arValue, (!$bVarsFromForm && $ID <= 0), false);
        }
        $return .= ob_get_contents();
        ob_end_clean();

        return $return;
    }

    public static function GetPropertyFieldHtmlMulty($arProperty, $arValues, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION, $ID;

        /*if (is_array($arValues))
        {
            foreach ($arValues as $i => $arValue)
            {
                $arValues[$i]['VALUE'] = current($arValue['VALUE']);
            }
        }*/

        ob_start();
        if ($_REQUEST['mode'] != 'frame') {
            _ShowListPropertyField('PROP[' . $arProperty["ID"] . ']', $arProperty, $arValues, (!$bVarsFromForm && $ID <= 0), false);
        }
        $return .= ob_get_contents();
        ob_end_clean();

        return $return;
    }

    public static function ConvertFromDB($arProperty, $value)
    {
        /*if ($arProperty['PROPERTY_VALUE_ID'] > 0 && !is_array($value['VALUE']))
        {
            $value['VALUE'] = array($arProperty['PROPERTY_VALUE_ID'] => $value['VALUE']);
        }*/

        return $value;
    }

    public static function GetPublicEditHTML($arProperty, $arValue, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION, $DB;
        $APPLICATION->SetAdditionalCSS('/bitrix/themes/.default/simai.property4iblock.css');
        CJSCore::Init(array('ajax'));

        //print_r($arValue);
        $rand = rand(99, 999);

        $value = $arValue['VALUE'];

        if ($arProperty['VALUE_ENUM_ID'])
            $value = $arProperty['VALUE_ENUM_ID'];

        if ($arProperty['PROPERTY_VALUE_ID'])
            $value_id = $arProperty['PROPERTY_VALUE_ID'];

        if (is_array($value))
            $value = current($value);

        if (is_array($value_id))
            $value_id = current($value_id);

        if ($arProperty['ELEMENT_ID']) {
            $element_id = $arProperty['ELEMENT_ID'];
        } elseif (strpos($value_id, ':')) {
            $element_id = intval($value_id);
        } elseif ($value_id > 0) {
            $res = $DB->Query('select * from `b_iblock_element_property` where `ID`=' . intval($value_id));
            if ($arr = $res->fetch())
                $element_id = $arr['IBLOCK_ELEMENT_ID'];
        }

        $i = 0;
        $enums = array();
        if ($arProperty["ID"]) {
            $res = CIBlockPropertyEnum::GetList(array("SORT" => "ASC"), array("IBLOCK_ID" => $arProperty["IBLOCK_ID"], "PROPERTY_ID" => $arProperty["ID"]));
            while ($enum = $res->GetNext()) {
                if ($arProperty["USER_TYPE_SETTINGS"]["COLORS"][$enum['ID']])
                    $enum['COLOR'] = $arProperty["USER_TYPE_SETTINGS"]["COLORS"][$enum['ID']];

                $i++;
                $enums[$i] = $enum;

                if (intval($value) <= 0 && $enum['DEF'] == 'Y') {
                    $value = $enum['ID'];
                }
            }
        }

        $currentStep = 0;
        $color = '#BFEBFB';
        $title = '';
        foreach ($enums as $i => $enum) {
            if ($value == $enum['ID']) {
                if ($enum['COLOR']) {
                    $color = htmlspecialcharsbx($enum['COLOR']);
                }
                $title = $enum['VALUE'];
                $currentStep = $i;
            }
        }

        foreach ($enums as $i => $enum) {
            $stepHtml .= '<td class="sp4ib-list-stage-bar-part">';
            $stepHtml .= '<div class="sp4ib-list-stage-bar-block" title="' . htmlspecialcharsbx($enum['VALUE']) . '" id="stage' . $rand . '-' . $i . '"';
            if ($i <= $currentStep) {
                $stepHtml .= ' style="background:' . $color . '"';
            }
            $stepHtml .= ' onclick="SetSFStadia' . $rand . '(' . $enum['ID'] . ', ' . $i . ')"';
            $stepHtml .= '><div class="sp4ib-list-stage-bar-btn"></div></div></td>';
        }

        $strResult = '<div class="sp4ib-list-stage-bar" id="sp4ib-stadia-' . $rand . '"><table class="sp4ib-list-stage-bar-table"><tr>' . $stepHtml . '</tr></table></div>';
        $strResult .= '<div class="sp4ib-list-stage-bar-title" id="sp4ib-stadia-' . $rand . '-title">' . $title . '</div>';

        $strResult .= '<input id="stage' . $rand . '-inp" type="hidden" name="' . $strHTMLControlName["VALUE"] . '" value="' . htmlspecialcharsbx($value) . '">';

        $strResult .= "
        <script>
        function SetSFStadia" . $rand . "(val, num)
        {
            BX.ajax.get('/simai/admin/simai_p4ib_stadia_set_value.php?element_id=" . $element_id . "&property_id=" . $arProperty["ID"] . "&value='+val, function (data) {});
            BX('stage" . $rand . "-inp').value = val;
            
            var scolors = [];
            var stitles = [];
            ";
        $title = '';
        foreach ($enums as $i => $enum) {
            $color = '#BFEBFB';
            if ($enum['COLOR'])
                $color = htmlspecialcharsbx($enum['COLOR']);
            $title = htmlspecialcharsbx($enum['VALUE']);
            $strResult .= "scolors[" . $i . "] = '" . $color . "';";
            $strResult .= "stitles[" . $i . "] = '" . $title . "';";
        }
        $strResult .= "
            i = 1;
            var color = scolors[i];
            var title = stitles[i];
            while (i <= num) 
            {
                color = scolors[i];
                title = stitles[i];
                i++;
            }
            i = 1;
            while (i <= " . count($enums) . ") 
            {
                if (i <= num)
                {
                    BX('stage" . $rand . "-'+i).style.backgroundColor = color;
                }
                else
                {
                    BX('stage" . $rand . "-'+i).style.backgroundColor = 'transparent';
                }
                i++;
            }
            BX('sp4ib-stadia-" . $rand . "-title').innerHTML = title;
        }
        </script>
        ";

        return $strResult;
    }


    public static function GetPublicViewHTML($arProperty, $arValue, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION, $DB;
        $APPLICATION->SetAdditionalCSS('/bitrix/themes/.default/simai.property4iblock.css');
        CJSCore::Init(array('ajax'));

        $rand = rand(99, 999);
        $element_id = 0;

        $value = $arValue['VALUE'];

        if ($arProperty['VALUE_ENUM_ID'])
            $value = $arProperty['VALUE_ENUM_ID'];

        if ($arProperty['PROPERTY_VALUE_ID'])
            $value_id = $arProperty['PROPERTY_VALUE_ID'];

        if (is_array($value))
            $value = current($value);

        if (is_array($value_id))
            $value_id = current($value_id);

        if (is_array($arValue) && $arValue['ELEMENT_ID']) {
            $element_id = $arValue['ELEMENT_ID'];
        } elseif (strpos($value_id, ':')) {
            $element_id = intval($value_id);
        } elseif ($value_id > 0) {
            $res = $DB->Query('select * from `b_iblock_element_property` where `ID`=' . intval($value_id));
            if ($arr = $res->fetch())
                $element_id = $arr['IBLOCK_ELEMENT_ID'];
        }

        $i = 0;
        $enums = array();
        if ($arProperty["ID"]) {
            $res = CIBlockPropertyEnum::GetList(array("SORT" => "ASC"), array("IBLOCK_ID" => $arProperty["IBLOCK_ID"], "PROPERTY_ID" => $arProperty["ID"]));
            while ($enum = $res->GetNext()) {
                if ($arProperty["USER_TYPE_SETTINGS"]["COLORS"][$enum['ID']])
                    $enum['COLOR'] = $arProperty["USER_TYPE_SETTINGS"]["COLORS"][$enum['ID']];

                $i++;
                $enums[$i] = $enum;
            }
        }

        $currentStep = 0;
        $color = '#BFEBFB';
        $title = '';
        foreach ($enums as $i => $enum) {
            if ($value == $enum['ID']) {
                if ($enum['COLOR']) {
                    $color = htmlspecialcharsbx($enum['COLOR']);
                }
                $title = $enum['VALUE'];
                $currentStep = $i;
            }
        }

        foreach ($enums as $i => $enum) {
            $stepHtml .= '<td class="sp4ib-list-stage-bar-part">';
            $stepHtml .= '<div class="sp4ib-list-stage-bar-block" title="' . htmlspecialcharsbx($enum['VALUE']) . '" id="stage' . $rand . '-' . $i . '"';
            if ($i <= $currentStep) {
                $stepHtml .= ' style="background:' . $color . '"';
            }
            $stepHtml .= ' onclick="SetSFStadia' . $rand . '(' . $enum['ID'] . ', ' . $i . ')"';
            $stepHtml .= '><div class="sp4ib-list-stage-bar-btn"></div></div></td>';
        }

        $strResult = '<div class="sp4ib-list-stage-bar" id="sp4ib-stadia-' . $rand . '"><table class="sp4ib-list-stage-bar-table"><tr>' . $stepHtml . '</tr></table></div>';
        $strResult .= '<div class="sp4ib-list-stage-bar-title" id="sp4ib-stadia-' . $rand . '-title">' . $title . '</div>';

        $strResult .= "
        <link href='/bitrix/themes/.default/simai.property4iblock.css?" . time() . "' type='text/css'  rel='stylesheet' />
        
        <script>
        function SetSFStadia" . $rand . "(val, num)
        {
            BX.ajax.get('/simai/admin/simai_p4ib_stadia_set_value.php?element_id=" . $element_id . "&property_id=" . $arProperty["ID"] . "&value='+val, function (data) {});
            
            var scolors = [];
            var stitles = [];
            ";
        $title = '';
        foreach ($enums as $i => $enum) {
            $color = '#BFEBFB';
            if ($enum['COLOR'])
                $color = htmlspecialcharsbx($enum['COLOR']);
            $title = htmlspecialcharsbx($enum['VALUE']);
            $strResult .= "scolors[" . $i . "] = '" . $color . "';";
            $strResult .= "stitles[" . $i . "] = '" . $title . "';";
        }
        $strResult .= "
            i = 1;
            var color = scolors[i];
            var title = stitles[i];
            while (i <= num) 
            {
                color = scolors[i];
                title = stitles[i];
                i++;
            }
            i = 1;
            while (i <= " . count($enums) . ") 
            {
                if (i <= num)
                {
                    BX('stage" . $rand . "-'+i).style.backgroundColor = color;
                }
                else
                {
                    BX('stage" . $rand . "-'+i).style.backgroundColor = 'transparent';
                }
                i++;
            }
            BX('sp4ib-stadia-" . $rand . "-title').innerHTML = title;
        }
        </script>
        ";

        return $strResult;
    }

    public static function GetAdminFilterHTML($arProperty, $strHTMLControlName)
    {
        $arSettings = static::PrepareSettings($arProperty);

        $values = array();
        if (array_key_exists($strHTMLControlName['VALUE'], $_REQUEST))
            $values = $_REQUEST[$strHTMLControlName['VALUE']];
        elseif (isset($GLOBALS[$strHTMLControlName['VALUE']]))
            $values = $GLOBALS[$strHTMLControlName['VALUE']];

        if (!is_array($values)) {
            $values = array($values);
        }

        $enums = array();
        $property_enums = CIBlockPropertyEnum::GetList(array("DEF" => "DESC", "SORT" => "ASC"), array("IBLOCK_ID" => $arProperty["IBLOCK_ID"], "PROPERTY_ID" => $arProperty["ID"]));
        while ($enum_fields = $property_enums->GetNext()) {
            $enums[$enum_fields["ID"]] = $enum_fields["VALUE"];
        }

        $strResult = '<select multiple name="' . htmlspecialcharsbx($strHTMLControlName['VALUE']) . '[]" id="filter_' . htmlspecialcharsbx($strHTMLControlName['VALUE']) . '">';
        $strResult .= '<option value=""' . (empty($values) ? ' selected="selected"' : '') . '></option>';
        foreach ($enums as $key => $value) {
            $strResult .= '<option value="' . htmlspecialcharsbx($key) . '"' . (in_array($key, $values) ? ' selected="selected"' : '') . '>' . htmlspecialcharsex($value) . '</option>';
        }
        $strResult .= '</select>';

        return $strResult;
    }

    public static function GetPublicFilterHTML($arProperty, $strHTMLControlName)
    {
        $filterOption = new \Bitrix\Main\UI\Filter\Options($strHTMLControlName["GRID_ID"]);
        $filterData = $filterOption->getFilter(array());

        $values = $filterData[$strHTMLControlName["VALUE"]];

        $enums = array();
        $property_enums = CIBlockPropertyEnum::GetList(array("DEF" => "DESC", "SORT" => "ASC"), array("IBLOCK_ID" => $arProperty["IBLOCK_ID"], "PROPERTY_ID" => $arProperty["ID"]));
        while ($enum_fields = $property_enums->GetNext()) {
            $enums[$enum_fields["ID"]] = $enum_fields["VALUE"];
        }

        $strResult .= '<input id="sta_' . htmlspecialcharsbx($strHTMLControlName['VALUE']) . '" type="hidden" name="' . htmlspecialcharsbx($strHTMLControlName['VALUE']) . '" value="' . htmlspecialcharsbx($values) . '">';

        $strResult .= '<select name="' . htmlspecialcharsbx($strHTMLControlName['VALUE']) . '" onchange="document.getElementById(\'sta_' . htmlspecialcharsbx($strHTMLControlName['VALUE']) . '\').value=this.value;">';
        $strResult .= '<option>Выбор</option>';
        $cruthResult = array();
        foreach ($enums as $key => $value) {
            $cruthResult[$key] = $value;
            //$strResult .= '<option value="' . htmlspecialcharsbx($key) . '"' . (in_array($key, $values) ? ' selected' : '') . '>' . htmlspecialcharsbx($value) . '</option>';
            $strResult .= '<option value="' . htmlspecialcharsbx($key) . '"' . '>' . htmlspecialcharsbx($value) . '</option>';
        }
        $strResult .= '</select>';

        return $strResult;

        // temporary solution
        $arVal = array();
        $arVal['type'] = "list";
        $arVal['items'] = $cruthResult;
        //return $arVal;
    }


    public static function GetUIFilterProperty($arProperty, $strHTMLControlName, &$fields)
    {
        $enums = array();
        $property_enums = CIBlockPropertyEnum::GetList(array("DEF" => "DESC", "SORT" => "ASC"), array("IBLOCK_ID" => $arProperty["IBLOCK_ID"], "PROPERTY_ID" => $arProperty["ID"]));
        while ($enum_fields = $property_enums->GetNext()) {
            $enums[$enum_fields["ID"]] = $enum_fields["VALUE"];
        }

        $fields['type'] = 'NUMBER';
        $fields['items'] = array();
        foreach ($enums as $index => $value) {
            $fields['items'][$index] = $value;
        }
        //unset($index, $value, $settings);


    }

    public static function GetAdminListViewHTML($arProperty, $arValue, $strHTMLControlName)
    {
        $strResult = $arValue['VALUE'];
        return $strResult;
    }

    public static function GetSearchContent($arProperty, $value, $strHTMLControlName)
    {
        return '';
    }
}
