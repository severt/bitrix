<?php
IncludeModuleLangFile(__FILE__);

use Bitrix\Iblock;
use Bitrix\Main\Application;
use Bitrix\Main\IO;
use Bitrix\Main\File\Image;
use Bitrix\Main\Loader;

class TypeSimaiP4IB
{
    public static function OnAfterIBlockElementUpdateHandler(&$arF)
    {
        global $DB;

        if ($arF["ID"] > 0 && $arF["RESULT"]) {
            $ext_searchable_content = '';
            $ext_tags = '';

            $resE = $DB->Query('select `IBLOCK_ID`, `SEARCHABLE_CONTENT`, `TAGS` from `b_iblock_element` where `ID`=' . intval($arF["ID"]));
            if ($arElement = $resE->fetch()) {
                $resPV = CIBlockElement::GetProperty($arElement["IBLOCK_ID"], $arF["ID"], "sort", "asc", array());
                while ($arPV = $resPV->fetch()) {
                    if (!is_array($arPV["VALUE"]))
                    {
                        $arPV["VALUE"] = trim($arPV["VALUE"]);
                        if ($arPV["VALUE"]) {
                            if ($arPV['USER_TYPE'] == 'simai_link') {
                                $ext_searchable_content .= ' ' . $arPV["VALUE"] . ' ' . $arPV["DESCRIPTION"];
                            } elseif ($arPV['USER_TYPE'] == 'simai_task') {
                                if (CModule::IncludeModule("tasks")) {
                                    $rsTask = CTasks::GetByID($arPV['VALUE']);
                                    if ($arTask = $rsTask->fetch()) {
                                        $ext_searchable_content .= ' ' . $arTask["ID"] . ' ' . $arTask["TITLE"];
                                    }
                                }
                            } elseif ($arPV['USER_TYPE'] == 'simai_ib_element') {
                                $res = CIBlockElement::GetByID($arPV["VALUE"]);
                                if ($arr = $res->fetch()) {
                                    $ext_searchable_content .= ' ' . $arr['NAME'];
                                }
                            } elseif ($arPV['USER_TYPE'] == 'simai_ib_section') {
                                $res = CIBlockSection::GetByID($arPV["VALUE"]);
                                if ($arr = $res->fetch()) {
                                    $ext_searchable_content .= ' ' . $arr['NAME'];
                                }
                            } elseif ($arPV['USER_TYPE'] == 'simai_tags') {
                                $ext_tags .= $arPV["VALUE"] . ', ';
                                $ext_searchable_content .= ' ' . str_replace(',', ' ', $arPV["VALUE"]);
                            }
                        }
                    }
                }

                $ext_searchable_content = trim($ext_searchable_content);
                $ext_searchable_content = explode(' ', $ext_searchable_content);

                foreach ($ext_searchable_content as $word) {
                    if ($word)
                    {
                        $word = strtoupper($word);
                        if (substr_count($arElement['SEARCHABLE_CONTENT'], $word) <= 0) {
                            $arElement['SEARCHABLE_CONTENT'] .= ' ' . $word;
                        }
                    }
                }

                $arElement['SEARCHABLE_CONTENT'] = trim($arElement['SEARCHABLE_CONTENT']);
                $arElement['TAGS'] = trim($arElement['TAGS']);

                if (trim($ext_tags)) {
                    $arElement['TAGS'] = trim($ext_tags);
                }

                $strUpdate = $DB->PrepareUpdate("b_iblock_element", array('SEARCHABLE_CONTENT' => $arElement['SEARCHABLE_CONTENT'], 'TAGS' => $arElement['TAGS']));
                $strSql = "UPDATE `b_iblock_element` SET " . $strUpdate . " WHERE ID=" . intval($arF["ID"]);
                $DB->Query($strSql, false, '');

                CIBlockElement::UpdateSearch($arF["ID"], true);
            }
        }
    }
}
