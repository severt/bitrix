
<?php
IncludeModuleLangFile(__FILE__);

use Bitrix\Iblock;
use Bitrix\Main\Application;
use Bitrix\Main\IO;
use Bitrix\Main\File\Image;
use Bitrix\Main\Loader;

class CCustomTypeSimaiImage
{
    const USER_TYPE = 'simai_image';

    const WIDTH = 2000;
    const HEIGHT = 2000;

    public static function GetUserTypeDescription()
    {
        return [
            'PROPERTY_TYPE' => Iblock\PropertyTable::TYPE_FILE,
            'USER_TYPE' => self::USER_TYPE,
            'DESCRIPTION' => GetMessage('SP4I_IMAGE_DESC'),
            'GetPropertyFieldHtml' => [__CLASS__, 'GetPropertyFieldHtml'],
            'GetPropertyFieldHtmlMulty' => [__CLASS__, 'GetPropertyFieldHtmlMulty'],
            'ConvertToDB' => [__CLASS__, 'ConvertToDB'],
            'ConvertFromDB' => [__CLASS__, 'ConvertFromDB'],
            'GetSettingsHTML' => [__CLASS__, 'GetSettingsHTML'],
            'PrepareSettings' => [__CLASS__, 'PrepareSettings'],
            'GetPublicViewHTML' => [__CLASS__, 'GetPublicViewHTML'],
            'GetPublicViewHTMLMulty' => [__CLASS__, 'GetPublicViewHTMLMulty'],
            'GetPublicEditHTML' => [__CLASS__, 'GetPublicEditHTML'],
            'GetPublicEditHTMLMulty' => [__CLASS__, 'GetPublicEditHTMLMulty'],
        ];
    }

    public static function GetPropertyFieldHtmlMulty($arProperty, $arValues, $strHTMLControlName)
    {
        $name = "PROP[{$arProperty['ID']}]";

        $images = [];
        foreach ($arValues as $key => $arValue) {
            $images[$name.'['.$key.']'] = $arValue['VALUE'];
        }

        return \Bitrix\Main\UI\FileInput::createInstance([
            'id' => $name.'[n#IND#]_'.mt_rand(1, 1000000),
            'name' => $name.'[n#IND#]',
            'description' => ($arProperty['WITH_DESCRIPTION'] === 'Y'),
            'upload' => true,
            'allowUpload' => 'I',
            'allowUploadExt' => $arProperty['FILE_TYPE'],
            'medialib' => true,
            'fileDialog' => true,
            'cloud' => true,
            'delete' => true
        ])->show($images);
    }

    public static function GetPropertyFieldHtml($arProperty, $value, $strHTMLControlName)
    {
        $propertyValueId = self::getElementPropertyValueId($arProperty['ID'], $_REQUEST['ID'], $arProperty['IBLOCK_ID']);

        $name = $propertyValueId
            ? "PROP[{$arProperty['ID']}][{$propertyValueId}]"
            : "PROP[{$arProperty['ID']}][n0]";

        return \Bitrix\Main\UI\FileInput::createInstance([
            'id' => $name.'_'.mt_rand(1, 1000000),
            'name' => $name,
            'description' => ($arProperty['WITH_DESCRIPTION'] === 'Y'),
            'upload' => true,
            'allowUpload' => 'I',
            'allowUploadExt' => $arProperty['FILE_TYPE'],
            'medialib' => true,
            'fileDialog' => true,
            'cloud' => true,
            'delete' => true,
            'maxCount' => 1
        ])->show($value['VALUE']);
    }

    public static function ConvertToDB($arProperty, $value)
    {
        $arFile = $value['VALUE'];

        // resize image before save
        if (is_array($arFile))
        {
            if ($arFile['tmp_name']) {
                CFile::ResizeImage(
                    $arFile,
                    ['width' => $arProperty['USER_TYPE_SETTINGS']['WIDTH'], 'height' => $arProperty['USER_TYPE_SETTINGS']['HEIGHT']],
                    BX_RESIZE_IMAGE_PROPORTIONAL_ALT
                );

                $value['VALUE'] = $arFile;
            }
        }

        return $value;
    }

    public static function ConvertFromDB($arProperty, $value)
    {
        if ($value['VALUE']) {
            // image parameters
            $arParams = self::getImageParams($arProperty);

            // file info
            $arFile = Bitrix\Main\FileTable::GetList([
                'select'  => ['ID', 'HEIGHT', 'WIDTH', 'FILE_SIZE', 'SUBDIR', 'FILE_NAME'],
                'filter'  => ['ID' => $value['VALUE']]
            ])->Fetch();

            if (($arParams['WIDTH'] < $arFile['WIDTH']) || ($arParams['HEIGHT'] < $arFile['HEIGHT'])) {
                self::optimizeImage($arFile, $arParams);
            }
        }

        return $value;
    }

    public static function PrepareSettings($arFields)
    {
        $width = $arFields['USER_TYPE_SETTINGS']['WIDTH'];
        $height = $arFields['USER_TYPE_SETTINGS']['HEIGHT'];

        $width = intval($width) > 0 ? $width : self::WIDTH;
        $height = intval($height) > 0 ? $height : self::HEIGHT;

        return [
            'WIDTH' => $width,
            'HEIGHT' => $height
        ];
    }

    public static function GetSettingsHTML($arProperty, $strHTMLControlName, &$arPropertyFields)
    {
        $arPropertyFields = [
            'HIDE' => ['ROW_COUNT', 'COL_COUNT'],
            'USER_TYPE_SETTINGS_TITLE' => GetMessage('SP4I_IMAGE_PARAMETERS')
        ];

        $width = (isset($arProperty['USER_TYPE_SETTINGS']['WIDTH']) && $arProperty['USER_TYPE_SETTINGS']['WIDTH'] > 0)
            ? $arProperty['USER_TYPE_SETTINGS']['WIDTH']
            : self::WIDTH;

        $height = (isset($arProperty['USER_TYPE_SETTINGS']['HEIGHT']) && $arProperty['USER_TYPE_SETTINGS']['HEIGHT'] > 0)
            ? $arProperty['USER_TYPE_SETTINGS']['HEIGHT']
            : self::HEIGHT;

        $return = '
            <tr>
            <td>' . GetMessage('SP4I_IMAGE_WIDTH') . ':</td>
            <td><input type="text" name="' . $strHTMLControlName["NAME"] . '[WIDTH]" value="'.$width.'"></td>
            </tr>
            <tr>
            <td>' . GetMessage('SP4I_IMAGE_HEIGHT') . ':</td>
            <td><input type="text" name="' . $strHTMLControlName["NAME"] . '[HEIGHT]" value="'.$height.'"></td>
            </tr>';

        return $return;
    }

    public static function GetPublicViewHTML($arProperty, $arValue, $strHTMLControlName)
    {
        if (Loader::includeModule('lists')) {
            return self::renderFieldByTypeF($arProperty, $arValue);
        } else {
            return self::renderLinks($arValue);
        }
    }

    public static function GetPublicViewHTMLMulty($arProperty, $arValue, $strHTMLControlName)
    {
        if (Loader::includeModule('lists')) {
            return self::renderFieldByTypeF($arProperty, $arValue);
        } else {
            return self::renderLinks($arValue);
        }
    }

    public static function GetPublicEditHTML($arProperty, $arValue, $strHTMLControlName)
    {
        return self::renderFieldByTypeF($arProperty);
    }

    public static function GetPublicEditHTMLMulty($field, $arValue, $strHTMLControlName)
    {
        $html = '';
        if(!is_array($field['VALUE']))
            $field['VALUE'] = array($field['VALUE']);

        $isEmptyValue = true;
        foreach($field['VALUE'] as $value)
        {
            if(!empty($value['VALUE']))
                $isEmptyValue = false;
        }

        if ($field['MULTIPLE'] == 'Y')
        {
            $html .= '<table id="tbl'.$field['FIELD_ID'].'">';
            if($field['ELEMENT_ID'] > 0 && $isEmptyValue && $field['READ'] == 'Y')
            {
                $html .= '<tr><td>';
                $html .= GetMessage('SP4I_IMAGE_NOT_DATA');
                $html .= '</td></tr>';
            }
            else
            {
                $iblockId = !empty($field['IBLOCK_ID']) ? intval($field['IBLOCK_ID']) : 0;
                $sectionId = !empty($field['SECTION_ID']) ? intval($field['SECTION_ID']) : 0;
                $elementId = !empty($field['ELEMENT_ID']) ? intval($field['ELEMENT_ID']) : 0;
                $fieldId = !empty($field['FIELD_ID']) ? $field['FIELD_ID'] : '';
                $socnetGroupId = !empty($field['SOCNET_GROUP_ID']) ? intval($field['SOCNET_GROUP_ID']) : 0;
                $urlTemplate = !empty($field['LIST_FILE_URL']) ? $field['LIST_FILE_URL'] : '';
                $downloadUrl = !empty($field['DOWNLOAD_FILE_URL']) ? $field['DOWNLOAD_FILE_URL'] : '';
                $params = array(
                    'max_size' => 2024000,
                    'max_width' => 100,
                    'max_height' => 100,
                    'url_template' => $urlTemplate,
                    'download_url' => $downloadUrl,
                    'download_text' => GetMessage('SP4I_IMAGE_DOWNLOAD'),
                    'show_input' => $field['READ'] == 'N'
                );
                foreach($field['VALUE'] as $key => $value)
                {
                    $html .= '<tr><td>';
                    $file = new \CListFile($iblockId, $sectionId, $elementId, $fieldId,
                        is_array($value) && isset($value['VALUE']) ? $value['VALUE'] : $value);
                    $file->setSocnetGroup($socnetGroupId);
                    $fieldControlId = $fieldId.'['.$key.'][VALUE]';
                    $fileControl = new \CListFileControl($file, $fieldControlId);
                    $html .= $fileControl->getHTML($params);
                    $html .= '</td></tr>';
                }
            }
            $html .= '</table>';
            if($field['READ'] == 'N')
            {
                $html .= '<input type="button" value="'.GetMessage("SP4I_IMAGE_ADD_BUTTON").'"
                    onclick="BX.Lists.addNewTableRow(\'tbl'.$field['FIELD_ID'].'\', 1, /'.
                    $field['FIELD_ID'].'\[(n)([0-9]*)\]/g, 2)">';
            }
        }

        return $html;
    }

    /**
     * field output for view and edit in frontend
     */
    private static function renderFieldByTypeF($field, $arValue = [])
    {
        if ($arValue && is_numeric($arValue['VALUE']) && is_array($field['VALUE'])) {
            $field['VALUE'] = $arValue['VALUE'];
        }

        if ((empty($field['VALUE']) || !empty($field['DEFAULT']))) return '';

        $iblockId = !empty($field['IBLOCK_ID']) ? intval($field['IBLOCK_ID']) : 0;
        $sectionId = !empty($field['SECTION_ID']) ? intval($field['SECTION_ID']) : 0;
        $elementId = !empty($field['ELEMENT_ID']) ? intval($field['ELEMENT_ID']) : 0;
        $fieldId = !empty($field['FIELD_ID']) ? $field['FIELD_ID'] : '';
        $socnetGroupId = !empty($field['SOCNET_GROUP_ID']) ? intval($field['SOCNET_GROUP_ID']) : 0;
        $urlTemplate = !empty($field['LIST_FILE_URL']) ? $field['LIST_FILE_URL'] : '';
        $downloadUrl = !empty($field['DOWNLOAD_FILE_URL']) ? $field['DOWNLOAD_FILE_URL'] : '';

        $params = array(
            'max_size' => 2024000,
            'max_width' => 100,
            'max_height' => 100,
            'url_template' => $urlTemplate,
            'download_url' => $downloadUrl,
            'download_text' => GetMessage('SP4I_IMAGE_DOWNLOAD'),
            'show_input' => false
        );

        if (!empty($field['READ']) && $field['READ'] == 'N')
            $params['show_input'] = true;

        if($field['MULTIPLE'] == 'Y' && is_array($field['VALUE']))
        {
            $results = array();
            foreach($field['VALUE'] as $key => $value)
            {
                $file = new \CListFile($iblockId, $sectionId, $elementId, $fieldId,
                    is_array($value) && isset($value['VALUE']) ? $value['VALUE'] : $value);
                $file->setSocnetGroup($socnetGroupId);
                $fieldControlId = $fieldId.'['.$key.'][VALUE]';
                $fileControl = new \CListFileControl($file, $fieldControlId);
                $results[] = $fileControl->getHTML($params);
            }
            $result = implode('<br>', $results);
        }
        else
        {
            if (is_array($field['VALUE']))
            {
                $results = array();
                foreach($field['VALUE'] as $key => $value)
                {
                    $file = new \CListFile($iblockId, $sectionId, $elementId, $fieldId,
                        is_array($value) && isset($value['VALUE']) ? $value['VALUE'] : $value);
                    $file->setSocnetGroup($socnetGroupId);
                    $fieldControlId = $fieldId.'['.$key.'][VALUE]';
                    $fileControl = new \CListFileControl($file, $fieldControlId);
                    $results[] = $fileControl->getHTML($params);
                }
                $result = implode('<br>', $results);
            }
            else
            {
                $file = new \CListFile($iblockId, $sectionId, $elementId, $fieldId, $field['VALUE']);
                $file->setSocnetGroup($socnetGroupId);
                $fileControl = new \CListFileControl($file, $fieldId);
                $result = $fileControl->getHTML($params);
            }
        }

        return $result;
    }


    private static function renderLinks($arValue)
    {
        $result = '';

        if (is_array($arValue['VALUE'])) {
            $results = [];
            foreach ($arValue['VALUE'] as $value) {
                $path = CFile::GetPath($value);
                $results[] = '<a href="'.$path.'">'.GetMessage('SP4I_IMAGE_DOWNLOAD').'</a>';
            }

            $result = implode(' / ', $results);
        } else {
            $path = CFile::GetPath($arValue['VALUE']);
            $result = '<a href="'.$path.'">'.GetMessage('SP4I_IMAGE_DOWNLOAD').'</a>';
        }

        return $result;
    }


    /**
     * return file property ID
     */
    private static function getElementPropertyValueId($propertyId, $elementId, $iblockId)
    {
        $arProperty = CIBlockElement::GetPropertyValues($iblockId, ['ID' => $elementId], true, ['ID' => $propertyId])->Fetch();

        if ($arProperty) {
            return $arProperty['PROPERTY_VALUE_ID'][$propertyId];
        }

        return 0;
    }


    /**
     * image optimize
     *
     * @param array $arFile - file info
     * @param array $arParams - image size
     * @return void
     */
    private static function optimizeImage(array $arFile, array $arParams)
    {
        $siteRoot = Application::getDocumentRoot();

        $imageSrc = $siteRoot.'/upload/'.$arFile['SUBDIR'].'/'.$arFile['FILE_NAME'];
        $imageDst = CTempFile::GetFileName('image');

        $bRes = CFile::ResizeImageFile($imageSrc, $imageDst, ['width' => $arParams['WIDTH'], 'height' => $arParams['HEIGHT']], BX_RESIZE_IMAGE_PROPORTIONAL_ALT);

        if ($bRes) {
            // image params
            $imageInfo = (new Image($imageDst))->getInfo();
            // work with image file
            $imageFile = new IO\File($imageDst);

            // renew image file info at b_file
            $GLOBALS['DB']->Query("UPDATE b_file SET FILE_SIZE='".round(floatval($imageFile->getSize()))."', HEIGHT='".round(floatval($imageInfo->getHeight()))."', WIDTH='".round(floatval($imageInfo->getWidth()))."' WHERE ID=".intval($arFile['ID']));

            // replace file with small copy
            unlink($imageSrc);
            rename($imageDst, $imageSrc);

            // clean file cache
            self::cleanFileCache($arFile['ID']);
        }
    }

    /**
     * Clean file cache
     *
     * @param integer $fileID - file ID
     * @return void
     */
    private static function cleanFileCache(int $fileID)
    {
        $cache = Application::getInstance()->getManagedCache();

        // cache ID
        $bucket_size = intval(CACHED_b_file_bucket_size);
        if ($bucket_size <= 0) {
            $bucket_size = 10;
        }
        $bucket = intval($fileID/$bucket_size);
        $cache_id = 'b_file'.intval(CMain::IsHTTPS()).$bucket;

        // clean cache
        $cache->clean($cache_id, 'b_file');
    }

    private static function getImageParams(array $arProperty)
    {
        if (is_array($arProperty['USER_TYPE_SETTINGS'])) {
            $arParams = $arProperty['USER_TYPE_SETTINGS'];
        } else if (is_string($arProperty['USER_TYPE_SETTINGS'])) {
            $arParams = unserialize($arProperty['USER_TYPE_SETTINGS']);
        }

        $arParams['WIDTH'] = (isset($arParams['WIDTH']) && intval($arParams['WIDTH']) > 0)
            ? $arParams['WIDTH']
            : self::WIDTH;

        $arParams['HEIGHT'] = (isset($arParams['HEIGHT']) && intval($arParams['HEIGHT']) > 0)
            ? $arParams['HEIGHT']
            : self::HEIGHT;

        return $arParams;
    }
}
