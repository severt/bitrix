<?php
IncludeModuleLangFile(__FILE__);

use Bitrix\Iblock;
use Bitrix\Main\Application;
use Bitrix\Main\IO;
use Bitrix\Main\File\Image;
use Bitrix\Main\Loader;

class CCustomTypeSimaiTags
{
    public static function GetUserTypeDescription()
    {
        return array(
            'PROPERTY_TYPE' => 'S',
            'USER_TYPE' => 'simai_tags',
            'DESCRIPTION' => GetMessage('SMPI_TAGS_PROP'),
            'PrepareSettings' => array('CCustomTypeSimaiTags', 'PrepareSettings'),
            'GetSettingsHTML' => array('CCustomTypeSimaiTags', 'GetSettingsHTML'),
            'GetPropertyFieldHtml' => array('CCustomTypeSimaiTags', 'GetPropertyFieldHtml'),
            'GetPropertyFieldHtmlMulty' => array('CCustomTypeSimaiTags', 'GetPropertyFieldHtmlMulty'),
            //'ConvertToDB' => array('CCustomTypeSimaiTags', 'ConvertToDB'),
            //'ConvertFromDB' => array('CCustomTypeSimaiTags', 'ConvertFromDB'),
            'GetSearchContent' => array('CCustomTypeSimaiTags', 'GetSearchContent'),
            'GetAdminListViewHTML' => array('CCustomTypeSimaiTags', 'GetAdminListViewHTML'),
            'GetPublicEditHTML' => array('CCustomTypeSimaiTags', 'GetPublicEditHTML'),
            'GetPublicViewHTML' => array('CCustomTypeSimaiTags', 'GetPublicViewHTML'),
        );
    }

    public static function PrepareSettings($arFields)
    {
        return array();
    }

    public static function GetSettingsHTML($arProperty, $strHTMLControlName, &$arPropertyFields)
    {
        $arPropertyFields = array(
            "HIDE" => array("DEFAULT_VALUE", "DISPLAY_TYPE", "EXPANDED", "PROPERTY_FILTER_HINT"),
            "SET" => array("FILTRABLE" => "Y", "SEARCHABLE" => "Y", "SMART_FILTER" => "N"),
        );

        $return = '';
        return $return;
    }

    public static function GetPropertyFieldHtml($arProperty, $arValue, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION;
        $strResult = '';

        ob_start();

        $APPLICATION->IncludeComponent("bitrix:search.tags.input", ".default", array(
            "NAME" => $strHTMLControlName["VALUE"],
            "VALUE" => htmlspecialchars($arValue["VALUE"]),
            "SITE_ID" => SITE_ID,
            "arrFILTER" => "no",
            "PAGE_ELEMENTS" => "10",
            "SORT_BY_CNT" => "Y",
            "TEXT" => "",
            "TMPL_IFRAME" => "Y"
        ),
            false
        );

        $strResult = ob_get_contents();
        ob_end_clean();

        return $strResult;
    }

    public static function GetPropertyFieldHtmlMulty($arProperty, $arValues, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION;

        $strResult = '';

        foreach ($arValues as $key => $val) {
            ob_start();

            echo '<div>';
            $APPLICATION->IncludeComponent("bitrix:search.tags.input", ".default", array(
                "NAME" => $strHTMLControlName["VALUE"] . '[' . $key . ']',
                "VALUE" => htmlspecialchars($val["VALUE"]),
                "SITE_ID" => SITE_ID,
                "arrFILTER" => "no",
                "PAGE_ELEMENTS" => "10",
                "SORT_BY_CNT" => "Y",
                "TEXT" => "",
                "TMPL_IFRAME" => "Y"
            ),
                false
            );
            echo '</div>';

            $strResult .= ob_get_contents();
            ob_end_clean();
        }
        if (!$bVarsFromForm && (int)$arProperty['MULTIPLE_CNT'] > 0) {
            for ($i = 0; $i < $arProperty['MULTIPLE_CNT']; $i++) {
                ob_start();

                echo '<div>';
                $APPLICATION->IncludeComponent("bitrix:search.tags.input", ".default", array(
                    "NAME" => $strHTMLControlName["VALUE"] . '[n' . $i . ']',
                    "VALUE" => "",
                    "SITE_ID" => SITE_ID,
                    "arrFILTER" => "no",
                    "PAGE_ELEMENTS" => "10",
                    "SORT_BY_CNT" => "Y",
                    "TEXT" => "",
                    "TMPL_IFRAME" => "Y"
                ),
                    false
                );
                echo '</div>';

                $strResult .= ob_get_contents();
                ob_end_clean();
            }
        }

        return $strResult;
    }

    public static function GetPublicEditHTML($arProperty, $arValue, $strHTMLControlName)
    {
        global $bVarsFromForm, $bCopy, $PROP, $APPLICATION;
        $strResult = '';

        ob_start();

        echo '<div>';
        $APPLICATION->IncludeComponent("bitrix:search.tags.input", ".default", array(
            "NAME" => $strHTMLControlName["VALUE"],
            "VALUE" => htmlspecialchars($arValue["VALUE"]),
            "SITE_ID" => SITE_ID,
            "arrFILTER" => "no",
            "PAGE_ELEMENTS" => "10",
            "SORT_BY_CNT" => "Y",
            "TEXT" => "",
            "TMPL_IFRAME" => "Y"
        ),
            false
        );
        echo '</div>';

        $strResult .= ob_get_contents();
        ob_end_clean();

        return $strResult;
    }

    public static function GetPublicViewHTML($arProperty, $arValue, $strHTMLControlName)
    {
        $strResult = $arValue['VALUE'];

        $search_page_url = COption::GetOptionString("simai.property4iblock", "search_page_url", "");
        $search_page_url = htmlspecialcharsbx($search_page_url);
        $search_page_url = str_replace('#SITE_DIR#', SITE_DIR, $search_page_url);

        if ($search_page_url) {
            $tags = explode(',', $arValue['VALUE']);
            $tags_print = array();
            foreach ($tags as $tag) {
                if (trim($tag)) {
                    $tag_page_url = str_replace('#TAG#', urlencode(htmlspecialcharsbx(trim($tag))), $search_page_url);

                    $tags_print[] = '<a href="' . $tag_page_url . '">' . htmlspecialcharsbx(trim($tag)) . '</a>';
                }
            }
            $strResult = implode(', ', $tags_print);
        }

        return $strResult;
    }

    public static function GetAdminListViewHTML($arProperty, $arValue, $strHTMLControlName)
    {
        $strResult = $arValue['VALUE'];
        return $strResult;
    }

    public static function GetSearchContent($arProperty, $value, $strHTMLControlName)
    {
        return $value['VALUE'];

        return '';
    }
}
