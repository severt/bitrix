<?php

IncludeModuleLangFile(__FILE__);

use Bitrix\Iblock;
use Bitrix\Main\Application;
use Bitrix\Main\IO;
use Bitrix\Main\File\Image;
use Bitrix\Main\Loader;

class CCustomTypeSimaiUser
{
    public static function GetUserTypeDescription()
    {
        return array(
            'PROPERTY_TYPE' => 'N',
            'USER_TYPE' => 'simai_user',
            'DESCRIPTION' => GetMessage('SMPI_USER_PROP'),
            'PrepareSettings' => array('CCustomTypeSimaiUser', 'PrepareSettings'),
            'GetSettingsHTML' => array('CCustomTypeSimaiUser', 'GetSettingsHTML'),
            'GetPropertyFieldHtml' => array('CCustomTypeSimaiUser', 'GetPropertyFieldHtml'),
            'GetPropertyFieldHtmlMulty' => array('CCustomTypeSimaiUser', 'GetPropertyFieldHtmlMulty'),
            'GetPublicEditHTML' => array('CCustomTypeSimaiUser', 'GetPublicEditHTML'),
            'ConvertToDB' => array('CCustomTypeSimaiUser', 'ConvertToDB'),
            'ConvertFromDB' => array('CCustomTypeSimaiUser', 'ConvertFromDB'),
            'GetPublicViewHTML' => array('CCustomTypeSimaiUser', 'GetPublicViewHTML'),
            'GetSearchContent' => array('CCustomTypeSimaiUser', 'GetSearchContent'),
            'GetAdminFilterHTML' => array('CCustomTypeSimaiUser', 'GetAdminFilterHTML'),
            'GetAdminListViewHTML' => array('CCustomTypeSimaiUser', 'GetAdminListViewHTML'),
        );
    }

    public static function PrepareSettings($arFields)
    {
        //return array("TASK_URL_TEMPLATE" => trim($arFields["USER_TYPE_SETTINGS"]["TASK_URL_TEMPLATE"]));
        return array();
    }

    public static function GetSettingsHTML($arProperty, $strHTMLControlName, &$arPropertyFields)
    {
        $arPropertyFields = array(
            "HIDE" => array("ROW_COUNT", "COL_COUNT", "DEFAULT_VALUE", "WITH_DESCRIPTION", "SEARCHABLE", "SMART_FILTER", "DISPLAY_TYPE", "EXPANDED"),
            "SET" => array("FILTRABLE" => "Y", "SEARCHABLE" => "Y", "SMART_FILTER" => "N", "MULTIPLE_CNT" => "1"),
            //"USER_TYPE_SETTINGS_TITLE" => GetMessage('SMPI_SELECT_SUBPROPS')
        );

        $return = "";

        /*$return .= '
        <tr>
        <td>'.GetMessage('SMPI_TASK_URL_TEMPLATE').':</td>
        <td>
        <input type="text" name="'.$strHTMLControlName["NAME"].'[TASK_URL_TEMPLATE]" style="width:270px;" value="'.$arProperty["USER_TYPE_SETTINGS"]["TASK_URL_TEMPLATE"].'">
        <br /><small>'.GetMessage('SMPI_TASK_URL_TEMPLATE_HINT').'<small>
        </td>
        </tr>';*/

        return $return;
    }

    public static function GetPropertyFieldHtml($arProperty, $value, $strHTMLControlName)
    {

        $arUser = array();
        if (trim($strHTMLControlName['VALUE']))
        {
            $arFilter = Array('ACTIVE'=>'Y', 'ID'=>$value['VALUE']);
            $by = 'ID';
            $order = 'asc';
            $arUser = \CUser::GetList($by, $order, $arFilter, array())->GetNext();
            if (!is_array($arUser))
                $arUser = array();
        }

        $input_id = 'user'.rand();
        $strResult = '<input type="text" name="'.$strHTMLControlName['VALUE'].'" id="'.$input_id.'" value="'.$value['VALUE'].'" size="25">'.
            '<input type="button" value="..." onClick="jsUtils.OpenWindow(\'/simai/admin/simai_p4ib_user_search.php?lang='.LANGUAGE_ID.'&amp;INPUT_ID='.urlencode($input_id).'\', 900, 700);">'.
            '&nbsp;<span id="sp_'.$input_id.'" >['.$arUser['LOGIN'].'] '.$arUser['NAME'].' '.$arUser['LAST_NAME'].'</span>';

        return $strResult;
    }

    public static function GetPropertyFieldHtmlMulty($arProperty, $value, $strHTMLControlName)
    {

        global $bVarsFromForm, $APPLICATION;
        
        $APPLICATION->AddHeadScript('/bitrix/js/simai.property4iblock/edit.js');
        
        $strResult = '';

        $inpid = md5('user_'.rand(0,999));
        
        //$arHtmlControl['NAME'] = str_replace('[]', '', $arHtmlControl['NAME']);

        $strResult .= '<table cellpadding="0" cellspacing="0" border="0" class="nopadding" width="100%" id="tb'.$inpid.'">';

        $windowTableId = 'iblockprop-U-'.$arProperty['ID'];

        foreach($value as $intPropertyValueID => $arOneValue) 
        {
            $arOneValue['VALUE'] = intval($arOneValue['VALUE']);
            
            if ($arOneValue['VALUE'] > 0)
            {
                $arFilter = Array('ACTIVE'=>'Y', 'ID'=>$arOneValue['VALUE']);
                $by = 'ID';
                $order = 'asc';
                $arUser = \CUser::GetList($by, $order, $arFilter, array())->GetNext();
                if (!is_array($arUser))
                    $arUser = array();
                
                $input_id = $strHTMLControlName['VALUE'].'['.$intPropertyValueID.']';
                $strResult .= '<tr><td><input type="text" name="'.$strHTMLControlName['VALUE'].'['.$intPropertyValueID.']'.'" id="'.$input_id.'" value="'.$arOneValue['VALUE'].'" size="25">'.
                    '<input type="button" value="..." onClick="jsUtils.OpenWindow(\'/simai/admin/simai_p4ib_user_search.php?lang='.LANGUAGE_ID.'&amp;n='.urlencode($strHTMLControlName['VALUE'].'['.$intPropertyValueID.']').'&amp;tableId='.$windowTableId.'&amp;INPUT_ID='.urlencode($input_id).'\', 900, 700);">'.
                    '&nbsp;<span id="sp_'.$input_id.'" >['.$arUser['LOGIN'].'] '.$arUser['NAME'].' '.$arUser['LAST_NAME'].'</span></td></tr>';
            }
        }

        $arUserField['MULTIPLE_CNT'] = 1;
        
        if (!$bVarsFromForm && (int)$arUserField['MULTIPLE_CNT'] > 0)
        {
            for ($i = 0; $i < $arUserField['MULTIPLE_CNT']; $i++)
            {
                $input_id = $strHTMLControlName['VALUE'].'[n'.$i.']';
                $strResult .= '<tr><td><input type="text" name="'.$strHTMLControlName['VALUE'].'[n'.$i.']'.'" id="'.$input_id.'" value="" size="25">'.
                    '<input type="button" value="..." onClick="jsUtils.OpenWindow(\'/simai/admin/simai_p4ib_user_search.php?lang='.LANGUAGE_ID.'&amp;n='.urlencode($arHtmlControl['NAME'].'[n'.$i.']').'&amp;tableId='.$windowTableId.'&amp;INPUT_ID='.urlencode($input_id).'\', 900, 700);">'.
                    '&nbsp;<span id="sp_'.$input_id.'" ></span></td></tr>';
            }
        }

        $strResult .= '<tr><td><input type="button" value="'.GetMessage("SMPI_USER_ADD_BUTTON").'" onClick="addNewRowSFPIB(\'tb'.$inpid.'\')"></td></tr>';
        $strResult .= "<script type=\"text/javascript\">BX.addCustomEvent('onAutoSaveRestore', function(ob, data) {for (var i in data){if (i.substring(0,".(strlen($strHTMLControlName['VALUE'])+1).")=='".\CUtil::JSEscape($strHTMLControlName['VALUE'])."['){addNewRowSFPIB('tb".$inpid."')}}})</script>";

        $strResult .= "</table>";

        return $strResult;


    }

    public static function GetPublicEditHTML($arProperty, $value, $strHTMLControlName)
    {

        global $bVarsFromForm, $APPLICATION;
        
        $APPLICATION->AddHeadScript('/bitrix/js/simai.property4iblock/edit.js');
        
        $strResult = '';

        $inpid = md5('user_'.rand(0,999));
        
        //$arHtmlControl['NAME'] = str_replace('[]', '', $arHtmlControl['NAME']);
        //$arProperty, $value, $strHTMLControlName
        //var_dump($value);

        $strResult .= '<table cellpadding="0" cellspacing="0" border="0" class="nopadding" width="100%" id="tb'.$inpid.'">';

        $windowTableId = 'iblockprop-U-'.$arProperty['ID'];

        //foreach($value as $intPropertyValueID => $arOneValue) 
        //{

            $arOneValue['VALUE'] = $value['VALUE'];
            $arOneValue['VALUE'] = intval($arOneValue['VALUE']);
            
        // if ($arOneValue['VALUE'] > 0)
        //{
                $arFilter = Array('ACTIVE'=>'Y', 'ID'=>$arOneValue['VALUE']);
                $by = 'ID';
                $order = 'asc';
                $arUser = \CUser::GetList($by, $order, $arFilter, array())->GetNext();
                if (!is_array($arUser))
                    $arUser = array();
                
                $input_id = $strHTMLControlName['VALUE'].'['.$inpid.']';
                $strResult .= '<tr><td><input type="text" name="'.$strHTMLControlName['VALUE'].'" id="'.$input_id.'" value="'.$arOneValue['VALUE'].'" size="25">'.
                    '<input type="button" value="..." onClick="jsUtils.OpenWindow(\'/simai/admin/simai_p4ib_user_search.php?lang='.LANGUAGE_ID.'&amp;n='.urlencode($strHTMLControlName['VALUE'].'['.$intPropertyValueID.']').'&amp;tableId='.$windowTableId.'&amp;INPUT_ID='.urlencode($input_id).'\', 900, 700);">'.
                    '&nbsp;<span id="sp_'.$input_id.'" >['.$arUser['LOGIN'].'] '.$arUser['NAME'].' '.$arUser['LAST_NAME'].'</span></td></tr>';
                //}
            //}


        $strResult .= "</table>";

        return $strResult;


    }


    public static function ConvertToDB($arProperty, $value)
    {
        return $value;
    }

    public static function ConvertFromDB($arProperty, $value)
    {
        return $value;
    }

    public static function GetPublicViewHTML($arProperty, $value, $strHTMLControlName)
    {
        if ($value["VALUE"] > 0):

            $rsUser = CUser::GetByID($value['VALUE']);
            if ($arUser = $rsUser->GetNext()):
                return '[' . $arUser["ID"] . ']&nbsp;<span >' . $arUser["LOGIN"] . '</span>';
            endif;
        endif;

        return '';
    }

    public static function GetSearchContent($arProperty, $value, $strHTMLControlName)
    {
        if ($value['VALUE'] > 0) {
            $rsUser = CUser::GetByID($value['VALUE']);
            if ($arUser = $rsUser->GetNext()) {
                return $arUser["ID"] . ' ' . $arUser["LOGIN"];
            }
        }

        return '';
    }

    public static function GetAdminFilterHTML($arProperty, $strHTMLControlName)
    {

        global $bVarsFromForm, $APPLICATION;
        
        $APPLICATION->AddHeadScript('/bitrix/js/simai.property4iblock/edit.js');
        
        $strResult = '';

        $inpid = md5('user_'.rand(0,999));


        $strResult .= '<table cellpadding="0" cellspacing="0" border="0" class="nopadding" width="100%" id="tb'.$inpid.'">';

        $windowTableId = 'iblockprop-U-'.$arProperty['ID'];

        //foreach($value as $intPropertyValueID => $arOneValue) 
        //{

            $arOneValue['VALUE'] = $value['VALUE'];
            $arOneValue['VALUE'] = intval($arOneValue['VALUE']);
            
        // if ($arOneValue['VALUE'] > 0)
        //{
                $arFilter = Array('ACTIVE'=>'Y', 'ID'=>$arOneValue['VALUE']);
                $by = 'ID';
                $order = 'asc';
                $arUser = \CUser::GetList($by, $order, $arFilter, array())->GetNext();
                if (!is_array($arUser))
                    $arUser = array();
                
                $input_id = $strHTMLControlName['VALUE'].'['.$inpid.']';
                $strResult .= '<tr><td><input type="text" name="'.$strHTMLControlName['VALUE'].'" id="'.$input_id.'" value="'.$arOneValue['VALUE'].'" size="25">'.
                    '<input type="button" value="..." onClick="jsUtils.OpenWindow(\'/simai/admin/simai_p4ib_user_search.php?lang='.LANGUAGE_ID.'&amp;n='.urlencode($strHTMLControlName['VALUE'].'['.$intPropertyValueID.']').'&amp;tableId='.$windowTableId.'&amp;INPUT_ID='.urlencode($input_id).'\', 900, 700);">'.
                    '&nbsp;<span id="sp_'.$input_id.'" >['.$arUser['LOGIN'].'] '.$arUser['NAME'].' '.$arUser['LAST_NAME'].'</span></td></tr>';
                //}
            //}

        $strResult .= "</table>";

        return $strResult;
    }

    public static function GetAdminListViewHTML($arProperty, $value, $strHTMLControlName)
    {
        if ($value["VALUE"] > 0):
            $rsUser = CUser::GetByID($value['VALUE']);
            if ($arUser = $rsUser->GetNext()):
                return '[' . $arUser["ID"] . ']&nbsp;<span>' . $arUser["LOGIN"] . '</span>';
            endif;
        endif;

        return '';
    }

    public static function GetPublicFilterHTML($arProperty, $strHTMLControlName)
    {
        global $APPLICATION;

        ob_start();
        ?>
        <div class="spi4ib spi4ib_a" style="padding-left:20px;">
        <span>

        <?
        $value = $GLOBALS[$strHTMLControlName["VALUE"]];
        if ($value > 0):
            $rsUser = CUser::GetByID($value);
            if ($arUser = $rsUser->GetNext()):?>
                <input type="text" id="selectedUserInput" value="<?=$arUser['ID']?>" name=<?=htmlspecialchars($strHTMLControlName["VALUE"])?> 
                    style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
                <a href="#modal_window" onclick="choiceProp('choiceUser', 'modal_window_user');">Выбрать</a>
                <span id="selectedUser"><i>[<?=$arUser['ID']?>] </i><?=$arUser['LOGIN']?></span>
            <?endif;
        else :?>
            <input type="text" id="selectedUserInput" value="" name=<?=htmlspecialchars($strHTMLControlName["VALUE"])?> 
                style="width:35px;font-size:14px;border:1px #c8c8c8 solid;height:var(--ui-field-size);border-radius: var(--ui-field-border-radius,2px);text-align: center;">
            <a href="#modal_window" onclick="choiceProp('choiceUser', 'modal_window_user');">Выбрать</a>
            <span id="selectedUser"></span>
        <?endif; ?>
        </span>

            <?
            $by = "id";
            $order = "asc";
            $arFilter = array();
            $rs = CUser::GetList($by, $order, $arFilter); 
            $users = [];
            while($ar = $rs->GetNext())
            {
                $users[] = ['str' => '[' . $ar['ID'] . '] ' . $ar['LOGIN'] . '<br>', 'id' => $ar['ID']];

            }
            CJSCore::Init(array("jquery"));
            ?>

            <div id="modal_window_user" style="display:none">
                <input class="type-search  finder-box-search-textbox" placeholder="Поиск" type="text" id="searchInputUser" value="" style="width:400px;"/><br>
                <span id="listUser">
                <?foreach ($users as $user) :?>
                    <span>
                        <i style="cursor: pointer;" onclick="
                            setProp('<?=$user['id']?>', '<?=$user['str']?>', 'selectedUser', 'selectedUserInput');
                            "><?=$user['str']?></i>
                    </span>
                <?endforeach;?>
                </span>
            </div>
        </div>
        <?require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.property4iblock/admin/simai_p4ib_script.php");?>
        <script>
            search('#listUser', '#searchInputUser');
        </script>
        <?
        $strResult = ob_get_contents();
        ob_end_clean();

        return $strResult;
    }
}