<?php

\CModule::AddAutoloadClasses(
        "simai.property4iblock",
        array(
            '\CCustomTypeSimaiTicket' => 'lib/ticket.php',
            '\CCustomTypeSimaiUser' => 'lib/user.php',
            '\CCustomTypeSimaiTask' => 'lib/task.php',
            '\CCustomTypeSimaiIBElement' => 'lib/ib_element.php',
            '\CCustomTypeSimaiIBSection' => 'lib/ib_section.php',
            '\CCustomTypeSimaiLink' => 'lib/link.php',
            '\CCustomTypeSimaiTags' => 'lib/tags.php',
            '\CCustomTypeSimaiStadia' => 'lib/stadia.php',
            '\CCustomTypeSimaiIndicator' => 'lib/indicator.php',
            '\CCustomTypeSimaiPassword' => 'lib/password.php',
            '\CCustomTypeSimaiImage' => 'lib/image.php',
            '\TypeSimaiP4IB' => 'lib/p4_ib.php',
        )
    );