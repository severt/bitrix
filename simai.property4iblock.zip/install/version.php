<?php
$arModuleVersion = array(
    "VERSION" => "2.6.2",
    "VERSION_DATE" => "2024-03-17 02:00:00",
);
?>