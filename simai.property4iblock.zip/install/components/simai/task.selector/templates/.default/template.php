<?
if(!Defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

if (!is_array($arParams['VALUE'])):
	$arParams['VALUE'] = array($arParams['VALUE']);
endif;

$APPLICATION->AddHeadScript($templateFolder.'/tasks.js');
?>

<div class="spi4ib">

<input id="property_id_<?=$arResult["NAME"]?>" type="hidden" value="<?=$arParams['PROPERTY_ID']?>">

<div id="prop_<?=$arResult["NAME"]?>">
<?if ($arParams["MULTIPLE"] != "Y"):
	$vid = 'n0';
	$val = '';
	foreach ($arParams['VALUE'] as $v_val):
		if ($v_val > 0):
			$val = intval($v_val);
			break;
		endif;
	endforeach;
?>
	<div id="<?=$arResult["NAME"]?>_task_val_input"><input id="<?=$arResult["NAME"]?>_task_val_input_val" name="PROP[<?=$arParams['PROPERTY_ID']?>][<?=$vid?>]" value="<?=$val?>" type="hidden"></div>
<?else:?>
	<?
	$i = 0;
	$rev_vals = array_flip($arParams['VALUE']);	
	foreach($arResult["CURRENT_TASKS"] as $task):
		$vid = 'n'.$i;
		if (isset($rev_vals[$task["ID"]]) && $task["ID"] > 0):
			$vid = preg_replace("/[^a-zA-Z0-9\:]/", "", $rev_vals[$task["ID"]]);
		endif;?>
		<div id="<?=$arResult["NAME"]?>_task_val_input_<?=$task["ID"]?>"><input name="PROP[<?=$arParams['PROPERTY_ID']?>][<?=$vid?>]" value="<?=$task["ID"]?>" type="hidden"></div>
		<?$i++;
	endforeach?>
<?endif?>
</div>

<script type="text/javascript">
	TasksTask.ajaxUrl = '<?=$this->__component->GetPath()."/ajax.php?lang=".LANGUAGE_ID."&SITE_ID=".$arParams["SITE_ID"]?>';
	TasksTask.lastTasks = <?=CUtil::PhpToJSObject($arResult["LAST_TASKS_IDS"])?>;
	TasksTask.filter = <?=CUtil::PhpToJSObject($arParams["FILTER"])?>

	var O_<?=$arResult["NAME"]?> = new TasksTask("<?=$arResult["NAME"]?>", <?=$arParams["MULTIPLE"] == "Y" ? "true" : "false"?>);

	O_<?=$arResult["NAME"]?>.filter = <?=CUtil::PhpToJSObject($arParams["FILTER"])?>;

	<?foreach($arResult["CURRENT_TASKS"] as $task):?>
		O_<?=$arResult["NAME"]?>.arSelected[<?=$task["ID"]?>] = {id : <?=CUtil::JSEscape($task["ID"])?>, name : "<?=CUtil::JSEscape($task["TITLE"])?>", status : <?=$task["STATUS"]?>};
		TasksTask.arTasksData[<?=$task["ID"]?>] = {id : <?=CUtil::JSEscape($task["ID"])?>, name : "<?=CUtil::JSEscape($task["TITLE"])?>", status : <?=$task["STATUS"]?>};
	<?endforeach?>

	<?foreach($arResult["LAST_TASKS"] as $task):?>
		TasksTask.arTasksData[<?=$task["ID"]?>] = {id : <?=CUtil::JSEscape($task["ID"])?>, name : "<?=CUtil::JSEscape($task["TITLE"])?>", status : <?=$task["STATUS"]?>};
	<?endforeach?>

	<?if((string) $arParams['PATH_TO_TASKS_TASK'] != ''):?>
		BX.message({TASKS_PATH_TO_TASK: "<?=CUtil::JSEscape($arParams['PATH_TO_TASKS_TASK'])?>"});
	<?endif?>

	BX.ready(function() {
		<?if (strlen($arParams["FORM_NAME"]) > 0 && strlen($arParams["INPUT_NAME"]) > 0):?>
			O_<?=$arResult["NAME"]?>.searchInput = document.forms["<?=CUtil::JSEscape($arParams["FORM_NAME"])?>"].element["<?=CUtil::JSEscape($arParams["INPUT_NAME"])?>"];
		<?elseif(strlen($arParams["INPUT_NAME"]) > 0):?>
			O_<?=$arResult["NAME"]?>.searchInput = BX("<?=CUtil::JSEscape($arParams["INPUT_NAME"])?>");
		<?else:?>
			O_<?=$arResult["NAME"]?>.searchInput = BX("<?=$arResult["NAME"]?>_task_input");
		<?endif?>

		<?if (strlen($arParams["ON_CHANGE"]) > 0):?>
			O_<?=$arResult["NAME"]?>.onChange = <?=CUtil::JSEscape($arParams["ON_CHANGE"])?>;
		<?endif?>

		<?if (strlen($arParams["ON_SELECT"]) > 0):?>
			O_<?=$arResult["NAME"]?>.onSelect= <?=CUtil::JSEscape($arParams["ON_SELECT"])?>;
		<?endif?>

		BX.bind(O_<?=$arResult["NAME"]?>.searchInput, "keyup", BX.proxy(O_<?=$arResult["NAME"]?>.search, O_<?=$arResult["NAME"]?>));
	});
</script>

<?//if ($arParams["MULTIPLE"] == "Y"):?>
<div <?/*class="finder-box-right-column"*/?> id="<?=$arResult["NAME"]?>_selected_tasks">
	<div class="finder-box-selected-title" style="display:none"><?=GetMessage("TASKS_TASKS_CURRENT_COUNT")?> (<span id="<?=$arResult["NAME"]?>_current_count"><?=sizeof($arResult["CURRENT_TASKS"])?></span>)</div>
	<div class="finder-box-selected-items">
		<?foreach($arResult["CURRENT_TASKS"] as $task):
			?>
			<div class="finder-box-selected-item" id="<?=$arResult["NAME"]?>_task_selected_<?=$task["ID"]?>">
			<div class="finder-box-selected-item-icon" <?if ($arParams['HIDE_ADD_REMOVE_CONTROLS'] === 'Y') echo ' style="display:none;" '; ?> onclick="O_<?=$arResult["NAME"]?>.unselect(<?=$task["ID"]?>, this);" id="task-unselect-<?=$task["ID"]?>"></div><a href="<?=CComponentEngine::MakePathFromTemplate($arParams["PATH_TO_TASKS_TASK"], array("task_id" => $task["ID"], "user_id" => $task["RESPONSIBLE_ID"], "action" => "view"))?>" target="_blank" class="finder-box-selected-item-text"><?=$task["TITLE"]?></a>
			</div>
		<?endforeach?>
	</div>
</div>
<?//endif?>

<div style="position:relative">

<div id="<?=$arResult["NAME"]?>_selector_content" class="finder-box<?if ($arParams["MULTIPLE"] == "Y"):?> finder-box-multiple<?endif?>" style="display:none; position:absolute; z-index:100; bottom:0; left:0;">
	<a class="spi-popup-window-close-icon" href="javascript:void(0)" onclick="HideSTS('<?=$arResult["NAME"]?>_selector_content')"></a>
	
	<table class="finder-box-layout" cellspacing="0">
		<tr>
			<td class="finder-box-left-column">
				<?if (!isset($arParams["INPUT_NAME"]) || strlen($arParams["INPUT_NAME"]) == 0):?>
				<div class="finder-box-search"><input name="<?=$arResult["NAME"]?>_task_input" id="<?=$arResult["NAME"]?>_task_input" class="finder-box-search-textbox" /></div>
				<?endif?>

				<div class="finder-box-tabs">
					<span class="finder-box-tab finder-box-tab-selected" id="<?=$arResult["NAME"]?>_tab_last" onclick="O_<?=$arResult["NAME"]?>.displayTab('last');"><span class="finder-box-tab-left"></span><span class="finder-box-tab-text"><?=GetMessage("TASKS_LAST_SELECTED")?></span><span class="finder-box-tab-right"></span></span><span class="finder-box-tab" id="<?=$arResult["NAME"]?>_tab_search" onclick="O_<?=$arResult["NAME"]?>.displayTab('search');"><span class="finder-box-tab-left"></span><span class="finder-box-tab-text"><?=GetMessage("TASKS_TASK_SEARCH")?></span><span class="finder-box-tab-right"></span></span>
				</div>

				<div class="popup-window-hr popup-window-buttons-hr"><i></i></div>

				<div class="finder-box-tabs-content">
					<div class="finder-box-tab-content finder-box-tab-content-selected" id="<?=$arResult["NAME"]?>_last">
						<table class="finder-box-tab-columns" cellspacing="0">
							<tr>
								<td>
									<?foreach($arResult["LAST_TASKS"] as $key=>$task):?>
										<div class="finder-box-item<?=(in_array($task["ID"], $arParams["VALUE"]) ? " finder-box-item-selected" : "")?>" id="<?=$arResult["NAME"]?>_last_task_<?=$task["ID"]?>" onclick="O_<?=$arResult["NAME"]?>.select(event)">
											<?if ($arParams["MULTIPLE"] == "Y"):?>
												<input type="hidden" name="<?=$arResult["NAME"]?>_m" value="<?=$task["ID"]?>" data-user="<?=$task["RESPONSIBLE_ID"]?>" rel="<?=(in_array($task["ID"], $arParams["VALUE"]) ? "checked" : "")?>" class="tasks-hidden-input" />
											<?else:?>
												<input type="hidden" name="<?=$arResult["NAME"]?>" value="<?=$task["ID"]?>" data-user="<?=$task["RESPONSIBLE_ID"]?>" rel="<?=(in_array($task["ID"], $arParams["VALUE"]) ? "checked" : "")?>" class="tasks-hidden-input" />
											<?endif?>
											<div class="finder-box-item-text"><?=$task["TITLE"]?></div>
											<div class="finder-box-item-icon"
												<?if ($arParams['HIDE_ADD_REMOVE_CONTROLS'] === 'Y') echo ' style="display:none;" '; ?>
												></div>
										</div>
									<?endforeach?>
									<?foreach($arResult["CURRENT_TASKS"] as $key=>$task):?>
										<?if (!in_array($task, $arResult["LAST_TASKS"])):?>
											<?if ($arParams["MULTIPLE"] == "Y"):?>
												<input type="hidden" name="<?=$arResult["NAME"]?>_m2" value="<?=$task["ID"]?>" data-user="<?=$task["RESPONSIBLE_ID"]?>" rel="<?=(in_array($task["ID"], $arParams["VALUE"]) ? "checked" : "")?>" class="tasks-hidden-input" />
											<?else:?>
												<input type="hidden" name="<?=$arResult["NAME"]?>2" value="<?=$task["ID"]?>" data-user="<?=$task["RESPONSIBLE_ID"]?>" rel="<?=(in_array($task["ID"], $arParams["VALUE"]) ? "checked" : "")?>" class="tasks-hidden-input" />
											<?endif?>
										<?endif?>
									<?endforeach?>
								</td>
							</tr>
						</table>
					</div>
					<div class="finder-box-tab-content" id="<?=$arResult["NAME"]?>_search"></div>
				</div>
			</td>
		</tr>
	</table>
</div>

</div>

<a class="spi-task-dashed-link" href="javascript:void()" onclick="ShowHideSTS('<?=$arResult["NAME"]?>_selector_content')"><?=GetMessage("TASKS_SELECTOR_SHOW")?></a>

</div>