<?php
$MESS['TASKS_TASKS_CURRENT_COUNT'] = "Выбранные";
$MESS['TASKS_LAST_SELECTED'] = "Последние";
$MESS['TASKS_TASK_SEARCH'] = "Поиск";
$MESS['TASKS_SELECTOR_SHOW'] = "Выбор задач";
?>