<?
if(!Defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

if (is_array($arParams['VALUE'])):
	$arParams['VALUE'] = current($arParams['VALUE']);
endif;

$APPLICATION->AddHeadScript($templateFolder.'/tasks.js');
?>

<div class="spi4ib">

<input type="hidden" id="v_inp_<?=$arResult["NAME"]?>" name="<?=htmlspecialcharsex($arParams['INP'])?>" value="<?=htmlspecialchars($arParams['VALUE'])?>" />

<script type="text/javascript">
	TasksTask.ajaxUrl = '<?=$this->__component->GetPath()."/ajax.php?lang=".LANGUAGE_ID."&SITE_ID=".$arParams["SITE_ID"]?>';
	TasksTask.lastTasks = <?=CUtil::PhpToJSObject($arResult["LAST_TASKS_IDS"])?>;
	TasksTask.filter = <?=CUtil::PhpToJSObject($arParams["FILTER"])?>

	var O_<?=$arResult["NAME"]?> = new TasksTask("<?=$arResult["NAME"]?>", <?=$arParams["MULTIPLE"] == "Y" ? "true" : "false"?>);

	O_<?=$arResult["NAME"]?>.filter = <?=CUtil::PhpToJSObject($arParams["FILTER"])?>;

	<?foreach($arResult["CURRENT_TASKS"] as $task):?>
		O_<?=$arResult["NAME"]?>.arSelected[<?=$task["ID"]?>] = {id : <?=CUtil::JSEscape($task["ID"])?>, name : "<?=CUtil::JSEscape($task["TITLE"])?>", status : <?=$task["STATUS"]?>};
		TasksTask.arTasksData[<?=$task["ID"]?>] = {id : <?=CUtil::JSEscape($task["ID"])?>, name : "<?=CUtil::JSEscape($task["TITLE"])?>", status : <?=$task["STATUS"]?>};
	<?endforeach?>

	<?foreach($arResult["LAST_TASKS"] as $task):?>
		TasksTask.arTasksData[<?=$task["ID"]?>] = {id : <?=CUtil::JSEscape($task["ID"])?>, name : "<?=CUtil::JSEscape($task["TITLE"])?>", status : <?=$task["STATUS"]?>};
	<?endforeach?>

	<?if((string) $arParams['PATH_TO_TASKS_TASK'] != ''):?>
		BX.message({TASKS_PATH_TO_TASK: "<?=CUtil::JSEscape($arParams['PATH_TO_TASKS_TASK'])?>"});
	<?endif?>

	BX.ready(function() {
		O_<?=$arResult["NAME"]?>.searchInput = BX("<?=$arResult["NAME"]?>_task_input");

		BX.bind(O_<?=$arResult["NAME"]?>.searchInput, "keyup", BX.proxy(O_<?=$arResult["NAME"]?>.search, O_<?=$arResult["NAME"]?>));
	});
</script>

<?//if ($arParams["MULTIPLE"] == "Y"):?>
<div <?/*class="finder-box-right-column"*/?> id="<?=$arResult["NAME"]?>_selected_tasks">
	<div class="finder-box-selected-title" style="display:none"><?=GetMessage("TASKS_TASKS_CURRENT_COUNT")?> (<span id="<?=$arResult["NAME"]?>_current_count"><?=sizeof($arResult["CURRENT_TASKS"])?></span>)</div>
	<div class="finder-box-selected-items">
		<?foreach($arResult["CURRENT_TASKS"] as $task):
			?>
			<div class="finder-box-selected-item" id="<?=$arResult["NAME"]?>_task_selected_<?=$task["ID"]?>">
			<div class="finder-box-selected-item-icon" <?if ($arParams['HIDE_ADD_REMOVE_CONTROLS'] === 'Y') echo ' style="display:none;" '; ?> onclick="O_<?=$arResult["NAME"]?>.unselect(<?=$task["ID"]?>, this);" id="task-unselect-<?=$task["ID"]?>"></div><a href="<?=CComponentEngine::MakePathFromTemplate($arParams["PATH_TO_TASKS_TASK"], array("task_id" => $task["ID"], "user_id" => $task["RESPONSIBLE_ID"], "action" => "view"))?>" target="_blank" class="finder-box-selected-item-text"><?=$task["TITLE"]?></a>
			</div>
		<?endforeach?>
	</div>
</div>
<?//endif?>

<a class="spi-task-dashed-link" href="javascript:void()" onclick="ShowHideSTS('<?=$arResult["NAME"]?>_selector_content')"><?=GetMessage("TASKS_SELECTOR_SHOW")?></a>

<div style="position:relative">

<div id="<?=$arResult["NAME"]?>_selector_content" class="finder-box<?if ($arParams["MULTIPLE"] == "Y"):?> finder-box-multiple<?endif?>" style="display:none; position:absolute; z-index:100; top:0; left:0;">
	<table class="finder-box-layout" cellspacing="0">
		<tr>
			<td class="finder-box-left-column">
				<div class="finder-box-search"><input name="<?=$arResult["NAME"]?>_task_input" id="<?=$arResult["NAME"]?>_task_input" class="finder-box-search-textbox" /></div>

				<div class="finder-box-tabs">
					<span class="finder-box-tab finder-box-tab-selected" id="<?=$arResult["NAME"]?>_tab_last" onclick="O_<?=$arResult["NAME"]?>.displayTab('last');"><span class="finder-box-tab-left"></span><span class="finder-box-tab-text"><?=GetMessage("TASKS_LAST_SELECTED")?></span><span class="finder-box-tab-right"></span></span><span class="finder-box-tab" id="<?=$arResult["NAME"]?>_tab_search" onclick="O_<?=$arResult["NAME"]?>.displayTab('search');"><span class="finder-box-tab-left"></span><span class="finder-box-tab-text"><?=GetMessage("TASKS_TASK_SEARCH")?></span><span class="finder-box-tab-right"></span></span>
				</div>

				<div class="popup-window-hr popup-window-buttons-hr"><i></i></div>

				<div class="finder-box-tabs-content">
					<div class="finder-box-tab-content finder-box-tab-content-selected" id="<?=$arResult["NAME"]?>_last">
						<table class="finder-box-tab-columns" cellspacing="0">
							<tr>
								<td>
									<?foreach($arResult["LAST_TASKS"] as $key=>$task):?>
										<div class="finder-box-item<?=(in_array($task["ID"], $arParams["VALUE"]) ? " finder-box-item-selected" : "")?>" id="<?=$arResult["NAME"]?>_last_task_<?=$task["ID"]?>" onclick="O_<?=$arResult["NAME"]?>.select(event)">
											<?if ($arParams["MULTIPLE"] == "Y"):?>
												<input type="hidden" name="<?=$arResult["NAME"]?>_m" value="<?=$task["ID"]?>" data-user="<?=$task["RESPONSIBLE_ID"]?>" rel="<?=(in_array($task["ID"], $arParams["VALUE"]) ? "checked" : "")?>" class="tasks-hidden-input" />
											<?else:?>
												<input type="hidden" name="<?=$arResult["NAME"]?>" value="<?=$task["ID"]?>" data-user="<?=$task["RESPONSIBLE_ID"]?>" rel="<?=(in_array($task["ID"], $arParams["VALUE"]) ? "checked" : "")?>" class="tasks-hidden-input" />
											<?endif?>
											<div class="finder-box-item-text"><?=$task["TITLE"]?></div>
											<div class="finder-box-item-icon"
												<?if ($arParams['HIDE_ADD_REMOVE_CONTROLS'] === 'Y') echo ' style="display:none;" '; ?>
												></div>
										</div>
									<?endforeach?>
									<?foreach($arResult["CURRENT_TASKS"] as $key=>$task):?>
										<?if (!in_array($task, $arResult["LAST_TASKS"])):?>
											<?if ($arParams["MULTIPLE"] == "Y"):?>
												<input type="hidden" name="<?=$arResult["NAME"]?>_m2" value="<?=$task["ID"]?>" data-user="<?=$task["RESPONSIBLE_ID"]?>" rel="<?=(in_array($task["ID"], $arParams["VALUE"]) ? "checked" : "")?>" class="tasks-hidden-input" />
											<?else:?>
												<input type="hidden" name="<?=$arResult["NAME"]?>2" value="<?=$task["ID"]?>" data-user="<?=$task["RESPONSIBLE_ID"]?>" rel="<?=(in_array($task["ID"], $arParams["VALUE"]) ? "checked" : "")?>" class="tasks-hidden-input" />
											<?endif?>
										<?endif?>
									<?endforeach?>
								</td>
							</tr>
						</table>
					</div>
					<div class="finder-box-tab-content" id="<?=$arResult["NAME"]?>_search"></div>
				</div>
			</td>
		</tr>
	</table>
</div>

</div>

</div>