function S4IBClearMField(what) 
{
	var ospan = what.parentNode;
	var odiv = ospan.parentNode;
	ospan.innerHTML = '';
	var obCInputs = BX.findChildren(odiv, 
		{
			'tag' : 'input',
			'attribute' : {'type' : 'hidden'}
		}, 
		true
	);
	obCInputs.forEach(function(el) 
	{
		el.value = '';
	});
}