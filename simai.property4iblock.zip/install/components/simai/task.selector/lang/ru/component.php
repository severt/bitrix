<?php
$MESS ['TASKS_MODULE_NOT_FOUND'] = "Модуль tasks не установлен";
?>