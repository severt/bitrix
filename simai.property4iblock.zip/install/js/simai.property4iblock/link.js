function SFIBChangeProptocol(link_md5_id)
{
    var protocol_ = BX('pro' + link_md5_id).value;	
    var linkval = BX('link' + link_md5_id).value;
    linkval = linkval.trim();
    while (linkval.substr(0, 1) == '/')
    {
        linkval = linkval.substr(1);
    }
    var linkval_ = linkval.toLowerCase();
    if (linkval_.substr(0, 8) == 'https://')
    {
        BX('link' + link_md5_id).value = linkval.substr(8);
        BX('full' + link_md5_id).value = protocol_ + linkval.substr(8);
    }
    else if (linkval_.substr(0, 7) == 'http://')
    {
        BX('link' + link_md5_id).value = linkval.substr(7);
        BX('full' + link_md5_id).value = protocol_ + linkval.substr(7);
    }
    else if (linkval.length > 0)
    {
        BX('full' + link_md5_id).value = protocol_ + linkval;
    }
    else
    {
        BX('full' + link_md5_id).value = '';
    }
}

function SFIBParseUrl(link_md5_id)
{
    var linkval = BX('link' + link_md5_id).value;
    linkval = linkval.trim();
    var linkval_ = linkval.toLowerCase();
    if (linkval_.substr(0, 8) == 'https://')
    {
        BX('pro' + link_md5_id).value = 'https://';
        linkval = linkval.substr(8);
        while (linkval.substr(0, 1) == '/')
        {
            linkval = linkval.substr(1);
        }
        BX('link' + link_md5_id).value = linkval;
        BX('full' + link_md5_id).value = 'https://' + linkval;
    }
    else if (linkval_.substr(0, 7) == 'http://')
    {
        BX('pro' + link_md5_id).value = 'http://';
        linkval = linkval.substr(7);
        while (linkval.substr(0, 1) == '/')
        {
            linkval = linkval.substr(1);
        }
        BX('link' + link_md5_id).value = linkval;
        BX('full' + link_md5_id).value = 'http://' + linkval;
    }
    else if (linkval_.substr(0, 2) == '//')
    {
        BX('pro' + link_md5_id).value = 'http://';
        while (linkval.substr(0, 1) == '/')
        {
            linkval = linkval.substr(1);
        }
        BX('link' + link_md5_id).value = linkval;
        BX('full' + link_md5_id).value = 'http://' + linkval;
    }
    else if (linkval_.substr(0, 1) == '/')
    {
        BX('pro' + link_md5_id).value = '/';
        while (linkval.substr(0, 1) == '/')
        {
            linkval = linkval.substr(1);
        }
        BX('link' + link_md5_id).value = linkval;
        BX('full' + link_md5_id).value = '/' + linkval;
    }
    else if (linkval.length > 0)
    {
        BX('full' + link_md5_id).value = BX('pro' + link_md5_id).value + linkval;
    }
    else
    {
        BX('full' + link_md5_id).value = '';
    }
}