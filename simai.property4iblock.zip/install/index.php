<?php
global $MESS;
$strPath2Lang = str_replace("\\", "/", __FILE__);
$strPath2Lang = substr($strPath2Lang, 0, strlen($strPath2Lang) - 18);
@include(GetLangFileName($strPath2Lang."/lang/", "/install/index.php"));
IncludeModuleLangFile($strPath2Lang."/install/index.php");

define('SP4I_DOCUMENT_ROOT', \Bitrix\Main\Application::getDocumentRoot());

class simai_property4iblock extends CModule
{
    const MODULE_ID = 'simai.property4iblock';
    var $MODULE_ID = 'simai.property4iblock';
    var $MODULE_VERSION;
    var $MODULE_VERSION_DATE;
    var $MODULE_NAME;
    var $MODULE_DESCRIPTION;
    var $MODULE_GROUP_RIGHTS = 'N';
    var $PARTNER_NAME;
    var $PARTNER_URI;
    
    function __construct() //simai_property4iblock()
    {
        $arModuleVersion = array();

        $path = str_replace("\\", "/", __FILE__);
        $path = substr($path, 0, strlen($path) - strlen("/index.php"));
        include($path."/version.php");

        $this->MODULE_VERSION = $arModuleVersion["VERSION"];
        $this->MODULE_VERSION_DATE = $arModuleVersion["VERSION_DATE"];

        $this->MODULE_NAME = GetMessage("SMPI_MODULE_NAME");
        $this->MODULE_DESCRIPTION = GetMessage("SMPI_MODULE_DESCRIPTION");
        
        $this->PARTNER_NAME = "SIMAI"; 
        $this->PARTNER_URI = "http://www.simai.ru";
    }
    
    public function DoInstall()
    {
        $this->InstallFiles();
        $this->InstallDB();
        $this->InstallEvents();
        
        return true;
    }
    
    function DoUninstall()
    {
        global $USER, $APPLICATION, $step;
        
        $request = \Bitrix\Main\Application::getInstance()->getContext()->getRequest();
        
        $step = IntVal($step);
        if ($step < 2)
        {
            $APPLICATION->IncludeAdminFile(GetMessage('SP4I_UNINSTALL_TITLE'), SP4I_DOCUMENT_ROOT.'/bitrix/modules/simai.property4iblock/install/unstep1.php');
        }
        elseif ($step == 2)
        {
            $this->UninstallFiles();
            $this->UninstallDB(array(
                'save_tables' => $request->getQuery('save_tables'),
            ));
            $this->UninstallEvents();
            
            $GLOBALS['errors'] = $this->errors;
            $APPLICATION->IncludeAdminFile(GetMessage('SP4I_UNINSTALL_TITLE'), SP4I_DOCUMENT_ROOT.'/bitrix/modules/simai.property4iblock/install/unstep2.php');
        }
        
        return true;
    }
    
    public function InstallDB()
    {
        if(!IsModuleInstalled("simai.property4iblock"))
        {
            RegisterModule("simai.property4iblock");
            
            COption::SetOptionString("simai.property4iblock", "search_page_url", "#SITE_DIR#search/?tags=#TAG#");
            COption::SetOptionString("simai.property4iblock", "method_send", "message");
            COption::SetOptionString("simai.property4iblock", "inp_idchat", "1");
            COption::SetOptionString("simai.property4iblock", "send_message", "system");
            COption::SetOptionString("simai.property4iblock", "user_message", "");
            COption::SetOptionString("simai.property4iblock", "mail_chat", "");
            COption::SetOptionString("simai.property4iblock", "macros", GetMessage('SP4I_MACROS'));
            COption::SetOptionString("simai.property4iblock", "macros2", GetMessage('SP4I_MACROS2'));
            COption::SetOptionString("simai.property4iblock", "macros3", GetMessage('SP4I_MACROS3'));
            
            RegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiTask", "GetUserTypeDescription");
            RegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiIBElement", "GetUserTypeDescription");
            RegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiIBSection", "GetUserTypeDescription");
            RegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiLink", "GetUserTypeDescription");
            RegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiTags", "GetUserTypeDescription");
            RegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiStadia", "GetUserTypeDescription");
            RegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiIndicator", "GetUserTypeDescription");
            RegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiPassword", "GetUserTypeDescription");
            RegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiImage", "GetUserTypeDescription");
            RegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiTicket", "GetUserTypeDescription");
            RegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiUser", "GetUserTypeDescription");
            
            RegisterModuleDependences("iblock", "OnAfterIBlockElementAdd", "simai.property4iblock", "TypeSimaiP4IB", "OnAfterIBlockElementUpdateHandler");
            RegisterModuleDependences("iblock", "OnAfterIBlockElementUpdate", "simai.property4iblock", "TypeSimaiP4IB", "OnAfterIBlockElementUpdateHandler");
            
        }
        
        
        return true;
    }
    
    public function UninstallDB($arParams = array())
    {
        
        $this->errors = false;
        if (!array_key_exists('save_tables', $arParams) || $arParams['save_tables'] != 'Y')
        {
            COption::RemoveOption("simai.property4iblock");
        }
        
        
        
        UnRegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiTask", "GetUserTypeDescription");
        UnRegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiIBElement", "GetUserTypeDescription");
        UnRegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiIBSection", "GetUserTypeDescription");
        UnRegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiLink", "GetUserTypeDescription");
        UnRegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiTags", "GetUserTypeDescription");
        UnRegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiStadia", "GetUserTypeDescription");
        UnRegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiIndicator", "GetUserTypeDescription");
        UnRegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiPassword", "GetUserTypeDescription");
        UnRegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiImage", "GetUserTypeDescription");
        UnRegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiTicket", "GetUserTypeDescription");
        UnRegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiUser", "GetUserTypeDescription");

        
        UnRegisterModuleDependences("iblock", "OnAfterIBlockElementAdd", "simai.property4iblock", "TypeSimaiP4IB", "OnAfterIBlockElementUpdateHandler");
        UnRegisterModuleDependences("iblock", "OnAfterIBlockElementUpdate", "simai.property4iblock", "TypeSimaiP4IB", "OnAfterIBlockElementUpdateHandler");
        
        UnRegisterModule("simai.property4iblock");
        
        return true;
    }
    
    public function InstallFiles()
    {
        CopyDirFiles(SP4I_DOCUMENT_ROOT.'/bitrix/modules/simai.property4iblock/install/components/simai/', SP4I_DOCUMENT_ROOT.'/bitrix/components/simai', true, true);
        CopyDirFiles(SP4I_DOCUMENT_ROOT."/bitrix/modules/simai.property4iblock/install/admin", SP4I_DOCUMENT_ROOT."/bitrix/admin");
        CopyDirFiles(SP4I_DOCUMENT_ROOT."/bitrix/modules/simai.property4iblock/install/admin", SP4I_DOCUMENT_ROOT."/simai/admin", true, true);
        CopyDirFiles(SP4I_DOCUMENT_ROOT.'/bitrix/modules/simai.property4iblock/install/themes', SP4I_DOCUMENT_ROOT.'/bitrix/themes', true, true);
        CopyDirFiles(SP4I_DOCUMENT_ROOT.'/bitrix/modules/simai.property4iblock/install/js', SP4I_DOCUMENT_ROOT.'/bitrix/js', true, true);
        
        return true;
    }
    
    public function UninstallFiles()
    {
        DeleteDirFilesEx("/bitrix/components/simai/task.selector");
        DeleteDirFilesEx('/bitrix/js/simai.property4iblock');
        DeleteDirFiles(SP4I_DOCUMENT_ROOT."/bitrix/modules/simai.property4iblock/install/admin", SP4I_DOCUMENT_ROOT."/bitrix/admin");
        DeleteDirFiles(SP4I_DOCUMENT_ROOT."/bitrix/modules/simai.property4iblock/install/admin", SP4I_DOCUMENT_ROOT."/simai/admin");
        DeleteDirFiles(SP4I_DOCUMENT_ROOT.'/bitrix/modules/simai.property4iblock/install/themes/.default/icons', SP4I_DOCUMENT_ROOT.'/bitrix/themes/.default/icons');
        DeleteDirFiles(SP4I_DOCUMENT_ROOT.'/bitrix/modules/simai.property4iblock/install/themes/.default/', SP4I_DOCUMENT_ROOT.'/bitrix/themes/.default');
        
        return true;
    }
    
    function InstallEvents()
    {
        //check install template mail
        $rsET = CEventType::GetList(array("TYPE_ID" => "SIMAI_PASSWORD_REQUIRED"));
        if ($rsET->Fetch()) {
        
        }
        else
        {
            $et = new CEventType;
            $et->Add(array(
                "LID" => LANGUAGE_ID,
                "EVENT_NAME" => "SIMAI_PASSWORD_REQUIRED",
                "NAME" => getMessage("PASSWORD_REQUIRED_NAME"),
                "DESCRIPTION" => getMessage("PASSWORD_REQUIRED_DESCRIPTION"),
            ));

            $arSites = array();
            $sites = CSite::GetList(($b = ""), ($o = ""), array("LANGUAGE_ID" => LANGUAGE_ID));
            while ($site = $sites->Fetch())
            {
                $arSites[] = $site["LID"];
            }

            if (count($arSites) > 0)
            {

                $emess = new CEventMessage;
                $emess->Add(array(
                    "ACTIVE" => "Y",
                    "EVENT_NAME" => "SIMAI_PASSWORD_REQUIRED",
                    "LID" => $arSites,
                    "EMAIL_FROM" => "#DEFAULT_EMAIL_FROM#",
                    "EMAIL_TO" => "#MAIL#",
                    "SUBJECT" => getMessage("PASSWORD_REQUIRED_FROM_SUBJECT"),
                    "BODY_TYPE" => "html",
                    "MESSAGE" => getMessage("PASSWORD_REQUIRED_FROM_MESSAGE"),
                ));
            }
            
        }
        
    }
    
    function UninstallEvents()
    {
        $rsET = CEventType::GetList(Array("TYPE_ID" => "SIMAI_PASSWORD_REQUIRED"));
        if ($rsET->fetch())
        {
            $rsMess = CEventMessage::GetList($by="site_id", $order="desc", Array("TYPE_ID" => "SIMAI_PASSWORD_REQUIRED"));
            while ($arMess = $rsMess->GetNext())
            {
                $emessage = new CEventMessage;
                $emessage->Delete($arMess['ID']);
            }
            
            $et = new CEventType;
            $et->Delete("SIMAI_PASSWORD_REQUIRED");
        }
        
        return true;
    }
}
?>
