<?php
define('STOP_STATISTICS', true);
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");
$GLOBALS['APPLICATION']->RestartBuffer();

global $USER;

$iblock_id = intval($_POST["IBLOCK_ID"]);
$element_id = intval($_POST["ELEMENT_ID"]);
$prop_id = intval($_POST["PROP_ID"]);

if ($iblock_id > 0 && $element_id > 0 && $prop_id > 0) {
    $value_pass = CIBlockElement::GetProperty($iblock_id, $element_id, array("sort" => "asc"), array("ID" => $prop_id));
    while ($ob_value_pass = $value_pass->GetNext())
    {
        if ($ob_value_pass['PROPERTY_VALUE_ID'] == htmlspecialcharsex($_POST["PROPERTY_VALUE_ID"])) {
            $ar_value_pass = $ob_value_pass;
        }
    }
    //$ar_value_pass = $value_pass->Fetch(); // пароль
}

if ($prop_id > 0) {
    $res_set = CIBlockProperty::GetByID($prop_id);
    $ar_res_set = $res_set->GetNext(); // настройки
}

if ($element_id > 0) {
    $main_param = CIBlockElement::GetByID($element_id);
    $ar_main_prop = $main_param->GetNext(); // основные параметры
}


$arSettings = $ar_res_set["USER_TYPE_SETTINGS"];
if ($arSettings["S_CHECK"] == "Y") {
    $SET_PASS = array(
        "ACT" => COption::GetOptionString("simai.property4iblock", "act", ""),
        "METHOD_SEND" => COption::GetOptionString("simai.property4iblock", "method_send", ""),
        "INP_IDCHAT" => COption::GetOptionString("simai.property4iblock", "inp_idchat", ""),
        "USER_MESSAGE" => ltrim(COption::GetOptionString("simai.property4iblock", "user_message", ""), "U"),
        "MACROS" => COption::GetOptionString("simai.property4iblock", "macros", ""),
        "MACROS2" => COption::GetOptionString("simai.property4iblock", "macros2", ""),
        "MACROS3" => COption::GetOptionString("simai.property4iblock", "macros3", ""),
        "SEND_MESSAGE" => COption::GetOptionString("simai.property4iblock", "send_message", ""),
        "MAIL_CHAT" => COption::GetOptionString("simai.property4iblock", "mail_chat", ""),
    );
} else {
    $SET_PASS = array(
        "ACT" => $arSettings["ACT"],
        "METHOD_SEND" => $arSettings["METHOD_SEND"],
        "INP_IDCHAT" => $arSettings["INP_IDCHAT"],
        "USER_MESSAGE" => ltrim($arSettings["USER_MESSAGE"], "U"),
        "MACROS" => $arSettings["MACROS"],
        "MACROS2" => $arSettings["MACROS2"],
        "MACROS3" => $arSettings["MACROS3"],
        "SEND_MESSAGE" => $arSettings["SEND_MESSAGE"],
        "MAIL_CHAT" => $arSettings["MAIL_CHAT"],
    );
}





$method_send = $SET_PASS['METHOD_SEND'];

$inp_idchat = $SET_PASS['INP_IDCHAT'];
$user_message = $SET_PASS['USER_MESSAGE'];
if ($_POST["VIEW"] == "1") {
    $macros =$SET_PASS['MACROS2'];
} else {
    $macros = $SET_PASS['MACROS3'];
}

if ($SET_PASS['SEND_MESSAGE'] == "system") {
    $send_message = "Y";
} else {
    $send_message = "N";
}


if ($method_send == "message") {

    if ($ar_main_prop["DETAIL_PAGE_URL"] != "") {
        $message = trim(str_replace('#LINK#', '[url='.$ar_main_prop["DETAIL_PAGE_URL"].']'.$ar_main_prop["NAME"].'[/url]', $macros));
    } else {
        $message = trim(str_replace('#LINK#', '', $macros));
    }
    $message = trim(str_replace('#USER#', $USER->GetFullName(), $message));
    $message = trim(str_replace('#NAME#', $ar_main_prop["NAME"], $message));
    if (CModule::IncludeModule('im')) {
        $ar = array(
            "TO_CHAT_ID" => $inp_idchat, // ID чата
            "FROM_USER_ID" => $user_message,
            "SYSTEM" => $send_message,
            "MESSAGE" => $message,
        );
        $fun = CIMChat::AddMessage($ar);
    }
} else {

    if ($ar_main_prop["DETAIL_PAGE_URL"] != "") {
        $message = trim(str_replace('#LINK#', GetMessage("MAIL-ADDRESS").$_SERVER['SERVER_NAME'].$ar_main_prop["DETAIL_PAGE_URL"], $macros));
    } else {
        $message = trim(str_replace('#LINK#', '', $macros));
    }
    $message = trim(str_replace('#USER#', $USER->GetFullName(), $message));
    $message = trim(str_replace('#NAME#', $ar_main_prop["NAME"], $message));
    $arEventFields = array(
        "USER" => $USER->GetFullName(),
        "NAME" => $ar_main_prop["NAME"],
        "LINK" => $ar_main_prop["DETAIL_PAGE_URL"],
        "MAIL" => $SET_PASS['MAIL_CHAT'],
        "MAIN_TEXT" => $message
    );
    CEvent::Send("PASSWORD_REQUIRED", "s1", $arEventFields);
}



echo base64_encode($ar_value_pass["VALUE"]);


if(!isset($APPLICATION)) {global $APPLICATION;}

$buffer = $APPLICATION->EndBufferContentMan();
$buffer .= ob_get_clean();

CMain::FinalActions($buffer);

die();
?>