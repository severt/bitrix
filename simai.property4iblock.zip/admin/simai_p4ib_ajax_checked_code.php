<?php
define('STOP_STATISTICS', true);
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");
$GLOBALS['APPLICATION']->RestartBuffer();

$iblock_id = intval($_POST["IBLOCK_ID"]);
$element_id = intval($_POST["ELEMENT_ID"]);
$prop_id = intval($_POST["PROP_ID"]);
$prop_val_id = htmlspecialcharsex($_POST["PROPERTY_VALUE_ID"]);

if ($iblock_id > 0 && $element_id > 0 && $prop_id > 0) {
    $value_pass = CIBlockElement::GetProperty($iblock_id, $element_id, array("sort" => "asc"), array("ID" => $prop_id));
    while ($ob_value_pass = $value_pass->GetNext())
    {
        if ($ob_value_pass['PROPERTY_VALUE_ID'] == $prop_val_id) {
            $ar_value_pass = $ob_value_pass;
        }
    }
}

if (empty($_SESSION['COUNT_CODE'])) {
    $_SESSION['COUNT_CODE'] = 0;
}
if ($_SESSION['COUNT_CODE'] > 3) {
    $_SESSION['COUNT_CODE'] = 0;
    ?>
    <script>
        BX.ajax({
            method: "POST",
            cache: false,
            url: "/simai/admin/simai_p4ib_ajax_send_mail.php",
            data: {
                PROPERTY_VALUE_ID : "<?=$prop_val_id;?>",
                PROP_ID : "<?=$prop_id;?>",
                ELEMENT_ID : "<?=$element_id;?>",
                IBLOCK_ID : "<?=$iblock_id;?>",
            },
            onsuccess:
                function(response) {
                    alert("<?=GetMessage("MAIL-CODE")?>");
                },
            onfailure:
                function() {
                    alert("fail");
                }
        });
    </script>
    <?php
} else {
    $_SESSION['COUNT_CODE']++;
}

if ($_SESSION['CODE_'.$prop_val_id] == $_POST['CHECK_CODE']) {
    echo base64_encode($ar_value_pass["VALUE"]);
    $_SESSION['COUNT_CODE'] = 0;
    unset($_SESSION['CODE_'.$prop_val_id]);
} else {
    echo "badcode";
}


if(!isset($APPLICATION)) {global $APPLICATION;}

$buffer = $APPLICATION->EndBufferContentMan();
$buffer .= ob_get_clean();

CMain::FinalActions($buffer);

die();
?>