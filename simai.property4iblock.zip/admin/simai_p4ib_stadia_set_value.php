<?php 
require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_before.php');
CModule::IncludeModule("iblock");

$element_id = intval($_REQUEST["element_id"]);
$property_id = intval($_REQUEST["property_id"]);
$value = intval($_REQUEST["value"]);

$USER_ID = $USER->GetID();
$USER_ID = intval($USER_ID);

$res = $DB->Query('select * from `b_iblock_element` where `ID`='.$element_id);
if ($arEl = $res->fetch())
{
    $iblock = $arEl['IBLOCK_ID'];
    
    //$iblock_permission = CIBlock::GetPermission($iblock);
    
    if (CIBlockElementRights::UserHasRightTo($arEl['IBLOCK_ID'], $element_id, "element_edit"))
    {
        CIBlockElement::SetPropertyValueCode($element_id, $property_id, $value);
        
        $el = new CIBlockElement;
        $arF = array(
            "NO_SIMAI_BU" => true,
            "MODIFIED_BY" => $USER_ID,
        );
        $el->Update($element_id, $arF);
        
        if (\Bitrix\Main\Loader::IncludeModule('bizproc'))
        {
            $arWorkflowTemplates = \CBPDocument::GetWorkflowTemplatesForDocumentType([
                'lists', 'Bitrix\Lists\BizprocDocumentLists', 'iblock_'.$iblock
            ]);
            
            foreach ($arWorkflowTemplates as $arTemplate) 
            {
                // AUTO_EXECUTE = 1 - on add
                // AUTO_EXECUTE = 2 - on update
                
                $arWorkflowParameters = array();
                
                if (/*$arTemplate['AUTO_EXECUTE'] == 1 || */ $arTemplate['AUTO_EXECUTE'] == 2 || $arTemplate['AUTO_EXECUTE'] == 3) 
                {
                    $wfId = \CBPDocument::StartWorkflow(
                        $arTemplate['ID'],
                        array('lists', 'Bitrix\Lists\BizprocDocumentLists', $element_id),
                        array_merge($arWorkflowParameters, array( 'TargetUser' => "user_".$USER_ID )),
                        $arErrorsTmp
                    );

                    /*if (count($arErrorsTmp) > 0) 
                    {
                        foreach ($arErrorsTmp as $e) {
                            $errorMessage .= "[".$e["code"]."] ".$e["message"]."";
                        }
                    }*/
                }
            }
        }
    }
}
?>