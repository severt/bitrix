<?require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_before.php');
\Bitrix\Main\Localization\Loc::loadMessages(__FILE__);

$APPLICATION->SetAdditionalCSS('/bitrix/js/main/core/css/core.css');
$APPLICATION->AddHeadScript('/bitrix/js/main/core/core.js');
$APPLICATION->AddHeadScript('/bitrix/js/main/core/core_ajax.js');
$APPLICATION->AddHeadScript('/bitrix/js/main/json/json2.js');
$APPLICATION->AddHeadScript('/bitrix/js/main/core/core.js');
$APPLICATION->AddHeadScript('/bitrix/js/main/core/core_ls.js');
$APPLICATION->AddHeadScript('/bitrix/js/main/session.js');

$APPLICATION->ShowHead();

$inp = htmlspecialcharsbx($_REQUEST["inp"]);
$value = htmlspecialcharsbx($_REQUEST["value"]);

$TASK_URL_TEMPLATE = COption::GetOptionString("tasks", "paths_task_user_entry", "");

$APPLICATION->IncludeComponent("simai:task.selector", "public_mult", 
	array(
		"MULTIPLE" => "N",
		"VALUE" => $value,
		"PATH_TO_TASKS_TASK" => $TASK_URL_TEMPLATE,
		"SITE_ID" => SITE_ID,
		"SELECT" => array('ID', 'TITLE', 'STATUS'),
		"INP" => $inp,
	), null, array("HIDE_ICONS" => "Y")
);
?>