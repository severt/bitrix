<? 
$MESS ['OPTIONS_TAB_1'] = "Настройки";
$MESS ['OPTIONS_TAB_2'] = "Пароль";
$MESS ['OPTIONS_TAB_1_TITLE'] = "Пользовательские настройки модуля";
$MESS ['OPTIONS_TAB_2_TITLE'] = "Запрос пароля";
$MESS ['SIMAI_P4IB_SPU'] = "Url страницы поиска по тегу (включая макросы #SITE_DIR# и #TAG#)";

$MESS ['SP4I_TEMPLATE'] = "Шаблон сообщения";
$MESS ['SP4I_TEMPLATE2'] = "Шаблон сообщения просмотра";
$MESS ['SP4I_TEMPLATE3'] = "Шаблон сообщения копирование";
$MESS ['SP4I_TEMPLATE4'] = "Шаблон сообщения редактирование";
$MESS ['SP4I_TEMPLATE'] = "Шаблон сообщения";
$MESS ['SP4I_ACT'] = "Действия при показе пароля";
$MESS ['SP4I_METHOD'] = "Метод отправки кода доступа";
$MESS ['SP4I_ID'] = "ID чата для кода доступа";
$MESS ['SP4I_ID_INFO'] = "Для получения ID, нужно в нужном чате отправить сообщение <b>/getChatId</b>";
$MESS ['SP4I_SEND'] = "Отправлять сообщение";
$MESS ['SP4I_SENDER'] = "Отправитель сообщения";
$MESS ['SP4I_ADMINCHECK'] = "Не применять ограничения просмотра к группе администраторов";
$MESS ['SP4I_MAIL'] = "Email чата для кода доступа";
$MESS ['SP4I_PASS'] = "Запрос пароля";
$MESS ['SP4I_MACROS'] = "Пользователь #USER# запросил пароль для #NAME# #LINK#. Код для получения доступа #CODE#";
$MESS ['SP4I_MACROS2'] = "Пользователь #USER# посмотрел пароль для #NAME# #LINK#";
$MESS ['SP4I_MACROS3'] = "Пользователь #USER# скопировал пароль для #NAME# #LINK#";
$MESS ['SP4I_MACROS4'] = "Пользователь #USER# правит пароль для #NAME# #LINK#";


$MESS ['SP4I_SECURITY'] = "Безопасность";
$MESS ['SP4I_KEYGEN'] = "Ключ шифрования";
$MESS ['SP4I_GENERAATE_KEY'] = "Сгенерировать ключ";

$MESS ['SP4I_NOTIF_PASS'] = "Настройки уведомлений пароля";
$MESS ['SP4I_ACT0'] = "Ничего не делать";
$MESS ['SP4I_ACT1'] = "Уведомить";
$MESS ['SP4I_ACT2'] = "Запросить код доступа";
$MESS ['SP4I_METHOD0'] = "Веб-мессенджер";
$MESS ['SP4I_METHOD1'] = "Электронная почта";
$MESS ['SP4I_SEND0'] = "Как системное";
$MESS ['SP4I_SEND1'] = "От имени пользователя";
$MESS ['SP4I_IM'] = "Модуль мгновенных сообщений и уведомлений - не устанлвлен! Пожалуйста <a href='/bitrix/admin/module_admin.php' target='_blank'>установите</a> «Веб-мессенджер (im)»";

$MESS ['SP4I_USER_EDIT'] = "Изменить";


?>