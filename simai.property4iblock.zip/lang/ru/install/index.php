<?php

global $MESS;

$MESS['SMPI_MODULE_NAME'] = 'SIMAI: Свойства для информационных блоков';
$MESS['SMPI_MODULE_DESCRIPTION'] = 'Дополнительные типы свойств для инфоблоков';

$MESS['SP4I_UNINSTALL_TITLE'] = 'Удаление модуля SIMAI: Свойства для информационных блоков';

$MESS['PASSWORD_REQUIRED_NAME'] = 'Запрос пароля';
$MESS['PASSWORD_REQUIRED_DESCRIPTION'] = '  #USER# - Пользователь 
                                            #NAME# - Название проекта
                                            #LINK# - Ссылка на проект
                                            #CODE# - Код доступа
                                            #MAIL# - Почта куда приходит запрос
                                            #MAIN_TEXT# - ШАБЛОН';
$MESS['PASSWORD_REQUIRED_FROM_SUBJECT'] = '#SITE_NAME#: Запрос пароля';
$MESS['PASSWORD_REQUIRED_FROM_MESSAGE'] = '#MAIN_TEXT#';

?>