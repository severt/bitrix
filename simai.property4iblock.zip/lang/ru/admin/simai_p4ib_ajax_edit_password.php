<?
$MESS["MAIL-ADDRESS"] = "Адрес: ";

?>