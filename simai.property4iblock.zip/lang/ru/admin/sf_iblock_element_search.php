<?
$MESS["IBLOCK_ELSEARCH_TITLE"] = "Поиск элемента";
$MESS["IBLOCK_ELSEARCH_LOCK_BY"] = "Кем заблокирована";
$MESS["IBLOCK_ELSEARCH_CHOOSE_IBLOCK"] = "Выберите информационный блок";
$MESS["IBLOCK_ELSEARCH_USERINFO"] = "Посмотреть параметры пользователя";
$MESS["IBLOCK_ELSEARCH_SECTION_EDIT"] = "Перейти на страницу редактирования раздела";
$MESS["IBLOCK_ELSEARCH_ELEMENT_EDIT"] = "Перейти на страницу редактирования элемента";
$MESS["IBLOCK_ELSEARCH_SELECT"] = "Выбрать";
$MESS["IBLOCK_ELSEARCH_NOT_SET"] = "(не установлено)";
$MESS["IBLOCK_ELSEARCH_F_DATE"] = "Дата";
$MESS["IBLOCK_ELSEARCH_F_CHANGED"] = "Кто изменил";
$MESS["IBLOCK_ELSEARCH_F_STATUS"] = "Статус";
$MESS["IBLOCK_ELSEARCH_F_SECTION"] = "Раздел";
$MESS["IBLOCK_ELSEARCH_F_ACTIVE"] = "Активность";
$MESS["IBLOCK_ELSEARCH_F_TITLE"] = "Название";
$MESS["IBLOCK_ELSEARCH_F_DSC"] = "Описание";
$MESS["IBLOCK_ELSEARCH_IBLOCK"] = "Информационный блок:";
$MESS["IBLOCK_ELSEARCH_DESC"] = "Описание:";
$MESS["IBLOCK_ELSEARCH_INCLUDING_SUBSECTIONS"] = "Включая подразделы";
$MESS["IBLOCK_ELSEARCH_FROMTO_ID"] = "ID (начальный и конечный):";
$MESS["IBLOCK_ELSEARCH_ELEMENTS"] = "Элементы";
$MESS["IBLOCK_FIELD_EXTERNAL_ID"] = "Внешний код";
$MESS["IBLOCK_FIELD_CODE"] = "Символьный код";
?>