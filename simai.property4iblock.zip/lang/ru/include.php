<?php

global $MESS;

$MESS['SMPI_MODULE_NAME'] = 'SIMAI: Свойства для информационных блоков';
$MESS['SMPI_MODULE_DESCRIPTION'] = 'Дополнительные типы свойств для инфоблоков';
$MESS['SMPI_LINK_PROP'] = 'SIMAI: Ссылка';
$MESS['SMPI_LINK_SETTINGS'] = 'Настройки ссылки';
$MESS['SMPI_LINK_BLANK'] = 'Открывать ссылку в новом окне';
$MESS['SMPI_IBS_PROP'] = 'SIMAI: Привязка к разделам инфоблока с сохранением в виде кода';
$MESS['SMPI_IBE_PROP'] = 'SIMAI: Привязка к элементам инфоблока с сохранением в виде кода';
$MESS['SMPI_TASK_PROP'] = 'SIMAI: Привязка к задаче';
$MESS['SMPI_LINK_NAME'] = 'Текст ссылки:';
$MESS['SMPI_TASK_LINK_IBLOCK'] = 'Инфоблок привязки';
$MESS['SMPI_SELECT_IBLOCK'] = 'Выбрать инфоблок';
$MESS['SMPI_TASK_URL_TEMPLATE'] = 'Шаблон URL для задачи';
$MESS['SMPI_TASK_URL_TEMPLATE_HINT'] = 'Доступен макрос #task_id# - ID задачи';
$MESS['SMPI_SELECT_TASK'] = 'Выбрать задачу';
$MESS['SMPI_TAGS_PROP'] = 'SIMAI: Теги';
$MESS['SMPI_STADIA_PROP'] = 'SIMAI: Стадия';
$MESS['SP4IB_COLORS_STADIA'] = 'Настройка цвета стадий';
$MESS['SMPI_INDICATOR_PROP'] = 'SIMAI: Индикатор';
$MESS['SP4IB_COLORS_INDICATOR'] = 'Настройка цветов индикатора';
$MESS['SMPI_PASSWORD_PROP'] = 'SIMAI: Пароль';
$MESS['SMPI_PASSWORD_REQUEST_PROP'] = 'SIMAI: Пароль';
$MESS['SMPI_GET_PASSWORD_PROP'] = 'SIMAI: Пароль по запросу';

$MESS['SMPI_GET_PASSWORD_SETTINGS'] = 'Настройки уведомлений о запросе пароля';
$MESS['SMPI_SHOW_PASSWORD_NOTICE'] = 'Уведомлять о просмотре';
$MESS['SMPI_SHOW_PASSWORD_OBSERVERS'] = 'Наблюдатели';
$MESS['SHOW_PASSWORD_NOTICE_SERVICE'] = 'Способ уведомления пользователей';
$MESS['SHOW_PASSWORD_NOTICE_SERVICE_CHAT'] = 'Через чат';
$MESS['SHOW_PASSWORD_NOTICE_SERVICE_NOTICE'] = 'Через уведомления';
$MESS['SMPI_SHOW_PASSWORD_USER_FROM'] = 'Отправитель сообщения';
$MESS['SHOW_PASSWORD_NOTICE_TEXT'] = 'Шаблон сообщения';
$MESS['SHOW_PASSWORD_NOTICE_TEXT_HINT'] = 'Доступны макросы:
<br>- #USER# - пользователь запросивший сообщение
<br>- #NAME# - название элемента, на который пользователь запросил сообщение
<br>- #LINK# - ссылка на элемент, на который запросил пользователь сообщение
<br>- #PASSWORD# - пароль';
$MESS['SHOW_PASSWORD_NOTICE_TEXT_DEFAULT'] = 'Пользователь #USER# запросил пароль для «#NAME#»
#LINK#';
$MESS['SHOW_PASSWORD_NOTICE_NEEDS_IM_MODULE'] = 'Для работы уведомлений необходимо наличие модуля "Веб-мессенджер"';

$MESS['SHOW_PASSWORD_GET_PASSWORD_BUTTON'] = 'Получить пароль';

$MESS ['SP4I_MACROS'] = "Пользователь #USER# запросил пароль для #NAME# #LINK#. Код для получения доступа #CODE#";
$MESS ['SP4I_MACROS2'] = "Пользователь #USER# посмотрел пароль для #NAME# #LINK#";
$MESS ['SP4I_MACROS3'] = "Пользователь #USER# скопировал пароль для #NAME# #LINK#";
$MESS ['SP4I_MACROS4'] = "Пользователь #USER# правит пароль для #NAME# #LINK#";

$MESS ['SP4I_TEMPLATE'] = "Шаблон сообщения:";
$MESS ['SP4I_TEMPLATE2'] = "Шаблон сообщения просмотра:";
$MESS ['SP4I_TEMPLATE3'] = "Шаблон сообщения копирование:";
$MESS ['SP4I_TEMPLATE4'] = "Шаблон сообщения редактирование:";
$MESS ['SP4I_ACT'] = "Действия при показе пароля:";
$MESS ['SP4I_METHOD'] = "Метод отправки кода доступа:";
$MESS ['SP4I_IM'] = "Модуль мгновенных сообщений и уведомлений - не устанлвлен! Пожалуйста <a href='/bitrix/admin/module_admin.php' target='_blank'>установите</a> «Веб-мессенджер (im)»";
$MESS ['SP4I_ID'] = "ID чата для кода доступа:";
$MESS ['SP4I_ID_INFO'] = "Для получения ID, нужно в нужном чате отправить сообщение <b>/getChatId</b>";
$MESS ['SP4I_SEND'] = "Отправлять сообщение:";
$MESS ['SP4I_SENDER'] = "Отправитель сообщения:";
$MESS ['SP4I_MAIL'] = "Email чата для кода доступа:";
$MESS ['SP4I_PASS'] = "Запрос пароля";

$MESS ['SP4I_USE_MODUL'] = "Использовать настройки модуля:";
$MESS ['SP4I_ADMINCHECK'] = "Не применять ограничения просмотра к группе администраторов";

$MESS ['SP4I_NOTIF_PASS'] = "Настройки уведомлений пароля";
$MESS ['SP4I_ACT0'] = "Ничего не делать";
$MESS ['SP4I_ACT1'] = "Уведомить";
$MESS ['SP4I_ACT2'] = "Запросить код доступа";
$MESS ['SP4I_METHOD0'] = "Веб-мессенджер";
$MESS ['SP4I_METHOD1'] = "Электронная почта";
$MESS ['SP4I_SEND0'] = "Как системное";
$MESS ['SP4I_SEND1'] = "От имени пользователя";

$MESS ['SP4I_COPY'] = "Скопировано";
$MESS ['SP4I_EMPTY'] = "Пусто";
$MESS ['SP4I_SHOW_PASSWORD'] = "Показать пароль";
$MESS ['SP4I_ENTER'] = "Подтвердить";
$MESS ['SP4I_PLACEHOLDER_CODE'] = "Введите код";
$MESS ['SP4I_ERROR_CODE'] = "Неверный код!";

$MESS ['SP4I_USER_EDIT'] = "Изменить";
$MESS ['SP4I_NEW_CODE'] = "Новый код успешно выслан.";

$MESS['SP4I_IMAGE_DESC'] = 'SIMAI: Изображение с оптимизацией';
$MESS['SP4I_IMAGE_PARAMETERS'] = 'Параметры изображения';
$MESS['SP4I_IMAGE_WIDTH'] = 'Максимальная ширина, px';
$MESS['SP4I_IMAGE_HEIGHT'] = 'Максимальная высота, px';
$MESS['SP4I_IMAGE_TYPES'] = 'Типы загружаемых изображений (расширения через запятую)';
$MESS['SP4I_IMAGE_DOWNLOAD'] = 'Скачать';
$MESS['SP4I_IMAGE_NOT_DATA'] = 'Нет данных';
$MESS['SP4I_IMAGE_ADD_BUTTON'] = 'Добавить';
?>