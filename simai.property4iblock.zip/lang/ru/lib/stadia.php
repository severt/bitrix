<?php

global $MESS;

$MESS['SMPI_STADIA_PROP'] = 'SIMAI: Стадия';
$MESS['SP4IB_COLORS_STADIA'] = 'Настройка цвета стадий';
