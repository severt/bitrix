<?php

global $MESS;

$MESS['SMPI_USER_PROP'] = 'SIMAI: Привязка к пользователю';
$MESS['SMPI_USER_ADD_BUTTON'] = 'Добавить';