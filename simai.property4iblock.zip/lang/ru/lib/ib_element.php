<?php

global $MESS;

$MESS['SMPI_IBE_PROP'] = 'SIMAI: Привязка к элементам инфоблока с сохранением в виде кода';
$MESS['SMPI_SELECT_IBLOCK'] = 'Выбрать инфоблок';
