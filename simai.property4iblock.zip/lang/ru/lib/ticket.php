<?php

global $MESS;

$MESS['SMPI_TICKET_PROP'] = 'SIMAI: Привязка к тикету';