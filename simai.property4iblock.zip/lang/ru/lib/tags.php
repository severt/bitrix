<?php

global $MESS;

$MESS['SMPI_TAGS_PROP'] = 'SIMAI: Теги';
