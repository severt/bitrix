
<?php

global $MESS;

$MESS['SMPI_IBS_PROP'] = 'SIMAI: Привязка к разделам инфоблока с сохранением в виде кода';
$MESS['SMPI_SELECT_IBLOCK'] = 'Выбрать инфоблок';
