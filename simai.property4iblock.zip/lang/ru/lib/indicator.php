
<?php

global $MESS;

$MESS['SMPI_INDICATOR_PROP'] = 'SIMAI: Индикатор';
$MESS['SP4IB_COLORS_INDICATOR'] = 'Настройка цветов индикатора';
