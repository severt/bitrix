
<?php

global $MESS;

$MESS['SP4I_IMAGE_DESC'] = 'SIMAI: Изображение с оптимизацией';
$MESS['SP4I_IMAGE_PARAMETERS'] = 'Параметры изображения';
$MESS['SP4I_IMAGE_WIDTH'] = 'Максимальная ширина, px';
$MESS['SP4I_IMAGE_HEIGHT'] = 'Максимальная высота, px';
$MESS['SP4I_IMAGE_TYPES'] = 'Типы загружаемых изображений (расширения через запятую)';
$MESS['SP4I_IMAGE_DOWNLOAD'] = 'Скачать';
$MESS['SP4I_IMAGE_NOT_DATA'] = 'Нет данных';
$MESS['SP4I_IMAGE_ADD_BUTTON'] = 'Добавить';