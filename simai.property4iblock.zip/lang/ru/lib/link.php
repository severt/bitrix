<?php

global $MESS;

$MESS['SMPI_MODULE_NAME'] = 'SIMAI: Свойства для информационных блоков';
$MESS['SMPI_MODULE_DESCRIPTION'] = 'Дополнительные типы свойств для инфоблоков';
$MESS['SMPI_LINK_PROP'] = 'SIMAI: Ссылка';
$MESS['SMPI_LINK_SETTINGS'] = 'Настройки ссылки';
$MESS['SMPI_LINK_BLANK'] = 'Открывать ссылку в новом окне';
$MESS['SMPI_LINK_NAME'] = 'Текст ссылки:';
