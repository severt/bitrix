<?php

global $MESS;

$MESS['SMPI_TASK_PROP'] = 'SIMAI: Привязка к задаче';
$MESS['SMPI_TASK_URL_TEMPLATE'] = 'Шаблон URL для задачи';
$MESS['SMPI_TASK_URL_TEMPLATE_HINT'] = 'Доступен макрос #task_id# - ID задачи';
$MESS['SMPI_SELECT_TASK'] = 'Выбрать задачу';
