<?php

global $MESS;

$MESS['SMPI_PASSWORD_PROP'] = 'SIMAI: Пароль';
$MESS ['SP4I_IM'] = "Модуль мгновенных сообщений и уведомлений - не устанлвлен! Пожалуйста <a href='/bitrix/admin/module_admin.php' target='_blank'>установите</a> «Веб-мессенджер (im)»";
$MESS ['SP4I_USE_MODUL'] = "Использовать настройки модуля:";
$MESS ['SP4I_ACT'] = "Действия при показе пароля:";
$MESS ['SP4I_ACT0'] = "Ничего не делать";
$MESS ['SP4I_ACT1'] = "Уведомить";
$MESS ['SP4I_ACT2'] = "Запросить код доступа";
$MESS ['SP4I_ADMINCHECK'] = "Не применять ограничения просмотра к группе администраторов";
$MESS ['SP4I_METHOD'] = "Метод отправки кода доступа:";
$MESS ['SP4I_METHOD0'] = "Веб-мессенджер";
$MESS ['SP4I_METHOD1'] = "Электронная почта";
$MESS ['SP4I_ID'] = "ID чата для кода доступа:";
$MESS ['SP4I_ID_INFO'] = "Для получения ID, нужно в нужном чате отправить сообщение <b>/getChatId</b>";
$MESS ['SP4I_SEND'] = "Отправлять сообщение:";
$MESS ['SP4I_SEND0'] = "Как системное";
$MESS ['SP4I_SEND1'] = "От имени пользователя";
$MESS ['SP4I_SENDER'] = "Отправитель сообщения:";
$MESS ['SP4I_USER_EDIT'] = "Изменить";
$MESS ['SP4I_MAIL'] = "Email чата для кода доступа:";
$MESS ['SP4I_TEMPLATE'] = "Шаблон сообщения:";
$MESS ['SP4I_TEMPLATE2'] = "Шаблон сообщения просмотра:";
$MESS ['SP4I_TEMPLATE3'] = "Шаблон сообщения копирование:";
$MESS ['SP4I_TEMPLATE4'] = "Шаблон сообщения редактирование:";
$MESS['SHOW_PASSWORD_NOTICE_TEXT'] = 'Шаблон сообщения';
$MESS['SHOW_PASSWORD_NOTICE_TEXT_HINT'] = 'Доступны макросы:
<br>- #USER# - пользователь запросивший сообщение
<br>- #NAME# - название элемента, на который пользователь запросил сообщение
<br>- #LINK# - ссылка на элемент, на который запросил пользователь сообщение
<br>- #PASSWORD# - пароль';
$MESS['SHOW_PASSWORD_NOTICE_TEXT_DEFAULT'] = 'Пользователь #USER# запросил пароль для «#NAME#»
#LINK#';
$MESS['SHOW_PASSWORD_NOTICE_NEEDS_IM_MODULE'] = 'Для работы уведомлений необходимо наличие модуля "Веб-мессенджер"';

$MESS['SHOW_PASSWORD_GET_PASSWORD_BUTTON'] = 'Получить пароль';
$MESS ['SP4I_PLACEHOLDER_CODE'] = "Введите код";
$MESS ['SP4I_NEW_CODE'] = "Новый код успешно выслан.";
$MESS ['SP4I_ERROR_CODE'] = "Неверный код!";
$MESS ['SP4I_SHOW_PASSWORD'] = "Показать пароль";
