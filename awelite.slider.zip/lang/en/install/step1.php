<?php

$MESS['AWELITE_SLIDER_INSTALL'] = 'Install';
$MESS['AWELITE_SLIDER_HELLO'] = 'Module installation "Awelite: Universal Slider"';
$MESS['AWELITE_SLIDER_STEP_1'] = 'Welcome to the module installer!';
$MESS['AWELITE_SLIDER_STEP_2'] = 'During installation, the necessary information block is created';
$MESS['AWELITE_SLIDER_SUPPORT'] = 'If you have any questions during the installation of the module, you can send them by mail';