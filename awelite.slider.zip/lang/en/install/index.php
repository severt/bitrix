<?php

$MESS['MODULE_AWELITE_SLIDER_PARTHER_NAME'] = 'Awelite web';
$MESS['MODULE_NAME'] = 'Awelite: Slider';
$MESS['MODULE_DESCRIPTION'] = 'niversal Slider';
$MESS['PARAM_NOT_FOUND'] = 'Missing required parameter';
$MESS['IBLOCK_SECTION_NAME'] = 'Section';
$MESS['IBLOCK_SECTIONS_NAME'] = 'Sections';
$MESS['IBLOCK_ELEMENTS_NAME'] = 'Slides';
$MESS['IBLOCK_ELEMENT_NAME'] = 'Slide';
$MESS['IBLOCK_DEMO_SECTION_NAME'] = 'Test section';
$MESS['AWELITE_SLIDER_HELLO'] = 'Install module "Awelite: Slider"';
$MESS['AWELITE_IBLOCK_NAME_EN'] = 'Awelite: Slider';
$MESS['AWELITE_ELEMENT_1'] = 'Element 1';
$MESS['AWELITE_ELEMENT_2'] = 'Element 2';
$MESS['AWELITE_SLIDER_MORE'] = 'More';