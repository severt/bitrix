<?php
$MESS['AWELITE_SLIDER_THANK'] = 'Thank you for installing the module!';
$MESS['AWELITE_SLIDER_INSTRUCTION'] = 'Detailed instructions for the module are located';
$MESS['AWELITE_SLIDER_INSTRUCTION_LINK'] = 'here';
$MESS['AWELITE_SLIDER_SUPPORT_TEXT'] = 'All questions about the operation of the module, suggestions can be sent to the mail';
$MESS['AWELITE_SLIDER_GOODBYE'] = 'Sincerely, “Awelite” company';
$MESS['MODULE_SLIDER_IN_MENU'] = 'Back to menu';