<?php

$MESS['AWELITE_SLIDER_INSTALL'] = 'Установить';
$MESS['AWELITE_SLIDER_HELLO'] = 'Установка модуля "Awelite: Универсальный слайдер"';
$MESS['AWELITE_SLIDER_STEP_1'] = 'Добро пожаловать в установщик модуля!';
$MESS['AWELITE_SLIDER_STEP_2'] = 'Выбирая опцию "Создать инфоблок" создаётся Демо инфоблок с демонстрацией';
$MESS['AWELITE_SLIDER_SUPPORT'] = 'Если во время установки модуля возникнут вопросы, их можно отправить на почту';
$MESS['AWELITE_SLIDER_IBLOCK_INSTALL'] = 'Установить инфоблок';