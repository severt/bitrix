<?php

$MESS['MODULE_AWELITE_SLIDER_PARTHER_NAME'] = 'Авелайт';
$MESS['MODULE_NAME'] = 'Awelite: Слайдер';
$MESS['MODULE_DESCRIPTION'] = 'Универсальный слайдер';
$MESS['PARAM_NOT_FOUND'] = 'Не удалось найти параметр при вызове';
$MESS['IBLOCK_SECTION_NAME'] = 'Раздел';
$MESS['IBLOCK_SECTIONS_NAME'] = 'Разделы';
$MESS['IBLOCK_ELEMENTS_NAME'] = 'Слайды';
$MESS['IBLOCK_ELEMENT_NAME'] = 'Слайд';
$MESS['IBLOCK_PROPERTY_LINK_NAME'] = 'Ссылка';
$MESS['IBLOCK_PROPERTY_TEXT_LINK_NAME'] = 'Текст ссылки';
$MESS['IBLOCK_DEMO_SECTION_NAME'] = 'Демо раздел';
$MESS['AWELITE_SLIDER_HELLO'] = 'Установка модуля "Awelite: Слайдер"';
$MESS['AWELITE_IBLOCK_NAME'] = 'Awelite: Слайдер';
$MESS['AWELITE_ELEMENT_1'] = 'Элемент 1';
$MESS['AWELITE_ELEMENT_2'] = 'Элемент 2';
$MESS['AWELITE_SLIDER_MORE'] = 'Узнать подробности';
