<?php

$MESS['MODULE_AWELITE_SLIDER_IN_MENU'] = 'Вернуться в меню';
