<?php
$MESS['AWELITE_SLIDER_THANK'] = 'Спасибо за установку модуля!';
$MESS['AWELITE_SLIDER_INSTRUCTION'] = 'Подробная инструкция модуля находится';
$MESS['AWELITE_SLIDER_INSTRUCTION_LINK'] = 'здесь';
$MESS['AWELITE_SLIDER_SUPPORT_TEXT'] = 'Все вопросы по работе модуля, предложения можно направить на почту';
$MESS['AWELITE_SLIDER_GOODBYE'] = 'С уважением, компания “Авелайт”';
$MESS['MODULE_SLIDER_IN_MENU'] = 'Вернуться в меню';
$MESS['MODULE_SLIDER_CHECK_INSTALL_IBLOCK'] = 'Вы установили Демо-инфоблок';