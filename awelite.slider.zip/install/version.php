<?php


$arModuleVersion = array(
    "VERSION" => "1.0.0",
    "VERSION_DATE" => "2023-06-28 10:53:00"
);
?>

