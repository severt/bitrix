<?php

use Bitrix\Main\Localization\Loc;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
    "NAME" => Loc::getMessage('AWELITE_FAVORITE_DESCRIPTION_NAME'),
    "DESCRIPTION" => Loc::getMessage('AWELITE_FAVORITE_DESCRIPTION_DESCRIPTION'),
    "ICON" => "/images/news_list.gif",
    "PATH" => array(
		"ID" => "Awelite",
    	"NAME" => 'Awelite',
    	"SORT" => 10,
		"CHILD" => array(
			"ID" => "content",
			"NAME" => Loc::getMessage('AWELITE_FAVORITE_DESCRIPTION_PATH_NAME'),
			"SORT" => 10,
		),
    ),
);
