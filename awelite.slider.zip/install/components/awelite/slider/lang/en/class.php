<?php

$MESS = [
    'MODULE_INCLUDE_ERROR' => 'Error while including module #MODULE_NAME#',
    'PARAM_NOT_FOUND_ERROR' => 'Missing required parameter #PARAM_NAME#',
];