<?php

$MESS = [
    'MODULE_INCLUDE_ERROR' => 'Не удалось подключить модуль #MODULE_NAME#',
    'PARAM_NOT_FOUND_ERROR' => 'Не указан обязательный параметр #PARAM_NAME#',
    'ERROR_NOT_FOUND_IBLOCK' => 'API код инфоблока не корректен',
];