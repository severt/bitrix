<?php

namespace Awelite\Slider\Errors;

use Bitrix\Main\Error as BitrixError;
use Awelite\Slider\AweliteLocale;

class ParametersNotFoundError extends BitrixError implements \Serializable
{

    public function serialize()
    {
        return serialize($this);
    }

    public function unserialize($data)
    {
        return unserialize($data, ['allowed_classes' => [static::class]]);
    }
}