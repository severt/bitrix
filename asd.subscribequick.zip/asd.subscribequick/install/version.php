<?
$arModuleVersion = array(
	"VERSION" => "2.6.0",
	"VERSION_DATE" => "2015-06-22 09:28:36"
);
?>