<?php
$MESS ['CD_BSF_NAME'] = 'Форма быстрой подписки';
$MESS ['CD_BSF_DESCRIPTION'] = 'Включаемая в дизайн сайта быстрая форма подписки на рассылки.';
$MESS ['CD_BSF_SERVICE'] = 'Рассылки';