<?php
$MESS['ASD_SUBSCRIBEQUICK_PODPISYVATQ_NA_RUBRI'] = 'Подписывать на рубрики';
$MESS['ASD_SUBSCRIBEQUICK_PODKLUCITQ'] = 'Подключить';
$MESS['ASD_SUBSCRIBEQUICK_SHOW_RUBRICS'] = 'Показывать рубрики';
$MESS['ASD_SUBSCRIBEQUICK_NOT_CONFIRM'] = 'Подписывать без подтверждения';
$MESS['ASD_SUBSCRIBEQUICK_FORMAT'] = 'Формат подписки';