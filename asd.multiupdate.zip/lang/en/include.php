<?php
$MESS ['ASD_MULTIUPDATE_TAB'] = 'Множественная установка';
$MESS ['ASD_MULTIUPDATE_TITLE'] = 'Укажите ссылки на сторонние модули по одному на строку';
$MESS ['ASD_MULTIUPDATE_BUTTON'] = 'Установить';