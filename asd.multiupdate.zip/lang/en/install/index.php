<?php
$MESS ['ASD_MULTIUPDATE_MODULE_NAME'] = 'Множественная установка решений из Маркетплейс';
$MESS ['ASD_MULTIUPDATE_MODULE_DESCRIPTION'] = 'Позволяет установить несколько решений из Маркетплейс одновременно на ваш сайт.';
$MESS ['ASD_MULTIUPDATE_MODULE_SETTINGS'] = 'Перейти на <a href="settings.php?mid=asd.multiupdate&amp;lang=#LANG#">страницу настроек модуля</a>.';
$MESS ['ASD_MULTIUPDATE_PARTNER_NAME'] = 'Долганин Антон';
$MESS ['ASD_MULTIUPDATE_NEED_RIGHT_VER'] = 'Для установки данного решения необходима версия главного модуля #NEED# или выше.';
$MESS ['ASD_MULTIUPDATE_NEED_MODULES'] = 'Для установки данного решения необходимо наличие модуля #MODULE#.';