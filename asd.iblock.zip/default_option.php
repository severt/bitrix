<?
$asd_iblock_default_option = array(
	"enable_section_multiselect" => "Y",
	"keep_old_sections_for_copy" => "N",
	"multiple_copy" => "N"
);