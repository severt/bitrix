<?php
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/asd.iblock/tools/props_export.php');