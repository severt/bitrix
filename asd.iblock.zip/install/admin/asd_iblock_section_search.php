<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/asd.iblock/admin/asd_iblock_section_search.php");
