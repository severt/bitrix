<?
$arModuleVersion = array(
	"VERSION" => "4.9.0",
	"VERSION_DATE" => "2023-02-23 15:16:38"
);
?>