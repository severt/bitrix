<?
$arModuleVersion = array(
	"VERSION" => "4.9.4",
	"VERSION_DATE" => "2024-10-03 08:07:28"
);
?>