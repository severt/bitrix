<?
$MESS ['ASD_UT_SECTION_DESCR'] = 'Привязка к собственной секции';
$MESS ['ASD_UT_SECTION_NO_PARENT_IBLOCK'] = 'Нельзя привязать элемент к разделу другого инфоблока';
$MESS ['ASD_UT_SECTION_SETTING_TITLE'] = 'Дополнительные настройки';
$MESS ['ASD_UT_SECTION_SETTING_VIEW_MODE'] = 'Интерфейс выбора раздела';
$MESS ['ASD_UT_SECTION_SETTING_VIEW_MODE_SELECT'] = 'выпадающий список';
$MESS ['ASD_UT_SECTION_SETTING_VIEW_MODE_WINDOW'] = 'окно поиска';
$MESS ['ASD_UT_SECTION_SETTING_MAX_LEVEL'] = 'Максимальная глубина вложенности для выпадающего списка';
$MESS ['ASD_UT_SECTION_SETTING_MAX_LEVEL_DESCR'] = '0 - без ограничений';
$MESS ['ASD_UT_SECTION_MESS_TOP_LEVEL'] = 'верхний уровень';
?>