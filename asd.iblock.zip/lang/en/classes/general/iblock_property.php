<?php
$MESS ['ASD_UT_CHECKBOX_DESCR'] = 'Простой чекбокс (строка)';
$MESS ['ASD_UT_CHECKBOX_VALUE_EMPTY'] = 'любое';
$MESS ['ASD_UT_CHECKBOX_VALUE_N'] = 'N';
$MESS ['ASD_UT_CHECKBOX_VALUE_Y'] = 'Y';
$MESS ['ASD_UT_CHECKBOX_SETTING_TITLE'] = 'Настройки показа';
$MESS ['ASD_UT_CHECKBOX_SETTING_VALUE_N'] = 'Текст для пустого чекбокса';
$MESS ['ASD_UT_CHECKBOX_SETTING_VALUE_Y'] = 'Текст для нажатого чекбокса';
$MESS ['ASD_UT_CHECKBOX_NUM_DESCR'] = 'Простой чекбокс (число)';
$MESS ['ASD_UT_CHECKBOX_VALUE_NUM_EMPTY'] = 'любое';
$MESS ['ASD_UT_CHECKBOX_NUM_VALUE_N'] = '0';
$MESS ['ASD_UT_CHECKBOX_NUM_VALUE_Y'] = '1';
$MESS ['ASD_UT_CHECKBOX_NUM_SETTING_TITLE'] = 'Настройки показа';
$MESS ['ASD_UT_CHECKBOX_NUM_SETTING_VALUE_N'] = 'Текст для пустого чекбокса';
$MESS ['ASD_UT_CHECKBOX_NUM_SETTING_VALUE_Y'] = 'Текст для нажатого чекбокса';
$MESS ['ASD_UT_PALETTE_DESCR'] = 'Палитра';