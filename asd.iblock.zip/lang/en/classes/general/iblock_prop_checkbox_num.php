<?php
$MESS ['ASD_UT_CHECKBOX_NUM_DESCR'] = 'Простой чекбокс (число)';
$MESS ['ASD_UT_CHECKBOX_NUM_VALUE_EMPTY'] = 'любое';
$MESS ['ASD_UT_CHECKBOX_NUM_VALUE_ABSENT'] = "пусто";
$MESS ['ASD_UT_CHECKBOX_NUM_VALUE_N'] = 'Нет';
$MESS ['ASD_UT_CHECKBOX_NUM_VALUE_Y'] = 'Да';
$MESS ['ASD_UT_CHECKBOX_NUM_SETTING_TITLE'] = 'Настройки показа';
$MESS ['ASD_UT_CHECKBOX_NUM_SETTING_VALUE_N'] = 'Текст для пустого чекбокса';
$MESS ['ASD_UT_CHECKBOX_NUM_SETTING_VALUE_Y'] = 'Текст для нажатого чекбокса';
$MESS ['ASD_UT_CHECKBOX_NUM_VALUE_EMPTY_NEW_STYLE'] = 'Не указан';