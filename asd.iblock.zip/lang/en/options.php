<?
$MESS["ASD_IBLOCK_MAIN_TAB_SET"] = "Настройки";
$MESS["ASD_IBLOCK_MAIN_TAB_TITLE_SET"] = "Настройка параметров модуля";
$MESS["ASD_IBLOCK_OPERATION_SECTION_TITLE"] = "Операции с элементами и разделами";
$MESS["ASD_IBLOCK_OPTION_MULTIPLE_COPY"] = "Отдельная копия в каждый раздел:";
$MESS["ASD_IBLOCK_OPTION_KEEP_OLD_SECTIONS_FOR_COPY"] = "При копировании элемента в тот же инфоблок сохранять привязку к разделам:";
$MESS["ASD_IBLOCK_OPTIONS_BTN_SAVE"] = "Сохранить";
?>