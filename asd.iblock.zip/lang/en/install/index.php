<?php
$MESS ['ASD_IBLOCK_MODULE_NAME'] = 'Информационные блоки, инструменты';
$MESS ['ASD_IBLOCK_MODULE_DESCRIPTION'] = 'Модуль расширяет стандартный функционал модуля инфоблоков, добавляя удобные инструменты.';
$MESS ['ASD_PARTNER_NAME'] = 'Долганин Антон';
$MESS ['ASD_NEED_MODULES'] = 'Для установки данного решения необходимо наличие модуля #MODULE#.';
$MESS ['ASD_ERR_MODULE_VERSION_ABSENT'] = 'Невозможно определить версию модуля #MODULE_ID#. Установка невозможна.';
$MESS ['ASD_ERR_MODULE_MIN_VERSION'] = 'Необходимая версия модуля #MODULE_ID# - #VERSION# и выше. Установка невозможна';
$MESS ['ASD_ERR_MODULE_UNINSTALL_BLOCKED'] = 'Удаление заблокировано модулем #MODULE_ID#';
$MESS ['ASD_MOD_INST_OK'] = 'The module has been successfully installed.';
$MESS ['ASD_MOD_UNINST_OK'] = 'The module has been successfully removed.';
$MESS ['ASD_MOD_BACK'] = 'Back to List';