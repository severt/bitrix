<?php
$MESS ['ASD_UT_PALETTE_DESCR'] = 'Палитра';