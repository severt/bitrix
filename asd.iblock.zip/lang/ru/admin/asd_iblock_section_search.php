<?
$MESS["IBLOCK_SECSEARCH_TITLE"] = "Поиск раздела";
$MESS["IBLOCK_SECSEARCH_IBLOCK"] = "Информационный блок:";
$MESS["IBLOCK_SECSEARCH_PARENT_ID"] = "Раздел-родитель";
$MESS["IBLOCK_SECSEARCH_ALL_PARENTS"] = "(любой)";
$MESS["IBLOCK_SECSEARCH_ROOT_PARENT_ID"] = "Верхний уровень";
$MESS["IBLOCK_SECSEARCH_ID"] = "ID раздела";
$MESS["IBLOCK_SECSEARCH_NAME"] = "Название";
$MESS["IBLOCK_SECSEARCH_ACTIVE"] = "Активность";
$MESS["IBLOCK_SECSEARCH_SORT"] = "Сортировка";
$MESS["IBLOCK_SECSEARCH_CODE"] = "Символьный код";
$MESS["IBLOCK_SECSEARCH_XML_ID"] = "Внешний код";
$MESS["IBLOCK_SECSEARCH_ELEMENT_CNT"] = "Элементов";
$MESS["IBLOCK_SECSEARCH_SECTION_CNT"] = "Подразделов";
$MESS["IBLOCK_SECSEARCH_TIMESTAMP"] = "Дата изменения";
$MESS["IBLOCK_SECSEARCH_MODIFIED_BY"] = "Кто изменил";
$MESS["IBLOCK_SECSEARCH_DATE_CREATE"] = "Дата создания";
$MESS["IBLOCK_SECSEARCH_CREATED_BY"] = "Кто создал";
$MESS["IBLOCK_SECSEARCH_CHOOSE_IBLOCK"] = "Выберите информационный блок";
$MESS["IBLOCK_SECSEARCH_LIST"] = "Перейти в список подразделов";
$MESS["IBLOCK_SECSEARCH_USERINFO"] = "Посмотреть параметры пользователя";
$MESS["IBLOCK_SECSEARCH_SELECT"] = "Выбрать";
$MESS["IBLOCK_SECSEARCH_PARENT"] = "Раздел-родитель";
$MESS["IBLOCK_SECSEARCH_SECTIONS"] = "Разделы";
$MESS["IBLOCK_ROOT_SECTION_SELECT"] = "Корневой раздел";
$MESS["IBLOCK_ROOT_SECTION_SELECT_TITLE"] = "Выбрать корневой раздел";
$MESS["IBLOCK_SECSEARCH_ENTITY_NAME"] = "Инфоблок: #NAME#";
?>