<?php

return [
    'controllers' => [
        'value' => [
            'defaultNamespace' => '\\Sotbit\\SmartSearch\\Controller',
        ],
        'readonly' => true,
    ]
];