<?php
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/sotbit.smartsearch/admin/templates/replacement_list.php");