<?php
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/sotbit.smartsearch/admin/templates/synonyms_list.php");