<?php
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/sotbit.smartsearch/admin/settings.php");