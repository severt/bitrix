<?php
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/sotbit.smartsearch/admin/templates/synonym_list_ai.php");