<?php
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/sotbit.smartsearch/admin/templates/ielement_exclude_list.php");