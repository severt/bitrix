<?
$arModuleVersion = [
	"VERSION" => "1.1.1",
	"VERSION_DATE" => "2024-05-21 22:21:56"
];
?>