;(function () {
    SotbitAiChat = function (params) {
        this.chatWrap = document.getElementById(params.chatWrap);
        this.btnSend = this.chatWrap.querySelector('[data-type="send-message"]');
        this.btnReset = this.chatWrap.querySelector('[data-type="send-reset"]');
        this.inputMessage = this.chatWrap.querySelector('[data-type="input-message"]');
        this.responceVontainer = this.chatWrap.querySelector('[data-type="response"]');

        return this;
    }

    SotbitAiChat.prototype = {
        init: function () {
            this.initSendMessage();
            this.initReset();
        },

        initSendMessage: function () {
            this.btnSend?.addEventListener('click', this.sendMessage.bind(this));
        },

        initReset: function () {
            this.btnReset?.addEventListener('click', () => {
                this.showResult('');
                this.inputMessage.value = '';
            });
        },

        sendMessage: async function () {
            const mess = this.inputMessage.value.trim();
            if (!mess || mess.length === 0) {
                return;
            }

            BX.showWait();
            try {
                const result = await BX.ajax.runAction('sotbit:smartsearch.aicontroller.sendMessage', {
                    data: {
                        message: mess
                    },
                });

                this.showResult(result.data);
            } catch (e) {
                this.showResult(e.errors.map(i => i.message).join('\n'), true);
            } finally {
                BX.closeWait();
            }
        },

        showResult: function (result, error = false) {
            this.responceVontainer.innerText = result;
            this.responceVontainer.style = `color: ${error ? '#f54819;' : ''}`;
        },
    }
})();