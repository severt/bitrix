;(function () {
    SotbitSmartSearchSelect = function (params) {
        this.wrap = document.getElementById(params.wrap);
        this.btnAdd = this.wrap.querySelector('[data-type="add"]');
        this.input = this.wrap.querySelector('[data-type="input"]');
        this.items = params.items || [];
        this.inputName = params.inputName || 'searchselect';

        return this;
    }

    SotbitSmartSearchSelect.prototype = {
        init: function () {
            this.createItemsWrap();
            this.initAdd();
            this.renderItems();
            return this;
        },

        createItemsWrap: function () {
            this.itemsWrap = BX.create('DIV', {props: {className: 'smartselect-items-wrap'}});
            this.wrap.appendChild(this.itemsWrap);
        },

        initAdd: function () {
            this.wrap.addEventListener('submit', (e) => {
                e.preventDefault();
                this.actionAdd();
            })


            if (!this.btnAdd) {
                return;
            }

            this.btnAdd.addEventListener('click', () => {
                this.actionAdd();
            })
        },

        actionAdd: function () {
            const value = this.input.value.trim();
            if (value.length === 0) {
                return;
            }

            this.renderItem(value);

            this.input.value = '';
        },

        renderItems: function () {
            if (this.items.length === 0) {
                return;
            }

            this.items.forEach(item => this.renderItem(item));
        },

        renderItem: function (item) {
            const element = BX.create('span', {
                dataset: {
                    type: 'item-value'
                },
                text: item,
            });

            element.appendChild(BX.create('input', {
                attrs : {name : this.inputName + '[]', type: "hidden"},
                props : {
                    value : item
                },
                events: {
                    click: this.deleteItem.bind(this)
                },
            }));

            element.appendChild(BX.create('i', {
                html: "&times;",
                events: {
                    click: this.deleteItem.bind(this)
                },
            }));

            this.itemsWrap.appendChild(element);


        },

        deleteItem: function (e) {
            e.target.parentNode.remove();
        },

        getValues: function () {
            const items = this.itemsWrap.querySelectorAll('[data-type="item-value"]');
            return Array.from(items).map(item => item.firstChild.textContent);
        }
    }
})();