;(function () {
    SmartsearchListbox = {
        init: function (params) {
            this.leftBox = document.querySelector('[data-type="final-rank"]');
            this.rightBox = document.querySelector('[data-type="variant-rank"]');
            this.btnMove = document.querySelector('[data-type="btn-move"]');

            this.input = params.input;

            this.maxRank = document.getElementById('CUSTOM_RANK_WEIGHT');

            this.initRightChange();
            this.initLeftChange();
            this.initClickMove();
            this.initDragula();
            this.initSearch();
            this.setMaxRank();
        },

        initSearch: function () {
            const search = document.getElementById('listbox-search');
            search.addEventListener('input', () => {
                let searchValue = search.value;
                let fields = this.rightBox.querySelectorAll('[data-type="rank-item"]');

                if (fields !== undefined) {
                    for (let i = 0; i <= fields.length; i++) {
                        if (fields[i] !== undefined) {
                            if (fields[i].innerText.toLowerCase().indexOf(searchValue.toLowerCase()) === -1) {
                                fields[i].style.display = 'none';
                            } else {
                                fields[i].style.display = 'block';
                            }
                        }
                    }
                }

                const sections  = this.rightBox.querySelectorAll('.section');

                sections.forEach(section => {
                    const items =  section.querySelector('[data-type="rank-item"][style="display: block;"]');
                    section.style.display = items ? 'block': 'none';
                });
            })
        },

        initRightChange: function () {
            this.rightBox.addEventListener('click', (event) => {
                const item = event.target.closest('[data-type="rank-item"]');

                if (!item) {
                    return;
                }

                item.classList.toggle('change');
            });

            this.rightBox.addEventListener('dblclick', (event) => {
                const item = event.target.closest('[data-type="rank-item"]');

                if (!item) {
                    return;
                }

                this.moveItemToLeft(item);
            });
        },

        initLeftChange: function () {
            this.leftBox.addEventListener('click', (event) => {
                if (!event.target.closest('[data-type="delete"]')) {
                    return;
                }

                const item = event.target.closest('[data-type="rank-item"]');
                this.moveItemToRight(item);
            });
        },

        initClickMove: function () {
            this.btnMove.addEventListener('click', () => {
                this.rightBox.querySelectorAll('.change[data-type="rank-item"]').forEach((item) => {
                    this.moveItemToLeft(item)
                });
            });
        },

        initDragula: function () {
            this.drake = dragula([this.leftBox], {});
            this.drake.on('drop', (el) => {
                this.recountRank();
            });
        },

        moveItemToLeft: function (item) {
            const entityId = item.closest('.section').dataset.id;
            const html = `<span data-type="rank-item" title="${BX.message('move')}">
                                                <i></i>
                          <input type="hidden" name="${this.input}[CODE][]" value="${item.dataset.code}">
                          <input type="hidden" name="${this.input}[VALUE][]" value="0">
                          <input type="hidden" name="${this.input}[ENTITY][]" value="${entityId}">
                            <span data-type="name">${item.textContent}</span>
                        <i data-type="delete" title="${BX.message('delete')}"></i>
                    </span>`;


            this.leftBox.innerHTML = this.leftBox.innerHTML + html;
            item.remove();
            this.recountRank();
            this.setMaxRank();
        },

        moveItemToRight: function (item) {
            const entity = item.querySelector(`[name="${this.input}[ENTITY][]"]`).value;
            const name = item.querySelector('[data-type="name"]').textContent;
            const code = item.querySelector(`[name="${this.input}[CODE][]"]`).value;

            const rSection = this.rightBox.querySelector(`.section[data-id="${entity}"]`);
            if (!rSection) {
                return;
            }

            rSection.innerHTML = rSection.innerHTML + `<span data-type="rank-item" data-code="${code}">${name}</span>`;
            item.remove();
            this.recountRank();
            this.setMaxRank();
        },

        recountRank: function() {
            const itemsNode = this.leftBox.querySelectorAll('[data-type="rank-item"]');
            itemsNode.forEach((item, k) => {
                item.querySelector(`input[name="${this.input}[VALUE][]"]`).value = (k + 1);
            });
        },

        calcMaxRank: function () {
            let max = 1;
            let total = 0;
            const items = this.leftBox.querySelectorAll('[data-type="rank-item"]');

            for (i = 1; i <= items.length; i++) {
                max = max * 2;
                total += max;
            }

            return total;
        },

        setMaxRank: function () {
            this.maxRank.innerText = this.calcMaxRank();
        }
    }
})();

