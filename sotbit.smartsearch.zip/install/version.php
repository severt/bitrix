<?
$arModuleVersion = [
	"VERSION" => "1.1.2",
	"VERSION_DATE" => "2024-06-21 12:07:49"
];
?>