<?php
$MESS["CP_BST_FORM_PAGE"] = "Search results page (macro #SITE_DIR# available)";
$MESS["CP_BST_NUM_CATEGORIES"] = "Number of search categories";
$MESS["CP_BST_NUM_CATEGORY"] = "Category ##NUM#";
$MESS["CP_BST_CATEGORY_TITLE"] = "name of category";
$MESS["CP_BST_TOP_COUNT"] = "Number of results in each category";
$MESS["CP_BST_CHECK_DATES"] = "Search only in documents that are active by date";
$MESS["CP_BST_SHOW_OTHERS"] = "Show category \"other\"";
$MESS["CP_BST_OTHERS_CATEGORY"] = "Category \"other\"";
$MESS["CP_BST_USE_LANGUAGE_GUESS"] = "Enable auto-detection of keyboard layout";
$MESS["CP_BST_USE_SPEECH"] = "Enable voice search";
$MESS["USE_SPEECH_HINT"] = "Not supported by all browsers";
$MESS["CP_BST_ORDER"] = "Sorting results";
$MESS["CP_BST_ORDER_BY_DATE"] = "by date";
$MESS["CP_BST_ORDER_BY_RANK"] = "by relevance";
