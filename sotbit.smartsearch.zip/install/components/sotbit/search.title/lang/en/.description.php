<?php
$MESS["SOTBIT_SEARCH_TITLE_COMPONENT_NAME"] = "Sotbit: Smart search by titles";
$MESS["SOTBIT_SEARCH_TITLE_COMPONENT_DESCRIPTION"] = "Dynamic search results by title.";
$MESS["SOTBIT_COMPONENTS_TITLE"] = "Sotbit";
$MESS["MODULE_SMARTSEARCH"] = "Smart Search";
