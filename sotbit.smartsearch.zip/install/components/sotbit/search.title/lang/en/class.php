<?php
$MESS["SMARTSEARCH_TITLE_ERROR_MODULE"] = "Sotbit module: Smart search is not installed.";
$MESS["SMARTSEARCH_TITLE_ENABLE_MODULE"] = "Sotbit module: Smart search is disabled in administrative settings.";
$MESS["CC_BST_MODULE_NOT_INSTALLED"] = "The search module is not installed.";
$MESS["CC_BST_ALL_RESULTS"] = "All results";
$MESS["CC_BST_MORE"] = "rest";
$MESS["CC_BST_QUERY_PROMPT"] = "results for: <b>\"#query#\"</b>";
$MESS["CC_BST_ALL_QUERY_PROMPT"] = "All results for: <b>\"#query#\"</b>";
