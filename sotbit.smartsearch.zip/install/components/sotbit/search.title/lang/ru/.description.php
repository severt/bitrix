<?php
$MESS["SOTBIT_SEARCH_TITLE_COMPONENT_NAME"] = "Сотбит: Умный поиск по заголовкам";
$MESS["SOTBIT_SEARCH_TITLE_COMPONENT_DESCRIPTION"] = "Динамические результаты поиска по заголовкам.";
$MESS["SOTBIT_COMPONENTS_TITLE"] = "Сотбит";
$MESS["MODULE_SMARTSEARCH"] = "Умный поиск";
?>