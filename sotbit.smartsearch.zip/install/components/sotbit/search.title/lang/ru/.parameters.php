<?
$MESS["CP_BST_FORM_PAGE"] = "Страница выдачи результатов поиска (доступен макрос #SITE_DIR#)";
$MESS["CP_BST_NUM_CATEGORIES"] = "Количество категорий поиска";
$MESS["CP_BST_NUM_CATEGORY"] = "Категория ##NUM#";
$MESS["CP_BST_CATEGORY_TITLE"] = "Название категории";
$MESS["CP_BST_TOP_COUNT"] = "Количество результатов в каждой категории";
$MESS["CP_BST_CHECK_DATES"] = "Искать только в активных по дате документах";
$MESS["CP_BST_SHOW_OTHERS"] = "Показывать категорию \"прочее\"";
$MESS["CP_BST_OTHERS_CATEGORY"] = "Категория \"прочее\"";
$MESS["CP_BST_USE_LANGUAGE_GUESS"] = "Включить автоопределение раскладки клавиатуры";
$MESS["CP_BST_USE_SPEECH"] = "Включить голосовой поиск";
$MESS["USE_SPEECH_HINT"] = "Поддерживается не всеми браузерами";
$MESS["CP_BST_ORDER"] = "Сортировка результатов";
$MESS["CP_BST_ORDER_BY_DATE"] = "по дате";
$MESS["CP_BST_ORDER_BY_RANK"] = "по релевантности";
?>