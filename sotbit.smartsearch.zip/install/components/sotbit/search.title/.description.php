<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
use Bitrix\Main\Localization\Loc;
Loc::loadMessages(__FILE__);
$arComponentDescription = array(
    "NAME" => Loc::getMessage("SOTBIT_SEARCH_TITLE_COMPONENT_NAME"),
    "DESCRIPTION" => Loc::getMessage("SOTBIT_SEARCH_TITLE_COMPONENT_DESCRIPTION"),
    "COMPLEX" => "N",
    "PATH" => array(
        "ID" => "sotbit",
        "NAME" =>  Loc::getMessage("SOTBIT_COMPONENTS_TITLE"),
        "CHILD" => array(
            "ID" => "sotbit.smartsearch",
            "NAME" => Loc::getMessage("MODULE_SMARTSEARCH")
        )
    ),
);
?>