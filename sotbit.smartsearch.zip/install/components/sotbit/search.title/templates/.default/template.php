<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;

$this->setFrameMode(true);

$INPUT_ID = trim($arParams["~INPUT_ID"]);
if ($INPUT_ID == '') {
    $INPUT_ID = "smartsearch-title-input";
}
$INPUT_ID = CUtil::JSEscape($INPUT_ID);

$CONTAINER_ID = trim($arParams["~CONTAINER_ID"]);
if ($CONTAINER_ID == '') {
    $CONTAINER_ID = "smartsearch-title";
}
$CONTAINER_ID = CUtil::JSEscape($CONTAINER_ID);
?>

<div id="<?= $CONTAINER_ID ?>" class="smartsearch-title__wrap">
    <form action="<?= $arResult["FORM_ACTION"] ?>">
        <div class="smartsearch-title__input-conteiner">
            <input id="<?= $INPUT_ID ?>" type="text" name="q" value="<?= htmlspecialcharsbx($_REQUEST["q"] ?? '') ?>"
                   placeholder="<?=$arParams['PLACEHOLDER_INPUT'] ?: Loc::getMessage('CT_BST_PLACEHOLDER')?>" autocomplete="off" class="smartsearch-title__input"/>
            <i id="smartsearch-title-clear" class="search-title__icon" title="<?=Loc::getMessage('CT_BST_CLEAR_SEARCH')?>">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4.39705 4.55379L4.46967 4.46967C4.73594 4.2034 5.1526 4.1792 5.44621 4.39705L5.53033 4.46967L12 10.939L18.4697 4.46967C18.7626 4.17678 19.2374 4.17678 19.5303 4.46967C19.8232 4.76256 19.8232 5.23744 19.5303 5.53033L13.061 12L19.5303 18.4697C19.7966 18.7359 19.8208 19.1526 19.6029 19.4462L19.5303 19.5303C19.2641 19.7966 18.8474 19.8208 18.5538 19.6029L18.4697 19.5303L12 13.061L5.53033 19.5303C5.23744 19.8232 4.76256 19.8232 4.46967 19.5303C4.17678 19.2374 4.17678 18.7626 4.46967 18.4697L10.939 12L4.46967 5.53033C4.2034 5.26406 4.1792 4.8474 4.39705 4.55379L4.46967 4.46967L4.39705 4.55379Z" fill="currentColor"/>
                </svg>
            </i>
            <?if ($arParams['USE_SPEECH'] === 'Y'):?>
                <i id="smartsearch-title-speech" class="search-title__icon" title="<?=Loc::getMessage('CT_BST_CLEAR_SPEECH')?>">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M18.25 11C18.6297 11 18.9435 11.2822 18.9932 11.6482L19 11.75V12.25C19 15.8094 16.245 18.7254 12.751 18.9817L12.75 21.25C12.75 21.6642 12.4142 22 12 22C11.6203 22 11.3065 21.7178 11.2568 21.3518L11.25 21.25L11.25 18.9818C7.83323 18.7316 5.12283 15.938 5.00406 12.4863L5 12.25V11.75C5 11.3358 5.33579 11 5.75 11C6.1297 11 6.44349 11.2822 6.49315 11.6482L6.5 11.75V12.25C6.5 15.077 8.73445 17.3821 11.5336 17.4956L11.75 17.5H12.25C15.077 17.5 17.3821 15.2656 17.4956 12.4664L17.5 12.25V11.75C17.5 11.3358 17.8358 11 18.25 11ZM12 2C14.2091 2 16 3.79086 16 6V12C16 14.2091 14.2091 16 12 16C9.79086 16 8 14.2091 8 12V6C8 3.79086 9.79086 2 12 2ZM12 3.5C10.6193 3.5 9.5 4.61929 9.5 6V12C9.5 13.3807 10.6193 14.5 12 14.5C13.3807 14.5 14.5 13.3807 14.5 12V6C14.5 4.61929 13.3807 3.5 12 3.5Z" fill="currentColor"/>
                    </svg>
                </i>
            <?endif;?>
        </div>
    </form>
</div>

<style>
    .smartsearch-title__wrap,
    .smartsearch-title__result {
        --main-color: <?=$arParams['MAIN_COLOR'] ?: '#8450DB'?>;
        --color-gray-200: #F3F5F6;
        --color-gray-500: #ABB5BE;
    }
</style>

<script>
    BX.ready(function () {
        new JCTitleSearch({
            'AJAX_PAGE': '<?= CUtil::JSEscape(POST_FORM_ACTION_URI)?>',
            'CONTAINER_ID': '<?= $CONTAINER_ID?>',
            'INPUT_ID': '<?= $INPUT_ID?>',
            'CLEAR_ID': 'smartsearch-title-clear',
            'SPEECH_ID': '<?=$arParams['USE_SPEECH'] === 'Y' ? 'smartsearch-title-speech' : ''?>',
            'MIN_QUERY_LEN': 2
        });
    });
</script>
