<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}
if (empty($arResult["CATEGORIES"]) || !$arResult['CATEGORIES_ITEMS_EXISTS']) {
    return;
}

$useGroups = false;
?>

    <div class="smartsearch-title__result">
        <? foreach ($arResult["CATEGORIES"] as $category_id => $arCategory): ?>
            <div class="result-group">
                <? if ($arParams['SHOW_GROUPS'] === 'Y'):?>
                    <?
                    $useGroups = $useGroups || !empty($arCategory['TITLE']);
                    ?>
                    <span class="result-group__title"><?= $arCategory['TITLE'] ?></span>
                <? endif; ?>
                <div class="smartsearch-title__items <?= $category_id === "all" ? 'm-auto' : '' ?>">
                    <? foreach ($arCategory["ITEMS"] as $i => $arItem): ?>
                        <?
                        if ($arItem['TYPE'] === 'all') {
                            continue;
                        }
                        ?>
                        <? if ($category_id === "all"): ?>
                            <div class="smartsearch-title__result-item">
                                <a href="<?= $arItem["URL"] ?>" class="all-result"><?= $arItem["NAME"] ?></a>
                            </div>
                        <? elseif (isset($arResult["ELEMENTS"][$arItem["ITEM_ID"]])):
                            $arElement = $arResult["ELEMENTS"][$arItem["ITEM_ID"]]; ?>
                            <div class="smartsearch-title__result-item">
                                <div class="item-img">
                                    <? if (is_array($arElement["PICTURE"])): ?>
                                        <a href="<?= $arItem["URL"] ?>">
                                            <img src="<?= $arElement["PICTURE"]["src"] ?>" alt="">
                                        </a>
                                    <? endif; ?>
                                </div>
                                <div>
                                    <a href="<?= $arItem["URL"] ?>" class="item-name">
                                        <?= $arItem["NAME"] ?>
                                    </a>
                                    <?
                                    foreach ($arElement["PRICES"] as $code => $arPrice) {
                                        if ($arPrice["MIN_PRICE"] !== "Y") {
                                            continue;
                                        }

                                        if ($arPrice["CAN_ACCESS"]) {
                                            if ($arPrice["DISCOUNT_VALUE"] < $arPrice["VALUE"]):?>
                                                <div class="item-price">
                                                    <?= $arPrice["PRINT_DISCOUNT_VALUE"] ?>
                                                    <span class="old"><?= $arPrice["PRINT_VALUE"] ?></span>
                                                </div>

                                            <? else: ?>
                                                <div class="item-price">
                                                    <?= $arPrice["PRINT_VALUE"] ?>
                                                </div>
                                            <?endif;
                                        }
                                        if ($arPrice["MIN_PRICE"] === "Y") {
                                            break;
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        <? elseif ($arItem['IS_SECTION'] === 'Y'):
                            $arElement = $arResult["SECTIONS"][$arItem["REAL_ID"]]; ?>
                            <div class="smartsearch-title__result-item">
                                <div class="item-img">
                                    <? if (is_array($arElement["PICTURE"])): ?>
                                        <a href="<?= $arItem["URL"] ?>">
                                            <img src="<?= $arElement["PICTURE"]["src"] ?>" alt="">
                                        </a>
                                    <? endif; ?>
                                </div>
                                <div>
                                    <a href="<?= $arItem["URL"] ?>" class="item-name"><?= $arItem["NAME"] ?></a>
                                    <? if ($arItem['SECTION_CHAIN']): ?>
                                        <div class="section">
                                            <?= $arItem['SECTION_CHAIN'] ?>
                                        </div>
                                    <? endif; ?>
                                </div>
                            </div>
                        <? else: ?>
                            <div class="smartsearch-title__result-item">
                                <div class="item-img"></div>
                                <div>
                                    <a href="<?= $arItem["URL"] ?>" class="item-name"><?= $arItem["NAME"] ?></a>
                                </div>
                            </div>
                        <? endif; ?>
                    <? endforeach; ?>
                </div>
            </div>
        <? endforeach; ?>
    </div>

<?if($useGroups === true):
    ?>
    <style>
        .smartsearch-title__result .result-group__title {
            width: 150px;
        }
    </style>
<?endif;?>