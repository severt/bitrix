<?
$MESS["CT_BST_PLACEHOLDER"] = "Поиск";
$MESS["CT_BST_CLEAR_SEARCH"] = "Очистить поиск";
$MESS["CT_BST_CLEAR_SPEECH"] = "Продиктовать";
?>