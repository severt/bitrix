<?
$MESS["CT_BST_SEARCH_BUTTON"] = "Search";
$MESS["CT_BST_CLEAR_SEARCH"] = "Clear search";
$MESS["CT_BST_CLEAR_SPEECH"] = "Speech";
?>