<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Loader,
    Bitrix\Main\Localization\Loc,
    Sotbit\SmartSearch\General\SearchTitle,
    Sotbit\SmartSearch\Helper\Config;


class SotbitSmartSearchTitle extends CBitrixComponent
{
    protected $originalQuery = '';
    protected $query = '';
    protected array $findItems = [];
    protected array $findItemsId = [];
    protected array $arOthersFilter;
    protected array $correctionSettings;
    protected SearchTitle $searchTitle;

    public function __construct($component = null)
    {
        parent::__construct($component);
        $this->arOthersFilter = ["LOGIC" => "OR"];
    }

    public function onPrepareComponentParams($arParams)
    {
        $arParams["PAGE"] = $arParams["PAGE"] ?: "#SITE_DIR#search/index.php";
        $arParams["NUM_CATEGORIES"] = intval($arParams["NUM_CATEGORIES"]);
        if ($arParams["NUM_CATEGORIES"] <= 0) {
            $arParams["NUM_CATEGORIES"] = 1;
        }

        $arParams["TOP_COUNT"] = intval($arParams["TOP_COUNT"]);
        if ($arParams["TOP_COUNT"] <= 0) {
            $arParams["TOP_COUNT"] = 5;
        }

        return $arParams;
    }

    public function executeComponent()
    {
        global $APPLICATION;

        if (!(Loader::includeModule('sotbit.smartsearch') && \SotbitSmartSearch::getDemo())) {
            ShowError(Loc::getMessage('SMARTSEARCH_TITLE_ERROR_MODULE'));
            return;
        }

        if (!\SotbitSmartSearch::isEnable()) {
            ShowError(Loc::getMessage('SMARTSEARCH_TITLE_ENABLE_MODULE'));
            return;
        }

        if (!Loader::includeModule("search")) {
            return;
        }

        $this->correctionSettings = Config::getCorrectionsOptions();
        $this->getQuery();
        $request = $this->request->getValues();

        if (!empty($this->query)
            && $request['ajax_call'] === 'y'
            && (!isset($request['INPUT_ID']) || $request['INPUT_ID'] == $this->arParams['INPUT_ID'])
        ) {
            $this->modifyQuery();
            $this->getAltQuery();
            $this->searchAction();
            $this->searchOther();
            $this->generateAllLink();

            $this->arResult['CATEGORIES_ITEMS_EXISTS'] = false;
            foreach ($this->arResult["CATEGORIES"] as $category) {
                if (!empty($category['ITEMS']) && is_array($category['ITEMS'])) {
                    $this->arResult['CATEGORIES_ITEMS_EXISTS'] = true;
                    break;
                }
            }
        }

        $this->arResult["FORM_ACTION"] = htmlspecialcharsbx(str_replace("#SITE_DIR#", SITE_DIR,
            $this->arParams["PAGE"]));

        if (
            isset($request["ajax_call"])
            && $request["ajax_call"] === "y"
            && (
                !isset($request["INPUT_ID"])
                || $request["INPUT_ID"] == $this->arParams["INPUT_ID"]
            )
        ) {
            $APPLICATION->RestartBuffer();

            if (!empty($this->query)) {
                $this->IncludeComponentTemplate('ajax');
            }
            CMain::FinalActions();
            die();
        } else {
            $APPLICATION->AddHeadScript($this->GetPath() . '/script.js');
            CUtil::InitJSCore(array('ajax'));

            $this->includeComponentTemplate();
        }
    }

    protected function getQuery()
    {
        if ($this->request->isPost() && $this->request->get('q')) {
            $this->originalQuery = $this->query = \Bitrix\Main\Text\Encoding::convertEncodingToCurrent(urldecode($this->request->get('q')));
        }
    }

    protected function searchAction()
    {
//        CUtil::decodeURIComponent($this->query);

        $this->searchTitle = new SearchTitle();

//        $arResult["phrase"] = stemming_split($query, LANGUAGE_ID);

        for ($i = 0; $i < $this->arParams["NUM_CATEGORIES"]; $i++) {
            $this->findItems = [];

            if ($this->isCustomSection($i)) {
                continue;
            }

            if (!$category_title = $this->getCategoryTitle($i)) {
                continue;
            }

            $exFILTER = $this->getCategoryFilter($i);

            $this->sendBaseSearch($exFILTER);
            $this->sendSearchWithReplace($exFILTER);

            if (!empty($this->findItems)) {
                $this->prepareItemsName();
                $this->arResult["CATEGORIES"][$i] = [
                    "TITLE" => $category_title,
                    "ITEMS" => $this->findItems
                ];
            }
        }
    }

    protected function prepareItemsName()
    {
        $sectionsId = [];
        $elementsId = [];
        foreach (array_column($this->findItems, 'ITEM_ID') as $id) {
            if (mb_strstr($id, 'S') !== false) {
                $sectionsId[] = str_replace('S', '', $id);
                continue;
            }

            $elementsId[] = $id;
        }

        $originalNames = \Sotbit\SmartSearch\Helper\IblockTools::getRealEntitiesName($elementsId, $sectionsId);

        foreach ($this->findItems as &$item) {
            if (!($item['ITEM_ID'] && $originalNames[$item['ITEM_ID']])) {
                continue;
            }

            $item['MODIFY_NAME'] = $item['NAME'];
            $item['NAME'] = \SotbitSmartSearchHelper::formatSearchTitle($item['NAME'], $originalNames[$item['ITEM_ID']], $this->originalQuery);
        }
    }

    protected function getAltQuery()
    {
        if ($this->arParams["USE_LANGUAGE_GUESS"] !== "N") {
            $arLang = CSearchLanguage::GuessLanguage($this->query);
            if (is_array($arLang) && $arLang["from"] != $arLang["to"]) {
                $altQuery = CSearchLanguage::ConvertKeyboardLayout($this->query, $arLang["from"], $arLang["to"]);
                if ($altQuery) {
                    $this->originalQuery = $this->query = $altQuery;
                    $this->modifyQuery();
                }
            }
        }
    }

    protected function modifyQuery()
    {
        $this->query = \SotbitSmartSearchHelper::removePrepositions($this->query);
        $this->query = \SotbitSmartSearchHelper::modifySearchString($this->query);
        $this->query = \SotbitSmartSearchHelper::manualReplace($this->query);
    }

    protected function isCustomSection($i)
    {
        $bCustom = true;
        if (is_array($this->arParams["CATEGORY_" . $i])) {
            foreach ($this->arParams["CATEGORY_" . $i] as $categoryCode) {
                if ((mb_strpos($categoryCode, 'custom_') !== 0)) {
                    $bCustom = false;
                    break;
                }
            }
        } else {
            $bCustom = (mb_strpos($this->arParams["CATEGORY_" . $i], 'custom_') === 0);
        }

        return $bCustom;
    }

    protected function getCategoryTitle($i)
    {
        $category_title = trim($this->arParams["CATEGORY_" . $i . "_TITLE"]);
        if (empty($category_title)) {
            if (is_array($this->arParams["CATEGORY_" . $i])) {
                $category_title = implode(", ", $this->arParams["CATEGORY_" . $i]);
            } else {
                $category_title = trim($this->arParams["CATEGORY_" . $i]);
            }
        }

        return htmlspecialcharsbx($category_title);
    }

    protected function getCategoryFilter($i)
    {
        $filter = \CSearchParameters::ConvertParamsToFilter($this->arParams, "CATEGORY_" . $i);
        $filter['LOGIC'] = 'OR';
        $exFILTER[] = $filter;

        if ($this->arParams["CHECK_DATES"] === "Y") {
            $exFILTER["CHECK_DATES"] = "Y";
        }

        return $this->arOthersFilter[] = $exFILTER;
    }

    protected function searchOther()
    {
        if ($this->arParams["SHOW_OTHERS"] !== "Y") {
            return;
        }

        $arItems = [];
        if ($this->sendSearchRequest()) {
            while (($ar = $this->searchTitle->Fetch()) && count($arItems) < $this->arParams["TOP_COUNT"]) {
                $arItems[] = array(
                    "NAME" => $ar["NAME"],
                    "URL" => htmlspecialcharsbx($ar["URL"]),
                    "MODULE_ID" => $ar["MODULE_ID"],
                    "PARAM1" => $ar["PARAM1"],
                    "PARAM2" => $ar["PARAM2"],
                    "ITEM_ID" => $ar["ITEM_ID"],
                );
            }
        }

        if ($arItems) {
            $this->arResult["CATEGORIES"]["others"] = array(
                "TITLE" => htmlspecialcharsbx($this->arParams["CATEGORY_OTHERS_TITLE"]),
                "ITEMS" => $arItems,
            );
        }
    }

    protected function generateAllLink()
    {
        if (!empty($this->arResult["CATEGORIES"])) {
            $this->arResult["CATEGORIES"]["all"] = array(
                "TITLE" => "",
                "ITEMS" => [
                    0 => [
                        "NAME" => Loc::getMessage("CC_BST_ALL_RESULTS"),
                        "URL" => CHTTP::urlAddParams(
                            str_replace("#SITE_DIR#", SITE_DIR, $this->arParams["PAGE"])
                            , ["q" => $this->originalQuery]
                            , array("encode" => true)
                        )
                    ]
                ]
            );
        }
    }

    protected function sendBaseSearch($filter)
    {
        if (count($this->findItems) >= $this->arParams["TOP_COUNT"]) {
            return;
        }

        if (!empty($this->findItems)) {
            $filter["!=ITEM_ID"] = array_column($this->findItems, 'ITEM_ID');
        }

        if ($this->sendSearchRequest($filter, false)) {
            while ($ar = $this->searchTitle->Fetch()) {
                $this->findItems[] = array(
                    "NAME" => $ar["NAME"],
                    "URL" => htmlspecialcharsbx($ar["URL"]),
                    "MODULE_ID" => $ar["MODULE_ID"],
                    "PARAM1" => $ar["PARAM1"],
                    "PARAM2" => $ar["PARAM2"],
                    "ITEM_ID" => $ar["ITEM_ID"],
                );

                if (count($this->findItems) === $this->arParams["TOP_COUNT"]) {
                    $url = \CHTTP::urlAddParams(
                            str_replace("#SITE_DIR#", SITE_DIR, $this->arParams["PAGE"])
                            , ["q" => $this->originalQuery]
                            , array("encode" => true)
                        ) . \CSearchTitle::MakeFilterUrl("f", $filter);

                    $this->findItems[] = array(
                        "NAME" => Loc::getMessage("CC_BST_MORE"),
                        "URL" => htmlspecialcharsex($url),
                        "TYPE" => "all"
                    );
                    break;
                }
            }
        }
    }

    protected function sendSearchWithReplace($filter)
    {
        if (!$this->checkUseCorrection()) {
            return;
        }

        $spellResult = \SotbitSmartSearchHelper::correctSpelling($this->query, 'yandex_speller', $filter);
        if ($this->isDiffQuery($spellResult)) {
            $this->query = \SotbitSmartSearchHelper::manualReplace($spellResult);
            $this->sendBaseSearch($filter);
        }

        if (!$this->checkUseCorrection()) {
            return;
        }

        if ($spellResult = \SotbitSmartSearchHelper::correctionBasedIndexedWords($this->query, $filter)) {
            $arQueryVariants = SotbitSmartSearchHelper::getWordSet($spellResult);
            foreach ($arQueryVariants as $str) {
                $this->query = $str;
                $this->sendBaseSearch($filter);
            }
        }
    }

    protected function sendSearchRequest($filter = [], $exclude = true): bool
    {
        $this->searchTitle->setMinWordLength($this->request->get('l'));
        return $this->searchTitle->Search(
            $this->query
            , $this->arParams["TOP_COUNT"]
            , $filter ?: $this->arOthersFilter
            , $exclude
            , $this->arParams["ORDER"]
        );
    }

    protected function isDiffQuery(string $str)
    {
        return $this->query !== $str;
    }

    protected function checkUseCorrection()
    {
        if (count($this->findItems) >= $this->arParams["TOP_COUNT"]) {
            return false;
        }

        if (!$this->correctionSettings['USE_CORRECTION']) {
            return false;
        }

        if (!!$this->correctionSettings['KEEP_SEARCH'] === false && !empty($this->findItems) && (count($this->findItems) < $this->arParams["TOP_COUNT"])) {
            return false;
        }

        return true;
    }
}