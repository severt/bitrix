<?php
$MESS["TP_BST_PLACEHOLDER_INPUT"] = "Плейсхолдер для строки поиска";
$MESS["TP_BST_MAIN_COLOR"] = "Основной цвет";
$MESS["TP_BST_HIDE_INPUT"] = "Скрыть строку поиска";
?>