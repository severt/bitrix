<?php
$MESS["TP_BST_PLACEHOLDER_INPUT"] = "Placeholder for search string";
$MESS["TP_BST_MAIN_COLOR"] = "Basic color";
$MESS["TP_BST_HIDE_INPUT"] = "Hide search bar";
?>