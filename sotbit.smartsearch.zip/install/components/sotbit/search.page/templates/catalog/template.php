<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
global $APPLICATION;

use Bitrix\Main\Localization\Loc;
?>

<div class="smartsearch-page">
    <form action="" method="get">
        <?if ($arParams['HIDE_INPUT'] !== 'Y'):?>
            <div class="smartsearch-page__input-container">
                <input placeholder="<?= $arParams["INPUT_PLACEHOLDER"] ?>" type="text" name="q" class="smartsearch-page__input"
                       value="<?= $arResult["REQUEST"]["QUERY"] ?>" size="50"/>
            </div>
        <?endif;?>

        <input type="hidden" name="how" value="<? echo $arResult["REQUEST"]["HOW"] == "d" ? "d" : "r" ?>"/>
        <? if ($arParams["SHOW_WHEN"]): ?>
            <br/><a class="search-page-params" href="#"
                    onclick="switchSearchParams()"><? echo Loc::getMessage('CT_BSP_ADDITIONAL_PARAMS') ?></a>
            <div id="search_params" class="search-page-params"
                 style="display:<? echo $arResult["REQUEST"]["FROM"] || $arResult["REQUEST"]["TO"] ? 'block' : 'none' ?>">
                <? $APPLICATION->IncludeComponent(
                    'bitrix:main.calendar',
                    '',
                    array(
                        'SHOW_INPUT' => 'Y',
                        'INPUT_NAME' => 'from',
                        'INPUT_VALUE' => $arResult["REQUEST"]["~FROM"],
                        'INPUT_NAME_FINISH' => 'to',
                        'INPUT_VALUE_FINISH' => $arResult["REQUEST"]["~TO"],
                        'INPUT_ADDITIONAL_ATTR' => 'size="10"',
                    ),
                    null,
                    array('HIDE_ICONS' => 'Y')
                ); ?>
            </div>
        <? endif ?>
    </form>
    <br/>

    <? if (isset($arResult["REQUEST"]["ORIGINAL_QUERY"])):
        ?>
        <div class="search-language-guess">
            <? echo Loc::getMessage("CT_BSP_KEYBOARD_WARNING", array("#query#" => '<a href="' . $arResult["ORIGINAL_QUERY_URL"] . '">' . $arResult["REQUEST"]["ORIGINAL_QUERY"] . '</a>')) ?>
        </div><br/><?
    endif; ?>

    <? if (is_array($arResult["SEARCH_HISTORY"]) && count($arResult["SEARCH_HISTORY"]) > 0): ?>
        <div class="ag-spage-history">
            <?= Loc::getMessage("SEARCH_HISTORY_TITLE") ?>
            <? foreach ($arResult["SEARCH_HISTORY"] as $k => $v):
                if ($k > 0) echo ', '; ?><a href="?q=<?= $v ?>"><?= $v ?></a><?
            endforeach ?>
        </div>
    <? endif; ?>

    <? if (is_array($arResult["CLARIFY_SECTION"]) && count($arResult["CLARIFY_SECTION"]) > 1): ?>
        <div class="ag-spage-clarify-list">
            <div class="ag-spage-clarify-title"><?= Loc::getMessage("AG_SPAGE_CLARIFY_SECTION"); ?></div>

            <a class="ag-spage-clarify-item <? if ($arResult["SELECTED_SECTION"] == "") echo 'selected'; ?>"
               href="<?= $APPLICATION->GetCurPageParam("", array("section")) ?>"><?= Loc::getMessage("AG_SPAGE_CLARIFY_SECTION_ALL"); ?></a>

            <? foreach ($arResult["CLARIFY_SECTION"] as $section): ?>
                <a class="ag-spage-clarify-item <? if ($arResult["SELECTED_SECTION"] == $section["ID"]) echo 'selected'; ?>"
                   href="<?= $APPLICATION->GetCurPageParam('section=' . $section["ID"], array("section")) ?>"><?= $section["NAME"] ?>
                    (<?= $section["CNT"] ?>)</a>
            <? endforeach; ?>
        </div>
    <? endif; ?>
</div>

<style>
    .smartsearch-page {
        --main-color: <?=$arParams['MAIN_COLOR'] ?: '#8450DB'?>;
        --color-gray-200: #F3F5F6;
        --color-gray-500: #ABB5BE;
    }
</style>