function switchSearchParams() {
    var sp = document.getElementById('search_params');
    var flag;

    if (sp.style.display == 'none') {
        flag = false;
        sp.style.display = 'block'
    } else {
        flag = true;
        sp.style.display = 'none';
    }

    var from = document.getElementsByName('from');
    for (var i = 0; i < from.length; i++)
        if (from[i].type.toLowerCase() == 'text')
            from[i].disabled = flag

    var to = document.getElementsByName('to');
    for (var i = 0; i < to.length; i++)
        if (to[i].type.toLowerCase() == 'text')
            to[i].disabled = flag

    return false;
}