<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

use Bitrix\Main\Localization\Loc;

$arTemplateParameters = array(
	"PLACEHOLDER_INPUT" => array(
		"NAME" => Loc::getMessage("TP_BST_PLACEHOLDER_INPUT"),
		"TYPE" => "STRING",
		"PARENT" => 'VISUAL'
	),
    "HIDE_INPUT" => array(
        "NAME" => Loc::getMessage("TP_BST_HIDE_INPUT"),
        "TYPE" => "CHECKBOX",
        "DEFAULT" => "Y",
        "REFRESH" => "Y",
    ),
	"MAIN_COLOR" => array(
		"NAME" => Loc::getMessage("TP_BST_MAIN_COLOR"),
		"TYPE" => "STRING",
		"PARENT" => 'VISUAL'
	),
);