<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

use Bitrix\Main\Localization\Loc;

$arTemplateParameters = array(
	"PLACEHOLDER_INPUT" => array(
		"NAME" => Loc::getMessage("TP_BST_PLACEHOLDER_INPUT"),
		"TYPE" => "STRING",
		"PARENT" => 'VISUAL'
	),
	"MAIN_COLOR" => array(
		"NAME" => Loc::getMessage("TP_BST_MAIN_COLOR"),
		"TYPE" => "STRING",
		"PARENT" => 'VISUAL'
	),
	"USE_SUGGEST" => Array(
		"NAME" => Loc::getMessage("TP_BSP_USE_SUGGEST"),
		"TYPE" => "CHECKBOX",
		"DEFAULT" => "N",
	),
);

if(COption::GetOptionString("search", "use_social_rating") == "Y")
{
	$arTemplateParameters["SHOW_RATING"] = Array(
		"NAME" => Loc::getMessage("TP_BSP_SHOW_RATING"),
		"TYPE" => "LIST",
		"VALUES" => Array(
			"" => Loc::getMessage("TP_BSP_SHOW_RATING_CONFIG"),
			"Y" => Loc::getMessage("MAIN_YES"),
			"N" => Loc::getMessage("MAIN_NO"),
		),
		"MULTIPLE" => "N",
		"DEFAULT" => "",
	);
	$arTemplateParameters["RATING_TYPE"] = Array(
		"NAME" => Loc::getMessage("TP_BSP_RATING_TYPE"),
		"TYPE" => "LIST",
		"VALUES" => Array(
			"" => Loc::getMessage("TP_BSP_RATING_TYPE_CONFIG"),
			"like" => Loc::getMessage("TP_BSP_RATING_TYPE_LIKE_TEXT"),
			"like_graphic" => Loc::getMessage("TP_BSP_RATING_TYPE_LIKE_GRAPHIC"),
			"standart_text" => Loc::getMessage("TP_BSP_RATING_TYPE_STANDART_TEXT"),
			"standart" => Loc::getMessage("TP_BSP_RATING_TYPE_STANDART_GRAPHIC"),
		),
		"MULTIPLE" => "N",
		"DEFAULT" => "",
	);
	$arTemplateParameters["PATH_TO_USER_PROFILE"] = Array(
		"NAME" => Loc::getMessage("TP_BSP_PATH_TO_USER_PROFILE"),
		"TYPE" => "STRING",
		"DEFAULT" => "",
	);
}
?>
