<?php
$MESS["SOTBIT_SEARCH_PAGE_COMPONENT_NAME"] = "Сотбит: Умный поиск. Страница поиска";
$MESS["SOTBIT_SEARCH_PAGE_COMPONENT_DESCRIPTION"] = "Страница с формой поиска и списком результатов поиска";
$MESS["SOTBIT_COMPONENTS_TITLE"] = "Сотбит";
$MESS["MODULE_SMARTSEARCH"] = "Умный поиск";
?>