<?php
$MESS["SOTBIT_SEARCH_PAGE_COMPONENT_NAME"] = "Sotbit: Smart search. Search page";
$MESS["SOTBIT_SEARCH_PAGE_COMPONENT_DESCRIPTION"] = "Page with a search form and a list of search results";
$MESS["SOTBIT_COMPONENTS_TITLE"] = "Sotbit";
$MESS["MODULE_SMARTSEARCH"] = "Smart Search";
