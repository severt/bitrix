<?php
$MESS["SMARTSEARCH_TITLE_ERROR_MODULE"] = "Sotbit module: Smart search is not installed.";
$MESS["SMARTSEARCH_TITLE_ENABLE_MODULE"] = "Sotbit module: Smart search is disabled in administrative settings.";
$MESS["SEARCH_MODULE_UNAVAILABLE"] = "Sorry, but the search module is temporarily unavailable";
$MESS["SEARCH_RESULTS"] = "searching results";
$MESS["SEARCH_FORUM"] = "Forum";
$MESS["SEARCH_BLOG"] = "Blogs";
$MESS["SEARCH_SOCIALNETWORK"] = "Social network";
$MESS["SEARCH_INTRANET"] = "Users";
$MESS["SEARCH_CRM"] = "CRM";
$MESS["SEARCH_DISK"] = "Disc files";
