<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Loader,
    Bitrix\Main\Localization\Loc,
    Sotbit\SmartSearch\Helper\Config;


class SotbitSmartSearchPage extends CBitrixComponent
{
    protected $q = '';
    protected $origQuery = '';
    protected $correctionSettings = [];
    protected $arCustomFilter = [];
    protected $exFilter = [];
    protected $arFilter = [];
    protected $tags;
    protected $arSort;
    protected $where;
    protected $arReturn = [];
    protected \CSearch $obSearch;
    protected array $result = [];

    public function onPrepareComponentParams($arParams)
    {
        if(!Loader::includeModule("search")) {
            return $arParams;
        }

        CPageOption::SetOptionString("main", "nav_page_in_session", "N");

        $arParams["CACHE_TIME"] = $arParams["CACHE_TIME"] ?? 3600;
        CRatingsComponentsMain::GetShowRating($arParams);
        $arParams["SHOW_WHEN"] = $arParams["SHOW_WHEN"] === "Y";
        $arParams["SHOW_WHERE"] = $arParams["SHOW_WHERE"] !== "N";
        $arParams["arrWHERE"] = !is_array($arParams["arrWHERE"]) ? [] : $arParams["arrWHERE"];
        $arParams["PAGE_RESULT_COUNT"] = intval($arParams["PAGE_RESULT_COUNT"]) ?: 50;

        $arParams["PAGER_TITLE"] = trim($arParams["PAGER_TITLE"]) ?: GetMessage("SEARCH_RESULTS");
        $arParams["PAGER_SHOW_ALWAYS"] = $arParams["PAGER_SHOW_ALWAYS"] !== "N";
        $arParams["USE_TITLE_RANK"] = $arParams["USE_TITLE_RANK"] === "Y";
        $arParams["PAGER_TEMPLATE"] = trim($arParams["PAGER_TEMPLATE"]);

        $arParams["DEFAULT_SORT"] = $arParams["DEFAULT_SORT"] !== "date" ? "rank" : "date";

        $this->arCustomFilter = is_array($GLOBALS[$arParams["FILTER_NAME"]]) ? $GLOBALS[$arParams["FILTER_NAME"]] : [];
        $this->exFilter = \CSearchParameters::ConvertParamsToFilter($arParams, "arrFILTER");

        $arParams["CHECK_DATES"] = $arParams["CHECK_DATES"] === "Y";

        if ($arParams["CHECK_DATES"]) {
            $this->arFilter["CHECK_DATES"] = "Y";
        }

        return $arParams;
    }

    public function executeComponent()
    {
        global $APPLICATION;

        if (!(Loader::includeModule('sotbit.smartsearch') && \SotbitSmartSearch::getDemo())) {
            ShowError(Loc::getMessage('SMARTSEARCH_TITLE_ERROR_MODULE'));
            return;
        }

        if (!\SotbitSmartSearch::isEnable()) {
            ShowError(Loc::getMessage('SMARTSEARCH_TITLE_ENABLE_MODULE'));
            return;
        }

        if (!Loader::includeModule("search")) {
            return;
        }

        $this->correctionSettings = Config::getCorrectionsOptions();

        $this->prepareRequestDate();
        $this->fillDropdown();
        $this->prepareQuery();
        $this->prepareTags();
        $this->setUrl();


        $templatePage = "";

        if ($this->InitComponentTemplate($templatePage)) {
            $template = &$this->GetTemplate();
            $this->arResult["FOLDER_PATH"] = $folderPath = $template->GetFolder();

            if (!$folderPath) {
                return;
            }

            $this->arFilter = array_merge($this->arFilter, [
                "SITE_ID" => SITE_ID,
                "QUERY" => $this->q,
                "TAGS" => $this->tags,
            ]);

            $this->arFilter = array_merge($this->arCustomFilter, $this->arFilter);
            if ($this->where <> '') {
                list($module_id, $part_id) = explode("_", $this->where, 2);
                $this->arFilter["MODULE_ID"] = $module_id;
                if ($part_id <> '') {
                    $this->arFilter["PARAM1"] = $part_id;
                }
            }

            $this->exFilter["STEMMING"] = false;
            $this->makeQuerySearch(true);

            $this->arResult["SEARCH"] = array();
            if ((int)$this->arResult["ERROR_CODE"] === 0) {
                $this->spellQuery();

                $ar = $this->obSearch->GetNext();
                while ($ar) {
                    $this->arReturn[$ar["ID"]] = $ar["ITEM_ID"];
                    $ar["CHAIN_PATH"] = $APPLICATION->GetNavChain($ar["URL"], 0, $folderPath . "/chain_template.php", true, false);
                    $ar["URL"] = htmlspecialcharsbx($ar["URL"]);
                    $ar["TAGS"] = array();
                    if (!empty($ar["~TAGS_FORMATED"])) {
                        foreach ($ar["~TAGS_FORMATED"] as $name => $tag) {
                            if ($this->arParams["TAGS_INHERIT"] === "Y") {
                                $arTags = $this->arResult["REQUEST"]["~TAGS_ARRAY"];
                                $arTags[$tag] = $tag;
                                $tags = implode(",", $arTags);
                            } else {
                                $tags = $tag;
                            }
                            $ar["TAGS"][] = array(
                                "URL" => $APPLICATION->GetCurPageParam("tags=" . urlencode($tags), array("tags")),
                                "TAG_NAME" => htmlspecialcharsex($name),
                            );
                        }
                    }
                    $this->arResult["SEARCH"][] = $ar;
                    $ar = $this->obSearch->GetNext();
                }

                if ($this->arResult["SEARCH"]) {
                    $this->prepareItemsName();
                }

                $navComponentObject = null;
                $this->arResult["NAV_STRING"] = $this->obSearch->GetPageNavStringEx($navComponentObject, $this->arParams["PAGER_TITLE"], $this->arParams["PAGER_TEMPLATE"], $this->arParams["PAGER_SHOW_ALWAYS"]);
                $this->arResult["NAV_CACHED_DATA"] = $navComponentObject->GetTemplateCachedData();
                $this->arResult["NAV_RESULT"] = $this->obSearch;
            }


            $this->arResult["TAGS_CHAIN"] = array();
            $url = array();
            foreach ($this->arResult["REQUEST"]["~TAGS_ARRAY"] as $key => $tag) {
                $url_without = $this->arResult["REQUEST"]["~TAGS_ARRAY"];
                unset($url_without[$key]);
                $url[$tag] = $tag;
                $result = array(
                    "TAG_NAME" => $tag,
                    "TAG_PATH" => $APPLICATION->GetCurPageParam("tags=" . urlencode(implode(",", $url)), array("tags")),
                    "TAG_WITHOUT" => $APPLICATION->GetCurPageParam("tags=" . urlencode(implode(",", $url_without)), array("tags")),
                );
                $this->arResult["TAGS_CHAIN"][] = $result;
            }


            $this->ShowComponentTemplate();

        } else {
            $this->__ShowError(str_replace("#PAGE#", $templatePage, str_replace("#NAME#", $this->getTemplateName(), "Can not find '#NAME#' template with page '#PAGE#'")));
        }

        return $this->arReturn;
    }

    protected function makeQuerySearch($setOption = false)
    {
        if (!$this->keepSearch()) {
            return;
        }

        $this->obSearch = new \CSearch();
        if ($setOption) {
            $this->obSearch->SetOptions(array(
                "ERROR_ON_EMPTY_STEM" => $this->arParams["RESTART"] !== "Y",
                "NO_WORD_LOGIC" => $this->arParams["NO_WORD_LOGIC"] === "Y",
            ));
        }

        $this->obSearch->Search($this->arFilter, $this->arSort, $this->exFilter);

        $this->arResult["ERROR_CODE"] = $this->obSearch->errorno;
        $this->arResult["ERROR_TEXT"] = $this->obSearch->error;

        if ((int)$this->obSearch->errorno === 0) {
            $this->obSearch->NavStart($this->arParams["PAGE_RESULT_COUNT"], false);
        }

        if (!empty($this->obSearch->arResult)) {
            $id = array_column($this->obSearch->arResult, 'ID');
            $this->result = array_replace($this->result, array_combine($id, $this->obSearch->arResult));
        }

        $this->obSearch->arResult = array_values($this->result);
    }

    protected function keepSearch()
    {
        if (!!$this->correctionSettings['KEEP_SEARCH_PAGE'] === true) {
            return true;
        }

        if (isset($this->obSearch) && !empty($this->result)) {
            return false;
        }

        return true;
    }

    protected function prepareRequestDate()
    {
        if (
            $this->arParams["SHOW_WHEN"]
            && isset($_REQUEST["from"])
            && is_string($_REQUEST["from"])
            && mb_strlen($_REQUEST["from"])
            && CheckDateTime($_REQUEST["from"])
        ) {
            $from = $_REQUEST["from"];
        } else {
            $from = "";
        }

        if (
            $this->arParams["SHOW_WHEN"]
            && isset($_REQUEST["to"])
            && is_string($_REQUEST["to"])
            && mb_strlen($_REQUEST["to"])
            && CheckDateTime($_REQUEST["to"])
        ) {
            $to = $_REQUEST["to"];
        } else {
            $to = "";
        }

        $this->where = $this->arParams["SHOW_WHERE"] ? trim($_REQUEST["where"]) : "";

        $how = trim($this->request->get('how'));
        if ($how === "d") {
            $how = "d";
        } elseif ($how === "r") {
            $how = "";
        } elseif ($this->arParams["DEFAULT_SORT"] === "date") {
            $how = "d";
        } else {
            $how = "";
        }

        if ($how === "d") {
            $this->arSort = ["CUSTOM_RANK" => "DESC", "DATE_CHANGE" => "DESC", "TITLE_RANK" => "ASC"];
        } else {
            $this->arSort = ["CUSTOM_RANK" => "DESC", "TITLE_RANK" => "ASC"];
        }

        if ($from) {
            $this->arFilter[">=DATE_CHANGE"] = $from;
        }

        if ($to) {
            $this->arFilter["<=DATE_CHANGE"] = $to;
        }

        $this->arResult["REQUEST"]["HOW"] = htmlspecialcharsbx($how);
        $this->arResult["REQUEST"]["~FROM"] = $from;
        $this->arResult["REQUEST"]["FROM"] = htmlspecialcharsbx($from);
        $this->arResult["REQUEST"]["~TO"] = $to;
        $this->arResult["REQUEST"]["TO"] = htmlspecialcharsbx($to);
        $this->arResult["REQUEST"]["WHERE"] = htmlspecialcharsbx($this->where);
    }

    protected function fillDropdown()
    {
        $arrDropdown = [];

        $obCache = new CPHPCache;

        if (
            $this->arParams["CACHE_TYPE"] == "N"
            || (
                $this->arParams["CACHE_TYPE"] == "A"
                && COption::GetOptionString("main", "component_cache_on", "Y") == "N"
            )
        ) {
            $this->arParams["CACHE_TIME"] = 0;
        }

        if ($obCache->StartDataCache($this->arParams["CACHE_TIME"], $this->GetCacheID(), "/" . SITE_ID . $this->GetRelativePath())) {
            // Getting of the Information block types
            $arIBlockTypes = array();
            if (CModule::IncludeModule("iblock")) {
                $rsIBlockType = CIBlockType::GetList(array("sort" => "asc"), array("ACTIVE" => "Y"));
                while ($arIBlockType = $rsIBlockType->Fetch()) {
                    if ($ar = CIBlockType::GetByIDLang($arIBlockType["ID"], LANGUAGE_ID))
                        $arIBlockTypes[$arIBlockType["ID"]] = $ar["~NAME"];
                }
            }

            // Creating of an array for drop-down list
            foreach ($this->arParams["arrWHERE"] as $code) {
                list($module_id, $part_id) = explode("_", $code, 2);
                if ($module_id <> '') {
                    if ($part_id === '') {
                        switch ($module_id) {
                            case "forum":
                                $arrDropdown[$code] = GetMessage("SEARCH_FORUM");
                                break;
                            case "blog":
                                $arrDropdown[$code] = GetMessage("SEARCH_BLOG");
                                break;
                            case "socialnetwork":
                                $arrDropdown[$code] = GetMessage("SEARCH_SOCIALNETWORK");
                                break;
                            case "intranet":
                                $arrDropdown[$code] = GetMessage("SEARCH_INTRANET");
                                break;
                            case "crm":
                                $arrDropdown[$code] = GetMessage("SEARCH_CRM");
                                break;
                            case "disk":
                                $arrDropdown[$code] = GetMessage("SEARCH_DISK");
                                break;
                        }
                    } else {
                        // if there is additional information specified besides ID then
                        switch ($module_id) {
                            case "iblock":
                                if (isset($arIBlockTypes[$part_id]))
                                    $arrDropdown[$code] = $arIBlockTypes[$part_id];
                                break;
                        }
                    }
                }
            }
            $obCache->EndDataCache($arrDropdown);
        } else {
            $arrDropdown = $obCache->GetVars();
        }

        $this->arResult["DROPDOWN"] = htmlspecialcharsex($arrDropdown);
    }

    protected function prepareQuery()
    {
        $this->q = $this->request->get("q") ? trim($this->request->get("q")) : false;

        if ($this->q === false) {
            $this->arResult["REQUEST"]["~QUERY"] = false;
            $this->arResult["REQUEST"]["QUERY"] = false;
            return;
        }

        if ($this->arParams["USE_LANGUAGE_GUESS"] === "N" || $this->request->get('spell')) {
            $this->arResult["REQUEST"]["~QUERY"] = $this->q;
            $this->arResult["REQUEST"]["QUERY"] = htmlspecialcharsex($this->q);
        } else {
            $arLang = CSearchLanguage::GuessLanguage($this->q);
            if (is_array($arLang) && $arLang["from"] != $arLang["to"]) {
                $this->arResult["REQUEST"]["~ORIGINAL_QUERY"] = $this->q;
                $this->arResult["REQUEST"]["ORIGINAL_QUERY"] = htmlspecialcharsex($this->q);

                $this->q = CSearchLanguage::ConvertKeyboardLayout($this->arResult["REQUEST"]["~ORIGINAL_QUERY"], $arLang["from"], $arLang["to"]);

                $this->arResult["REQUEST"]["~QUERY"] = $this->q;
                $this->arResult["REQUEST"]["QUERY"] = htmlspecialcharsex($this->q);
            } else {
                $this->arResult["REQUEST"]["~QUERY"] = $this->q;
                $this->arResult["REQUEST"]["QUERY"] = htmlspecialcharsex($this->q);
            }
        }

        $this->origQuery = $this->q;

        $this->modifyQuery();
    }

    protected function modifyQuery()
    {
        $this->q = \SotbitSmartSearchHelper::removePrepositions($this->q);
        $this->q = \SotbitSmartSearchHelper::modifySearchString($this->q);
        $this->q = \SotbitSmartSearchHelper::manualReplace($this->q);
    }

    protected function prepareTags()
    {
        $this->tags = $this->request->get("tags") ? trim($this->request->get("tags")) : false;

        if ($this->tags !== false) {
            $this->arResult["REQUEST"]["~TAGS_ARRAY"] = array();
            $arTags = explode(",", $this->tags);
            foreach ($arTags as $tag) {
                $tag = trim($tag);
                if ($tag <> '')
                    $this->arResult["REQUEST"]["~TAGS_ARRAY"][$tag] = $tag;
            }
            $this->arResult["REQUEST"]["TAGS_ARRAY"] = htmlspecialcharsex($this->arResult["REQUEST"]["~TAGS_ARRAY"]);
            $this->arResult["REQUEST"]["~TAGS"] = implode(",", $this->arResult["REQUEST"]["~TAGS_ARRAY"]);
            $this->arResult["REQUEST"]["TAGS"] = htmlspecialcharsex($this->arResult["REQUEST"]["~TAGS"]);
        } else {
            $this->arResult["REQUEST"]["~TAGS_ARRAY"] = array();
            $this->arResult["REQUEST"]["TAGS_ARRAY"] = array();
            $this->arResult["REQUEST"]["~TAGS"] = false;
            $this->arResult["REQUEST"]["TAGS"] = false;
        }
    }

    protected function setUrl()
    {
        global $APPLICATION;

        $this->arResult["URL"] = $APPLICATION->GetCurPage()
            . "?q=" . urlencode($this->q)
            . (isset($_REQUEST["spell"]) ? "&amp;spell=1" : "")
            . "&amp;where=" . urlencode($this->where)
            . ($this->tags !== false ? "&amp;tags=" . urlencode($this->tags) : "");


        if (isset($this->arResult["REQUEST"]["~ORIGINAL_QUERY"])) {
            $this->arResult["ORIGINAL_QUERY_URL"] = $APPLICATION->GetCurPage()
                . "?q=" . urlencode($this->arResult["REQUEST"]["~ORIGINAL_QUERY"])
                . "&amp;spell=1"
                . "&amp;where=" . urlencode($this->arResult["REQUEST"]["WHERE"])
                . ($this->arResult["REQUEST"]["HOW"] == "d" ? "&amp;how=d" : "")
                . ($this->arResult["REQUEST"]["FROM"] ? '&amp;from=' . urlencode($this->arResult["REQUEST"]["~FROM"]) : "")
                . ($this->arResult["REQUEST"]["TO"] ? '&amp;to=' . urlencode($this->arResult["REQUEST"]["~TO"]) : "")
                . ($this->tags !== false ? "&amp;tags=" . urlencode($this->tags) : "");
        }
    }

    protected function spellQuery()
    {
        if (!($this->correctionSettings['USE_CORRECTION'] && $this->keepSearch())) {
            return;
        }

        $spellResult = \SotbitSmartSearchHelper::correctSpelling($this->q, 'yandex_speller', $this->arFilter);
        if ($this->q !== $spellResult) {
            $this->q = \SotbitSmartSearchHelper::manualReplace($spellResult);
            $this->arFilter["QUERY"] = $this->q;
            $this->makeQuerySearch();
        }

        if (!($this->correctionSettings['USE_CORRECTION'] && $this->keepSearch())) {
            return;
        }

        if ($spellResult = \SotbitSmartSearchHelper::correctionBasedIndexedWords($this->q, $this->arFilter)) {
            $arQueryVariants = SotbitSmartSearchHelper::getWordSet($spellResult);
            foreach ($arQueryVariants as $str) {
                $this->q = $str;
                $this->arFilter["QUERY"] = $this->q;
                $this->makeQuerySearch();
            }
        }
    }

    protected function prepareItemsName()
    {
        $sectionsId = [];
        $elementsId = [];
        foreach (array_values($this->arReturn) as $id) {
            if (mb_strstr($id, 'S') !== false) {
                $sectionsId[] = str_replace('S', '', $id);
                continue;
            }

            $elementsId[] = $id;
        }

        $originalNames = \Sotbit\SmartSearch\Helper\IblockTools::getRealEntitiesName($elementsId, $sectionsId);

        foreach ($this->arResult["SEARCH"] as &$item) {
            if (!($item['ITEM_ID'] && $originalNames[$item['ITEM_ID']])) {
                continue;
            }
            $item['TITLE'] = $originalNames[$item['ITEM_ID']];
            $item['TITLE_FORMATED'] = \SotbitSmartSearchHelper::formatSearchTitle($item['TITLE_FORMATED'], $originalNames[$item['ITEM_ID']], $this->origQuery);
        }
    }
}