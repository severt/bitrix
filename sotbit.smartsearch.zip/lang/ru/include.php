<?php
$MESS["SOTBIT_SMARTSEARCH_GET_DEMO_ERROR"] = 'Пробный период закончился. Пожалуйста, <a href="/bitrix/admin/update_system.php?lang=' . LANGUAGE_ID .'" target="_blank">активируйте</a>  или <a href="https://marketplace.1c-bitrix.ru/solutions/sotbit.smartsearch/" target="_blank">приобретите</a> лицензию.';
$MESS["SOTBIT_SMARTSEARCH_ACCESS_DENIDED"] = 'Доступ к модулю запрещен';
$MESS["SOTBIT_SMARTSEARCH_GET_DEMO_TITLE"] = 'Модуль работает в демо-режиме.<br>По истечению пробного периода модуль будет заблокирован.<br><a href="https://marketplace.1c-bitrix.ru/solutions/sotbit.smartsearch/" target="_blank">Приобретите полную версию</a>';
$MESS["SOTBIT_SMARTSEARCH_E_SEARCH"] = 'ё';
$MESS["SOTBIT_SMARTSEARCH_E_SEARCH_2"] = 'Ё';
$MESS["SOTBIT_SMARTSEARCH_E_REPLACE"] = 'е';
$MESS["SOTBIT_SMARTSEARCH_E_REPLACE_2"] = 'Е';