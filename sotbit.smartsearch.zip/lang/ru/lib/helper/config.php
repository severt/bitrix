<?php
$MESS['SPELLER_SERVICE_YANDEX'] = 'Яндекс Speller';
$MESS['SPELLER_SERVICE_METAPHONE'] = 'Metaphone';