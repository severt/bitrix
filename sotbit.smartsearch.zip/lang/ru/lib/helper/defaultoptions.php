<?php
$MESS['SMARTSEARCH_DEFAULT_EXCLUDED_PREPOSITIONS'] = 'и,в,без,до,из,к,на,по,о,от,перед,при,с,у,за,над,об,под,про,для';