<?php
$moduleId = 'sotbit.smartsearch';
$MESS[$moduleId . '_GLOBAL_MENU'] = 'Сотбит';
$MESS[$moduleId . '_GLOBAL_MENU_MODULE_NAME'] = 'Сотбит: Умный поиск';
$MESS[$moduleId . '_SETTINGS'] = 'Настройки';
$MESS[$moduleId . '_REINDEX'] = 'Переиндексация';
