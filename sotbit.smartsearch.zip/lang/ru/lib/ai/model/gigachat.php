<?php
$MESS['GIGACHAT_ERROR_GET_TOKEN'] = 'Ошибка авторизации GigaChat. Не удалось получить токен.';