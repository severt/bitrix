<?php
$MESS['SMARTSEARCH_AI_JSON_ERROR'] = 'Невозможно прочитать ответ от нейросети';
$MESS['SMARTSEARCH_AI_RESPONSE_ERROR'] = 'Ошибка при запросе к нейросети (#ERROR_STATUS#). ';
$MESS['SMARTSEARCH_AI_RESPONSE_ERROR_MESS'] = 'Ответ: #ERROR_MESS#. ';