<?php
$MESS['ERROR_EMPTY_WORD'] = 'Не указано верное слово для замены';
$MESS['ERROR_EMPTY_EXCEPTION_WORD'] = 'Не указано ошибочное слово';
$MESS['ERROR_RULE_EXIST'] = 'Правило с таким словом (#WORD#) уже создано';
$MESS['ERROR_ERROR_FILE_EMPTY'] = 'Файл пустой или неверной структуры';
$MESS['ERROR_EMPTY_VALID_DATA'] = 'Нет доступных данных для добавления';
$MESS['ERROR_EMPTY_DATA'] = 'Нет данных для добавления.';