<?php
$MESS['ERROR_ERROR_FILE_EMPTY'] = 'Файл пустой или неверной структуры';
$MESS['ERROR_EMPTY_VALID_DATA'] = 'Нет доступных данных для добавления';
$MESS['ERROR_EMPTY_DATA'] = 'Нет данных для добавления.';