<?php
$MESS['SOTBIT_SMARTSEARCH_AI_ERROR_MODEL'] = 'Не указана модель интеграции с нейросетью';
$MESS['SOTBIT_SMARTSEARCH_AI_ERROR_CLASS'] = 'Класс модели нейросети не найден';
$MESS['SOTBIT_SMARTSEARCH_AI_ENTITY_SECTIONS'] = 'Название разделов';
$MESS['SOTBIT_SMARTSEARCH_AI_ENTITY_ELEMENTS'] = 'Названия элементов';
$MESS['SOTBIT_SMARTSEARCH_AI_PROPMT_REPLACE'] = 'Сформируй уникальные ошибочные написания, транслиты, жаргоны для следующих слов: #WORD_LIST_TAG#.
Для каждого слова предоставь #WORD_COUNT_TAG# варианта.
Пример для английского слова Apple - Эпл, Апл, Aple. Пример для русского слова Атлант - Отлант, Атланд, Atlant. Пример жаргона для слова Apple - Яблоко, Яблочный.
Ответ дай в формате: #FORMAT_TAG#.';
$MESS['SOTBIT_SMARTSEARCH_AI_PROPMT_SYNONYM'] = 'Сформируй набор синонимов для следующих слов: #WORD_LIST_TAG#.
Для каждого слова предоставь #WORD_COUNT_TAG# различных варианта.
Ответ дай в формате: #FORMAT_TAG#.';
$MESS['SOTBIT_SMARTSEARCH_AI_REUL_FORMAT_REPLACE'] = '{слово|вариант1;вариант2;вариант3;} Оберни каждое правило в фигурные скобки. Слова в ответе не должны повторяться';
$MESS['SOTBIT_SMARTSEARCH_AI_REUL_FORMAT_SYNONYM'] = '{слово;вариант1;вариант2;вариант3;} Оберни каждое правило в фигурные скобки. Слова в ответе не должны повторяться';