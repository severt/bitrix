<?php
$MESS['SMARTSEARCH_AI_EMPTY_DATA'] = 'Отсутствуют данные для формирования запроса.';
$MESS['SMARTSEARCH_AI_ERROR_OBJECT'] = 'Ошибка. Некорректный объект.';
$MESS['SMARTSEARCH_AI_ERROR_PROMPT'] = 'Ошибка. Пустой запрос к нейросети.';
$MESS['SMARTSEARCH_AI_PROCESSED_ITEMS'] = 'Обработано значений:';