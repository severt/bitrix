<?php
$MESS['ERROR_FILE_IMPORT'] = 'Файл пустой или неверной структуры';