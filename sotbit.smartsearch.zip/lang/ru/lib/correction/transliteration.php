<?php
$MESS['TRANSLIT_FROM'] = 'А,Б,В,Г,Д,Е,Ж,З,И,Й,К,Л,М,Н,О,П,Р,С,Т,У,Ф,Х,Ц,Ч,Ш,Щ,Ъ,Ы,Ь,Э,Ю,Я';
$MESS['TRANSLIT_TO'] = 'A,B,V,G,D,E,J,Z,I,Y,K,L,M,N,O,P,R,S,T,U,F,H,TS,CH,SH,SCH,,YI,,E,YU,YA';