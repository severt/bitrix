<?php
$MESS['SOTBIT_SMARTSEARCH_MODULE_NAME'] = 'Сотбит: Умный поиск – исправление ошибок, область поиска, приоритизация, исключения';
$MESS['SOTBIT_SMARTSEARCH_MODULE_DESC'] = '';
$MESS['SOTBIT_SMARTSEARCH_PARTNER_NAME'] = 'Сотбит';
$MESS['SOTBIT_SMARTSEARCH_PARTNER_URI'] = 'https://www.sotbit.ru';
$MESS['SOTBIT_SMARTSEARCH_INSTALL_ERROR_VERSION_PHP'] = "Установка невозможна<br>Для корректной работы модуля версия PHP должна быть не ниже 7.4!";