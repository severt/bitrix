<?php
$MESS['SOTBIT_SMARTSEARCH_GENERATE_SYNONYM_TITLE'] = 'Генерация синонимов';
$MESS['SOTBIT_SMARTSEARCH_GENERATE_SYNONYM_START'] = 'Продолжить';
$MESS['SOTBIT_SMARTSEARCH_GENERATE_SYNONYM_STOP'] = 'Остановить';
$MESS['SOTBIT_SMARTSEARCH_GENERATE_SYNONYM_CLOSE'] = 'Закрыть';
$MESS['SOTBIT_SMARTSEARCH_GENERATE_SYNONYM_CANCELING'] = 'Отменить';
$MESS['SOTBIT_SMARTSEARCH_GENERATE_SYNONYM_CANCELED'] = 'Отменено';
$MESS['SOTBIT_SMARTSEARCH_GENERATE_SYNONYM_COMPLETED'] = 'Результат работы нейросети:';
$MESS['SOTBIT_SMARTSEARCH_GENERATE_SYNONYM_SUMMARY'] = 'По данным параметрам будет подготовлен запрос для нейросети';
$MESS['SOTBIT_SMARTSEARCH_GENERATE_SYNONYM_SUMMARY_PROMT'] = 'Прежде чем отправить запрос, вы можете его редактировать.<br>{WORD_LIST}: список значений для обработки (подставляется автоматически)';
$MESS['SOTBIT_SMARTSEARCH_GENERATE_SYNONYM_META_TITLE_COMPLETED_PROMT'] = 'Итоговый запрос:';
$MESS['SOTBIT_SMARTSEARCH_GENERATE_SYNONYM_IBLOCK_ID'] = 'Инфоблок:';
$MESS['SOTBIT_SMARTSEARCH_GENERATE_SYNONYM_ENTITY'] = 'Характеристика:';
$MESS['SOTBIT_SMARTSEARCH_GENERATE_SYNONYM_VARIANTS_COUNT'] = 'Количество синонимов:';
$MESS['SOTBIT_SMARTSEARCH_GENERATE_SYNONYM_RES_TITLE'] = 'Результат работы нейросети:';
$MESS['SOTBIT_SMARTSEARCH_GENERATE_SYNONYM_RES_TEXT'] = 'Вы можете изменить результат перед сохранением. Каждое правило должно начинаться с новой строки.';
$MESS['SOTBIT_SMARTSEARCH_GENERATE_SYNONYM_RES_SAVE'] = 'Сохранить результат';
$MESS['SOTBIT_SMARTSEARCH_GENERATE_SYNONYM_COUNT_RESULT'] = 'Добавлено наборов синонимов: ';