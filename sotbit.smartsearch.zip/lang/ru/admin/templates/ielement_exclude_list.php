<?php
$MESS['SOTBIT_SMARTSEARCH_EL_ACTION_ADD'] = 'Добавить';
$MESS['SOTBIT_SMARTSEARCH_EL_ACTION_DELETE'] = 'Удалить';
$MESS['SOTBIT_SMARTSEARCH_EL_ACTION_DELETE_CONFIRM'] = 'Вы действительно хотите удалить правило?';
$MESS['SOTBIT_SMARTSEARCH_EL_HEADER_ID'] = '№';
$MESS['SOTBIT_SMARTSEARCH_EL_IBLOCK_ID'] = 'Инфоблок';
$MESS['SOTBIT_SMARTSEARCH_EL_PROPERTY_ID'] = 'Свойство';
$MESS['SOTBIT_SMARTSEARCH_EL_VALUE_ID'] = 'Значение свойства';
$MESS['SOTBIT_SMARTSEARCH_EL_FORM_IBLOCK_ID'] = 'Инфоблок:';
$MESS['SOTBIT_SMARTSEARCH_EL_FORM_PROP'] = 'Свойство элемента:';
$MESS['SOTBIT_SMARTSEARCH_EL_FORM_PROP_HINT'] = 'Исключить элементы с данным свойством';
$MESS['SOTBIT_SMARTSEARCH_EL_FORM_PROP_ENUM'] = 'Значение свойства (список):';
$MESS['SOTBIT_SMARTSEARCH_EL_FORM_PROP_ENUM_HINT'] = 'Исключить элементы только с данным значением свойства';
$MESS['SOTBIT_SMARTSEARCH_EL_ERROR_1'] = 'Выберите инфоблок и свойство для исключения';
$MESS['SOTBIT_SMARTSEARCH_EL_ERROR_2'] = 'Выберите свойство инфоблока для исключения';
$MESS['SOTBIT_SMARTSEARCH_EL_EMPTY_VAL'] = 'не выбрано';