<?php
$MESS["SMARTSEARCH_DEFAULT_EXCLUDED_PREPOSITIONS"] = "and, in, without, to, from, to, on, by, about, from, before, with, with, at, for, above, about, under, about, for";
