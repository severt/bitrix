<?php
$MESS["SPELLER_SERVICE_YANDEX"] = "Yandex Speller";
$MESS["SPELLER_SERVICE_METAPHONE"] = "Metaphone";
