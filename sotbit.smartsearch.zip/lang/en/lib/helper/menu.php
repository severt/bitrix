<?php
$MESS["sotbit.smartsearch_GLOBAL_MENU"] = "Sotbit";
$MESS["sotbit.smartsearch_GLOBAL_MENU_MODULE_NAME"] = "Sotbit: Smart Search";
$MESS["sotbit.smartsearch_SETTINGS"] = "Settings";
$MESS["sotbit.smartsearch_REINDEX"] = "Reindexing";
