<?php
$MESS["ERROR_FILE_IMPORT"] = "File is empty or has incorrect structure";
