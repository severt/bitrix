<?php
$MESS["ERROR_EMPTY_WORD"] = "The correct replacement word is not specified";
$MESS["ERROR_EMPTY_EXCEPTION_WORD"] = "Incorrect word not specified";
$MESS["ERROR_RULE_EXIST"] = "A rule with the same word (#WORD#) has already been created";
$MESS["ERROR_ERROR_FILE_EMPTY"] = "File is empty or has incorrect structure";
