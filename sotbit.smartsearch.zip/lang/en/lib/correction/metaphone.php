<?php
$MESS["TRANSLIT_FROM"] = "A, B, C, D, D, E, F, Z, I, J, K, L, M, N, O, P, R, S, T, U, F, X, C, H, W, Shch, b, y, b, e, yu, i";
$MESS["TRANSLIT_TO"] = "A,B,V,G,D,E,J,Z,I,Y,K,L,M,N,O,P,R,S,T,U,F,H,TS,CH,SH, SCH,,YI,,E,YU,YA";
