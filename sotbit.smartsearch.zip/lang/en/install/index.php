<?php
$MESS["SOTBIT_SMARTSEARCH_MODULE_NAME"] = "Sotbit: Smart Search - error correction, search scope, prioritization, exceptions";
$MESS["SOTBIT_SMARTSEARCH_MODULE_DESC"] = " ";
$MESS["SOTBIT_SMARTSEARCH_PARTNER_NAME"] = "Sotbit";
$MESS["SOTBIT_SMARTSEARCH_PARTNER_URI"] = "https://www.sotbit.ru";
$MESS["SOTBIT_SMARTSEARCH_INSTALL_ERROR_VERSION_PHP"] = "Installation is not possible<br> For the module to work correctly, the PHP version must be at least 7.4!";
