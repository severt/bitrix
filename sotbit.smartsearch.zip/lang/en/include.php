<?php
$MESS["SOTBIT_SMARTSEARCH_GET_DEMO_ERROR"] = "The trial period has ended. Please <a href=\"/bitrix/admin/update_system.php?lang=ru\" target=\"_blank\">activate</a> or <a href=\"https://marketplace.1c-bitrix.ru/solutions/sotbit.smartsearch/\" target=\"_blank\">purchase</a> a license.";
$MESS["SOTBIT_SMARTSEARCH_ACCESS_DENIDED"] = "Access to the module is denied";
$MESS["SOTBIT_SMARTSEARCH_GET_DEMO_TITLE"] = "<strong>Attention!</strong> The module works in demo mode, functionality is limited.";
$MESS["SOTBIT_SMARTSEARCH_E_SEARCH"] = "e";
$MESS["SOTBIT_SMARTSEARCH_E_REPLACE"] = "e";
