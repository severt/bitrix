<?php

namespace Sotbit\SmartSearch\AI\Model;


use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Request;
use Sotbit\SmartSearch\AI;

class ChatGPT extends AI\Base implements AI\AIModel
{
    const API_MESSAGE_URL = 'https://api.openai.com/v1/chat/completions';

    public function getURl(): string
    {
       return self::API_MESSAGE_URL;
    }

    public function getHeaders(): array
    {
        $apiKey = $this->getSetting('CHAT_GPT_API_KEY');
        if(strpos($apiKey,'�') !== false) {
            $apiKey = preg_replace('/\x{00AD}/u', '', $apiKey);
        }

        return [
            'Content-Type' => 'application/json',
            'Authorization' => "Bearer {$apiKey}"
        ];
    }

    public function getPostParams(): array
    {
        return [
            'model' => $this->getSetting('AI_MODEL_VERSION') ?? 'gpt-3.5-turbo',
            'messages' => $this->arMessage,
            'temperature' => (float)$this->getSetting('AI_TEMPERATURE') ?: 1.0,
            'max_tokens' => (int)$this->getSetting('AI_MAX_TOKENS') ?: 1024,
        ];
    }

    public static function getName(): string
    {
        return 'ChatGPT';
    }

    public static function getVersionList(): array
    {
        return [
            'gpt-3.5-turbo' => 'gpt-3.5-turbo',
            'gpt-4' => 'gpt-4'
        ];
    }

    public function renderOptions(\CAdminForm $tabControl, Request $request)
    {
        parent::renderOptions($tabControl, $request);
        $settings = $this->getSettings();
        
        $tabControl->AddEditField(
            'CHAT_GPT_API_KEY',
            Loc::getMessage('SOTBIT_SMARTSEARCH_FIELD_AI_API_KEY_CHATGPT'),
            true,
            [
                "size" => 35,
                "maxlength" => 255
            ],
            $request->get('CHAT_GPT_API_KEY') ?: $settings['CHAT_GPT_API_KEY'] ?: ''
        );

        $tabControl->BeginCustomField("MAX_TOKENS", Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_AI_MAX_TOKENS"));
        echo '
            <tr id="tr_MAX_TOKENS">
                <td width="40%">
                        ' . $tabControl->GetCustomLabelHTML() . '
                 </td>
                <td width="60%">
                    <input type="number" id="max_tokens" name="AI_MAX_TOKENS" value="' . ($request->get('AI_MAX_TOKENS') ?: $settings['AI_MAX_TOKENS'] ?: 1024) . '" step="1" min="0"/>
                   <span data-hint="' . Loc::getMessage('SOTBIT_SMARTSEARCH_FIELD_AI_MAX_TOKEN_HINT_CHATGPT'). '" data-hint-html></span>
                </td>
            </tr>';
        $tabControl->EndCustomField("MAX_TOKENS");

        $tabControl->BeginCustomField("TEMPERATURE", Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_AI_TEMPERATURE"));
        echo '
            <tr id="tr_TEMPERATURE">
                 <td width="40%">
                   ' . $tabControl->GetCustomLabelHTML() . '
                 </td>
                 <td width="60%">
                    <input type="number" id="temperature" name="AI_TEMPERATURE" value="' . ($request->get('AI_TEMPERATURE') ? round($request->get('AI_TEMPERATURE'), 1) : ($settings['AI_TEMPERATURE'] ? round($settings['AI_TEMPERATURE'], 1) : 1)) . '" step="any" min="0"/>
                    <span data-hint="' . Loc::getMessage('SOTBIT_SMARTSEARCH_FIELD_AI_TEMPERATURE_HINT_CHATGPT'). '" data-hint-html></span>
                </td>
            </tr>';
        $tabControl->EndCustomField("TEMPERATURE");

        $tabControl->AddEditField(
            'AI_PROXY_ADDRESS',
            Loc::getMessage('SOTBIT_SMARTSEARCH_FIELD_AI_PROXY_ADDRESS'),
            false,
            [
                "size" => 35,
                "maxlength" => 255
            ],
            $request->get('AI_PROXY_ADDRESS') ?: $settings['AI_PROXY_ADDRESS'] ?: ''
        );

        $tabControl->AddEditField(
            'AI_PROXY_PORT',
            Loc::getMessage('SOTBIT_SMARTSEARCH_FIELD_AI_PROXY_PORT'),
            false,
            [
                "size" => 35,
                "maxlength" => 255
            ],
            $request->get('AI_PROXY_PORT') ?: $settings['AI_PROXY_PORT'] ?: ''
        );

        $tabControl->AddEditField(
            'AI_PROXY_LOGIN',
            Loc::getMessage('SOTBIT_SMARTSEARCH_FIELD_AI_PROXY_LOGIN'),
            false,
            [
                "size" => 35,
                "maxlength" => 255
            ],
            $request->get('AI_PROXY_LOGIN') ?: $settings['AI_PROXY_LOGIN'] ?: ''
        );

        $tabControl->AddEditField(
            'AI_PROXY_PASSWORD',
            Loc::getMessage('SOTBIT_SMARTSEARCH_FIELD_AI_PROXY_PASSWORD'),
            false,
            [
                "size" => 35,
                "maxlength" => 255
            ],
            $request->get('AI_PROXY_PASSWORD') ?: $settings['AI_PROXY_PASSWORD'] ?: ''
        );
    }
}