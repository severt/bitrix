<?php

namespace Sotbit\SmartSearch\AI\Model;


use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Request;
use Sotbit\SmartSearch\AI;

class GigaChat extends AI\Base implements AI\AIModel
{
    const API_MESSAGE_URL = 'https://gigachat.devices.sberbank.ru/api/v1/chat/completions';
    const GET_TOKEN_URL = 'https://ngw.devices.sberbank.ru:9443/api/v2/oauth';

    const TOKEN_LIFETIME = 1500;

    private static string $token;
    private static int $tokenCreateTime;

    public function getURl(): string
    {
        return self::API_MESSAGE_URL;
    }

    public function getHeaders(): array
    {
        $token = $this->getToken();

        return [
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
            'Authorization' => "Bearer {$token}"
        ];
    }

    public function getPostParams(): array
    {
        return [
            'model' => $this->getSetting('AI_MODEL_VERSION') ?? 'GigaChat',
            'messages' => $this->arMessage,
            'temperature' => (float)$this->getSetting('AI_TEMPERATURE') ?: 1.0,
            'max_tokens' => (int)$this->getSetting('AI_MAX_TOKENS') ?: 1024,
        ];
    }

    public function getToken()
    {
        if (isset(self::$token) && $this->isTokenEnable()) {
            return self::$token;
        }

        $apiKey = $this->getSetting('GIGA_CHAT_API_KEY');
        if(strpos($apiKey,'�') !== false) {
            $apiKey = preg_replace('/\x{00AD}/u', '', $apiKey);
        }

        $headers = [
            'Content-Type' => 'application/x-www-form-urlencoded',
            'Accept' => 'application/json',
            'RqUID' => $this->guidv4(),
            'Authorization' => "Basic {$apiKey}"
        ];

        $params['scope'] = $this->getSetting('GIGA_CHAT_SCOPE');

        try {
            $token = $this->sendPostRequest(self::GET_TOKEN_URL, $headers, $params);
            self::$tokenCreateTime = time();
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage() . Loc::getMessage('GIGACHAT_ERROR_GET_TOKEN'));
        }

        return self::$token = $token['access_token'];
    }

    private function isTokenEnable()
    {
        return (time() - self::$tokenCreateTime) < self::TOKEN_LIFETIME;
    }

    protected function guidv4($data = null)
    {
        $data = $data ?? random_bytes(16);
        assert(strlen($data) == 16);

        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);

        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }

    public static function getName(): string
    {
        return 'GigaChat';
    }

    public static function getVersionList(): array
    {
        return [
            'GigaChat' => 'GigaChat',
            'GigaChat:latest' => 'GigaChat:latest',
            'GigaChat-Plus' => 'GigaChat-Plus',
            'GigaChat-Pro' => 'GigaChat-Pro'
        ];
    }

    public function renderOptions(\CAdminForm $tabControl, Request $request)
    {
        parent::renderOptions($tabControl, $request);
        $settings = $this->getSettings();

        $tabControl->AddEditField(
            'GIGA_CHAT_API_KEY',
            Loc::getMessage('SOTBIT_SMARTSEARCH_FIELD_AI_API_KEY_GIGACHAT'),
            true,
            [
                "size" => 35,
                "maxlength" => 255
            ],
            $request->get('GIGA_CHAT_API_KEY') ?: $settings['GIGA_CHAT_API_KEY'] ?: ''
        );

        $tabControl->AddDropDownField(
            'GIGA_CHAT_SCOPE',
            Loc::getMessage('SOTBIT_SMARTSEARCH_FIELD_AI_GIGA_CHAT_SCOPE'),
            true,
            [
                'GIGACHAT_API_PERS' => 'GIGACHAT_API_PERS',
                'GIGACHAT_API_CORP' => 'GIGACHAT_API_CORP'
            ],
            $request->get('GIGA_CHAT_SCOPE') ?: $settings['GIGA_CHAT_SCOPE'] ?: ''
        );

        $tabControl->BeginCustomField("MAX_TOKENS", Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_AI_MAX_TOKENS"));
        echo '
            <tr id="tr_MAX_TOKENS">
                <td width="40%">
                        ' . $tabControl->GetCustomLabelHTML() . '
                 </td>
                <td width="60%">
                    <input type="number" id="max_tokens" name="AI_MAX_TOKENS" value="' . ($request->get('AI_MAX_TOKENS') ?: $settings['AI_MAX_TOKENS'] ?: 1024) . '" step="1" min="0"/>
                   <span data-hint="' . Loc::getMessage('SOTBIT_SMARTSEARCH_FIELD_AI_MAX_TOKEN_HINT_GIGACHAT'). '" data-hint-html></span>
                </td>
            </tr>';
        $tabControl->EndCustomField("MAX_TOKENS");

        $tabControl->BeginCustomField("TEMPERATURE", Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_AI_TEMPERATURE"));
        echo '
            <tr id="tr_TEMPERATURE">
                 <td width="40%">
                   ' . $tabControl->GetCustomLabelHTML() . '
                 </td>
                 <td width="60%">
                    <input type="number" id="temperature" name="AI_TEMPERATURE" value="' . ($request->get('AI_TEMPERATURE') ? round($request->get('AI_TEMPERATURE'), 1) : ($settings['AI_TEMPERATURE'] ? round($settings['AI_TEMPERATURE'], 1) : 1)) . '" step="any" min="0"/>
                    <span data-hint="' . Loc::getMessage('SOTBIT_SMARTSEARCH_FIELD_AI_TEMPERATURE_HINT_GIGACHAT'). '" data-hint-html></span>
                </td>
            </tr>';
        $tabControl->EndCustomField("TEMPERATURE");
    }
}