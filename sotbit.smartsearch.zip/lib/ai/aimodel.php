<?php

namespace Sotbit\SmartSearch\AI;


use Bitrix\Main\Request;

interface AIModel
{
    public static function getName(): string;
    public static function getVersionList(): array;
    public function getURl(): string;
    public function getHeaders(): array;
    public function getPostParams(): array;
    public function renderOptions(\CAdminForm $tabControl, Request $request);
}