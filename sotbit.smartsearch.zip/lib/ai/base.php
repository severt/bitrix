<?php

namespace Sotbit\SmartSearch\AI;

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Request;
use Bitrix\Main\Web\Json;
use Sotbit\SmartSearch\Helper\Config;

abstract class Base
{
    protected static $settings;
    protected array $arMessage;


    public function __construct()
    {
        $this->getSettings();
    }

    protected function getSettings()
    {
        if (self::$settings) {
            return self::$settings;
        }

        return self::$settings = Config::getAIOptions();
    }


    protected function prepareMessage($arMessage)
    {
        return array_map(fn($role, $content) => [
            'role' => $role,
            'content' => $content
        ], array_keys($arMessage), array_values($arMessage));
    }

    /**
     * @param array $arMessage format: role => content
     */
    public function sendMessage(array $arMessage = [])
    {
        $this->arMessage = $this->prepareMessage($arMessage);

        $response = $this->sendPostRequest($this->getURL(), $this->getHeaders(), Json::encode($this->getPostParams()));
        return $this->formatResult($response);
    }

    protected function sendPostRequest(string $url, array $headers, $params)
    {
        $httpClient = new \Bitrix\Main\Web\HttpClient();
        $httpClient->setHeaders($headers);

        if ($this->getSetting('PROXY_ADDRESS')) {
            $httpClient->setProxy($this->getSetting('AI_PROXY_ADDRESS'), $this->getSetting('AI_PROXY_PORT'),
                $this->getSetting('AI_PROXY_LOGIN'), $this->getSetting('AI_PROXY_PASSWORD'));
        }

        $httpClient->disableSslVerification();
        $response = $httpClient->post($url, $params);

        if ($httpClient->getStatus() !== 200) {
            $error = Loc::getMessage('SMARTSEARCH_AI_RESPONSE_ERROR', ['#ERROR_STATUS#' =>  $httpClient->getStatus()]);
            try {
                if (!empty($response) && $arResponse = Json::decode($response)) {
                    $error .=  $arResponse['message'] ? Loc::getMessage('SMARTSEARCH_AI_RESPONSE_ERROR_MESS', ['#ERROR_MESS#' => $arResponse['message']]): '';
                }
            } catch (\Throwable $e) {}

            $error .= ($httpClient->getError() ? (implode(',', $httpClient->getError())) : '');
            throw new \Exception($error);
        }

        try {
            return Json::decode($response);
        } catch (\Throwable $exception) {
            throw new \Exception(Loc::getMessage('SMARTSEARCH_AI_JSON_ERROR'));
        }
    }

    protected function getSetting(string $name)
    {
        return self::$settings[$name];
    }

    protected function formatResult($result)
    {
        return $result['choices'][0]['message']['content'];
    }

    public function renderOptions(\CAdminForm $tabControl, Request $request)
    {
        $tabControl->AddDropDownField(
            'AI_MODEL_VERSION',
            Loc::getMessage('SOTBIT_SMARTSEARCH_FIELD_AI_MODEL_VERSION'),
            true,
            $this->getVersionList(),
            $request->get('AI_MODEL_VERSION') ?: $this->getSetting('AI_MODEL_VERSION')
        );
    }
}