<?php

namespace Sotbit\SmartSearch;


use Sotbit\SmartSearch\Helper\Config;
use Sotbit\SmartSearch\Helper\Menu;

class EventHandlers
{
    public static function onBuildGlobalMenuHandler(&$arGlobalMenu, &$arModuleMenu)
    {
        Menu::getAdminMenu($arGlobalMenu, $arModuleMenu);
    }

    public static function onBeforeIndex($arFields)
    {
        return \SotbitSmartSearchHelper::indexingEventHandler($arFields);
    }

    public static function onAfterUpdateProduct(\Bitrix\Main\Entity\Event $event)
    {
        \SotbitSmartSearchHelper::indexIblockElement($event->getParameter("id")['ID']);
    }

    public static function onBeforeFullReindexClear()
    {
        \SotbitSmartSearchHelper::clearLogs();
        Config::setReindexingFlag(false);
    }
}