<?php

namespace Sotbit\SmartSearch\ORM;

use Bitrix\Iblock\IblockTable;
use Bitrix\Iblock\PropertyEnumerationTable;
use Bitrix\Iblock\PropertyTable;
use Bitrix\Main;
use Bitrix\Main\ORM\Fields\Relations\Reference;
use Bitrix\Main\ORM\Query\Join;


class IElementExcludeRulesTable extends Main\Entity\DataManager
{
    use BulkOperation;

    public static function getTableName()
    {
        return 'sotbit_smartsearch_ielement_exclude_rules';
    }

    public static function getMap()
    {
        return array(
            new Main\Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true,
            )),
            new Main\Entity\IntegerField('IBLOCK_ID', array(
                'required' => true,
            )),
            new Main\Entity\IntegerField('PROPERTY_ID', array(
                'required' => true,
            )),
            new Main\Entity\IntegerField('VALUE_ID', array(
                'default_value' => 0
            )),
            (new Reference(
                'IBLOCK',
                IblockTable::class,
                Join::on('this.IBLOCK_ID', 'ref.ID')
            ))->configureJoinType('inner'),
            (new Reference(
                'PROPERTY',
                PropertyTable::class,
                Join::on('this.PROPERTY_ID', 'ref.ID')
            ))->configureJoinType('inner'),
            (new Reference(
                'ENUM',
                PropertyEnumerationTable::class,
                Join::on('this.VALUE_ID', 'ref.ID')
            ))->configureJoinType('left'),
        );
    }
}
