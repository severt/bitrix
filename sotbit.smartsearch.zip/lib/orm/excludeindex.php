<?php

namespace Sotbit\SmartSearch\ORM;

use Bitrix\Main;
use Bitrix\Main\Entity\EventResult;
use Bitrix\Main\ORM\Event;
use Bitrix\Main\ORM\Fields;


class ExcludeIndexTable extends Main\Entity\DataManager
{
    use BulkOperation;

    public static function getTableName()
    {
        return 'sotbit_smartsearch_exclude_index';
    }

    public static function getMap()
    {
        return array(
            new Main\Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true,
            )),
            new Main\Entity\DatetimeField('DATE', array(
                'default_value' => function() {
                    return new Main\Type\DateTime();
                },
            )),
            new Main\Entity\StringField('MODULE_ID', array(
                'required' => true,
            )),
            new Main\Entity\StringField('ITEM_ID', array(
                'required' => true,
            )),
            new Main\Entity\TextField('TITLE', array(
            )),
            new Main\Entity\StringField('PARAM1', array(
            )),
            new Main\Entity\StringField('PARAM2', array(
            )),
        );
    }
}
