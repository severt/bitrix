<?php

namespace Sotbit\SmartSearch\ORM;

use Bitrix\Main;
use Bitrix\Main\Entity\EventResult;
use Bitrix\Main\ORM\Event;
use Bitrix\Main\ORM\Fields;


class ReplacementTable extends Main\Entity\DataManager
{
    use BulkOperation;

    public static function getTableName()
    {
        return 'sotbit_smartsearch_replacement';
    }


    public static function getMap()
    {
        return array(
            new Main\Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true,
            )),
            new Main\Entity\StringField('WORD', array(
                'required' => true,
            )),
            (new Fields\Relations\OneToMany('RULES', ReplacementRuleTable::class, 'REPLACEMENT'))->configureJoinType('left')
        );
    }

    public static function onDelete(Event $event)
    {
        $result = new EventResult();

        ReplacementRuleTable::bulkDelete(['REPLACEMENT_ID' => (int)$event->getParameter('primary')['ID']]);

        return $result;
    }

    public static function deleteAll()
    {
        self::bulkDelete();
        ReplacementRuleTable::bulkDelete();
    }
}
