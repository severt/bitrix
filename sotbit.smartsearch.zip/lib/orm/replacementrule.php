<?php

namespace Sotbit\SmartSearch\ORM;

use Bitrix\Main;
use Bitrix\Main\ORM\Fields\Relations\Reference;
use Bitrix\Main\ORM\Query\Join;
use Sotbit\SmartSearch\ORM\BulkOperation;


class ReplacementRuleTable extends Main\Entity\DataManager
{
    use BulkOperation;

    public static function getTableName()
    {
        return 'sotbit_smartsearch_replacement_rule';
    }

    public static function getMap()
    {
        return array(
            new Main\Entity\IntegerField('REPLACEMENT_ID', array(
                'primary' => true,
            )),
            new Main\Entity\StringField('EXCEPTION_WORD', array(
                'primary' => true,
                'required' => true,
            )),
            (new Reference(
                'REPLACEMENT',
                ReplacementTable::class,
                Join::on('this.REPLACEMENT_ID', 'ref.ID')
            ))->configureJoinType('left'),
        );
    }
}
