<?php

namespace Sotbit\SmartSearch\ORM;

use Bitrix\Main;


trait BulkOperation
{
    private static $tableFields;

    public static function bulkAdd(array $rows, $primary = null): void
    {
        if (empty($rows)) {
            return;
        }

        if (!\SotbitSmartSearch::getDemo()) {
            return;
        }

        if (\SotbitSmartSearch::returnDemo() === Main\Loader::MODULE_DEMO) {
            foreach ($rows as $row) {
                static::add($row);
            }

            return;
        }

        $tableName = static::getTableName();
        $connection = Main\Application::getConnection();
        $sqlHelper = $connection->getSqlHelper();

        if (empty(static::$tableFields)) {
            static::$tableFields = $connection->getTableFields($tableName);
        }

        $columns0 = array_keys($rows[0]);
        $columns = [];
        foreach ($columns0 as $c) {
            $columns[$c] = $sqlHelper->quote(mb_strtoupper($c));
        }

        $sqlValues = [];
        foreach ($rows as $data) {
            foreach ($data as $columnName => $value) {
                $data[$columnName] = $sqlHelper->convertToDb($value, static::$tableFields[$columnName]);
            }
            $sqlValues[] = '(' . implode(', ', $data) . ')';
        }
        unset($data);

        $sql = "INSERT INTO {$tableName} (" . implode(', ', $columns) . ") VALUES " . implode(', ', $sqlValues);

        $checkPrimary = false;
        if (!empty($primary)) {
            if (!is_array($primary)) {
                $primary = array($primary);
            }
            if (count(array_intersect($primary, $columns0)) > 0) {
                $checkPrimary = true;
            }
        }
        if ($checkPrimary) {
            $sqlUpdate = array();
            foreach (array_diff($columns0, $primary) as $columnName) {
                $sqlUpdate[] = "{$columns[$columnName]} = VALUES({$columns[$columnName]})";
            }
            $sql .= " ON DUPLICATE KEY UPDATE " . implode(', ', $sqlUpdate);
        }

        $connection->queryExecute($sql);
    }


    public static function bulkDelete(array $filter = []): void
    {
        $tableName = static::getTableName();
        $connection = Main\Application::getConnection();

        if (!empty($filter)) {
            $hasSubQuery = false;
            foreach ($filter as $field => $value) {
                if (mb_strpos($field, '.') !== false) {
                    $hasSubQuery = true;
                    break;
                }
            }
            if ($hasSubQuery) {
                $whereSql = (static::query())
                    ->setSelect(['ID' => 'ID'])
                    ->setFilter($filter)
                    ->getQuery();

                $querySql = "DELETE target FROM {$tableName} target INNER JOIN ({$whereSql}) source ON target.ID = source.ID";
            } else {
                $whereSql = Main\ORM\Query\Query::buildFilterSql(static::getEntity(), $filter);
                $querySql = "DELETE FROM {$tableName} WHERE {$whereSql}";
            }
        } else {
            $querySql = "TRUNCATE TABLE {$tableName}";
        }

        $connection->queryExecute($querySql);
    }
}
