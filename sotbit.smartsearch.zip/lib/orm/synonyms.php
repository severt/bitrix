<?php

namespace Sotbit\SmartSearch\ORM;

use Bitrix\Main;
use Bitrix\Main\Entity\EventResult;
use Bitrix\Main\ORM\Event;
use Bitrix\Main\ORM\Fields;


class SynonymsTable extends Main\Entity\DataManager
{
    use BulkOperation;

    public static function getTableName()
    {
        return 'sotbit_smartsearch_synonyms';
    }

    public static function getMap()
    {
        return array(
            new Main\Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true,
            )),
            new Main\Entity\IntegerField('SET_ID', array(
                'required' => true,
            )),
            new Main\Entity\StringField('WORD', array(
                'required' => true,
            )),
        );
    }

    public static function deleteSet(int $id)
    {
        self::bulkDelete(['SET_ID' => $id]);
    }

    public static function deleteAll()
    {
        self::bulkDelete();
    }
}
