<?php

namespace Sotbit\SmartSearch\Helper;


use Bitrix\Iblock\PropertyTable;
use Bitrix\Main\Loader;
use Bitrix\Main\UserFieldTable;

Loader::includeModule('iblock');

class IblockTools
{
    protected static $searchProps = [];
    protected static $searchSectionProps = [];

    public static function getSearchProps($iblockId)
    {
        if (isset(self::$searchProps[$iblockId])) {
            return self::$searchProps[$iblockId];
        }

        return self::$searchProps[$iblockId] = array_column(PropertyTable::query()
            ->addSelect('ID')
            ->where('SEARCHABLE', 'Y')
            ->whereNot('PROPERTY_TYPE', PropertyTable::TYPE_FILE)
            ->fetchAll() ?: [], 'ID') ?: null;
    }

    public static function getSectionSearchProps($iblockId)
    {
        if (isset(self::$searchSectionProps[$iblockId])) {
            return self::$searchSectionProps[$iblockId];
        }

        return self::$searchSectionProps[$iblockId] = array_column(UserFieldTable::query()
            ->addSelect('FIELD_NAME')
            ->where('IS_SEARCHABLE', 'Y')
            ->where('ENTITY_ID', "IBLOCK_{$iblockId}_SECTION")
            ->fetchAll() ?: [], 'FIELD_NAME') ?: null;
    }

    public static function getRealEntitiesName($elementsId, $sectionsId)
    {
        $arElements = $arSections = [];
        $useSeoTitle = !!Config::get('USE_SEO_TITLE');

        if (!empty($elementsId)) {
            $dbElements = \Bitrix\Iblock\ElementTable::query()
                ->setSelect(['ID', 'NAME', 'IBLOCK_ID'])
                ->whereIn('ID', $elementsId)
                ->exec();

            while ($item = $dbElements->fetch()) {
                $value = '';
                if ($useSeoTitle) {
                    $iTemlate = new \Bitrix\Iblock\InheritedProperty\ElementValues($item['IBLOCK_ID'], $item['ID']);
                    $seoValues = $iTemlate->getValues();

                    if ($seoValues['ELEMENT_PAGE_TITLE']) {
                        $value = $seoValues['ELEMENT_PAGE_TITLE'];
                    }
                }

                $value = $value ?: $item['NAME'];
                $arElements[$item['ID']] = htmlspecialchars_decode($value);
            }
        }

        if (!empty($sectionsId)) {
            $dbSections = \Bitrix\Iblock\SectionTable::query()
                ->addSelect('NAME')
                ->addSelect('IBLOCK_ID')
                ->addSelect(new \Bitrix\Main\ORM\Fields\ExpressionField('SID', 'CONCAT("S", %s)', 'ID'))
                ->whereIn('ID', $sectionsId)
                ->exec();

            while ($item = $dbSections->fetch()) {
                $value = '';
                if ($useSeoTitle) {
                    $iTemlate = new \Bitrix\Iblock\InheritedProperty\SectionValues($item['IBLOCK_ID'], $item['ID']);
                    $seoValues = $iTemlate->getValues();

                    if ($seoValues['SECTION_PAGE_TITLE']) {
                        $value = $seoValues['SECTION_PAGE_TITLE'];
                    }
                }

                $value = $value ?: $item['NAME'];
                $arSections[$item['SID']] = htmlspecialchars_decode($value);
            }
        }

        return $arElements + $arSections;
    }

    public static function getIblockList()
    {
        $result = [];
        $query = \Bitrix\Iblock\IblockTable::query()
            ->setSelect(['ID', 'NAME'])
            ->exec();

        while ($item = $query->fetch()) {
            $result[$item['ID']] = "[{$item['ID']}] {$item['NAME']}";
        }

        return $result;
    }

    public static function getIblockProps($filter = [])
    {
        $query = PropertyTable::query()
            ->setSelect(['ID', 'CODE', 'NAME', 'IBLOCK_ID']);

        if ($filter) {
            $query->setFilter($filter);
        }

        $dbResult = $query->exec();
        while ($item = $dbResult->fetch()) {
            $result[$item['IBLOCK_ID']][$item['ID']] = "[{$item['CODE']}] {$item['NAME']}";
        }

        return $result ?? [];
    }

    public static function getPropEnumValues()
    {
        $values = [];

        $enum = \CIBlockPropertyEnum::getList([], []);
        while ($listData = $enum->fetch()) {
            $values[$listData['PROPERTY_ID']][$listData['ID']] = $listData["VALUE"];
        }

        return $values;
    }
}