<?php

namespace Sotbit\SmartSearch\Helper;

use Bitrix\Main\Localization\Loc,
    Bitrix\Main\Loader;

Loc::loadMessages(__FILE__);

class Menu
{
    public static function getAdminMenu(&$arGlobalMenu, &$arModuleMenu)
    {
        $moduleInclude = Loader::includeModule('sotbit.smartsearch');

        if (!isset($arGlobalMenu['global_menu_sotbit'])) {
            $arGlobalMenu['global_menu_sotbit'] = [
                'menu_id'   => 'sotbit',
                'text'      => Loc::getMessage(\SotbitSmartSearch::MODULE_ID.'_GLOBAL_MENU'),
                'title'     => Loc::getMessage(\SotbitSmartSearch::MODULE_ID.'_GLOBAL_MENU'),
                'sort'      => 1000,
                'items_id'  => 'global_menu_sotbit_items',
                "icon"      => "",
                "page_icon" => "",
            ];
        }

        $menu = [];

        if ($moduleInclude) {
            if ($GLOBALS['APPLICATION']->GetGroupRight(\SotbitSmartSearch::MODULE_ID) >= 'R') {
                $menu = [
                    "section"   => "sotbit_smartsearch",
                    "menu_id"   => "sotbit_smartsearch",
                    "sort"      => 300,
                    'id'        => 'smartsearch',
                    "text"      => Loc::getMessage(\SotbitSmartSearch::MODULE_ID.'_GLOBAL_MENU_MODULE_NAME'),
                    "title"     => Loc::getMessage(\SotbitSmartSearch::MODULE_ID.'_GLOBAL_MENU_MODULE_NAME'),
                    "icon"      => "sotbit_smartsearch_menu_icon",
                    "page_icon" => "",
                    "items_id"  => "global_menu_sotbit_smartsearch",
                    "items"     => [
                        [
                            'text'      => Loc::getMessage(\SotbitSmartSearch::MODULE_ID.'_SETTINGS'),
                            'title'     => Loc::getMessage(\SotbitSmartSearch::MODULE_ID.'_SETTINGS'),
                            'sort'      => 10,
                            'icon'      => '',
                            'page_icon' => '',
                            "url"   => '/bitrix/admin/sotbit.smartsearch_settings.php?lang='.LANGUAGE_ID,
                        ],
                        [
                            'text'      => Loc::getMessage(\SotbitSmartSearch::MODULE_ID.'_REINDEX'),
                            'title'     => Loc::getMessage(\SotbitSmartSearch::MODULE_ID.'_REINDEX'),
                            'sort'      => 20,
                            'icon'      => '',
                            'page_icon' => '',
                            "url"   => '/bitrix/admin/search_reindex.php?lang='.LANGUAGE_ID,
                        ]
                    ],
                    "more_url" => array(
                    ),
                ];
            }
        }

        $arGlobalMenu['global_menu_sotbit']['items']['sotbit.smartsearch'] = $menu;
    }
}