<?php

namespace Sotbit\SmartSearch\Helper;


use Bitrix\Main\Loader;
use Bitrix\Highloadblock\HighloadBlockTable;

class HlTools
{
    protected static array $hlValues = [];

    public static function getHlValue($tableName, $xmlId)
    {
        if (isset(self::$hlValues[$tableName])) {
            return self::$hlValues[$tableName][$xmlId] ?: '';
        }

        self::$hlValues[$tableName] = self::getHlValues($tableName);

        return self::$hlValues[$tableName][$xmlId] ?: '';
    }

    private static function getHlValues($tableName)
    {
        if (!Loader::includeModule('highloadblock')) {
            return null;
        }

        if (!$hlId = self::getHlByTable($tableName)) {
            return null;
        }

        return array_column((self::compileHlEntityClass($hlId))::query()
            ->setSelect(['UF_XML_ID', 'UF_NAME'])
            ->fetchAll() ?: [], 'UF_NAME', 'UF_XML_ID');
    }

    public static function getHlByTable($tableName): int
    {
        return ($res = HighloadBlockTable::query()
            ->setSelect(['ID'])
            ->where('TABLE_NAME', $tableName)
            ->fetch()) ? $res['ID'] : 0;
    }

    public static function compileHlEntityClass($hlId)
    {
        $entity = HighloadBlockTable::compileEntity($hlId);
        return $entity->getDataClass();
    }


}