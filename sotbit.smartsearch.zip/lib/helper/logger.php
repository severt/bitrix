<?php

namespace Sotbit\SmartSearch\Helper;

use Bitrix\Main\Localization\Loc,
    Bitrix\Main\Diag\Debug;
use Sotbit\SmartSearch\ORM\ExcludeIndexTable;


class Logger
{
    const DIR_PATH = '/logs/';
    const FILE_EXCLUDED = 'exclude_log.txt';
    const FILE_ERRORS = 'errors_log.txt';


    public static function saveExcludeLog($mess)
    {
        ExcludeIndexTable::add($mess);
    }

    public static function saveErrorLog($mess)
    {
        self::saveLog($mess, self::FILE_ERRORS);
    }

    public static function clearLogs()
    {
        $dir = new \Bitrix\Main\IO\Directory($_SERVER['DOCUMENT_ROOT'] . self::getDirLogs());
        if (!$dir->isExists()) {
            return;
        }

        $files = $dir->getChildren();

        foreach ($files as $file) {
            $file->delete();
        }
    }

    private static function saveLog($mess, $file)
    {
        $dirPath = self::getDirLogs();
        CheckDirPath($_SERVER['DOCUMENT_ROOT'] . $dirPath);
        $mess['DATE_TIME'] = date('m.d.Y H:i:s');
        Debug::writeToFile($mess,"", $dirPath . $file);
    }

    private static function getDirLogs()
    {
        return '/bitrix/modules/' . \SotbitSmartSearch::MODULE_ID . self::DIR_PATH;
    }

}