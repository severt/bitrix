<?php

namespace Sotbit\SmartSearch\Helper;


class Timer
{
    private $timeLimit = 15;
    private $startTime = -1;


    public function __construct($timeLimit = 0)
    {
        if ($timeLimit > 0) {
            $this->setTimeLimit($timeLimit);
        }
    }

    public function startTimer($startingTime = null)
    {
        if ((int)$startingTime > 0) {
            $this->startTime = (int)$startingTime;
        } else {
            $this->startTime = \time();
        }

        return $this;
    }

    public function hasTimeLimitReached()
    {
        if ($this->timeLimit > 0 && $this->startTime > 0) {
            if ((\time() - $this->startTime) >= $this->timeLimit) {
                return true;
            }
        }

        return false;
    }

    public function getTimeLimit()
    {
        return $this->timeLimit;
    }


    public function setTimeLimit($timeLimit)
    {
        $this->timeLimit = $timeLimit;

        return $this;
    }
}

