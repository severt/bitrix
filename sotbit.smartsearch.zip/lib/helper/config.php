<?php

namespace Sotbit\SmartSearch\Helper;


use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;

class Config
{
    const BASE_OPTIONS = [
        'ENABLE_MODULE' => false,
        'ADVANCED_TITLE_SEARCH_MODE' => false,
    ];

    const CORRECTION_OPTIONS = [
        'USE_CORRECTION' => false,
        'SPELLER_METHOD' => [],
        'REPLACE_WORD_LEN' => 4,
        'KEEP_SEARCH' => false,
        'KEEP_SEARCH_PAGE' => false,
    ];

    const INDEXING_OPTIONS = [
        'USE_SEARCH_PROPS' => false,
        'USE_TAGS' => false,
        'USE_SEO_TITLE' => false,
        'USE_SECTION_NAME' => false,
        'USE_SUBSECTION' => false,
        'REPLACE_DESCRIPTION' => false,
        'RANK_SETTINGS' => [],
        'RANK_WEIGHT' => [],
        'SECTION_FIRST_PRODUCT' => false,
        'EXCLUDE_UNAVAILABLE' => false,
        'EXCLUDE_NOT_QUANTITY' => false,
        'EXCLUDE_BY_SECTION' => false,
        'EXCLUDE_OFFER_BY_ACTIVE_MAIN' => false,
        'EXCLUDE_MODULES' => [],
        'EXCLUDED_PREPOSITIONS' => [],
        'KEEP_DATA_LOGGING' => true,
        'USE_SYNONYMS' => false,
    ];

    const AI_OPTIONS = [
        'CHAT_GPT_API_KEY' => '',
        'GIGA_CHAT_API_KEY' => '',
        'GIGA_CHAT_SCOPE' => '',
        'AI_MODEL' => '',
        'AI_MODEL_VERSION' => '',
        'AI_MAX_TOKENS' => 1024,
        'AI_TEMPERATURE' => 1,
        'AI_PROXY_ADDRESS' => '',
        'AI_PROXY_PORT' => '',
        'AI_PROXY_LOGIN' => '',
        'AI_PROXY_PASSWORD' => ''
    ];

    const TRANSLIT_WORD_TITLE = 'translit_title';
    const TRANSLIT_CACHE_TTL = 3600;
    const TRANSLIT_CACHE_PATH = 'sotbit.smartsearch';

    private static array $options = [];
    private static $indexOptions;
    private static $correctionsOptions;
    private static $aIOptions;
    private static $excludedPrepositions;
    private static $allCode;

    public static function getIndexOptions()
    {
        if (self::$indexOptions) {
            return self::$indexOptions;
        }

        return self::$indexOptions = array_intersect_key(self::getAll(), self::INDEXING_OPTIONS);
    }

    public static function getCorrectionsOptions()
    {
        if (self::$correctionsOptions) {
            return self::$correctionsOptions;
        }

        return self::$correctionsOptions = array_intersect_key(self::getAll(), self::CORRECTION_OPTIONS);
    }

    public static function getAIOptions()
    {
        if (self::$aIOptions) {
            return self::$aIOptions;
        }

        return self::$aIOptions = array_intersect_key(self::getAll(), self::AI_OPTIONS);
    }

    public static function getUsedSpellerService()
    {
        $arService = self::getSpellerServices();
        $usedServices = self::get('SPELLER_METHOD');

        $result = [];

        foreach ($usedServices as $service) {
            $result[$service] = $arService[$service]['CLASS'];
        }

        return $result;
    }

    public static function getSpellerServices()
    {
        return [
            'yandex_speller' => [
                'NAME' => Loc::getMessage('SPELLER_SERVICE_YANDEX'),
                'CLASS' => 'YandexSpeller',
            ],
            'metaphone' => [
                'NAME' => Loc::getMessage('SPELLER_SERVICE_METAPHONE'),
                'CLASS' => 'Metaphone'
            ],
        ];
    }

    public static function getEexcludedPrepositions()
    {
        if (self::$excludedPrepositions) {
            return self::$excludedPrepositions;
        }

        return self::$excludedPrepositions = self::get('EXCLUDED_PREPOSITIONS');
    }

    public static function get($code, $default = null)
    {
        $options = self::$options ?: self::getAll();
        return $options[$code] ?? $default;
    }

    public static function getAll($isCache = true)
    {
        if (!empty(self::$options) && $isCache) {
            return self::$options;
        }

        $options = Option::getForModule(\SotbitSmartSearch::MODULE_ID);
        foreach ($options as &$option) {
            $option = unserialize($option) !== false ? unserialize($option) : $option;
        }

        return self::$options = $options ?: [];
    }

    public static function saveOptions(array $arFields)
    {
        $arFields = array_intersect_key($arFields, self::getAllCode());
        foreach (self::getAllCode() as $code => $default) {
            $value = $arFields[$code] ?? (is_bool($default) ? $default : (is_array($default) ? $default : null));
            if (is_null($value)) {
                continue;
            }
            $value = $value === 'true' ? true : $value;
            Option::set(\SotbitSmartSearch::MODULE_ID, $code, is_array($value) ? serialize($value) : $value);
        }
    }

    private static function getAllCode()
    {
        if (self::$allCode) {
            return self::$allCode;
        }

        return self::$allCode = self::BASE_OPTIONS + self::CORRECTION_OPTIONS + self::INDEXING_OPTIONS + self::AI_OPTIONS;
    }

    public static function checkReindexFlag($arFields)
    {
        $newOptions = array_intersect_key($arFields, self::INDEXING_OPTIONS);
        foreach (self::INDEXING_OPTIONS as $code => $default) {
            $value = $newOptions[$code] ?? $default;
            $value = $value === 'true' ? true : $value;
            $newOptions[$code] = $value;
        }

        $diff = self::arrayRecursiveDiff($newOptions, self::getIndexOptions() ?: []);

        return !empty($diff);
    }

    public static function setReindexingFlag($value)
    {
        Option::set(\SotbitSmartSearch::MODULE_ID, 'NEED_REINDEX', $value);
    }

    public static function getReindexingFlag()
    {
        return Option::get(\SotbitSmartSearch::MODULE_ID, 'NEED_REINDEX', 0);
    }

    private static function arrayRecursiveDiff($aArray1, $aArray2)
    {
        $aReturn = [];

        foreach ($aArray1 as $mKey => $mValue) {
            if (array_key_exists($mKey, $aArray2)) {
                if (is_array($mValue) && $aArray2[$mKey]) {
                    $aRecursiveDiff = self::arrayRecursiveDiff($mValue, $aArray2[$mKey]);
                    if (count($aRecursiveDiff)) {
                        $aReturn[$mKey] = $aRecursiveDiff;
                    }
                } else {
                    if (is_bool(self::getAllCode()[$mKey])) {
                       if (!!$mValue !== !!$aArray2[$mKey]) {
                           $aReturn[$mKey] = $mValue;
                       }
                    }
                }
            } else {
                $aReturn[$mKey] = $mValue;
            }
        }
        return $aReturn;
    }

    public static function getAIModelClass()
    {
        $model = self::getAIOptions()['AI_MODEL'];
        return $model ? ('\\Sotbit\\SmartSearch\\AI\\Model\\' . $model) : null;
    }

    public static function getAIModelList()
    {
        $modelDir = $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/' . \SotbitSmartSearch::MODULE_ID . '/lib/ai/model/';
        if ($dir = opendir($modelDir)) {
            while (false !== $item = readdir($dir)) {
                if ($item == '..' || $item == '.') {
                    continue;
                }

                $current = self::parseClassName($modelDir . $item);
                if ($current !== false) {
                    list($namespace, $class) = $current;
                    $arClasses[$class] = $class;
                }
            }
            closedir($dir);
        }

        return $arClasses;
    }

    protected static function parseClassName(string $filePath)
    {
        $tokens = token_get_all(file_get_contents($filePath));
        $nsStart = false;
        $classStart = false;
        $namespace = '';
        foreach ($tokens as $token) {
            if ($token[0] === T_ABSTRACT) {
                return false;
            }
            if ($token[0] === T_CLASS) {
                $classStart = true;
            }
            if ($classStart && ($token[0] === T_STRING || $token[0] === T_NAME_QUALIFIED)) {
                return [$namespace, $token[1]];
            }
            if ($token[0] === T_NAMESPACE) {
                $nsStart = true;
            }

            if ($nsStart && $token[0] === ';') {
                $nsStart = false;
            }

            if ($nsStart && $token[0] === T_NAME_QUALIFIED) {
                $namespace = $token[1];
            }

            if ($nsStart && $token[0] === T_STRING) {
                $namespace .= $token[1] . '\\';
            }
        }

        return false;
    }
}