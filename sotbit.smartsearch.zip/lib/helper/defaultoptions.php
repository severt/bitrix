<?php

namespace Sotbit\SmartSearch\Helper;


use Bitrix\Main\Localization\Loc;

class DefaultOptions extends Config
{
    public static function getOptions()
    {
        return [
            'USE_CORRECTION' => true,
            'SPELLER_METHOD' => [
                'yandex_speller',
                'metaphone'
            ],
            'REPLACE_WORD_LEN' => 4,
            'KEEP_SEARCH' => true,
            'USE_SEARCH_PROPS' => true,
            'USE_TAGS' => true,
            'USE_SECTION_NAME' => true,
            'USE_SUBSECTION' => true,
            'RANK_SETTINGS' => array (
                0 =>
                    array (
                        'CODE' => 'AVAILABLE',
                        'VALUE' => '1',
                        'ENTITY' => '0',
                    ),
                1 =>
                    array (
                        'CODE' => 'IS_PRODUCT',
                        'VALUE' => '2',
                        'ENTITY' => '0',
                    )
            ),
            'RANK_WEIGHT' => array (
                'AVAILABLE' => 4,
                'IS_PRODUCT' => 2,
            ),
            'SECTION_FIRST_PRODUCT' => true,
            'EXCLUDE_UNAVAILABLE' => true,
            'EXCLUDE_NOT_QUANTITY' => true,
            'EXCLUDE_BY_SECTION' => true,
            'EXCLUDE_OFFER_BY_ACTIVE_MAIN' => true,
            'EXCLUDED_PREPOSITIONS' => explode(',', Loc::getMessage('SMARTSEARCH_DEFAULT_EXCLUDED_PREPOSITIONS')),
            'KEEP_DATA_LOGGING' => true,
        ];
    }

    public static function setOptions()
    {
        parent::saveOptions(self::getOptions());
    }
}