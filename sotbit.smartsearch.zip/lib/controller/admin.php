<?php

namespace Sotbit\SmartSearch\Controller;

use Bitrix\Main\Application;
use Bitrix\Main\Error;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Text\Encoding;
use Sotbit\SmartSearch\General\IblockExcludeRules;
use Sotbit\SmartSearch\General\Replacement;
use Sotbit\SmartSearch\General\Synonyms;
use Sotbit\SmartSearch\ORM\ReplacementRuleTable;
use Sotbit\SmartSearch\ORM\ReplacementTable;

Loc::setCurrentLang(LANGUAGE_ID);


class Admin extends \Bitrix\Main\Engine\Controller
{
    public function saveCorrectionAction(array $fields)
    {
        try {
            if (!$fields['ID']) {
                 Replacement::create($fields);
            } else {
                 Replacement::update($fields);
            }
        } catch (\Throwable $e) {
            $this->addError(new Error($e->getMessage()));
            return null;
        }
    }

    public function getExceptionWordsAction(int $replaceId)
    {
        $replaceObj = ReplacementTable::getByPrimary($replaceId)->fetchObject();
        $items = [];
        $replaceObj->fillRules();
        $ruleCollect = $replaceObj->getRules();
        if ($ruleCollect) {
            foreach ($ruleCollect->getAll() as $rule) {
                $items[] = $rule->get('EXCEPTION_WORD');
            }
        }

        return [
            'replace' => [
                'id' => $replaceId,
                'word' => $replaceObj->getWord(),
            ],
            'items' => $items
        ];
    }

    public function exportRulesAction()
    {
        return Replacement::createFile();
    }

    public function importReplaceRulesAction()
    {
        $file = $this->getRequest()->getFile('FILE_IMPORT');

        if (!$file) {
            $this->addError(new Error(Loc::getMessage('ERROR_FILE_IMPORT')));
            return null;
        }

        try {
            return Replacement::importFile($file, $this->request->get('DELETE_ITEMS') ?? false);
        } catch (\Throwable $e) {
            $this->addError(new Error($e->getMessage()));
            return null;
        }
    }

    public function getSetWordsAction(int $setId)
    {
        return [
            'replace' => [
                'setId' => $setId,
            ],
            'items' => Synonyms::getSetWord($setId)
        ];
    }

    public function saveSynonymSetAction(array $fields)
    {
        try {
            if (!$fields['SET_ID']) {
                Synonyms::createFromArray($fields['ITEMS']);
            } else {
                Synonyms::updateSet($fields['SET_ID'], $fields['ITEMS']);
            }
        } catch (\Throwable $e) {
            $this->addError(new Error($e->getMessage()));
            return null;
        }
    }

    public function importSynonymSetsAction()
    {
        $file = $this->getRequest()->getFile('FILE_IMPORT');

        if (!$file) {
            $this->addError(new Error(Loc::getMessage('ERROR_FILE_IMPORT')));
            return null;
        }

        try {
            return Synonyms::importFile($file, $this->request->get('DELETE_ITEMS') ?? false);
        } catch (\Throwable $e) {
            $this->addError(new Error($e->getMessage()));
            return null;
        }
    }

    public function exportSynonymsAction($order = [])
    {
        return Synonyms::export($order);
    }

    public function saveExcludeIblockRuleAction(array $fields)
    {
       return IblockExcludeRules::add($fields);
    }
}