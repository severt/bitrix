<?php

namespace Sotbit\SmartSearch\Controller;


use Bitrix\Main\Error;
use Bitrix\Main\Localization\Loc;
use Sotbit\SmartSearch\General\AI;
use Sotbit\SmartSearch\General\Replacement;
use Sotbit\SmartSearch\General\Synonyms;

Loc::setCurrentLang(LANGUAGE_ID);


class AIController extends \Bitrix\Main\Engine\Controller
{
    public function getIblockEntitiesAction($iblockId)
    {
        return AI::getEntityToProcess($iblockId);
    }

    public function generatePromtAction()
    {
        $aiObject = new AI($this->request->getValues());
        if (!$aiObject->getVariants()) {
            $this->addError(new Error(Loc::getMessage('SMARTSEARCH_AI_EMPTY_DATA')));
            return null;
        }

        return [
            'COMPLETED_PROMPT' => $aiObject->createPrompt(),
            'AI_OBJECT' => $aiObject->serialize(),
            'STATUS' => 'COMPLETED'
        ];
    }

    public function generateRulesAction($aiObject)
    {
        $aiObject = AI::unserialize($aiObject);
        if (!($aiObject instanceof AI)) {
            $this->addError(new Error(Loc::getMessage('SMARTSEARCH_AI_ERROR_OBJECT')));
            return null;
        }

        if ($aiObject->getProcessedItems() === 0) {
            if (!$promt = $this->request->get('COMPLETED_PROMPT')) {
                $this->addError(new Error(Loc::getMessage('SMARTSEARCH_AI_ERROR_PROMPT')));
                return null;
            }

            $aiObject->setPrompt($promt);
        }

        try {
            $aiObject->sendAction();
        } catch (\Throwable $exception) {
            $this->addError(new Error($exception->getMessage()));
            return null;
        }

        if ($aiObject->getProcessedItems() < count($aiObject->getVariants())) {
            $result = [
                'SUMMARY' => Loc::getMessage('SMARTSEARCH_AI_PROCESSED_ITEMS'),
                'PROCESSED_ITEMS' => $aiObject->getProcessedItems(),
                'TOTAL_ITEMS' => count($aiObject->getVariants()),
                'STATUS' => 'PROGRESS'
            ];
        } else {
            $result = [
                'STATUS' => 'COMPLETED',
                'RESULT_ITEMS_HTML' => implode("\n\n", $aiObject->getResultItems()),
            ];
        }

        $result['AI_OBJECT'] = $aiObject->serialize();

        return $result;
    }

    public function saveAiResultAction(string $result, $type = AI::TYPE_REPLACE)
    {
        switch ($type) {
            case AI::TYPE_REPLACE:
                return Replacement::bulkCreateFromString($result, false,true);
            case AI::TYPE_SYNONYM:
                return Synonyms::bulkCreateFromString($result);
        }
    }

    public function cancelAction()
    {
        return  [ 'STATUS' => 'COMPLETED'];
    }

    public function sendMessageAction(string $message)
    {
        try {
            return AI::sendMessage([
                'user' => $message
            ]);
        } catch (\Throwable $exception) {
            $this->addError(new Error($exception->getMessage()));
            return null;
        }
    }
}