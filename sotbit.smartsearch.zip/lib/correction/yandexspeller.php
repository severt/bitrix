<?php

namespace Sotbit\SmartSearch\Correction;


use Bitrix\Main\Application;
use Bitrix\Main\Text\Encoding;
use Bitrix\Main\Web\HttpClient;
use Bitrix\Main\Web\Json;

class YandexSpeller extends SpellerService
{
    const URL = 'https://speller.yandex.net/services/spellservice.json/checkTexts';
    const OPTIONS = 514;

    protected array $arWord;
    protected bool $correct = false;


    public function toCorrect(): string
    {
        $this->arWord = explode(' ', (Encoding::convertToUtf($this->query)));
        $this->checkWords();

        return $this->getResult();
    }

    protected function checkWords()
    {
        $result = $this->sendRequest();

        foreach ($result as $num => $item) {
            if (empty($item) && !$item[0]) {
                continue;
            }

            $this->arWord[$num] = $item[0]['s'][0];
            $this->correct = true;
        }
    }

    protected function getResult()
    {
        if ($this->correct === false) {
            return $this->query;
        }

        if (!Application::isUtfMode()) {
            foreach ($this->arWord as &$word) {
                $word = Encoding::convertEncodingToCurrent($word);
            }
        }

        return implode(' ', $this->arWord);
    }

    private function sendRequest()
    {
        $http = new HttpClient();
        $url = '?';

        foreach ($this->arWord as $q) {
            $url .= 'text=' . $q . '&';
        }

        $url .= 'options=' . self::OPTIONS;
        $requestResult = $http->post(self::URL . $url);

        if (!$requestResult) {
            return null;
        }

        try {
            return Json::decode($requestResult);
        } catch (\Throwable $e) {
            return [];
        }
    }
}