<?php

namespace Sotbit\SmartSearch\Correction;


use Sotbit\SmartSearch\ORM\ReplacementRuleTable;

class ManualReplace
{
    protected string $query;
    protected array $arWord;

    public function __construct(string $query)
    {
        $this->query = mb_strtoupper($query);
        $this->arWord = array_map('trim', explode(' ', mb_strtoupper($query)));
    }

    public function correctionPhrase()
    {
        if (!\SotbitSmartSearch::getDemo()) {
            return;
        }

        $this->replaceFullMatch();
        $this->replacePregMatch();
    }

    public function replaceFullMatch()
    {
        if (!$arRules = self::getRules($this->getWordSet())) {
            return;
        }

        $this->query = str_replace(array_keys($arRules), array_values($arRules), $this->query);
        $this->arWord = array_diff($this->arWord, array_keys($arRules));
    }

    protected function getWordSet()
    {
        $set = [];

        for ($i = 0; $i < count($this->arWord); $i++) {
            $ar1 = array_slice($this->arWord, $i);
            $j = 1;
            do {
                $ar2 = array_slice($ar1, 0, $j);
                $set[] = implode(' ', $ar2);
                $j++;
            } while (count($ar1) !== count($ar2));
        }

        return array_unique($set);
    }

    public function replacePregMatch()
    {
        if (!$arPregWord = self::getPregRules()) {
            return;
        }

        foreach ($arPregWord as $pattern => $replacement) {
            $pattern = mb_strtoupper('/' . str_replace('*', '.*', $pattern) . '/');
            foreach ($this->arWord as $key => $word) {
                if (preg_match($pattern, $word)) {
                    $this->query = str_replace($word, $replacement, $this->query);
                    unset($this->arWord[$key]);
                }
            }
        }
    }

    public static function getRules(array $arWord)
    {
        return array_column(ReplacementRuleTable::query()
            ->addSelect(new \Bitrix\Main\Entity\ExpressionField('WORD', 'UPPER(%s)', 'REPLACEMENT.WORD'))
            ->addSelect(new \Bitrix\Main\Entity\ExpressionField('REPLACED_WORD', 'UPPER(%s)', 'EXCEPTION_WORD'))
            ->whereIn('EXCEPTION_WORD', $arWord)
            ->fetchAll() ?: [], 'WORD', 'REPLACED_WORD');
    }

    public static function getPregRules()
    {
        $filter = \Bitrix\Main\Entity\Query::filter();
        $filter->logic('or')
            ->whereLike('EXCEPTION_WORD', '%*')
            ->whereLike('EXCEPTION_WORD', '*%');

        return array_column(ReplacementRuleTable::query()
            ->addSelect('REPLACEMENT.WORD', 'WORD')
            ->addSelect('EXCEPTION_WORD')
            ->where($filter)
            ->fetchAll() ?: [], 'WORD', 'EXCEPTION_WORD');
    }

    public function getQuery()
    {
        return $this->query;
    }
}