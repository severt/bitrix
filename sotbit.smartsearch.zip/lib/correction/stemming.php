<?php

namespace Sotbit\SmartSearch\Correction;


use Bitrix\Landing\Update\Block\SearchContent;
use Bitrix\Main\Application;
use Bitrix\Main\Loader;
use Bitrix\Main\Text\Encoding;
use Bitrix\Main\Web\HttpClient;
use Bitrix\Main\Web\Json;
use Sotbit\SmartSearch\Helper\Config;

require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/search/tools/stemming.php");

class Stemming
{
    use Transliteration;

    protected string $word = '';
    protected string $stemming = '';
    protected string $lang = 'ru';
    protected bool $existResult = false;

    public function __construct(string $word, array $params = [], string $lang = 'ru')
    {
        $this->word = $word;
        $this->initTransliteration($params, $lang);
    }

    public function process()
    {
        if (!!Config::get('ADVANCED_TITLE_SEARCH_MODE') === false) {
            return;
        }

        $this->stemming();
        $this->stemmingStripos();
    }

    protected function stemming()
    {
        if (!function_exists("stemming")) {
            return;
        }

        if (preg_match('/[\d]+/i', $this->word)) {
            return;
        }

        if ($arStemming = stemming($this->word)) {
            foreach ($arStemming as $key => $value) {
                if ($key) {
                    $this->stemming = $key;
                }
                break;
            }
        }
    }

    protected function stemmingStripos()
    {
        if (empty($this->stemming)) {
            return;
        }

        foreach ($this->getTranslit() as $dbWord) {
            if (mb_stripos($dbWord, $this->stemming) !== false) {
                $this->existResult = true;
            }
        }
    }

    public function existResult()
    {
        return $this->existResult;
    }

    public function getStemmingWord()
    {
        return $this->stemming;
    }
}