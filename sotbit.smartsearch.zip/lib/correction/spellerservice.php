<?php

namespace Sotbit\SmartSearch\Correction;


abstract class SpellerService
{
    protected string $query;
    protected array $params;

    public function __construct(string $query, array $params = [], string $lang = 'ru')
    {
        $this->query = mb_strtoupper($query);
        $this->params = $params;
    }

    abstract public function toCorrect(): string;
}