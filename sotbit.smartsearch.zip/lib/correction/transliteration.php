<?php

namespace Sotbit\SmartSearch\Correction;


use Bitrix\Main\Loader;
use Sotbit\SmartSearch\Helper\Config;

trait Transliteration
{
    public static array $translit = [];
    protected array $params;
    protected string $cacheId;
    protected string $cachePath;
    protected string $lang = 'ru';

    public function initTransliteration($params, $lang)
    {
        $this->lang = $lang;
        $this->params = $params;
        $this->cacheId = self::createCacheId($params);
        $this->cachePath = Config::TRANSLIT_CACHE_PATH . '/' . Config::TRANSLIT_WORD_TITLE;
    }

    private static function createCacheId($params)
    {
        $result = '';
        foreach ($params[0] as $param) {
            if (!is_array($param)) {
                continue;
            }

            $result .= $param['=MODULE_ID'] ?: '';

            if (!$param['PARAM2']) {
                continue;
            }

            $result .= is_array($param['PARAM2']) ? implode('_', $param['PARAM2']) : $param['PARAM2'];
        }

        return md5($result);
    }

    public function getTranslit()
    {
        if (!empty(self::$translit)) {
            return self::$translit;
        }

        return self::$translit = $this->fillTranslitWord();
    }

    public function fillTranslitWord()
    {
        $cache = \Bitrix\Main\Application::getInstance()->getManagedCache();
        if ($cache->read(Config::TRANSLIT_CACHE_TTL, $this->cacheId, $this->cachePath)) {
            return $cache->get($this->cacheId);
        } else {
            $res = array_flip(self::setTranslitWord());
            $cache->setImmediate($this->cacheId, $res);

            return $res;
        }
    }

    public function setTranslitWord(): array
    {
        Loader::includeModule('search');
        $DB = \CDatabase::GetModuleConnection('search');

        $res = [];
        $aSites = false;
        $where = \CSearch::__PrepareFilter($this->params, $aSites);

        $strSql = "SELECT ct.WORD AS WORD FROM b_search_content_title ct
    INNER JOIN b_search_content sc ON sc.ID = ct.SEARCH_CONTENT_ID
    INNER JOIN b_search_content_site scsite ON sc.ID = scsite.SEARCH_CONTENT_ID
WHERE " . $where . ';';
        $db = $DB->Query($strSql);

        while ($item = $db->Fetch()) {
            if (!$res[$item['WORD']]) {
                $res[$item['WORD']] = self::translit($item['WORD'], $this->lang);
            }
        }

        return $res;
    }

    public static function translit($str, $lang = 'ru')
    {
        static $search = array();

        if (!isset($search[$lang])) {
            $mess = IncludeModuleLangFile($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/sotbit.smartsearch/lib/correction/transliteration.php",
                $lang, true);
            $transFrom = explode(",", $mess["TRANSLIT_FROM"]);
            $transTo = explode(",", $mess["TRANSLIT_TO"]);
            $search[$lang] = array_combine($transFrom, $transTo);
        }

        return strtr($str, $search[$lang]);
    }
}