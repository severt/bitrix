<?php

namespace Sotbit\SmartSearch\Correction;


use Bitrix\Landing\Update\Block\SearchContent;
use Bitrix\Main\Application;
use Bitrix\Main\Loader;
use Bitrix\Main\Text\Encoding;
use Bitrix\Main\Web\HttpClient;
use Bitrix\Main\Web\Json;
use Sotbit\SmartSearch\Helper\Config;

class Metaphone extends SpellerService
{
    use Transliteration;

    const MIN_WORD = 3;

    protected array $arWords;

    public function __construct(string $query, array $params = [], string $lang = 'ru')
    {
        parent::__construct($query, $params, $lang);
        $this->initTransliteration($params, $lang);
        $this->arWords = explode(' ', mb_strtoupper($this->query));
    }

    public function toCorrect(): string
    {
        $minWordLen = Config::get('REPLACE_WORD_LEN', 4);
        $minWordLen = $minWordLen < self::MIN_WORD ? self::MIN_WORD : $minWordLen;
        foreach ($this->arWords as &$word) {
            if (mb_strlen($word) < $minWordLen) {
                continue;
            }

            $word = $this->correctionWord($word);
        }

        return implode(' ', $this->arWords);
    }

    public function correctionWord($word)
    {
        $result = [];
        $transWord = self::translit($word, $this->lang);
        $arTransilt = $this->getTranslit();

        if (array_key_exists($transWord, $arTransilt)) {
            return $arTransilt[$transWord];
        }

        foreach ($arTransilt as $bdTrans => $bdWord) {
            if (levenshtein(metaphone($transWord), metaphone($bdTrans)) < mb_strlen(metaphone($transWord)) / 2) {
                if (levenshtein($transWord, $bdTrans) < mb_strlen($transWord) / 2) {
                    $possibleWord[$bdWord] = $bdTrans;
                }
            }
        }

        $similarity = 0;
        $meta_similarity = 0;
        $min_levenshtein = 1000;
        $meta_min_levenshtein = 1000;

        foreach ($possibleWord as $n) {
            $min_levenshtein = min($min_levenshtein, levenshtein($n, $transWord));
        }

        foreach ($possibleWord as $key => $n) {
            if (levenshtein($n, $transWord) === $min_levenshtein) {
                $similarity = max($similarity, similar_text($n, $transWord));
                continue;
            }

            unset($possibleWord[$key]);
        }

        foreach ($possibleWord as $n => $k) {
            if (similar_text($k, $transWord) >= $similarity) {
                $result[$n] = $k;
            }
        }

        if (empty($result)) {
            return $word;
        }

        if (count($result) === 1) {
            return $n;
        }

        foreach ($result as $n) {
            $meta_min_levenshtein = min($meta_min_levenshtein, levenshtein(metaphone($n), metaphone($transWord)));
        }

        foreach ($result as $n) {
            if (levenshtein($n, $transWord) === $meta_min_levenshtein) {
                $meta_similarity = max($meta_similarity, similar_text(metaphone($n), metaphone($transWord)));
            }
        }

        foreach ($result as $n => $k) {
            if (similar_text(metaphone($k), metaphone($transWord)) >= $meta_similarity) {
                return $n;
            }
        }

        return $word;
    }
}