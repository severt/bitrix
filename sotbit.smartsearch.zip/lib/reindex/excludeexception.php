<?php

namespace Sotbit\SmartSearch\Reindex;


class ExcludeException extends \Exception
{

}