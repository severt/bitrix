<?php

namespace Sotbit\SmartSearch\Reindex;

use Sotbit\SmartSearch\General\Synonyms;
use Sotbit\SmartSearch\Helper\Config;
use Sotbit\SmartSearch\Helper\Logger;

abstract class Index
{
    private static $indexOptions = [];
    protected string $itemId;
    protected string $title;
    protected string $origTitle = '';
    protected string $tags = '';
    protected string $body;
    protected int $rank = 0;
    protected array $fields;
    protected bool $exclude = false;

    public function __construct($arFields)
    {
        $this->fields = $arFields;
        $this->itemId = $this->fields['ITEM_ID'];
        $this->origTitle = $this->fields['TITLE'];
        $this->title =& $this->fields['TITLE'];
        $this->body =& $this->fields['BODY'];

        if (!is_null($this->fields['TAGS'])) {
            $this->tags =& $this->fields['TAGS'];
        }

        $this->fields['CUSTOM_RANK'] =& $this->rank;

        self::setIndexOptions();
    }

    abstract protected function startIndex(): void;

    final public function index(): array
    {
        try {
            $this->excludeModules();
            $this->startIndex();
            $this->title = $this->prepareSearch($this->title);
            $this->body = $this->prepareSearch($this->body);
        } catch (\Throwable $e) {
            $this->saveLog($e);
            return $this->fields;
        }

        return $this->fields;
    }

    protected function excludeModules()
    {
        $modulesExclude = $this->getOption('EXCLUDE_MODULES');
        if (!empty($modulesExclude) && in_array($this->fields['MODULE_ID'], $modulesExclude)) {
            $this->exclude();
        }
    }

    protected function exclude()
    {
        $this->exclude = true;
        $this->title = $this->body = $this->tags = '';

        throw new ExcludeException();
    }

    protected static function setIndexOptions()
    {
        if (self::$indexOptions) {
            return self::$indexOptions;
        }

        self::$indexOptions = Config::getIndexOptions();
        self::$indexOptions['RANK_PROPERTIES'] = array_filter(array_keys(self::$indexOptions['RANK_WEIGHT'] ?: []), 'self::isProperty');
    }

    protected static function isProperty($code): bool
    {
        return is_numeric($code);
    }

    protected static function getPropertyId($code): int
    {
        return str_replace('PROPERTY_', '', $code);
    }

    protected function getOption($name)
    {
        return self::$indexOptions[$name];
    }

    protected function addSynonyms()
    {
        if (!$this->getOption('USE_SYNONYMS')) {
            return;
        }

        if (!$arSynonyms = Synonyms::getSynonymsForPhrase($this->title)) {
            return;
        }

        $this->appendTitleValue(implode(' ', $arSynonyms));
    }

    protected static function prepareSearch(string $str): string
    {
        if (empty($str)) {
            return $str;
        }

        $str = strip_tags(htmlspecialchars_decode($str));
        $str = \SotbitSmartSearchHelper::modifySearchString($str);
        $str = \SotbitSmartSearchHelper::removePrepositions($str);

        return $str;
    }

    private function saveLog($e)
    {
        if (!$this->getOption('KEEP_DATA_LOGGING')) {
            return;
        }

        $info = $this->getInfo();
        if ($e instanceof ExcludeException) {
            Logger::saveExcludeLog($info);
        } else {
            $info['ERROR'] = $e->getMessage();
            Logger::saveErrorLog($info);
        }
    }

    private static function deleteLogs()
    {
        Logger::clearLogs();
    }

    protected function getInfo()
    {
        return [
            'ITEM_ID' => $this->fields['ITEM_ID'],
            'MODULE_ID' => $this->fields['MODULE_ID'],
            'TITLE' => $this->origTitle,
            'PARAM1' => $this->fields['PARAM1'],
            'PARAM2' => $this->fields['PARAM2'],
        ];
    }

    protected function appendTitleValue($value)
    {
        $this->title .= ' ' . $value;
    }
}