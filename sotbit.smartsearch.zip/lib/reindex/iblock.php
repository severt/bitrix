<?php

namespace Sotbit\SmartSearch\Reindex;

use Bitrix\Catalog\ProductTable;
use Bitrix\Iblock\ElementTable;
use Bitrix\Iblock\PropertyTable;
use Bitrix\Iblock\SectionTable;
use Bitrix\Main\Loader;
use Sotbit\SmartSearch\General\IblockExcludeRules;
use Sotbit\SmartSearch\Helper\HlTools;
use Sotbit\SmartSearch\Helper\IblockTools;

Loader::includeModule('iblock');
Loader::includeModule('catalog');


class Iblock extends Index
{
    protected int $iblockId;
    protected bool $isSection;
    protected bool $isOffer = false;
    protected array $elementFields;
    protected array $mainElementFields = [];
    protected $maxRank = null;
    protected array $excludeProps = [];


    public function __construct($arFields)
    {
        parent::__construct($arFields);
        $this->iblockId = (int) $arFields['PARAM2'];
        $this->excludeProps = IblockExcludeRules::getRulesByIblock($this->iblockId);
        $this->isSection();
        $this->isOffer();
    }

    public function startIndex(): void
    {
        if ($this->isSection) {
            $this->itemId = mb_substr($this->itemId, 1);
        } else {
            $this->elementFields = $this->getElement();
            $this->elementProps = $this->getProps();
        }

        if (!$this->isSection) {
            $this->checkExclude();
            $this->modifyTitle();
            $this->modifyBody();
            $this->addSynonyms();
            $this->calcRank();
        } else {
            $this->modifySectionTitle();
            $this->setSectionRank();
        }
    }

    protected function checkExclude()
    {
        if ($this->isOffer) {
            $this->checkOfferExclude();
        }

        if (!!$this->getOption('EXCLUDE_BY_SECTION') && $this->elementFields['SECTION_ACTIVE'] === 'N') {
            $this->exclude();
        }

        if (!!$this->getOption('EXCLUDE_UNAVAILABLE') && $this->elementFields['AVAILABLE'] === 'N') {
            $this->exclude();
        }

        if (!!$this->getOption('EXCLUDE_NOT_QUANTITY') && !$this->elementFields['QUANTITY'] && (int)$this->elementFields['TYPE'] !== ProductTable::TYPE_SKU) {
            $this->exclude();
        }

        if ($this->excludeProps && $this->elementProps) {
            $this->checkExcludeProps();
        }
    }

    protected function checkOfferExclude()
    {
        if (!$this->mainElementFields) {
            $this->exclude();
        }

        if (!!$this->getOption('EXCLUDE_OFFER_BY_ACTIVE_MAIN') && $this->mainElementFields['ACTIVE'] === 'N') {
            $this->exclude();
        }
    }

    protected function checkExcludeProps()
    {
        foreach ($this->excludeProps as $propertyId => $enum) {
            if (empty($enum) && !empty($this->elementProps[$propertyId]['VALUE'])) {
                $this->exclude();
                continue;
            }

            $enumValueId = $this->elementProps[$propertyId]['VALUE_ENUM_ID'];
            $enumValueId = is_array($enumValueId) ? $enumValueId : [$enumValueId];

            if (!empty($enum) && !empty($enumValueId) && array_intersect($enum, $enumValueId)) {
                $this->exclude();
            }
        }
    }

    protected function modifyTitle()
    {
        $this->setSeoTitle();
        $this->setTags();
        $this->addSectionName();
        $this->addSearchProps();
    }

    protected function modifySectionTitle()
    {
        $this->setSeoTitle();

        if (!!$this->getOption('USE_SUBSECTION')) {
            $arParent = \CIBlockSection::GetNavChain($this->iblockId, $this->itemId, ['ID', 'NAME'], true);
            foreach ($arParent as $section) {
                if ((int) $section['ID'] === (int) $this->itemId) {
                    continue;
                }

                $this->appendTitleValue($section['NAME']);
            }
        }

        if (!!$this->getOption('USE_SEARCH_PROPS') && $arSearchFields = IblockTools::getSectionSearchProps($this->iblockId)) {
            $dbProps = \CIBlockSection::GetList(['ID' => 'ASC'], ['ID' => $this->itemId, 'IBLOCK_ID' => $this->iblockId], false, $arSearchFields);
            while ($values = $dbProps->Fetch()) {
                foreach (array_intersect_key($values, array_flip($arSearchFields)) as $value) {
                    $this->appendTitleValue(is_array($value) ? implode(' ', $value) : $value);
                }
            }
        }
    }

    protected function modifyBody()
    {
        if ($this->getOption('REPLACE_DESCRIPTION')) {
            $this->body = '';
        }
    }

    protected function calcRank()
    {
        $propsRank = [];
        $dbPropsRank = \CIBlockElement::GetProperty($this->iblockId, $this->itemId, "sort", "asc", ['ID' => $this->getOption('RANK_PROPERTIES'), 'EMPTY' => 'N']);
        while ($item = $dbPropsRank->fetch()) {
            $propsRank[$item['ID']] = $item['VALUE'];
        }

        $checkField = function ($code) {
            switch ($code) {
                case 'AVAILABLE':
                    return  $this->elementFields['AVAILABLE'] === 'Y';
                case 'QUANTITY':
                    return (float)($this->elementFields['AVAILABLE']) > 0;
                case 'PICTURE':
                    return ($this->elementFields['DETAIL_PICTURE'] || $this->elementFields['PREVIEW_PICTURE']);
                case 'IS_PRODUCT':
                    return ((int)$this->elementFields['TYPE'] === ProductTable::TYPE_PRODUCT) || ((int)$this->elementFields['TYPE'] === ProductTable::TYPE_SKU);
                case 'IS_OFFER':
                    return (int)$this->elementFields['TYPE'] === ProductTable::TYPE_OFFER;
                default:
                    return false;
            }
        };

        foreach ($this->getOption('RANK_WEIGHT') as $code => $weight) {
            if (self::isProperty($code)) {
                if (!empty($propsRank) && isset($propsRank[self::getPropertyId($code)])) {
                    $this->rank += $weight;
                }
                continue;
            }

            if ($checkField($code)) {
                $this->rank += $weight;
            }
        }
    }

    protected function setSectionRank()
    {
        if (!!$this->getOption('SECTION_FIRST_PRODUCT') === false) {
            return;
        }

        $this->rank += $this->maxRank ?? array_sum($this->getOption('RANK_WEIGHT')) + 1;
    }

    protected function setSeoTitle()
    {
        if (!$this->getOption('USE_SEO_TITLE')) {
            return;
        }

        if ($seoTitle = $this->getSeoTitle()) {
            $this->title = $seoTitle . ' ' . $this->title;
        }
    }

    protected function setTags()
    {
        if (!!$this->getOption('USE_TAGS') && !empty($this->tags)) {
            $this->appendTitleValue($this->tags);
        } else {
            $this->tags = '';
        }
    }

    protected function addSectionName()
    {
        if (!!$this->getOption('USE_SECTION_NAME') && !$this->isSection) {
            $this->appendTitleValue($this->elementFields['SECTION_NAME']);
        }
    }

    protected function addSearchProps()
    {
        if (!!$this->getOption('USE_SEARCH_PROPS') && IblockTools::getSearchProps($this->iblockId)) {
            $db = \CIBlockElement::GetProperty($this->iblockId, $this->itemId, "sort", "asc", ['ID' => IblockTools::getSearchProps($this->iblockId), 'EMPTY' => 'N']);
            while ($property = $db->fetch()) {
                if (($property['PROPERTY_TYPE'] === PropertyTable::TYPE_STRING || $property['PROPERTY_TYPE'] === PropertyTable::TYPE_NUMBER) && is_null($property['USER_TYPE'])) {
                    $this->appendTitleValue($property['VALUE']);
                    continue;
                }

                if ($property['PROPERTY_TYPE'] === PropertyTable::TYPE_LIST) {
                    $this->appendTitleValue($property['VALUE_ENUM']);
                    continue;
                }

                if ($property['PROPERTY_TYPE'] === PropertyTable::TYPE_STRING && $property['USER_TYPE'] === 'HTML') {
                    if (is_array($property['VALUE']) && $property['VALUE']['TEXT']) {
                        $this->appendTitleValue($property['VALUE']['TEXT']);
                    }
                    continue;
                }

                if ($property['PROPERTY_TYPE'] === PropertyTable::TYPE_STRING && $property['USER_TYPE'] === 'directory') {
                    $this->appendTitleValue(HlTools::getHlValue($property['USER_TYPE_SETTINGS']['TABLE_NAME'], $property['VALUE']));
                }
            }
        }
    }

    protected function getSeoTitle()
    {
        $iTemplatesClass = '\\Bitrix\\Iblock\\InheritedProperty\\' . ($this->isSection ? 'SectionValues' : 'ElementValues');
        $iTemlate = new $iTemplatesClass($this->iblockId, $this->itemId);
        $iblockTemlateValues = $iTemlate->getValues();

        if ($this->isSection && $iblockTemlateValues['SECTION_PAGE_TITLE']) {
            return $iblockTemlateValues['SECTION_PAGE_TITLE'];
        }

        if ($iblockTemlateValues['ELEMENT_PAGE_TITLE']) {
            return $iblockTemlateValues['ELEMENT_PAGE_TITLE'];
        }

        return false;
    }

    protected function isSection()
    {
        $this->isSection = mb_substr($this->itemId, 0, 1) === 'S';
    }

    protected function isOffer()
    {
        if ($this->isSection) {
            return;
        }

        $mainElement = \CCatalogSKU::GetProductInfo($this->itemId);
        if (is_array($mainElement)) {
            $this->isOffer = true;
            $this->mainElementFields = $this->getElement([
                'ID' => $mainElement['ID'],
                'IBLOCK_ID' => $mainElement['IBLOCK_ID'],
            ]);
        }
    }

    protected function getElement($filter = [])
    {
        $filter = $filter ?: [
            'IBLOCK_ID' => $this->iblockId,
            'ID' => $this->itemId
        ];

        return ElementTable::query()
            ->registerRuntimeField(new \Bitrix\Main\Entity\ReferenceField('PRODUCT',
                ProductTable::class,
                array('=this.ID' => 'ref.ID')))
            ->setSelect([
                'ID',
                'PREVIEW_PICTURE',
                'DETAIL_PICTURE',
                'ACTIVE',
                'QUANTITY' => 'PRODUCT.QUANTITY',
                'AVAILABLE' => 'PRODUCT.AVAILABLE',
                'TYPE' => 'PRODUCT.TYPE',
                'SECTION_ACTIVE' => 'IBLOCK_SECTION.ACTIVE',
                'SECTION_NAME' => 'IBLOCK_SECTION.NAME',
            ])
            ->setFilter($filter)
            ->fetch() ?: [];
    }

    protected function getProps()
    {
        $result = [];
        if (empty($this->excludeProps)) {
            return $result;
        }

        \CIBlockElement::GetPropertyValuesArray($result,
            $this->iblockId,
            ["ID" => $this->itemId],
            ['ID' => array_keys($this->excludeProps)],
            ['USE_PROPERTY_ID' => 'Y', 'PROPERTY_FIELDS' => ['VALUE', 'VALUE_ENUM_ID', 'MULTIPLE']]
        );

        return $result[$this->itemId];
    }
}