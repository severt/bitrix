<?php

namespace Sotbit\SmartSearch\Reindex;


class Base extends Index
{
    protected bool $isSection;

    public function __construct($arFields)
    {
        parent::__construct($arFields);
    }

    public function startIndex(): void
    {
    }
}