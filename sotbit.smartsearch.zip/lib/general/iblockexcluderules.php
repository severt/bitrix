<?php

namespace Sotbit\SmartSearch\General;

use Sotbit\SmartSearch\ORM\IElementExcludeRulesTable;

class IblockExcludeRules
{
    protected static $iblockRules = [];

    public static function getFieldsMap()
    {
        return [
            'IBLOCK_ID' => 'IBLOCK_ID',
            'PROPERTY_ID' => 'PROPERTY_ID',
            'VALUE_ID' => 'VALUE_ID'
        ];
    }

    public static function add(array $arFields)
    {
        $arFields = array_intersect_key($arFields, self::getFieldsMap());
        return IElementExcludeRulesTable::add($arFields);
    }

    public static function delete(int $id)
    {
        return IElementExcludeRulesTable::delete($id);
    }

    public static function getRulesByIblock(int $iblockId)
    {
        if (isset(self::$iblockRules[$iblockId])) {
            return self::$iblockRules[$iblockId];
        }

       return self::$iblockRules[$iblockId] = self::getRulesTree($iblockId);
    }

    public static function getRulesTree(int $iblockId)
    {
        $result = [];
        $query = IElementExcludeRulesTable::query()
            ->addSelect('*')
            ->where('IBLOCK_ID', $iblockId)
            ->exec();

        while ($item = $query->fetch()) {
            if ($item['VALUE_ID'] === 0) {
                $result[$item['PROPERTY_ID']] = [];
            } else {
                $result[$item['PROPERTY_ID']][] = $item['VALUE_ID'];
            }
        }

        return $result;
    }
}