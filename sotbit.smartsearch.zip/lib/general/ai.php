<?php

namespace Sotbit\SmartSearch\General;


use Bitrix\Iblock\ElementTable;
use Bitrix\Iblock\PropertyEnumerationTable;
use Bitrix\Iblock\PropertyTable;
use Bitrix\Iblock\SectionTable;
use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;
use Sotbit\Seometa\Section\Section;
use Sotbit\SmartSearch\Helper\Config;
use Sotbit\SmartSearch\Helper\Timer;

Loader::includeModule('iblock');

class AI
{
    const ELEMENT_STEP = 5;
    const TYPE_REPLACE = 'REPLACE';
    const TYPE_SYNONYM = 'SYNONYM';
    const WORD_REPLACE_TAG = '{WORD_LIST}';
    const COUNT_REPLACE_TAG = '{COUNT}';
    const RESULT_FORMAT_REPLACE_TAG = '{RESULT_FORMAT}';

    protected int $iblockId;
    protected string $entity;
    protected int $count;
    protected array $results = [];
    protected array $variants = [];
    protected int $propertyId = 0;
    protected int $processedItems = 0;
    protected string $prompt;
    protected string $type;
    protected string $resultFormat;
    protected Timer $timer;

    public function __construct(array $params)
    {
        $this->iblockId = $params['IBLOCK_ID'] ?? 0;
        $this->entity = $params['ENTITY'] ?? '';
        $this->count = $params['VARIANTS_COUNT'] ?? 5;
        $this->type = $params['AI_TYPE'] ?? self::TYPE_REPLACE;
        $this->propertyId = $this->getProperty();
        $this->timer = new Timer();
        $this->resultFormat = $this->fillResultFormat();
    }

    private function getProperty()
    {
        return str_starts_with($this->entity, 'PROPERTY_') ? substr($this->entity, 9) : 0;
    }

    public function createPrompt()
    {
        switch ($this->type) {
            case self::TYPE_REPLACE:
                $value = Loc::getMessage('SOTBIT_SMARTSEARCH_AI_PROPMT_REPLACE', [
                    '#WORD_LIST_TAG#' => self::WORD_REPLACE_TAG,
                    '#WORD_COUNT_TAG#' => $this->count,
                    '#FORMAT_TAG#' => $this->resultFormat,
                ]);
                break;
            case self::TYPE_SYNONYM:
                $value = Loc::getMessage('SOTBIT_SMARTSEARCH_AI_PROPMT_SYNONYM', [
                    '#WORD_LIST_TAG#' => self::WORD_REPLACE_TAG,
                    '#WORD_COUNT_TAG#' => $this->count,
                    '#FORMAT_TAG#' => $this->resultFormat,
                ]);
            break;
            default:
                $value = '';
        }

        return $this->prompt = $value;
    }

    protected function fillResultFormat()
    {
        switch ($this->type) {
            case self::TYPE_REPLACE:
                $value = Loc::getMessage('SOTBIT_SMARTSEARCH_AI_REUL_FORMAT_REPLACE');
                break;
            case self::TYPE_SYNONYM:
                $value = Loc::getMessage('SOTBIT_SMARTSEARCH_AI_REUL_FORMAT_SYNONYM');
                break;
            default:
                $value = '';
        }

        return $value;
    }

    public function setPrompt(string $value)
    {
        $this->prompt = $value;
    }

    public function getPrompt()
    {
        return $this->prompt;
    }

    public function getVariants()
    {
        if ($this->variants) {
            return $this->variants;
        }

        return $this->variants = $this->getProcessVariants();
    }

    public function sendAction()
    {
        $this->timer->startTimer();

        while (!$this->timer->hasTimeLimitReached()) {
            $items = array_slice($this->variants, ($this->processedItems === 0 ? 0 : $this->processedItems), self::ELEMENT_STEP);
            if (!$items) {
                break;
            }

            $result = self::sendMessage([
                'user' => $this->replaceWordTag($items)
            ]);

            $this->parseResult($result);
            $this->processedItems += self::ELEMENT_STEP;
        }

        return true;
    }

    public function getProcessedItems()
    {
        return $this->processedItems;
    }

    public function getResultItems()
    {
        return $this->results;
    }

    protected function replaceWordTag(array $word, $separator = ',')
    {
        return str_replace(
            [self::WORD_REPLACE_TAG, self::COUNT_REPLACE_TAG, self::RESULT_FORMAT_REPLACE_TAG],
            [implode($separator, $word), $this->count, $this->results],
            $this->prompt
        );
    }

    protected function parseResult($string)
    {
        preg_match_all('/{(.*)}/U', $string, $matches);
        if (!$matches[1]) {
            return;
        }

        $this->results = array_filter(array_merge($this->results, $matches[1]));
    }

    /**
     * @param array $arMessage format: role => content
     */
    public static function sendMessage(array $arMessage)
    {
        if (!$class = Config::getAIModelClass()) {
            throw new \Exception(Loc::getMessage('SOTBIT_SMARTSEARCH_AI_ERROR_MODEL'));
        }

        if (!class_exists($class)) {
            throw new \Exception(Loc::getMessage('SOTBIT_SMARTSEARCH_AI_ERROR_CLASS'));
        }

        return (new $class())->sendMessage($arMessage);
    }

    public static function getEntityToProcess(int $iblockId)
    {
        return self::getDefaultProcessFields() + self::getProcessProps($iblockId);
    }

    protected static function getDefaultProcessFields()
    {
        return [
            'ELEMENTS' => Loc::getMessage('SOTBIT_SMARTSEARCH_AI_ENTITY_ELEMENTS'),
            'SECTIONS' => Loc::getMessage('SOTBIT_SMARTSEARCH_AI_ENTITY_SECTIONS'),
        ];
    }

    protected static function getProcessProps($iblockId)
    {
        $result = [];

        $query = PropertyTable::query()
            ->setSelect(['ID', 'NAME', 'CODE', 'PROPERTY_TYPE', 'USER_TYPE'])
            ->where('IBLOCK_ID', $iblockId)
            ->whereIn('PROPERTY_TYPE', [
                PropertyTable::TYPE_LIST,
                PropertyTable::TYPE_ELEMENT,
                PropertyTable::TYPE_SECTION,
                PropertyTable::TYPE_STRING,
            ])
            ->exec();

        while ($item = $query->fetch()) {
            if ($item['PROPERTY_TYPE'] === PropertyTable::TYPE_STRING && $item['USER_TYPE'] !== 'directory') {
                continue;
            }

            $result["PROPERTY_{$item['ID']}"] = "[{$item['CODE']}] {$item['NAME']}";
        }

        return $result;
    }

    public function getProcessVariants()
    {
        if ($this->propertyId) {
            return $this->getPropertyValues();
        }

        if ($this->entity === 'SECTIONS') {
            return $this->getSections($this->iblockId);
        }

        if ($this->entity === 'ELEMENTS') {
            return $this->getElements($this->iblockId);
        }
    }

    public function serialize()
    {
        return base64_encode(serialize($this));
    }

    public static function unserialize($string): self
    {
        return  unserialize(base64_decode($string));
    }

    protected function getPropertyValues()
    {
        $property = PropertyTable::query()
            ->setSelect(['ID', 'NAME', 'CODE', 'PROPERTY_TYPE', 'USER_TYPE', 'USER_TYPE_SETTINGS', 'LINK_IBLOCK_ID'])
            ->where('ID', $this->propertyId)
            ->fetch();

        $propSettings = $property['USER_TYPE_SETTINGS'] ? unserialize($property['USER_TYPE_SETTINGS']) : [];

        switch ($property['PROPERTY_TYPE']) {
            case PropertyTable::TYPE_SECTION:
                return self::getSections($property['LINK_IBLOCK_ID']);
            case PropertyTable::TYPE_ELEMENT:
                return self::getElements($property['LINK_IBLOCK_ID']);
            case PropertyTable::TYPE_LIST:
                return array_column(PropertyEnumerationTable::query()
                    ->addSelect('VALUE')
                    ->where('PROPERTY_ID', $property['ID'])
                    ->fetchAll() ?: [], 'VALUE');
            case PropertyTable::TYPE_STRING:
            {
                if ($property['USER_TYPE'] !== 'directory') {
                    return null;
                }

                return self::getHlElements($propSettings['TABLE_NAME']);
            }
        }

    }

    protected function getSections($iblockId)
    {
        return array_column(SectionTable::query()
            ->addSelect('NAME')
            ->where('IBLOCK_ID', $iblockId)
            ->fetchAll(), 'NAME');
    }

    protected function getElements($iblockId)
    {
        return array_column(ElementTable::query()
            ->addSelect('NAME')
            ->where('IBLOCK_ID', $iblockId)
            ->fetchAll(), 'NAME');
    }

    protected static function getHlElements($tableName)
    {
        if (!Loader::includeModule('highloadblock')) {
            return null;
        }

        $hlblock = \Bitrix\Highloadblock\HighloadBlockTable::getRow([
            'filter' => [
                '=TABLE_NAME' => $tableName,
            ],
        ]);

        if ($hlblock) {
            $entity = \Bitrix\Highloadblock\HighloadBlockTable::compileEntity($hlblock);
            $entityClass = $entity->getDataClass();

            $items = $entityClass::query()
                ->addSelect('UF_NAME')
                ->fetchAll();

            return array_column($items, 'UF_NAME');
        }

        return null;
    }
}