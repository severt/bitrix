<?php

namespace Sotbit\SmartSearch\General;

use Bitrix\Main\Application;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Text\Encoding;
use Sotbit\SmartSearch\ORM\ReplacementRuleTable;
use Sotbit\SmartSearch\ORM\ReplacementTable;

class Replacement
{
    public static function create(array $arFields, $updateExist = false)
    {
        if (!$arFields['WORD']) {
            throw new \Exception(Loc::getMessage('ERROR_EMPTY_WORD'));
        }

        if (!(is_array($arFields['EXCEPTION_WORD']) && !empty($arFields['EXCEPTION_WORD']))) {
            throw new \Exception(Loc::getMessage('ERROR_EMPTY_EXCEPTION_WORD'));
        }

        if ($issetId = self::getDuplicate($arFields['WORD'])) {
            if (!$updateExist) {
                throw new \Exception(Loc::getMessage('ERROR_RULE_EXIST', ['#WORD#' => $arFields['WORD']]));
            }
        }

        if ($issetId) {
            $replaceObj = ReplacementTable::getByPrimary($issetId, [
                'select' => ['*', 'RULES']
            ])->fetchObject();

            $replaceObj->delete();
            $replaceObj->save();
        }

        $replaceObj = ReplacementTable::createObject();

        $replaceObj->setWord(Encoding::convertEncodingToCurrent($arFields['WORD']));

        foreach ($arFields['EXCEPTION_WORD'] as $word) {
            $word = trim($word);
            if (empty($word)) {
                continue;
            }
            $ruleObj = ReplacementRuleTable::createObject();
            $ruleObj->set('EXCEPTION_WORD', \SotbitSmartSearchHelper::replaceELetter(Encoding::convertEncodingToCurrent($word)));
            $replaceObj->addToRules($ruleObj);
        }

        $result = $replaceObj->save();

        if (!$result->isSuccess()) {
            throw new \Exception($result->getErrorCollection()[0]);
        }

        return $result->getId();
    }

    public static function update(array $fields)
    {
        $id = (int)$fields['ID'];
        ReplacementTable::update($id, ['WORD' => $fields['WORD']]);
        ReplacementRuleTable::bulkDelete(['REPLACEMENT_ID' => $id]);

        foreach (self::prepareArrayWords($fields['EXCEPTION_WORD']) as $word) {
            ReplacementRuleTable::add(['REPLACEMENT_ID' => $id, 'EXCEPTION_WORD' => $word]);
        }
    }

    protected static function prepareArrayWords($arWords)
    {
        $res = [];
        foreach ($arWords as $word) {
            $res[] = \SotbitSmartSearchHelper::replaceELetter(mb_strtoupper($word));
        }

        return array_unique($res);
    }

    protected static function checkDuplicate(string $word): bool
    {
        return ReplacementTable::getCount(['WORD' => $word]) === 0;
    }

    protected static function getDuplicate(string $word)
    {
        return ReplacementTable::query()
            ->addSelect('ID')
            ->where('WORD', $word)
            ->fetch()['ID'];
    }

    public static function delete(int $id)
    {
        ReplacementTable::delete($id);
    }

    public static function createFile()
    {
        $row = '';
        $arCollection = ReplacementTable::getList([
            'select' => ['WORD', 'RULES'],
            'order' => ['WORD' => 'asc']
        ])->fetchCollection();

        foreach ($arCollection as $object) {
            $row .= $object->getWord() . '|';
            $rules = [];
            $rulesCollect = $object->getRules();
            if ($rulesCollect) {
                foreach ($object->getRules()->getAll() as $rule) {
                    $rules[] = $rule->get('EXCEPTION_WORD');
                }
            }
            $row .= implode(';', $rules) . "\n";
        }

        return $row;
    }

    public static function deleteAll()
    {
        ReplacementTable::deleteAll();
    }

    public static function importFile($arFile, $deleteAll = true)
    {
        $f = fopen($arFile['tmp_name'], "rb");
        if (!$size = filesize($arFile['tmp_name'])) {
            throw new \Exception(Loc::getMessage('ERROR_ERROR_FILE_EMPTY'));
        }

        $data = fread($f, $size);
        fclose($f);

        return self::bulkCreateFromString($data, $deleteAll, true);
    }

    public static function bulkCreateFromString(string $data, bool $deleteAll = false, bool $updateExist = false)
    {
        $arFields = self::prepareData($data);

        if ($deleteAll) {
            Replacement::deleteAll();
        }

        foreach ($arFields as $word => $exWords) {
            Replacement::create([
                'WORD' => $word,
                'EXCEPTION_WORD' => array_unique(array_map('\SotbitSmartSearchHelper::replaceELetter', $exWords))
            ], $updateExist);
        }

        return count($arFields);
    }

    private static function prepareData(string $str)
    {
        $str = mb_strtoupper($str);
        $arData = array_filter(array_map('trim', explode("\n", $str)));

        if (!($arData)) {
            throw new \Exception(Loc::getMessage('ERROR_EMPTY_DATA'));
        }

        $arFields = [];
        foreach ($arData as $row) {
            $prepare = explode('|', $row);
            $word = trim($prepare[0]);
            if (Application::isUtfMode() || defined('BX_UTF')) {
                $word = preg_replace('/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $word);
            }

            if (!$prepare || empty($word)) {
                continue;
            }
            if (!(isset($arFields[$word]) && !empty($arFields[$word]))) {
                $exWords = array_filter(array_map('trim', explode(';', $prepare[1])));
                if (empty($exWords)) {
                    continue;
                }

                $arFields[$word] = $exWords;
            }
        }

        if (empty($arFields)) {
            throw new \Exception(Loc::getMessage('ERROR_EMPTY_VALID_DATA'));
        }

        return $arFields;
    }
}