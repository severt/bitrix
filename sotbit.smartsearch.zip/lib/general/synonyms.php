<?php

namespace Sotbit\SmartSearch\General;

use Bitrix\Main\Application;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ORM\Fields\ExpressionField;
use Bitrix\Main\ORM\Query\Query;
use Sotbit\SmartSearch\ORM\ReplacementTable;
use Sotbit\SmartSearch\ORM\SynonymsTable;

class Synonyms
{
    public static function updateSet($setId, $arWord)
    {
        SynonymsTable::deleteSet($setId);
        self::createFromArray($arWord, $setId);
    }

    public static function createFromArray(array $arWord, $setId = null)
    {
        $setId = $setId ?? self::getLastSetId() + 1;
        $arFields = array_map(fn($word) => [
            'WORD' => $word,
            'SET_ID' => $setId
        ], $arWord);

        SynonymsTable::bulkAdd($arFields);
    }

    protected static function getLastSetId()
    {
        return (int)SynonymsTable::query()
            ->addSelect(Query::expr()->max("SET_ID"), 'MAX_SET_ID')
            ->fetch()['MAX_SET_ID'];
    }

    public static function getSetCount()
    {
        return (int)count(SynonymsTable::query()
            ->registerRuntimeField(new ExpressionField('CNT', 'COUNT(1)'))
            ->addGroup('SET_ID')
            ->fetchAll());
    }

    public static function getSetWord($setId)
    {
        return array_column(SynonymsTable::query()
            ->addSelect('WORD')
            ->where('SET_ID', $setId)
            ->fetchAll() ?: [], 'WORD');
    }

    public static function importFile($arFile, $deleteAll = true)
    {
        $f = fopen($arFile['tmp_name'], "rb");
        if (!$size = filesize($arFile['tmp_name'])) {
            throw new \Exception(Loc::getMessage('ERROR_ERROR_FILE_EMPTY'));
        }

        $data = fread($f, $size);
        fclose($f);

        return self::bulkCreateFromString($data, $deleteAll);
    }

    public static function bulkCreateFromString(string $data, bool $deleteAll = false)
    {
        $arFields = self::prepareData($data);

        if ($deleteAll) {
            SynonymsTable::deleteAll();
        }

        $lastSet = self::getLastSetId();
        foreach ($arFields as $arWords) {
            self::createFromArray($arWords, ++$lastSet);
        }

        return count($arFields);
    }

    private static function prepareData(string $str)
    {
        $str = mb_strtoupper($str);
        $arData = array_filter(array_map('trim', explode("\n", $str)));

        if (!($arData)) {
            throw new \Exception(Loc::getMessage('ERROR_EMPTY_DATA'));
        }

        $arFields = [];
        foreach ($arData as $row) {
            if (Application::isUtfMode() || defined('BX_UTF')) {
                $row = preg_replace('/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $row);
            }

            $words = array_filter(array_map('trim', explode(';', $row)));
            if (empty($words)) {
                continue;
            }

            $arFields[] = $words;
        }

        if (empty($arFields)) {
            throw new \Exception(Loc::getMessage('ERROR_EMPTY_VALID_DATA'));
        }

        return $arFields;
    }

    public static function export($order)
    {
        $arSet = array_column(self::getListSet($order), 'WORD_SET');
        return implode("\n", $arSet);
    }

    public static function getListSet($order = [], $navParams = [])
    {
        $query = SynonymsTable::query()
            ->addSelect(new ExpressionField('WORD_SET', "GROUP_CONCAT(WORD SEPARATOR '; ')"))
            ->addSelect('SET_ID')
            ->addGroup('SET_ID')
            ->setOrder($order ?: ['SET_ID' => 'asc']);

        if ($navParams) {
            $query
                ->setLimit($navParams['SIZEN'])
                ->setOffset($navParams['SIZEN'] * ($navParams['PAGEN'] - 1));
        }

        return $query->fetchAll();
    }

    public static function getSynonymsForPhrase(string $string)
    {
        $arWord = explode(' ', $string);

        $arSetId = array_column(SynonymsTable::query()
            ->addSelect('SET_ID')
            ->whereIn('WORD', self::getWordSet($arWord))
            ->fetchAll() ?: [], 'SET_ID');

        if (!$arSetId) {
            return [];
        }

        return  array_column(SynonymsTable::query()
            ->addSelect('WORD')
            ->whereIn('SET_ID', $arSetId)
            ->whereNotIn('WORD', $arWord)
            ->fetchAll() ?: [], 'WORD');
    }

    protected static function getWordSet($arWord)
    {
        $set = [];

        for ($i = 0; $i < count($arWord); $i++) {
            $ar1 = array_slice($arWord, $i);
            $j = 1;
            do {
                $ar2 = array_slice($ar1, 0, $j);
                $set[] = implode(' ', $ar2);
                $j++;
            } while (count($ar1) !== count($ar2));
        }

        return array_unique($set);
    }
}
