<?php

namespace Sotbit\SmartSearch\General;


use Sotbit\SmartSearch\Helper\Config;

\Bitrix\Main\Loader::includeModule('search');

require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/search/classes/general/title.php");


class SearchTitle extends \CAllSearchTitle
{
    protected bool $advancedSearch;

    public function __construct($res = null)
    {
        $this->advancedSearch = !!Config::get('ADVANCED_TITLE_SEARCH_MODE');
        parent::__construct($res);
    }

    function searchTitle($phrase = "", $nTopCount = 5, $arParams = array(), $bNotFilter = false, $order = "")
    {
        $DB = \CDatabase::GetModuleConnection('search');

        $sqlHaving = array();
        $sqlWords = array();
        if (!empty($this->_arPhrase)) {
            $last = true;
            foreach (array_reverse($this->_arPhrase, true) as $word => $pos) {

                if ($last && !preg_match("/[\\n\\r \\t]$/", $phrase)) {
                    $last = false;
                    if (strlen($word) >= $this->minLength) {
                        if ($this->advancedSearch) {
                            $s = $sqlWords[] = "ct.WORD like '%" . $DB->ForSQL($word) . "%'";
                        } else {
                            $s = $sqlWords[] = "ct.WORD like '" . $DB->ForSQL($word) . "%'";
                        }
                    } else {
                        $s = "";
                    }
                } else {
                    if ($this->advancedSearch) {
                        $s = $sqlWords[] = "ct.WORD like '%" . $DB->ForSQL($word) . "%'";
                    } else {
                        $s = $sqlWords[] = "ct.WORD = '" . $DB->ForSQL($word) . "'";
                    }
                }

                if ($s) {
                    $sqlHaving[] = "(sum(" . $s . ") > 0)";
                }
            }
        }

        if (!empty($sqlWords)) {
            $bIncSites = false;
            $strSqlWhere = \CSearch::__PrepareFilter($arParams, $bIncSites);
            if ($bNotFilter)
            {
                if (!empty($strSqlWhere))
                    $strSqlWhere = "NOT (".$strSqlWhere.")";
                else
                    $strSqlWhere = "1=0";
            }

            $strSelect = "
			sc.ID
			,sc.MODULE_ID
			,sc.ITEM_ID
			,sc.TITLE
			,sc.PARAM1
			,sc.PARAM2
			,sc.DATE_CHANGE
			,sc.URL as URL
			,sc.CUSTOM_RANK as CUSTOM_RANK
			,scsite.URL as SITE_URL
			,scsite.SITE_ID
			";

            $strSelect .= $this->getSqlSelectRank($phrase);

            $strSql = "
				SELECT
					" . $strSelect . "
				FROM
					b_search_content_title ct
					inner join b_search_content sc on sc.ID = ct.SEARCH_CONTENT_ID
					INNER JOIN b_search_content_site scsite ON sc.ID = scsite.SEARCH_CONTENT_ID and ct.SITE_ID = scsite.SITE_ID
				WHERE
					" . \CSearch::CheckPermissions("sc.ID") . "
					AND ct.SITE_ID = '" . SITE_ID . "'
					AND (" . implode(" OR ", $sqlWords) . ")
					" . (!empty($strSqlWhere) ? "AND " . $strSqlWhere : "") . "
				GROUP BY
					ID, MODULE_ID, ITEM_ID, TITLE, PARAM1, PARAM2, DATE_CHANGE, URL, SITE_URL, SITE_ID
				" . (count($sqlHaving) > 1 ? "HAVING " . implode(" AND ", $sqlHaving) : "") . "
				ORDER BY " . $this->getSqlOrderExt($order) . "
				LIMIT 0, " . ($nTopCount + 1) . "
			";

            $r = $DB->Query($strSql);
            \CDBResult::__construct($r);

            return true;
        } else {
            return false;
        }
    }

    protected function getSqlOrderExt($order)
    {
        if ($order === 'rank') {
            if ($this->advancedSearch) {
                return "CUSTOM_RANK DESC, RANK1 ASC, ID ASC";
            } else {
                return "CUSTOM_RANK DESC, RANK1 DESC, RANK2 DESC, RANK3 ASC, TITLE";
            }
        } else {
            return "CUSTOM_RANK DESC, DATE_CHANGE DESC, RANK1 ASC, TITLE";
        }
    }

    protected function getSqlOrder($isRank)
    {
        return $this->getSqlOrderExt($isRank ? 'rank' : 'other');
    }

    protected function getSqlSelectRank($phrase)
    {
        $DB = \CDatabase::GetModuleConnection('search');
        $result = '';

        if ($this->advancedSearch && !empty($this->_arPhrase)) {
            foreach (array_keys($this->_arPhrase) as $word) {
                if (strlen($result) > 0) {
                    $result .= " + ";
                }

                $result .= "if(locate('" . $DB->ForSql(mb_strtoupper($word)) . "', upper(sc.TITLE)) > 0, locate('" . $DB->ForSql(mb_strtoupper($word)) . "', upper(sc.TITLE)), 250)";
            }

            return ', ' . $result . " as RANK1";
        } else {
            $result = ",if(locate('".$DB->ForSQL(mb_strtoupper($phrase))."', upper(sc.TITLE)) > 0, 1, 0) RANK1
					,locate('".$DB->ForSQL(ToUpper($phrase))."', upper(sc.TITLE)) RANK2
					,min(ct.POS) RANK3";
            return $result;
        }
    }
}