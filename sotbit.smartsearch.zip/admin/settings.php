<?php
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_admin_before.php");

use Bitrix\Main\Loader,
    Bitrix\Main\Localization\Loc,
    Bitrix\Main\Context,
    Sotbit\SmartSearch\Helper\Config;


const MODULE_NAME = 'sotbit.smartsearch';
global $APPLICATION;

if (!Loader::includeModule(MODULE_NAME)) {
    die();
}



if ($APPLICATION->GetGroupRight(MODULE_NAME) == "D") {
    $APPLICATION->AuthForm(\SotbitSmartSearch::getAccessDenidedTitle());
}

require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_admin_after.php");
require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/iblock/prolog.php');

if (!\SotbitSmartSearch::getDemo()) {
    CAdminMessage::ShowMessage(array(
        "MESSAGE" => \SotbitSmartSearch::getDemoExpiredTitle(),
        'HTML' => 1,
        "TYPE" => "ERROR"
    ));
    return;
}

$APPLICATION->AddHeadScript('/bitrix/js/sotbit.smartsearch/listboxes.js');
$APPLICATION->AddHeadScript('/bitrix/js/sotbit.smartsearch/dragula.js');
$APPLICATION->AddHeadScript('/bitrix/js/sotbit.smartsearch/customselect.js');
$APPLICATION->AddHeadScript('/bitrix/js/sotbit.smartsearch/aichat.js');
$APPLICATION->SetAdditionalCSS('/bitrix/css/sotbit.smartsearch/admin.css');
\Bitrix\Main\UI\Extension::load(["ui.hint", "ui.dialogs.messagebox", "ui.alerts"]);
//Config::setReindexingFlag(false);
$request = Context::getCurrent()->getRequest();

if ($request->isPost() && $request->get('save') <> '') {
    try {
        $arFields = $request->getValues();
        if (!empty($arFields['RANK_SETTINGS'])) {
            $rankSettings = [];
            $rankWeight = [];
            $maxRate = 1;
            foreach ($arFields['RANK_SETTINGS'] as $code => $items) {
                foreach ($items as $i => $val) {
                    $rank[$i][$code] = $val;
                    if ($code === 'CODE' && !$rankWeight[$code]) {
                        $rankWeight[$val] = $maxRate = ($maxRate) * 2;
                    }
                }
            }

            $arFields['RANK_SETTINGS'] = $rank;
            $arFields['RANK_WEIGHT'] = array_combine(array_keys($rankWeight), array_reverse(array_values($rankWeight)));
        }

        $needReindex = Config::checkReindexFlag($arFields);
        Config::saveOptions($arFields);

        if ($needReindex) {
            Config::setReindexingFlag(true);
        }

        CAdminMessage::ShowMessage(array(
            "MESSAGE" => Loc::getMessage('SOTBIT_SMARTSEARCH_TITLE_SAVE_SUCCESS'),
            'HTML' => 1,
            "TYPE" => "OK"
        ));
    } catch (\Throwable $e) {
    }
}

if (!!Config::getReindexingFlag()) {
    echo '<div class="adm-info-message-wrap"><div class="adm-info-message">	<table><tbody><tr>
	<td><img src="/bitrix/images/search/warning.gif">&nbsp;</td>
	<td><font class="legendtext">'.Loc::getMessage('SOTBIT_SMARTSEARCH_SETTINGS_REINDEX_WARNING').'</font></td>
	</tr></tbody></table>
	</div>
</div>';
}

$arOptions = Config::getAll(false);

$aTabs = [
    [
        "DIV" => "main",
        "TAB" => Loc::getMessage('SOTBIT_SMARTSEARCH_SETTINGS_MAIN_TAB'),
        "TITLE" => Loc::getMessage('SOTBIT_SMARTSEARCH_SETTINGS_MAIN_TAB_TITLE'),
    ],
    [
        "DIV" => "ai",
        "TAB" => Loc::getMessage('SOTBIT_SMARTSEARCH_SETTINGS_AI_TAB'),
        "TITLE" => Loc::getMessage('SOTBIT_SMARTSEARCH_SETTINGS_AI_TAB_TITLE'),
    ],
    [
        "DIV" => "replacement",
        "TAB" => Loc::getMessage('SOTBIT_SMARTSEARCH_SETTINGS_REPLACE_TAB'),
        "TITLE" => Loc::getMessage('SOTBIT_SMARTSEARCH_SETTINGS_REPLACE_TAB_TITLE'),
    ],
    [
        "DIV" => "synonyms",
        "TAB" => Loc::getMessage('SOTBIT_SMARTSEARCH_SETTINGS_SYNONYMS_TAB'),
        "TITLE" => Loc::getMessage('SOTBIT_SMARTSEARCH_SETTINGS_SYNONYMS_TAB_TITLE'),
    ],
];

if (\SotbitSmartSearch::isDemo()) {
    CAdminMessage::ShowMessage(array(
        "MESSAGE" => \SotbitSmartSearch::getDemoTitle(),
        'HTML' => 1,
    ));
}

$formName = 'smartsearch_settings';
$tabControl = new CAdminForm($formName, $aTabs);
$tabControl->BeginEpilogContent();
echo bitrix_sessid_post();
$tabControl->EndEpilogContent();
$tabControl->Begin();

//MAIN tab
$tabControl->BeginNextFormTab();
$tabControl->BeginCustomField("ENABLE",
    '', false);
?>
    <tr>
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_SECTION_ENABLE_MODULE") ?>
        </td>
        <td width="50%">
            <input type="checkbox" value="true"
                   name="ENABLE_MODULE" <?= !!$arOptions['ENABLE_MODULE'] ? 'checked' : '' ?>>
        </td>
    </tr>
<?php
$tabControl->EndCustomField("ENABLE");

$tabControl->AddSection('SEARCH_ALGORITHM', Loc::getMessage('SOTBIT_SMARTSEARCH_SECTION_SEARCH_ALGORITHM'));
$tabControl->BeginCustomField("MECHANISM",
    '', false);
?>
    <tr id="tr_ADVANCED_TITLE_SEARCH_MODE">
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_ADVANCED_TITLE_SEARCH_MODE") ?>
        </td>
        <td width="50%">
            <input type="checkbox" value="true"
                   name="ADVANCED_TITLE_SEARCH_MODE" <?= !!$arOptions['ADVANCED_TITLE_SEARCH_MODE'] ? 'checked' : '' ?>>
            <span data-hint="<?= Loc::getMessage('SOTBIT_SMARTSEARCH_FIELD_ADVANCED_TITLE_SEARCH_MODE_HINT'); ?>"></span>
        </td>
    </tr>
    <tr>
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_USE_SEARCH_PROPS") ?>
        </td>
        <td width="50%">
            <input type="checkbox" value="true"
                   name="USE_SEARCH_PROPS" <?= !!$arOptions['USE_SEARCH_PROPS'] ? 'checked' : '' ?>>
            <span data-hint="<?= Loc::getMessage('SOTBIT_SMARTSEARCH_USE_SEARCH_PROPS_HINT'); ?>"></span>
        </td>
    </tr>
    <tr>
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_USE_TAGS") ?>
        </td>
        <td width="50%">
            <input type="checkbox" value="true" name="USE_TAGS" <?= !!$arOptions['USE_TAGS'] ? 'checked' : '' ?>>
        </td>
    </tr>
    <tr>
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_USE_SEO_TITLE") ?>
        </td>
        <td width="50%">
            <input type="checkbox" value="true"
                   name="USE_SEO_TITLE" <?= !!$arOptions['USE_SEO_TITLE'] ? 'checked' : '' ?>>
        </td>
    </tr>
    <tr>
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_USE_SECTION_NAME") ?>
        </td>
        <td width="50%">
            <input type="checkbox" value="true"
                   name="USE_SECTION_NAME" <?= !!$arOptions['USE_SECTION_NAME'] ? 'checked' : '' ?>>
            <span data-hint="<?= Loc::getMessage('SOTBIT_SMARTSEARCH_USE_SECTION_NAME_HINT'); ?>"></span>
        </td>
    </tr>
    <tr>
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_USE_SUBSECTION") ?>
        </td>
        <td width="50%">
            <input type="checkbox" value="true"
                   name="USE_SUBSECTION" <?= !!$arOptions['USE_SUBSECTION'] ? 'checked' : '' ?>>
            <span data-hint="<?= Loc::getMessage('SOTBIT_SMARTSEARCH_USE_SUBSECTION_HINT'); ?>"></span>
        </td>
    </tr>
    <tr>
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_REPLACE_DESCRIPTION") ?>
        </td>
        <td width="50%">
            <input type="checkbox" value="true"
                   name="REPLACE_DESCRIPTION" <?= !!$arOptions['REPLACE_DESCRIPTION'] ? 'checked' : '' ?>>
            <span data-hint="<?= Loc::getMessage('SOTBIT_SMARTSEARCH_REPLACE_DESCRIPTION_HINT'); ?>"></span>
        </td>
    </tr>
<?
$tabControl->EndCustomField("MECHANISM");

$tabControl->AddSection('SPELLING', Loc::getMessage('SOTBIT_SMARTSEARCH_SECTION_SPELLING'));
$tabControl->BeginCustomField('SPELLING_SETTINGS', '');
?>
    <tr>
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_USE_CORRECTION") ?>
        </td>
        <td width="50%">
            <input type="checkbox" value="true"
                   name="USE_CORRECTION" <?= !!$arOptions['USE_CORRECTION'] ? 'checked' : '' ?>>
        </td>
    </tr>
    <tr id="tr_SPELLER_METHOD">
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_USE_SPELLER_METHOD") ?>
        </td>
        <td width="50%">
            <select name="SPELLER_METHOD[]" multiple>
                <? foreach (Config::getSpellerServices() as $key => $service): ?>
                    <option value="<?= $key ?>" <?= (is_array($arOptions['SPELLER_METHOD']) && in_array($key, $arOptions['SPELLER_METHOD'])) ? 'selected' : '' ?>><?= $service['NAME'] ?></option>
                <? endforeach; ?>
            </select>
            <span data-hint="<?= Loc::getMessage('SOTBIT_SMARTSEARCH_FIELD_USE_SPELLER_METHOD_HINT'); ?>"
                  data-hint-html></span>
        </td>
    </tr>
    <tr id="tr_REPLACE_WORD_LEN">
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_REPLACE_WORD_LEN") ?>
        </td>
        <td width="50%">
            <input type="number" step="1"  min="0" name="REPLACE_WORD_LEN" value="<?= $arOptions['REPLACE_WORD_LEN'] ?>">
        </td>
    </tr>
    <tr id="tr_KEEP_SEARCH">
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_KEEP_SEARCH") ?>
        </td>
        <td width="50%">
            <input type="checkbox" value="true"
                   name="KEEP_SEARCH" <?= !!$arOptions['KEEP_SEARCH'] ? 'checked' : '' ?>>
            <span data-hint="<?= Loc::getMessage('SOTBIT_SMARTSEARCH_FIELD_KEEP_SEARCH_HINT'); ?>"
                  data-hint-html></span>
        </td>
    </tr>
    <tr id="tr_KEEP_SEARCH_PAGE">
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_KEEP_SEARCH_PAGE") ?>
        </td>
        <td width="50%">
            <input type="checkbox" value="true"
                   name="KEEP_SEARCH_PAGE" <?= !!$arOptions['KEEP_SEARCH_PAGE'] ? 'checked' : '' ?>>
            <span data-hint="<?= Loc::getMessage('SOTBIT_SMARTSEARCH_FIELD_KEEP_SEARCH_PAGE_HINT'); ?>"
                  data-hint-html></span>
        </td>
    </tr>
<?php
$tabControl->EndCustomField('SPELLING_SETTINGS');

$tabControl->BeginCustomField('INDEXING_RANK_SECTION', '');
?>
    <tr class="heading" id="tr_INDEXING_RANK">
        <td colspan="2">
            <?= Loc::getMessage('SOTBIT_SMARTSEARCH_SECTION_INDEXING_RANK'); ?>
            <span data-hint="<?= Loc::getMessage('SOTBIT_SMARTSEARCH_SECTION_INDEXING_RANK_HINT'); ?>"></span>
        </td>
    </tr>
<?php
$tabControl->EndCustomField('INDEXING_RANK_SECTION');

$tabControl->BeginCustomField('SECTION_FIRST_PRODUCT', Loc::getMessage('SOTBIT_SMARTSEARCH_SECTION_FIRST_PRODUCT'));
?>
    <tr id="tr_SECTION_FIRST_PRODUCT">
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_SECTION_FIRST_PRODUCT") ?>
        </td>
        <td width="50%">
            <input type="checkbox" name="SECTION_FIRST_PRODUCT" value="true" <?= !!$arOptions['SECTION_FIRST_PRODUCT'] ? 'checked' : '' ?>>
        </td>
    </tr>
<?php
$tabControl->EndCustomField('SECTION_FIRST_PRODUCT');

$tabControl->BeginCustomField("RANK_SETTINGS",
    '', false);

$arGroupsSorting = [
    0 => [
        'NAME' => Loc::getMessage('SOTBIT_SMARTSEARCH_CUSTOM_RANK_DEF_GROUP'),
        'FIELDS' => [
            'AVAILABLE' => Loc::getMessage('SOTBIT_SMARTSEARCH_CUSTOM_RANK_AVAILABLE'),
            'QUANTITY' => Loc::getMessage('SOTBIT_SMARTSEARCH_CUSTOM_RANK_QNT'),
            'PICTURE' => Loc::getMessage('SOTBIT_SMARTSEARCH_CUSTOM_PICTURE'),
            'IS_PRODUCT' => Loc::getMessage('SOTBIT_SMARTSEARCH_CUSTOM_RANK_IS_PRODUCT'),
            'IS_OFFER' => Loc::getMessage('SOTBIT_SMARTSEARCH_CUSTOM_RANK_IS_OFFER'),
        ]
    ],
];

$dbIblock = \Bitrix\Iblock\IblockTable::query()
    ->setSelect(['ID', 'NAME'])
    ->exec();

while ($iblock = $dbIblock->fetch()) {
    $arProps = array_column(\Bitrix\Iblock\PropertyTable::query()
        ->setSelect(['ID', 'NAME', 'CODE'])
        ->addSelect(new \Bitrix\Main\ORM\Fields\ExpressionField('VAL', 'CONCAT("[", %s, "] ", %s)', ['CODE', 'NAME']))
        ->where('IBLOCK_ID', $iblock['ID'])
        ->fetchAll() ?: [], 'VAL', 'ID');
    if (!empty($arProps)) {
        $arGroupsSorting[$iblock['ID']] = [
            'NAME' => Loc::getMessage('SOTBIT_SMARTSEARCH_PROP_IBLOCK') . ' [' . $iblock["ID"] . '] "' . $iblock["NAME"] . '"',
            'FIELDS' => $arProps
        ];
    }
}
?>
    <tr id="tr_RANK_SETTINGS">
        <td colspan="2">
            <div class="setting-group">
                <div id="rank-listbox">
                    <div class="container">
                        <div id="final-rank" class="listbox" data-type="final-rank">
                            <? if ($arOptions['RANK_SETTINGS']) {
                                foreach ($arOptions['RANK_SETTINGS'] as $rank):?>
                                    <span data-type="rank-item">
                                        <i></i>
                                        <input type="hidden" name="RANK_SETTINGS[CODE][]" value="<?= $rank['CODE'] ?>">
                                        <input type="hidden" name="RANK_SETTINGS[VALUE][]"
                                               value="<?= $rank['VALUE'] ?>">
                                        <input type="hidden" name="RANK_SETTINGS[ENTITY][]"
                                               value="<?= $rank['ENTITY'] ?>">
                                            <span data-type="name"><?= $arGroupsSorting[$rank['ENTITY']]['FIELDS'][$rank['CODE']] ?></span>
                                        <i data-type="delete"></i>
                                    </span>
                                <? endforeach;
                            } ?>
                        </div>
                    </div>

                    <div class="btn-move" data-type="btn-move"></div>
                    <div class="container">
                        <div class="search">
                            <input type="text" id="listbox-search" name="search_filed"
                                   placeholder="<?= Loc::getMessage('SOTBIT_SMARTSEARCH_SEARCH_FIELDS'); ?>">
                        </div>
                        <div class="listbox" data-type="variant-rank">
                            <? foreach ($arGroupsSorting as $groupId => $group): ?>
                                <div class="section" data-id="<?= $groupId ?>">
                                    <span><?= $group['NAME'] ?></span>
                                    <? foreach ($group['FIELDS'] as $code => $field) {
                                        $continue = false;
                                        foreach ($arOptions['RANK_SETTINGS'] as $rank) {
                                            if ($rank['CODE'] === $code && (int)$rank['ENTITY'] === $groupId) {
                                                $continue = true;
                                                break;
                                            }
                                        }

                                        if ($continue) {
                                            continue;
                                        }
                                        echo "<span data-type=\"rank-item\" data-code=\"{$code}\">{$field}</span>";
                                    } ?>
                                </div>
                            <? endforeach; ?>
                        </div>
                    </div>
                </div>
                <div class="adm-info-message-wrap" style="display: flex; justify-content: center;">
                    <div class="adm-info-message">
                        <span class=""><?= Loc::getMessage('SOTBIT_SMARTSEARCH_CUSTOM_RANK_MESSAGE'); ?></span>
                    </div>
                </div>
            </div>

            <script>
                BX.ready(() => {
                    SmartsearchListbox.init({
                        input: 'RANK_SETTINGS'
                    });
                });
            </script>
        </td>
    </tr>
<?php
$tabControl->EndCustomField("RANK_SETTINGS");

//EXCLUDE
$tabControl->AddSection('EXCLUDE', Loc::getMessage('SOTBIT_SMARTSEARCH_SECTION_EXCLUDE'));
$tabControl->BeginCustomField("EXCLUDE_PARAMS", "");
?>
    <tr>
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_EXCLUDE_UNAVAILABLE") ?>
        </td>
        <td width="50%">
            <input type="checkbox" value="true"
                   name="EXCLUDE_UNAVAILABLE" <?= !!$arOptions['EXCLUDE_UNAVAILABLE'] ? 'checked' : '' ?>>
        </td>
    </tr>
    <tr>
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_EXCLUDE_NOT_QUANTITY") ?>
        </td>
        <td width="50%">
            <input type="checkbox" value="true"
                   name="EXCLUDE_NOT_QUANTITY" <?= !!$arOptions['EXCLUDE_NOT_QUANTITY'] ? 'checked' : '' ?>>
        </td>
    </tr>
    <tr>
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_EXCLUDE_BY_SECTION") ?>
        </td>
        <td width="50%">
            <input type="checkbox" value="true" name="EXCLUDE_BY_SECTION"  <?= !!$arOptions['EXCLUDE_BY_SECTION'] ? 'checked' : '' ?>>
        </td>
    </tr>
    <tr>
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_EXCLUDE_OFFER_BY_ACTIVE_MAIN") ?>
        </td>
        <td width="50%">
            <input type="checkbox" value="true"
                   name="EXCLUDE_OFFER_BY_ACTIVE_MAIN" <?= !!$arOptions['EXCLUDE_OFFER_BY_ACTIVE_MAIN'] ? 'checked' : '' ?>>
        </td>
    </tr>
    <tr>
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_EXCLUDED_PREPOSITIONS") ?>
        </td>
        <td width="50%">
            <div id="excluded_prepositions_wrap">
                <input type="text" name="EXCLUDED_PREPOSITIONS_INPUT" data-type="input">
                <button type="button" class="adm-btn adm-btn-add smartselect-add"
                        title="<?= Loc::getMessage('SOTBIT_SMARTSEARCH_ADD_TITLE'); ?>"
                        data-type="add"></button>
            </div>
            <script>
                const prep_exclude = new SotbitSmartSearchSelect({
                    wrap: 'excluded_prepositions_wrap',
                    inputName: 'EXCLUDED_PREPOSITIONS',
                    items: <?=CUtil::PhpToJSObject($arOptions['EXCLUDED_PREPOSITIONS'])?>,
                }).init();
            </script>
        </td>
    </tr>
<?php
$installModules = array_keys(\Bitrix\Main\ModuleManager::getInstalledModules());
?>
    <tr>
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_EXCLUDE_MODULES") ?>
        </td>
        <td width="50%">
            <?
            echo SelectBoxMFromArray('EXCLUDE_MODULES[]', [
                'REFERENCE' => $installModules,
                'REFERENCE_ID' => $installModules,
            ], $arOptions['EXCLUDE_MODULES'])
            ?>
        </td>
    </tr>
<?php
$tabControl->EndCustomField("EXCLUDE_PARAMS");
$tabControl->BeginCustomField('EXCLUDE_IBLOCK_ELEMENT', '');
?>
    <tr class="heading" id="tr_EXCLUDE_IBLOCK_ELEMENT">
        <td colspan="2">
            <?= Loc::getMessage('SOTBIT_SMARTSEARCH_SECTION_EXCLUDE_IBLOCK_ELEMENT'); ?>
            <span data-hint="<?= Loc::getMessage('SOTBIT_SMARTSEARCH_SECTION_EXCLUDE_IBLOCK_ELEMENT_HINT'); ?>" data-hint-html></span>
        </td>
    </tr>
<?php
$tabControl->EndCustomField('EXCLUDE_IBLOCK_ELEMENT');
$tabControl->BeginCustomField("EXCLUDE_IBLOCK_ELEMENT_RULES", "");
?>
    <tr>
        <td colspan="2">
            <?
            include $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/sotbit.smartsearch/admin/templates/ielement_exclude_list.php';
            ?>
        </td>
    </tr>
<?php
$tabControl->EndCustomField("EXCLUDE_IBLOCK_ELEMENT_RULES");

//AI TAB
$arAIModels = Config::getAIModelList();
$model = $request->get('AI_MODEL') ?: $arOptions['AI_MODEL'] ?: array_key_first($arAIModels);
$classModel = '\\Sotbit\\SmartSearch\\AI\\Model\\' . $model;

$tabControl->BeginNextFormTab();
$tabControl->BeginCustomField("AI_MODEL", Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_AI_MODEL"), true);
if (class_exists($classModel)) {
    echo '<tr id="tr_MODEL">
        <td width="40%">' . $tabControl->GetCustomLabelHTML() . '</td>
        <td width="60%">
            ' . SelectBoxFromArray('AI_MODEL',
            [
                'REFERENCE_ID' => $arAIModels,
                'REFERENCE' => $arAIModels,
            ],
            $model,
            '',
            '',
            true,
            'smartsearch_settings_form') . '
        </td>
    </tr>';
} else {
    echo '<tr><td colspan="2">' .  ShowError('AI model class not found') . '</td></tr>';
}
$tabControl->EndCustomField("AI_MODEL");

if (class_exists($classModel)) {
    $obModel = new $classModel();
    $obModel->renderOptions($tabControl, $request);
}

$tabControl->AddSection('AI_CHAT_SECTION', Loc::getMessage('SOTBIT_SMARTSEARCH_SECTION_AI_CHAT'));
$tabControl->BeginCustomField("AI_CHAT", 'AI_CHAT', true);
?>
    <tr>
        <td width="40%"><?=Loc::getMessage('SOTBIT_SMARTSEARCH_AI_CHAT_MESS');?></td>
        <td width="60%">
            <textarea name="AI_CHAT_MESSAGE" id="ai_message" cols="60" rows="10" data-type="input-message"></textarea>
        </td>
    </tr>
    <tr>
        <td width="40%"><?=Loc::getMessage('SOTBIT_SMARTSEARCH_AI_CHAT_RESP');?></td>
        <td width="60%">
            <div data-type="response"></div>
        </td>
    </tr>
    <tr>
        <td class="adm-detail-content-cell-l"></td>
        <td id="btn_section_send_request" style="position: relative" class="adm-detail-content-cell-r">
            <input class="adm-btn-save" data-type="send-message"name="send_ai_request" type="button" value="<?=Loc::getMessage('SOTBIT_SMARTSEARCH_AI_CHAT_SEND');?>">
            <input data-type="send-reset" type="button" value="<?=Loc::getMessage('SOTBIT_SMARTSEARCH_AI_CHAT_RESET');?>">
        </td>
    </tr>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            new SotbitAiChat({
                chatWrap: 'ai_edit_table'
            }).init();
        });
    </script>
<?php
$tabControl->EndCustomField("AI_CHAT");


//REPLACEMENT
$tabControl->BeginNextFormTab();
$tabControl->BeginCustomField("REPLACEMENT",
    '', false);
?>
    <tr id="tr_REPLACEMENT">
        <td colspan="2">
            <?
            include $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/sotbit.smartsearch/admin/templates/replacement_list.php';
            ?>
        </td>
    </tr>
<?php
$tabControl->EndCustomField("REPLACEMENT");

//SYNONYMS
$tabControl->BeginNextFormTab();
$tabControl->BeginCustomField('USE_SYNONYMS', '');
?>
    <tr id="tr_USE_SYNONYMS">
        <td width="50%">
            <?= Loc::getMessage("SOTBIT_SMARTSEARCH_FIELD_USE_SYNONYMS") ?>
        </td>
        <td width="50%">
            <input type="checkbox" value="true"
                   name="USE_SYNONYMS" <?= !!$arOptions['USE_SYNONYMS'] ? 'checked' : '' ?>>
            <span data-hint="<?= Loc::getMessage('SOTBIT_SMARTSEARCH_FIELD_USE_SYNONYMS_HINT'); ?>"
                  data-hint-html></span>
        </td>
    </tr>
    <tr><td colspan="2" style="padding: 6px;"></td></tr>
<?php
$tabControl->EndCustomField("USE_SYNONYMS");

$tabControl->BeginCustomField("SYNONYMS",
    '', false);
?>
    <tr id="tr_SYNONYMS">
        <td colspan="2">
            <?
            include $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/sotbit.smartsearch/admin/templates/synonyms_list.php';
            ?>
        </td>
    </tr>
<?php
$tabControl->EndCustomField("SYNONYMS");


$tabControl->arParams["FORM_ACTION"] = $APPLICATION->GetCurPageParam();
$arButtonsParams = array(
    'disabled' => false,
    'btnApply' => false
);

$tabControl->Buttons($arButtonsParams);

$tabControl->SetShowSettings(false);
$tabControl->Show();
$APPLICATION->setTitle(Loc::getMessage('SOTBIT_SMARTSEARCH_TITLE'));
?>

    <script>
        BX.UI.Hint.init(BX('smartsearch_settings_form'));
    </script>

<?php
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/epilog_admin.php");