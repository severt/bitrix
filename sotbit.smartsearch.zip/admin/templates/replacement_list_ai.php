<?php
use Bitrix\Main\UI\Extension;
use Bitrix\Main\Localization\Loc;

Extension::load(["ui.progressbar", "ui.stepprocessing"]);

Loc::loadLanguageFile(__FILE__);

$iblockList = \Sotbit\SmartSearch\Helper\IblockTools::getIblockList();
$currentIblockId = array_key_first($iblockList);
$entity = \Sotbit\SmartSearch\General\AI::getEntityToProcess($currentIblockId);
$range = range(1, 10);
?>

<template id="aiResultTemplate">
    <div class="ai_result__wrap">
        <div class="form-group">
            <textarea name="AI_RESULT" id="ai_result"></textarea>
        </div>

        <span class="text-mutted"><?=Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_RES_TEXT')?></span>
        <button type="button" class="ui-btn ui-btn-success ui-btn-icon-start"><?=Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_RES_SAVE')?></button>
    </div>
</template>

<script>
    AiGenerateRules = function () {
        this.init();
    }

    AiGenerateRules.prototype = {
        init: function () {
            this.createProcess();
            this.initResult();
        },

        initResult: function () {
            this.resultTmp = document.getElementById('aiResultTemplate');
        },

        setResultValue: function (value) {
            this.cloneTmp = this.resultTmp.content.cloneNode(true);
            this.textArea = this.cloneTmp.querySelector('textarea');
            this.btnSave = this.cloneTmp.querySelector('button');
            this.btnSave.addEventListener('click', this.saveResult.bind(this))
            this.textArea.value = value;
        },

        getResultHTML: function () {
            return this.cloneTmp;
        },

        saveResult: async function () {
            BX.showWait();
            try {
                const result = await BX.ajax.runAction('sotbit:smartsearch.aicontroller.saveAiResult', {
                    data: {
                        result: this.textArea.value
                    }
                });

                const aiResultBlock = document.querySelector('.bx-stepprocessing-dialog-process-popup');
                aiResultBlock.innerHTML = '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_COUNT_RESULT')?>' + result.data;
                BX.closeWait();
                ReplaceAddRule.prototype.refreshTableList();
            } catch (e) {
                BX.closeWait();
                console.log(e)
            }
        },

        clearSession: function () {
            sessionStorage.removeItem('bx.generateReplaceRules');
        },

        createProcess: function () {
            BX.UI.StepProcessing.ProcessManager.create(
                <?=\Bitrix\Main\Web\Json::encode([
                    'id' => 'generateReplaceRules',
                    'controller' => 'sotbit:smartsearch.controller.aicontroller',
                    'optionsFields' => [
                        'IBLOCK_ID' => [
                            'name' => 'IBLOCK_ID',
                            'type' => 'select',
                            'title' => Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_IBLOCK_ID'),
                            'list' => $iblockList,
                            'value' => $currentIblockId,
                        ],
                        'ENTITY' => [
                            'name' => 'ENTITY',
                            'type' => 'select',
                            'title' => Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_ENTITY'),
                            'list' => $entity,
                            'value' => array_key_first($entity),
                        ],
                        'VARIANTS_COUNT' => [
                            'name' => 'VARIANTS_COUNT',
                            'type' => 'select',
                            'title' => Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_VARIANTS_COUNT'),
                            'list' => array_combine($range, $range),
                            'value' => '3',
                        ],
                    ],
                ])?>).setQueue([
                {
                    'action': 'generatePromt',
                    'title': '<?= Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE') ?>',
                    'handlers': {
                        'StepCompleted': function (state, data) {
                            if (data['AI_OBJECT']) {
                                window.aiGenerateRules.aiObject = data['AI_OBJECT'];
                            }

                            if (state === BX.UI.StepProcessing.ProcessResultStatus.completed) {
                                BX.UI.StepProcessing.ProcessManager.create(
                                    {
                                        id: 'completedRequest',
                                        controller: 'sotbit:smartsearch.controller.aicontroller',
                                        optionsFields: {
                                            COMPLETED_PROMPT: {
                                                name: 'COMPLETED_PROMPT',
                                                type: 'text',
                                                title: '<?= Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_META_TITLE_COMPLETED_PROMT') ?>',
                                                value: data['COMPLETED_PROMPT'],
                                            },
                                        },
                                    })
                                    .setParams({
                                        'aiObject': window.aiGenerateRules.aiObject
                                    })
                                    .setQueue([
                                    {
                                        'action': 'generateRules',
                                        'title': '<?= Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_TITLE') ?>',
                                        'handlers': {
                                            'StepCompleted': function (state, data) {

                                                if (state === BX.UI.StepProcessing.ProcessResultStatus.completed) {
                                                    const aiResultBlock = document.querySelector('.bx-stepprocessing-dialog-process-popup');
                                                    window.aiGenerateRules.setResultValue(data['RESULT_ITEMS_HTML']);
                                                    aiResultBlock.append(window.aiGenerateRules.getResultHTML());
                                                }

                                                if (data['AI_OBJECT']) {
                                                    this.setParam('aiObject', data['AI_OBJECT'])
                                                }
                                            },

                                        }
                                    },
                                ]).setMessages({
                                    'DialogTitle': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_TITLE')?>',
                                    'DialogSummary': '<?= Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_SUMMARY_PROMT') ?>',
                                    'DialogStartButton': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_START')?>',
                                    'DialogStopButton': '<?= Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_STOP') ?>',
                                    'DialogCloseButton': '<?= Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_CLOSE') ?>',
                                    'RequestCanceling': '<?= Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_CANCELING') ?>',
                                    'RequestCanceled': '<?= Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_CANCELED') ?>',
                                    'RequestCompleted': '<?= Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_COMPLETED') ?>',
                                });
                                BX.UI.StepProcessing.ProcessManager.get('completedRequest').showDialog();
                            }
                        }
                    }
                },
            ])
            .setParams({
                'AI_TYPE': '<?=\Sotbit\SmartSearch\General\AI::TYPE_REPLACE?>'
            })
            .setMessages({
            'DialogTitle': '<?= Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_TITLE') ?>',
            'DialogSummary': '<?= Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_SUMMARY') ?>',
            'DialogStartButton': '<?= Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_START') ?>',
            'DialogStopButton': '<?= Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_STOP') ?>',
            'DialogCloseButton': '<?= Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_CLOSE') ?>',
            'RequestCanceling': '<?= Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_CANCELING') ?>',
            'RequestCanceled': '<?= Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_CANCELED') ?>',
            'RequestCompleted': '<?= Loc::getMessage('SOTBIT_SMARTSEARCH_GENERATE_REPLACE_COMPLETED') ?>',
        });
        },

        initOptions: function () {
            this.clearSession();

            this.selectIblock = document.getElementById('generateReplaceRules_opt_IBLOCK_ID');
            this.selectEntities = document.getElementById('generateReplaceRules_opt_ENTITY');
            this.selectCount = document.getElementById('generateReplaceRules_opt_ENTITY');
            this.promt = '';

            this.selectIblock.addEventListener('change', async () => {
                BX.showWait();
                const result = await BX.ajax.runAction('sotbit:smartsearch.aicontroller.getIblockEntities', {
                    data: {
                        iblockId: this.selectIblock.value
                    }
                });

                let options = ''
                for (let i in result.data) {
                    options += `<option value="${i}">${result.data[i]}</option>`;
                }

                this.selectEntities.innerHTML = options;

                BX.closeWait();
            });
        },

        showProcess: function () {
            this.clearSession();
            BX.UI.StepProcessing.ProcessManager.get('generateReplaceRules').showDialog();
            this.initOptions();
        },
    };

    document.addEventListener('DOMContentLoaded', () => {
        window.aiGenerateRules = new AiGenerateRules();
    });
</script>
