<?php

use Bitrix\Main\Loader,
    Bitrix\Main\Localization\Loc,
    Bitrix\Main\Context;
use Sotbit\SmartSearch\General\Replacement;

require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_admin_before.php");
require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/iblock/prolog.php');
require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/iblock/classes/general/subelement.php');

global $adminPage, $adminSidePanelHelper, $APPLICATION;

Loader::includeModule('iblock');
Loader::includeModule('sotbit.smartsearch');

$publicMode = $adminSidePanelHelper->isSidePanelFrame();
$selfFolderUrl = $adminPage->getSelfFolderUrl();

$context = Context::getCurrent();
$request = $context->getRequest();
$strSubElementAjaxPath = '/bitrix/admin/sotbit.smartsearch_replacement_list.php';
\Bitrix\Main\UI\Extension::load("ui.dialogs.messagebox");

if ($request->isPost() && ($request->get('action_button') || $request->get('action'))) {
    $action = $request->get('action_button') ?? $request->get('action');
    $elements = is_array($request->get('SUB_ID')) ? $request->get('SUB_ID') : [$request->get('SUB_ID')];

    if ($action === 'delete') {
        foreach ($elements as $id) {
            Replacement::delete($id);
        }
    }
}

$sTableID = "tbl_replace_list";
$lid = $request->get('id');
$adminSort = new CAdminSubSorting($sTableID, 'WORD', 'ASC', 'by', 'order',
    $strSubElementAjaxPath . '?id=' . $lid);
$lAdmin = new CAdminSubList($sTableID, $adminSort, $strSubElementAjaxPath . '?id=' . $lid);

\CPageOption::SetOptionString("main", "nav_page_in_session", "N");
$usePageNavigation = true;
$navParams = CDBResult::GetNavParams(
    $nSize = CAdminResult::GetNavSize(
        $sTableID,
        [
            'nPageSize' => 20,
            'sNavID' => $APPLICATION->GetCurPageParam()
        ]
    )
);

if ($navParams['SHOW_ALL']) {
    $usePageNavigation = false;
    $navParams['SIZEN'] = 0;
} else {
    $navParams['PAGEN'] = (int)$navParams['PAGEN'];
    $navParams['SIZEN'] = (int)$navParams['SIZEN'];
}

$arHeader = [
    [
        "id" => "WORD",
        "content" => Loc::getMessage('SOTBIT_SMARTSEARCH_RL_HEADER_WORD'),
        "sort" => "WORD",
        "default" => true
    ],
    [
        "id" => "EXCEPTION_WORD",
        "content" => Loc::getMessage('SOTBIT_SMARTSEARCH_RL_HEADER_WORD_EX'),
        "sort" => false,
        "default" => true
    ]
];

$lAdmin->AddHeaders($arHeader);
$by = $request->get('by') ?: 'WORD';
$order = $request->get('order') ?: 'asc';

$totalCount = \Sotbit\Smartsearch\ORM\ReplacementTable::getCount([]);
if ($totalCount > 0) {
    $totalPages = 1;
    if ($navParams['SIZEN'] != 0) {
        $totalPages = ceil($totalCount / $navParams['SIZEN']);
    }

    if ($navParams['PAGEN'] > $totalPages) {
        $navParams['PAGEN'] = $totalPages;
    }

    $getListParams['limit'] = $navParams['SIZEN'];
    $getListParams['offset'] = $navParams['SIZEN'] * ($navParams['PAGEN'] - 1);
} else {
    $navParams['PAGEN'] = 1;
}

$query = \Sotbit\Smartsearch\ORM\ReplacementTable::query()
        ->addSelect('*')
    ->setOrder([$by => $order]);

if ($usePageNavigation) {
    $query
        ->setLimit($navParams['SIZEN'])
        ->setOffset($navParams['SIZEN'] * ($navParams['PAGEN'] - 1));
}

$arReplace = $query->fetchAll();

$arRules = [];
$dbRules = \Sotbit\Smartsearch\ORM\ReplacementRuleTable::query()
    ->addSelect('*')
    ->whereIn('REPLACEMENT_ID', array_column($arReplace, 'ID'))
    ->exec();

while ($item = $dbRules->fetch()) {
    $arRules[$item['REPLACEMENT_ID']][] = $item['EXCEPTION_WORD'];
}


$rsData = new CAdminSubResult($arReplace, $sTableID, $lAdmin->GetListUrl(true));
$rsData->NavPageNomer = $navParams['PAGEN'];
$rsData->NavRecordCount = $totalCount;
if ($usePageNavigation) {
    $rsData->NavStart($navParams['SIZEN'], $navParams['SHOW_ALL'], $navParams['PAGEN']);
    $rsData->NavPageCount = $totalPages;

} else {
    $rsData->NavPageCount = 1;
    $rsData->NavStart();
}

$lAdmin->NavText($rsData->GetNavPrint(Loc::getMessage('SOTBIT_SMARTSEARCH_REPLACE_PAGEN')));
foreach ($arReplace as $arRes) {
    $itemId = $arRes['ID'];
    $row = $lAdmin->AddRow($itemId, [],
        '');
    $row->AddViewField("WORD", $arRes['WORD']);
    $row->AddViewField("EXCEPTION_WORD", $arRules[$itemId] ? implode(', ', $arRules[$itemId]) : '');

    $arActions = [
        [
            "ICON" => "edit",
            "TEXT" => Loc::getMessage('SOTBIT_SMARTSEARCH_RL_ACTION_DETAIL'),
            "DEFAULT" => true,
            "ACTION" => "javascript:editRule({$itemId})"
        ],
        [
            "ICON" => "delete",
            "TEXT" => Loc::getMessage('SOTBIT_SMARTSEARCH_RL_ACTION_DELETE'),
            "DEFAULT" => true,
            "ACTION" => "if(confirm('". Loc::getMessage('SOTBIT_SMARTSEARCH_RL_ACTION_DELETE_CONFIRM') ."')) " . $lAdmin->ActionDoGroup($itemId, "delete")
        ]
    ];

    $row->AddActions($arActions);
}

$aContext = [
    0 => [
        "ICON" => "btn_sub_new",
        "TEXT" => Loc::getMessage('SOTBIT_SMARTSEARCH_RL_ACTION_ADD'),
        "LINK" => "javascript:addRule()",
        "TITLE" => Loc::getMessage('SOTBIT_SMARTSEARCH_RL_ACTION_ADD'),
    ],
    1 => [
        "ICON" => "btn_sub_gen",
        "TEXT" => Loc::getMessage('SOTBIT_SMARTSEARCH_RL_ACTION_IMPORT'),
        "LINK" => "javascript:importRules()",
        "TITLE" => Loc::getMessage('SOTBIT_SMARTSEARCH_RL_ACTION_IMPORT'),
    ],
];

if (!empty($arReplace)) {
    $aContext[] = [
        "ICON" => "btn_sub_gen",
        "TEXT" => Loc::getMessage('SOTBIT_SMARTSEARCH_RL_ACTION_EXPORT'),
        "LINK" => "javascript:exportRules()",
        "TITLE" => Loc::getMessage('SOTBIT_SMARTSEARCH_RL_ACTION_EXPORT'),
    ];
}

$aContext[] = [
    "ICON" => "btn_sub_gen",
    "TEXT" => Loc::getMessage('SOTBIT_SMARTSEARCH_RL_ACTION_AI_SEND'),
    "LINK" => "javascript:window.aiGenerateRules.showProcess()",
    "TITLE" => Loc::getMessage('SOTBIT_SMARTSEARCH_RL_ACTION_AI_SEND'),
];

?>
    <script>
        BX.message({
            'save': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_SAVE')?>',
            'new_rule': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_NEW_RULE')?>',
            'edit_rule': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_EDIT_RULE')?>',
            'import': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_IMPORT')?>',
            'import_title': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_IMPORT_TITLE')?>',
            'import_file': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_IMPORT_FILE')?>',
            'import_dscr': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_IMPORT_DSCR')?>',
            'delete_items': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_IMPORT_DELETE_ITEMS')?>',
            'error_empty_word': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_ERROR_EMPTY_WORD')?>',
            'error_empty_ex_word': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_ERROR_EMPTY_EXWORD')?>',
            'error_file': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_ERROR_FILE')?>',
            'import_result': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_IMPORT_RESULT')?>',
            'add_btn': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_ADD')?>',
            'ex_word': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_ADD_WORD')?>',
            'word': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_ADD_EXWORD')?>',
            'error_title': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_ERROR_TITLE')?>',
            'success_title': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_SUCCESS_TITLE')?>',
            'delete': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_DELETE')?>',
            'move': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_MOVE')?>',
            'word_add_muted': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_ADD_MUTED')?>',
        });

        ReplaceAddRule = function () {
            this.customSelect = {};
            this.modalAdd = {};
            this.modalEdit = {};
            return this;
        }

        ReplaceAddRule.prototype = {
            showAddModal: function () {
                const formId = this.getFormId();
                this.modalAdd = new BX.CDialog(
                    {
                        'width': 400,
                        'height': 250,
                        'buttons': [
                            new BX.CWindowButton({
                                'title': BX.message('save'),
                                'onclick': `saveRule("${formId}")`,
                                'name': 'save',
                                'id': 'save',
                                'className': 'adm-btn-save',
                            }),
                            BX.CDialog.prototype.btnClose,
                        ],
                        'title': BX.message('new_rule'),
                        'content': this.getContentForm(formId)
                    }
                );

                this.modalAdd.Show();

                this.customSelect = new SotbitSmartSearchSelect({
                    wrap: formId,
                    items: []
                }).init();
            },

            showEditModal: function (data) {
                const formId = this.getFormId();
                this.modalEdit = new BX.CDialog(
                    {
                        'width': 400,
                        'height': 250,
                        'buttons': [
                            new BX.CWindowButton({
                                'title': BX.message('save'),
                                'onclick': `saveRule("${formId}")`,
                                'name': 'save',
                                'id': 'save',
                                'className': 'adm-btn-save',
                            }),
                            BX.CDialog.prototype.btnClose,
                        ],
                        'title': BX.message('edit_rule'),
                        'content': this.getContentForm(formId, data.replace)
                    }
                );

                this.modalEdit.Show();

                this.customSelect = new SotbitSmartSearchSelect({
                    wrap: formId,
                    items: data.items
                }).init();
            },

            showImportForm: function () {
                if (this.importForm) {
                    this.importForm.Show();
                    return;
                }

                const formId = this.getFormId();

                this.importForm = new BX.CDialog(
                    {
                        'width': 400,
                        'height': 200,
                        'buttons': [
                            new BX.CWindowButton({
                                'title': BX.message('import'),
                                'onclick': 'importAction()',
                                'name': 'save',
                                'id': 'btn_import',
                                'className': 'adm-btn-save',
                                'disabled': 'true'
                            }),
                            BX.CDialog.prototype.btnClose,
                        ],
                        'title': BX.message('import_title'),
                        'content': `<form id="importRules" action="" enctype="multipart/form-data">
<div class="smartselect-input">
            <label for="file_import">${BX.message('import_file')}</label>
            <input type="file" id="file_import" name="FILE_IMPORT" accept=".txt" onchange="onChangeImportFile(false)">
        </div>
        <div class="form-group">
            <label for="delete_items">${BX.message('delete_items')}</label>
                <input type="checkbox" id="delete_items" name="DELETE_ITEMS" checked>
        </div>
        <div class="smartselect-input">
            <span class="text-muted">
               ${BX.message('import_dscr')}
            </span>
        </div>

    </form>`
                    }
                );
                onChangeImportFile();

                this.importForm.Show();
            },

            getContentForm: function (formId, replace = '') {
                return `<form id="${formId}" action="">
        <input type="hidden" name="ID" value="${replace.id || ''}">
        <div class="smartselect-input">
            <label for="word">${BX.message('word')}</label>
            <input type="text" id="word" name="WORD" value="${replace.word || ''}">
        </div>
        <div class="smartselect-input">
            <label for="word-ex">${BX.message('ex_word')}</label>
            <div>
                <input type="text" id="word-ex" name="WORD_EX" data-type="input">
                <button type="submit" class="adm-btn adm-btn-add smartselect-add" title="${BX.message('add_btn')}" data-type="add"></button>
            </div>
            <span class="text-muted">${BX.message('word_add_muted')}</span>
        </div>
    </form>`;
            },

            getFormId: function () {
                return (Math.random() + 1).toString(36).substring(7);
            },

            refreshTableList: function () {
                const url = '<?=$lAdmin->GetListUrl(true)?>';
                const table = '<?=$sTableID?>';
                window[table].GetAdminList(url);
            }
        }

        async function saveRule(formId) {
            const form = document.getElementById(formId);
            const word = form.querySelector('[name="WORD"]').value.trim();
            const wordEx = form.querySelector('[name="WORD_EX"]').value.trim();
            const id = form.querySelector('[name="ID"]').value;

            if (word.length === 0) {
                showErrorAlert(BX.message('error_empty_word'));
                return;
            }

            const items = window.ReplaceSmartSearch.customSelect.getValues();

            if (items.length === 0) {
                if (wordEx.length > 0) {
                    items.push(wordEx)
                } else {
                    showErrorAlert(BX.message('error_empty_ex_word'));
                    return;
                }
            }

            try {
                BX.showWait();
                const result = await BX.ajax.runAction('sotbit:smartsearch.admin.saveCorrection', {
                    data: {
                        fields: {
                            'WORD': word,
                            'EXCEPTION_WORD': items,
                            'ID': id || 0,
                        }
                    },
                });
                BX.closeWait();
                if (id) {
                    window.ReplaceSmartSearch.modalEdit.Close();
                } else {
                    window.ReplaceSmartSearch.modalAdd.Close();
                }
                ReplaceAddRule.prototype.refreshTableList();
            } catch (e) {
                showErrorAlert(e.errors.map(i => i.message).join('\n'));
                BX.closeWait();
            }
        }

        function addRule() {
            window.ReplaceSmartSearch = new ReplaceAddRule();
            window.ReplaceSmartSearch.showAddModal();
        }

        async function editRule(id) {
            BX.showWait();
            const result = await BX.ajax.runAction('sotbit:smartsearch.admin.getExceptionWords', {
                data: {
                    replaceId: id
                },
            });

            BX.closeWait();

            window.ReplaceSmartSearch = new ReplaceAddRule();
            window.ReplaceSmartSearch.showEditModal(result.data);
        }

        async function exportRules() {
            BX.showWait();
            const result = await BX.ajax.runAction('sotbit:smartsearch.admin.exportRules', {});
            BX.closeWait();

            const url = window.URL.createObjectURL(new Blob(["\ufeff", [result.data]], {type: 'plain/text'}));
            const a = document.createElement("a");
            a.style = "display: none";
            a.href = url;
            a.download = 'replace.txt';
            a.click();
            window.URL.revokeObjectURL(url);
        }

        function importRules() {
            if (window.ReplaceSmartSearch) {
                window.ReplaceSmartSearch.showImportForm();
                return;
            }

            window.ReplaceSmartSearch = new ReplaceAddRule();
            window.ReplaceSmartSearch.showImportForm();
        }

        function onChangeImportFile(value = true) {
            const btn_import = document.getElementById('btn_import');
            btn_import.disabled = value;
        }

        async function importAction() {
            const formImport = document.getElementById('importRules');

            BX.showWait();
            try {
                const result = await BX.ajax.runAction('sotbit:smartsearch.admin.importReplaceRules', {
                    data: new FormData(formImport),
                });
                BX.closeWait();
                window.ReplaceSmartSearch.importForm.Close();
                showSuccessAlert(BX.message('import_result') + result.data)
                ReplaceAddRule.prototype.refreshTableList();
                onChangeImportFile();
                formImport.reset();
            } catch (e) {
                showErrorAlert(e.errors.map(i => i.message).join('\n'));
                BX.closeWait();
            }
        }

        function showErrorAlert(error) {
            BX.UI.Dialogs.MessageBox.show(
                {
                    title: BX.message('error_title'),
                    message: error,
                    modal: true,
                    buttons: BX.UI.Dialogs.MessageBoxButtons.OK,
                    mediumButtonSize: true,
                    minWidth: '400'
                }
            );
        }

        function showSuccessAlert(mes) {
            BX.UI.Dialogs.MessageBox.show(
                {
                    title: BX.message('success_title'),
                    message: mes,
                    modal: true,
                    buttons: BX.UI.Dialogs.MessageBoxButtons.OK,
                    mediumButtonSize: true,
                    minWidth: '400'
                }
            );
        }
    </script>

<?php

$lAdmin->AddFooter(
    array(
        array(
            "title" => GetMessage("MAIN_ADMIN_LIST_SELECTED"),
            "value" => 123
        ),
        array(
            "counter" => true,
            "title" => GetMessage("MAIN_ADMIN_LIST_CHECKED"),
            "value" => "0"
        ),
    )
);

$lAdmin->AddGroupActionTable([
    "delete" => '',
], ['disable_action_sub_target' => true]);
$lAdmin->AddAdminContextMenu(
    $aContext,
    false
);

$lAdmin->CheckListMode();
$lAdmin->DisplayList([]);


include_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/admin/sotbit.smartsearch_synonym_ai.php';