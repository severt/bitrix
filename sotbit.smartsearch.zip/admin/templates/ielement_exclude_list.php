<?php

use Bitrix\Main\Loader,
    Bitrix\Main\Localization\Loc,
    Bitrix\Main\Context,
    Sotbit\SmartSearch\General\IblockExcludeRules,
    Sotbit\SmartSearch\ORM\IElementExcludeRulesTable;

require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_admin_before.php");
require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/iblock/prolog.php');
require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/iblock/classes/general/subelement.php');

global $adminPage, $adminSidePanelHelper, $APPLICATION;

Loader::includeModule('iblock');
Loader::includeModule('sotbit.smartsearch');

$publicMode = $adminSidePanelHelper->isSidePanelFrame();
$selfFolderUrl = $adminPage->getSelfFolderUrl();

$context = Context::getCurrent();
$request = $context->getRequest();
$strSubElementAjaxPath = '/bitrix/admin/sotbit.smartsearch_ielement_exclude.php';
\Bitrix\Main\UI\Extension::load("ui.dialogs.messagebox");

if ($request->isPost() && ($request->get('action_button') || $request->get('action'))) {
    $action = $request->get('action_button') ?? $request->get('action');
    $elements = is_array($request->get('SUB_ID')) ? $request->get('SUB_ID') : [$request->get('SUB_ID')];

    if ($action === 'delete') {
        foreach ($elements as $id) {
            IblockExcludeRules::delete($id);
        }
    }

    if ($action === 'edit') {
        $arEnum = [];
        $query = IElementExcludeRulesTable::query()
            ->registerRuntimeField(
                new \Bitrix\Main\Entity\ReferenceField(
                    'ENUM',
                    \Bitrix\Iblock\PropertyEnumerationTable::class,
                    ['=this.PROPERTY_ID' => 'ref.PROPERTY_ID'],
                    ['join_type' => 'INNER']
                ),
            )
            ->addSelect('PROPERTY_ID')
            ->addSelect('ENUM.ID', 'ENUM_ID')
            ->addSelect('ENUM.VALUE', 'ENUM_VALUE')
            ->whereIn('ID', $elements)
            ->exec();

        while ($item = $query->fetch()) {
            $arEnum[$item['PROPERTY_ID']][$item['ENUM_ID']] = $item['ENUM_VALUE'];
        }
    }
}

if ($request->isPost() && $request->get('save_sub')) {
    foreach ($request->get('FIELDS') as $id => $fields) {
        IElementExcludeRulesTable::update($id, $fields);
    }
}



$sTableID = "tbl_element_exclude_rules_list";
$lid = $request->get('id');
$adminSort = new CAdminSubSorting($sTableID, 'ID', 'ASC', 'by', 'order',
    $strSubElementAjaxPath . '?id=' . $lid);
$lAdmin = new CAdminSubList($sTableID, $adminSort, $strSubElementAjaxPath . '?id=' . $lid);
$arID = $lAdmin->GroupAction();


\CPageOption::SetOptionString("main", "nav_page_in_session", "N");
$usePageNavigation = true;
$navParams = CDBResult::GetNavParams(
    $nSize = CAdminResult::GetNavSize(
        $sTableID,
        [
            'nPageSize' => 20,
            'sNavID' => $APPLICATION->GetCurPageParam()
        ]
    )
);

if ($navParams['SHOW_ALL']) {
    $usePageNavigation = false;
    $navParams['SIZEN'] = 0;
} else {
    $navParams['PAGEN'] = (int)$navParams['PAGEN'];
    $navParams['SIZEN'] = (int)$navParams['SIZEN'];
}

$arHeader = [
    [
        "id" => "ID",
        "content" => Loc::getMessage('SOTBIT_SMARTSEARCH_EL_HEADER_ID'),
        "sort" => "ID",
        "default" => true
    ],
    [
        "id" => "IBLOCK_ID",
        "content" => Loc::getMessage('SOTBIT_SMARTSEARCH_EL_IBLOCK_ID'),
        "sort" => 'IBLOCK_ID',
        "default" => true
    ],
    [
        "id" => "PROPERTY_ID",
        "content" => Loc::getMessage('SOTBIT_SMARTSEARCH_EL_PROPERTY_ID'),
        "sort" => 'PROPERTY_ID',
        "default" => true
    ],
    [
        "id" => "VALUE_ID",
        "content" => Loc::getMessage('SOTBIT_SMARTSEARCH_EL_VALUE_ID'),
        "sort" => 'VALUE_ID',
        "default" => true
    ]
];

$lAdmin->AddHeaders($arHeader);
$by = $request->get('by') ?: 'ID';
$order = $request->get('order') ?: 'asc';

$totalCount = IElementExcludeRulesTable::getCount([]);
if ($totalCount > 0) {
    $totalPages = 1;
    if ($navParams['SIZEN'] != 0) {
        $totalPages = ceil($totalCount / $navParams['SIZEN']);
    }

    if ($navParams['PAGEN'] > $totalPages) {
        $navParams['PAGEN'] = $totalPages;
    }

    $getListParams['limit'] = $navParams['SIZEN'];
    $getListParams['offset'] = $navParams['SIZEN'] * ($navParams['PAGEN'] - 1);
} else {
    $navParams['PAGEN'] = 1;
}

$query = IElementExcludeRulesTable::query()
    ->addSelect('*')
    ->addSelect('IBLOCK.NAME', 'IBLOCK_NAME')
    ->addSelect('IBLOCK.CODE', 'IBLOCK_CODE')
    ->addSelect('PROPERTY.CODE', 'PROPERTY_CODE')
    ->addSelect('PROPERTY.NAME', 'PROPERTY_NAME')
    ->addSelect('ENUM.VALUE', 'ENUM_VALUE')
    ->setOrder([$by => $order]);

if ($usePageNavigation) {
    $query
        ->setLimit($navParams['SIZEN'])
        ->setOffset($navParams['SIZEN'] * ($navParams['PAGEN'] - 1));
}

$arExcludeRules = $query->fetchAll();
$rsData = new CAdminSubResult($arExcludeRules, $sTableID, $lAdmin->GetListUrl(true));
$rsData->NavPageNomer = $navParams['PAGEN'];
$rsData->NavRecordCount = $totalCount;
if ($usePageNavigation) {
    $rsData->NavStart($navParams['SIZEN'], $navParams['SHOW_ALL'], $navParams['PAGEN']);
    $rsData->NavPageCount = $totalPages;

} else {
    $rsData->NavPageCount = 1;
    $rsData->NavStart();
}

$lAdmin->NavText($rsData->GetNavPrint(Loc::getMessage('SOTBIT_SMARTSEARCH_REPLACE_PAGEN')));
foreach ($arExcludeRules as $arRes) {
    $itemId = $arRes['ID'];
    $arRes['VALUE_ID'] = $arRes['VALUE_ID'] ? $arRes['ENUM_VALUE'] : '';

    $row = $lAdmin->AddRow($itemId, $arRes, false,'');


    $row->AddViewField("ID", $itemId);
    $row->AddViewField("IBLOCK_ID", "[{$arRes['IBLOCK_ID']}] " . $arRes['IBLOCK_NAME'] ?: $arRes['IBLOCK_CODE']);
    $row->AddViewField("PROPERTY_ID", "[{$arRes['PROPERTY_CODE']}] " . $arRes['PROPERTY_NAME']);
    $row->AddViewField("VALUE_ID", $arRes['VALUE_ID'] ? $arRes['ENUM_VALUE'] : '');
//    $row->AddInputField("VALUE_ID");
    $row->AddSelectField("VALUE_ID", $arEnum[$arRes['PROPERTY_ID']] ?? []);

    $arActions = [
        [
            "ICON" => "delete",
            "TEXT" => Loc::getMessage('SOTBIT_SMARTSEARCH_EL_ACTION_DELETE'),
            "DEFAULT" => false,
            "ACTION" => "if(confirm('" . Loc::getMessage('SOTBIT_SMARTSEARCH_EL_ACTION_DELETE_CONFIRM') . "')) " . $lAdmin->ActionDoGroup($itemId,
                    "delete")
        ]
    ];

    $row->AddActions($arActions);
}

$aContext = [
    0 => [
        "ICON" => "btn_sub_new",
        "TEXT" => Loc::getMessage('SOTBIT_SMARTSEARCH_EL_ACTION_ADD'),
        "LINK" => "javascript:window.objectElementExcludeRule.showAddModal()",
        "TITLE" => Loc::getMessage('SOTBIT_SMARTSEARCH_EL_ACTION_ADD'),
    ],
];

$iblockList = \Sotbit\SmartSearch\Helper\IblockTools::getIblockList();
$iblockList[0] = Loc::getMessage('SOTBIT_SMARTSEARCH_EL_EMPTY_VAL');
ksort($iblockList);

$iblockProps = \Sotbit\SmartSearch\Helper\IblockTools::getIblockProps();
$iblockPropsEnum = \Sotbit\SmartSearch\Helper\IblockTools::getPropEnumValues();
?>

    <template id="exclude_rule_form_template">
        <form id="exclude_rule_add" action="">
            <div class="smartselect-input">
                <label for="exclude_iblock_id"><?=Loc::getMessage('SOTBIT_SMARTSEARCH_EL_FORM_IBLOCK_ID');?></label>
                <select name="EXCLUDE_IBLOCK_ID" id="exclude_iblock_id">
                    <? foreach ($iblockList as $id => $iblock): ?>
                        <option value="<?= $id ?>"><?= $iblock ?></option>
                    <?endforeach; ?>
                </select>
            </div>
            <div class="smartselect-input">
                <label for="exclude_property_id"><?=Loc::getMessage('SOTBIT_SMARTSEARCH_EL_FORM_PROP');?></label>
                <select name="EXCLUDE_PROPERTY_ID" id="exclude_property_id"></select>
                <span class="text-muted"><?=Loc::getMessage('SOTBIT_SMARTSEARCH_EL_FORM_PROP_HINT');?></span>
            </div>
            <div class="smartselect-input">
                <label for="exclude_value_id"><?=Loc::getMessage('SOTBIT_SMARTSEARCH_EL_FORM_PROP_ENUM');?></label>
                <select name="EXCLUDE_VALUE_ID" id="exclude_value_id"></select>
                <span class="text-muted"><?=Loc::getMessage('SOTBIT_SMARTSEARCH_EL_FORM_PROP_ENUM_HINT');?></span>
            </div>
        </form>
    </template>


    <script>
        document.addEventListener('DOMContentLoaded', () => {
            window.objectElementExcludeRule = new ElementExcludeRule({
                'props': <?=CUtil::PhpToJSObject($iblockProps)?>,
                'propsEnum': <?=CUtil::PhpToJSObject($iblockPropsEnum)?>
            });
        });


        ElementExcludeRule = function (params) {
            this.createModal();
            this.initFormAction();

            this.iblockProps = params.props;
            this.iblockPropsEnum = params.propsEnum;
        }

        ElementExcludeRule.prototype = {
            createModal: function () {
                this.modalAdd = new BX.CDialog(
                    {
                        'width': 400,
                        'height': 250,
                        'buttons': [
                            new BX.CWindowButton({
                                'title': BX.message('save'),
                                'onclick': `window.objectElementExcludeRule.saveRule()`,
                                'name': 'save',
                                'id': 'save',
                                'className': 'adm-btn-save',
                            }),
                            BX.CDialog.prototype.btnClose,
                        ],
                        'title': BX.message('new_rule'),
                        'content': this.getContentForm()
                    }
                );

            },

            showAddModal: function () {
                this.modalAdd.Show();
            },

            getContentForm: function () {
                const tmpl = document.getElementById('exclude_rule_form_template');
                const form = tmpl.cloneNode(true);
                return form.innerHTML;
            },

            refreshTableList: function () {
                const url = '<?=$lAdmin->GetListUrl(true)?>';
                const table = '<?=$sTableID?>';
                window[table].GetAdminList(url);
            },

            initFormAction: function () {
                this.initFormData();

                this.form = document.getElementById('exclude_rule_add');

                this.iblockSelect = this.form.querySelector('[name="EXCLUDE_IBLOCK_ID"]');
                this.iblockSelect.addEventListener('change', () => {
                    this.currentIblockId = this.iblockSelect.value;
                    this.fillProps();
                });

                this.propsSelect = this.form.querySelector('[name="EXCLUDE_PROPERTY_ID"]');
                this.propsSelect.addEventListener('change', () => {
                    this.currentPropery = this.propsSelect.value;
                    this.fillEnum();
                });

                this.propsEnumSelect = this.form.querySelector('[name="EXCLUDE_VALUE_ID"]');
                this.propsEnumSelect.addEventListener('change', () => {
                    this.currentEnum = this.propsEnumSelect.value;
                });
            },

            initFormData: function () {
                this.currentIblockId = 0;
                this.currentPropery = 0;
                this.currentEnum = 0;
            },

            resetForm: function () {
                this.propsSelect.innerHTML = '';
                this.propsEnumSelect.innerHTML = '';
            },

            fillProps: async function () {
                if (this.currentIblockId === 0) {
                    this.propsSelect.innerHTML = '';
                    this.currentPropery = 0;
                    return;
                }

                const arProps = this.iblockProps[this.currentIblockId];
                if (typeof arProps === "undefined") {
                    this.propsSelect.innerHTML = '';
                    this.currentPropery = 0;
                    return;
                }

                let options = '';
                for (let propId in arProps) {
                    options += `<option value="${propId}">${arProps[propId]}</option>`;
                }

                this.propsSelect.innerHTML = options;
                this.currentPropery = Object.keys(arProps)[0];

                this.fillEnum();
            },

            fillEnum: function () {
                const arEnum = this.iblockPropsEnum[this.currentPropery];

                if (typeof arEnum === "undefined") {
                    this.propsEnumSelect.innerHTML = '';
                    this.currentEnum = 0;
                    return;
                }

                let options = `<option value="0">`+'<?=Loc::getMessage('SOTBIT_SMARTSEARCH_EL_EMPTY_VAL');?>'+`</option>`;
                for (let enumId in arEnum) {
                    options += `<option value="${enumId}">${arEnum[enumId]}</option>`;
                }

                this.propsEnumSelect.innerHTML = options;
            },

            saveRule: async function () {
                if (!this.currentIblockId) {
                    showErrorAlert('<?=Loc::getMessage('SOTBIT_SMARTSEARCH_EL_ERROR_1');?>');
                    return;
                }

                if (!this.currentPropery) {
                    showErrorAlert('<?=Loc::getMessage('SOTBIT_SMARTSEARCH_EL_ERROR_2');?>');
                    return;
                }

                try {
                    BX.showWait();
                    const result = await BX.ajax.runAction('sotbit:smartsearch.admin.saveExcludeIblockRule', {
                        data: {
                            fields: {
                                'IBLOCK_ID': this.currentIblockId,
                                'PROPERTY_ID': this.currentPropery,
                                'VALUE_ID': this.currentEnum,
                            }
                        },
                    });

                    this.modalAdd.Close();
                } catch (e) {
                    showErrorAlert(e.errors.map(i => i.message).join('\n'));
                } finally {
                    BX.closeWait();
                }

                this.refreshTableList();
            }
        }
    </script>
<?php
$lAdmin->bCanBeEdited = true;

$lAdmin->AddGroupActionTable([
    "delete" => '',
    "edit" => '',
], ['disable_action_sub_target' => true]);
$lAdmin->AddAdminContextMenu(
    $aContext,
    false
);

$lAdmin->CheckListMode();

$lAdmin->DisplayList(array("default_action" => $sec_list_url));
