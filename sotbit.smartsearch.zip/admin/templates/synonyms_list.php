<?php

use Bitrix\Main\Loader,
    Bitrix\Main\Localization\Loc,
    Bitrix\Main\Context;

require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_admin_before.php");
require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/iblock/prolog.php');
require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/iblock/classes/general/subelement.php');

global $adminPage, $adminSidePanelHelper, $APPLICATION;

Loader::includeModule('iblock');
Loader::includeModule('sotbit.smartsearch');

$publicMode = $adminSidePanelHelper->isSidePanelFrame();
$selfFolderUrl = $adminPage->getSelfFolderUrl();

$context = Context::getCurrent();
$request = $context->getRequest();
$strSubElementAjaxPath = '/bitrix/admin/sotbit.smartsearch_synonyms_list.php';
\Bitrix\Main\UI\Extension::load("ui.dialogs.messagebox");

if ($request->isPost() && ($request->get('action_button') || $request->get('action'))) {
    $action = $request->get('action_button') ?? $request->get('action');
    $elements = is_array($request->get('SUB_ID')) ? $request->get('SUB_ID') : [$request->get('SUB_ID')];

    if ($action === 'delete') {
        foreach ($elements as $id) {
            \Sotbit\SmartSearch\ORM\SynonymsTable::deleteSet($id);
        }
    }
}

$sTableID = "tbl_synonyms_list";
$lid = $request->get('id');
$adminSort = new CAdminSubSorting($sTableID, 'SET_ID', 'desc', 'by', 'order',
    $strSubElementAjaxPath . '?id=' . $lid);
$lAdmin = new CAdminSubList($sTableID, $adminSort, $strSubElementAjaxPath . '?id=' . $lid);

global $NavNum;
$NavNum = 2;
$usePageNavigation = true;
\CPageOption::SetOptionString("main", "nav_page_in_session", "N");
$navyParams = CDBResult::GetNavParams(
    $nSize = CAdminResult::GetNavSize(
        $sTableID,
        [
            'nPageSize' => 20,
            'sNavID' => $APPLICATION->GetCurPageParam()
        ]
    )
);

if ($navyParams['SHOW_ALL']) {
    $usePageNavigation = false;
    $navyParams['SIZEN'] = 0;
} else {
    $navyParams['PAGEN'] = (int)$navyParams['PAGEN'];
    $navyParams['SIZEN'] = (int)$navyParams['SIZEN'];
}

$arHeader = [
    [
        "id" => "SET_ID",
        "content" => Loc::getMessage('SOTBIT_SMARTSEARCH_SL_HEADER_SET_ID'),
        "sort" => "SET_ID",
        "default" => true
    ],
    [
        "id" => "WORD_SET",
        "content" => Loc::getMessage('SOTBIT_SMARTSEARCH_SL_HEADER_WORD'),
        "sort" => "WORD_SET",
        "default" => true
    ],
];

$lAdmin->AddHeaders($arHeader);
$by = $request->get('by') ?: 'SET_ID';
$order = $request->get('order') ?: 'desc';

$totalCount = \Sotbit\SmartSearch\General\Synonyms::getSetCount();

if ($totalCount > 0) {
    $totalPages = 1;
    if ($navyParams['SIZEN'] != 0) {
        $totalPages = ceil($totalCount / $navyParams['SIZEN']);
    }

    if ($navyParams['PAGEN'] > $totalPages) {
        $navyParams['PAGEN'] = $totalPages;
    }

    $getListParams['limit'] = $navyParams['SIZEN'];
    $getListParams['offset'] = $navyParams['SIZEN'] * ($navyParams['PAGEN'] - 1);
} else {
    $navyParams['PAGEN'] = 1;
}


$arSynonymSets = \Sotbit\SmartSearch\General\Synonyms::getListSet([$by => $order], $usePageNavigation ? $navyParams : []);
$rsData = new CAdminSubResult($arSynonymSets, $sTableID, $lAdmin->GetListUrl(true));
$rsData->NavPageNomer = $navyParams['PAGEN'];
$rsData->NavRecordCount = $totalCount;
if ($usePageNavigation) {
    $rsData->NavStart($navyParams['SIZEN'], $navyParams['SHOW_ALL'], $navyParams['PAGEN']);
    $rsData->NavPageCount = $totalPages;

} else {
    $rsData->NavPageCount = 1;
    $rsData->NavStart();
}

$lAdmin->NavText($rsData->GetNavPrint(Loc::getMessage('SOTBIT_SMARTSEARCH_REPLACE_PAGEN')));
foreach ($arSynonymSets as $arRes) {
    $itemId = $arRes['SET_ID'];
    $row = $lAdmin->AddRow($itemId, [],
        '');
    $row->AddViewField("SET_ID", $arRes['SET_ID']);
    $row->AddViewField("WORD_SET", $arRes['WORD_SET']);

    $arActions = [
        [
            "ICON" => "edit",
            "TEXT" => Loc::getMessage('SOTBIT_SMARTSEARCH_SL_ACTION_DETAIL'),
            "DEFAULT" => true,
            "ACTION" => "javascript:editSet({$itemId})"
        ],
        [
            "ICON" => "delete",
            "TEXT" => Loc::getMessage('SOTBIT_SMARTSEARCH_SL_ACTION_DELETE'),
            "DEFAULT" => true,
            "ACTION" => "if(confirm('".Loc::getMessage('SOTBIT_SMARTSEARCH_SL_ACTION_DELETE_CONFIRM')."')) " . $lAdmin->ActionDoGroup($itemId, "delete")
        ]
    ];

    $row->AddActions($arActions);
}

$aContext = [
    0 => [
        "ICON" => "btn_sub_new",
        "TEXT" => Loc::getMessage('SOTBIT_SMARTSEARCH_SL_ACTION_ADD'),
        "LINK" => "javascript:addSetSynonym()",
        "TITLE" => Loc::getMessage('SOTBIT_SMARTSEARCH_SL_ACTION_ADD'),
    ],
    1 => [
        "ICON" => "btn_sub_gen",
        "TEXT" => Loc::getMessage('SOTBIT_SMARTSEARCH_SL_ACTION_IMPORT'),
        "LINK" => "javascript:importSets()",
        "TITLE" => Loc::getMessage('SOTBIT_SMARTSEARCH_SL_ACTION_IMPORT'),
    ],
];

if (!empty($arSynonymSets)) {
    $aContext[] = [
        "ICON" => "btn_sub_gen",
        "TEXT" => Loc::getMessage('SOTBIT_SMARTSEARCH_SL_ACTION_EXPORT'),
        "LINK" => "javascript:exportSets()",
        "TITLE" => Loc::getMessage('SOTBIT_SMARTSEARCH_SL_ACTION_EXPORT'),
    ];
}

$aContext[] = [
    "ICON" => "btn_sub_gen",
    "TEXT" => Loc::getMessage('SOTBIT_SMARTSEARCH_SL_ACTION_AI_SEND'),
    "LINK" => "javascript:window.AiGenerateSynonym.showProcess()",
    "TITLE" => Loc::getMessage('SOTBIT_SMARTSEARCH_SL_ACTION_AI_SEND'),
];
?>
    <script>
        BX.message({
            'save': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_SAVE')?>',
            'new_set': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_NEW_RULE')?>',
            'edit_set': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_EDIT_SET')?>',
            'import': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_IMPORT')?>',
            'synonym_import_title': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_IMPORT_TITLE')?>',
            'import_file': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_IMPORT_FILE')?>',
            'synonym_import_dscr': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_IMPORT_DSCR')?>',
            'synonym_delete_items': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_IMPORT_DELETE_ITEMS')?>',
            'error_empty_word': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_ERROR_EMPTY_WORD')?>',
            'error_empty_ex_word': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_ERROR_EMPTY_EXWORD')?>',
            'error_file': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_ERROR_FILE')?>',
            'import_result': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_IMPORT_RESULT')?>',
            'add_btn': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_ADD')?>',
            'new_synonym_word': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_SYNONYM_WORD')?>',
            'word': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_ADD_EXWORD')?>',
            'error_title': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_ERROR_TITLE')?>',
            'success_title': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_SUCCESS_TITLE')?>',
            'delete': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_DELETE')?>',
            'move': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_MOVE')?>',
            'synonym_add_muted': '<?=Loc::getMessage('SOTBIT_SMARTSEARCH_ADD_MUTED')?>',
        });

        SynonymList = function () {
            this.customSelect = {};
            this.modalAdd = {};
            this.modalEdit = {};
            return this;
        }

        SynonymList.prototype = {
            showAddModal: function () {
                const formId = this.getFormId();
                this.modalAdd = new BX.CDialog(
                    {
                        'width': 400,
                        'height': 250,
                        'buttons': [
                            new BX.CWindowButton({
                                'title': BX.message('save'),
                                'onclick': `saveSet("${formId}")`,
                                'name': 'save',
                                'id': 'save',
                                'className': 'adm-btn-save',
                            }),
                            BX.CDialog.prototype.btnClose,
                        ],
                        'title': BX.message('new_set'),
                        'content': this.getContentForm(formId)
                    }
                );

                this.modalAdd.Show();

                this.customSelect = new SotbitSmartSearchSelect({
                    wrap: formId,
                    items: []
                }).init();
            },

            showEditModal: function (data) {
                const formId = this.getFormId();
                this.modalEdit = new BX.CDialog(
                    {
                        'width': 400,
                        'height': 250,
                        'buttons': [
                            new BX.CWindowButton({
                                'title': BX.message('save'),
                                'onclick': `saveSet("${formId}")`,
                                'name': 'save',
                                'id': 'save',
                                'className': 'adm-btn-save',
                            }),
                            BX.CDialog.prototype.btnClose,
                        ],
                        'title': BX.message('edit_set'),
                        'content': this.getContentForm(formId, data.replace)
                    }
                );

                this.modalEdit.Show();

                this.customSelect = new SotbitSmartSearchSelect({
                    wrap: formId,
                    items: data.items
                }).init();
            },

            showImportForm: function () {
                if (this.importForm) {
                    this.importForm.Show();
                    return;
                }

                formId = this.getFormId();

                this.importForm = new BX.CDialog(
                    {
                        'width': 400,
                        'height': 200,
                        'buttons': [
                            new BX.CWindowButton({
                                'title': BX.message('import'),
                                'onclick': 'importSynonymsAction()',
                                'name': 'save',
                                'id': 'synonym_btn_import',
                                'className': 'adm-btn-save',
                                'disabled': 'true'
                            }),
                            BX.CDialog.prototype.btnClose,
                        ],
                        'title': BX.message('synonym_import_title'),
                        'content': `<form id="synonymImportRules" action="" enctype="multipart/form-data">
<div class="smartselect-input">
            <label for="file_import">${BX.message('import_file')}</label>
            <input type="file" id="file_import" name="FILE_IMPORT" accept=".txt" onchange="onChangeSynonymImportFile(false)">
        </div>
        <div class="form-group">
            <label for="delete_items">${BX.message('synonym_delete_items')}</label>
                <input type="checkbox" id="delete_items" name="DELETE_ITEMS" checked>
        </div>
        <div class="smartselect-input">
            <span class="text-muted">
               ${BX.message('synonym_import_dscr')}
            </span>
        </div>

    </form>`
                    }
                );
                onChangeSynonymImportFile();

                this.importForm.Show();
            },

            getContentForm: function (formId, replace = '') {
                return `<form id="${formId}" action="">
        <input type="hidden" name="SET_ID" value="${replace.setId || ''}">
        <div class="smartselect-input">
            <label for="word-ex">${BX.message('new_synonym_word')}</label>
            <div>
                <input type="text" id="word-ex" name="WORD" data-type="input">
                <button type="submit" class="adm-btn adm-btn-add smartselect-add" title="${BX.message('add_btn')}" data-type="add"></button>
            </div>
            <span class="text-muted">${BX.message('synonym_add_muted')}</span>
        </div>
    </form>`;
            },

            getFormId: function () {
                return (Math.random() + 1).toString(36).substring(7);
            },

            refreshTableList: function () {
                const url = '<?=$lAdmin->GetListUrl(true)?>';
                const table = '<?=$sTableID?>';
                window[table].GetAdminList(url);
            }
        }

        async function saveSet(formId) {
            const form = document.getElementById(formId);
            const word = form.querySelector('[name="WORD"]').value.trim();
            const setId = form.querySelector('[name="SET_ID"]').value;

            const items = window.SynonymsSmartSearch.customSelect.getValues();

            if (word.length > 0) {
                items.push(word)
            }

            if (items.length < 2) {
                showErrorAlert(BX.message('error_empty_ex_word'));
                return;
            }

            try {
                BX.showWait();
                const result = await BX.ajax.runAction('sotbit:smartsearch.admin.saveSynonymSet', {
                    data: {
                        fields: {
                            'ITEMS': items,
                            'SET_ID': setId || 0,
                        }
                    },
                });
                BX.closeWait();
                if (setId) {
                    window.SynonymsSmartSearch.modalEdit.Close();
                } else {
                    window.SynonymsSmartSearch.modalAdd.Close();
                }
                window.SynonymsSmartSearch.refreshTableList();
            } catch (e) {
                showErrorAlert(e.errors.map(i => i.message).join('\n'));
                BX.closeWait();
            }
        }

        function addSetSynonym() {
            window.SynonymsSmartSearch = new SynonymList();
            window.SynonymsSmartSearch.showAddModal();
        }

        async function editSet(id) {
            BX.showWait();
            const result = await BX.ajax.runAction('sotbit:smartsearch.admin.getSetWords', {
                data: {
                    setId: id
                },
            });

            BX.closeWait();

            window.SynonymsSmartSearch = new SynonymList();
            window.SynonymsSmartSearch.showEditModal(result.data);
        }

        async function exportSets() {
            BX.showWait();
            const result = await BX.ajax.runAction('sotbit:smartsearch.admin.exportSynonyms', {
                data: {
                    order: {
                        '<?=$by?>': '<?=$order?>'
                    }
                }
            });
            BX.closeWait();

            const url = window.URL.createObjectURL(new Blob(["\ufeff", [result.data]], {type: 'plain/text'}));
            const a = document.createElement("a");
            a.style = "display: none";
            a.href = url;
            a.download = 'synonyms.txt';
            a.click();
            window.URL.revokeObjectURL(url);
        }

        function importSets() {
            if (window.SynonymsSmartSearch) {
                window.SynonymsSmartSearch.showImportForm();
                return;
            }

            window.SynonymsSmartSearch = new SynonymList();
            window.SynonymsSmartSearch.showImportForm();
        }

        function onChangeSynonymImportFile(value = true) {
            const synonym_btn_import = document.getElementById('synonym_btn_import');
            synonym_btn_import.disabled = value;
        }

        async function importSynonymsAction() {
            const formImport = document.getElementById('synonymImportRules');

            BX.showWait();
            try {
                const result = await BX.ajax.runAction('sotbit:smartsearch.admin.importSynonymSets', {
                    data: new FormData(formImport),
                });
                BX.closeWait();
                window.SynonymsSmartSearch.importForm.Close();
                showSuccessAlert(BX.message('import_result') + result.data)
                window.SynonymsSmartSearch.refreshTableList();
                formImport.reset();
                onChangeSynonymImportFile();
            } catch (e) {
                showErrorAlert(e.errors.map(i => i.message).join('\n'));
                BX.closeWait();
            }
        }

        function showErrorAlert(error) {
            BX.UI.Dialogs.MessageBox.show(
                {
                    title: BX.message('error_title'),
                    message: error,
                    modal: true,
                    buttons: BX.UI.Dialogs.MessageBoxButtons.OK,
                    mediumButtonSize: true,
                    minWidth: '400'
                }
            );
        }

        function showSuccessAlert(mes) {
            BX.UI.Dialogs.MessageBox.show(
                {
                    title: BX.message('success_title'),
                    message: mes,
                    modal: true,
                    buttons: BX.UI.Dialogs.MessageBoxButtons.OK,
                    mediumButtonSize: true,
                    minWidth: '400'
                }
            );
        }
    </script>

<?php

$lAdmin->AddGroupActionTable([
    "delete" => '',
], ['disable_action_sub_target' => true]);
$lAdmin->AddAdminContextMenu(
    $aContext,
    false
);


$lAdmin->CheckListMode();
$lAdmin->DisplayList(array());

include_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/admin/sotbit.smartsearch_replace_ai.php';