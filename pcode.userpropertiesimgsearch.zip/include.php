<?php

CModule::AddAutoloadClasses(
    'pcode.userpropertiesimgsearch',
    array(
        'Pcode\CUserPropImage' => 'lib/user_prop_image.php'
    )
);