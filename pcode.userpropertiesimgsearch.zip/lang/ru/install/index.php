<?php

$MESS['PCODE_USER_PROPS_NAME'] = 'Дополнительный тип пользовательского свойства';
$MESS['PCODE_USER_PROPS_DESCRIPTION'] = 'Дополнительный тип пользовательского свойства для поиска и отдельного вывода элементов инф. блоков';
$MESS['PCODE_USER_PROPS_PARTNER_NAME'] = 'ProfyCode';
$MESS['PCODE_USER_PROPS_PARTNER_URI'] = 'https://profycode.pro/';