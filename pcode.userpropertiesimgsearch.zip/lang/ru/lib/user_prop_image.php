<?php

$MESS['PCODE_USER_PROPS_ADMIN_DESCRIPTION'] = 'Привязка к элементам инф. блоков с поиском и картинкой';
$MESS['PCODE_USER_PROPS_ADMIN_SEARCH'] = 'поиск';
$MESS['PCODE_USER_PROPS_ADMIN_DEFAULT'] = 'не выбрано';