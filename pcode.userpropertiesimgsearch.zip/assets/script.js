$(function () {

    //search
    $(document).on('input', '.custom_user_field_list .input_search', function () {
        let val = $(this).val().toLowerCase();
        let select = $(this).closest('.custom_user_field_list').find('select');

        select.find('option').removeClass('hide');
        select.find('option').each(function () {
            if ($(this).text().toLowerCase().indexOf(val) === -1) {
                $(this).addClass('hide');
            }
        });
    });

    //delete
    $(document).on('click', '.custom_user_field_list .btn_item', function () {
        let btn = $(this).closest('.inner_item');
        let id = Number($(this).data('id'));
        let select = $(this).closest('.custom_user_field_list').find('select');
        let parent = $(this).closest('.custom_user_field_list');
        let selected = [];

        select.find('option').each(function () {
            if (Number($(this).val()) === id) {
                $(this).removeClass('selected');
            }
        });
        btn.remove();

        parent.find('.inner_list .inner_item').each(function () {
            selected.push($(this).find('.btn_item').data('id'));
        });

        if (selected.length > 0) {
            select.val(selected);

        } else {
            select.prop('selectedIndex', 0);
        }

        return false;
    });

    //change
    $(document).on('change', '.custom_user_field_list select', function () {

        let id = Number($(this).val());
        let option = $(this).find('option[value="' + id + '"]');
        let name = option.text();
        let parent = $(this).closest('.custom_user_field_list');
        let selected = [];

        if (parent.hasClass('select_multiple') !== true) {
            parent.find('.inner_list').html('');
            $(this).find('option').each(function () {
                $(this).removeClass('selected');
            });
        }

        if (id > 0 && name !== '') {
            name = name.replace(/ \.+/g, '');
            parent.find('.inner_list').append('' + '<div class="inner_item">' + '<button data-id="' + id + '" class="btn_item"></button>' + '<span class="name_item">' + name + '</span>' + '</div>');
            option.addClass('selected');

            //image
            if (parent.hasClass('custom_user_field_elements_search_image')) {
                parent.find('.inner_image').html('');
                let img = option.data('img');
                if (img !== '') {
                    parent.find('.inner_image').append('<img src="' + img + '">');
                }
            }

        }

        parent.find('.inner_list .inner_item').each(function () {
            selected.push($(this).find('.btn_item').data('id'));
        });

        if (selected.length > 0) {
            $(this).val(selected);

        } else {
            $(this).prop('selectedIndex', 0);
        }

        return false;
    });

    //show image by click
    $(document).on('click', '.custom_user_field_elements_search_image .name_item', function () {
        let btn = $(this).closest('.inner_item');
        let id = Number(btn.find('.btn_item').data('id'));
        let parent = $(this).closest('.custom_user_field_elements_search_image');

        if (id > 0) {
            let option = parent.find('select').find('option[value="' + id + '"]');
            parent.find('.inner_image').html('');
            let img = option.data('img');
            if (img !== '') {
                parent.find('.inner_image').append('<img src="' + img + '">');
            }
        }

        return false;
    });

});