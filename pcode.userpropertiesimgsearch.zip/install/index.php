<?php

use Bitrix\Main\Application;
use Bitrix\Main\Localization\Loc;

Loc::loadMessages(__FILE__);

if (class_exists('pcode_userpropertiesimgsearch')) {
    return;
}

class pcode_userpropertiesimgsearch extends CModule
{
    var $MODULE_ID = 'pcode.userpropertiesimgsearch';
    var $MODULE_VERSION;
    var $MODULE_VERSION_DATE;
    var $MODULE_NAME;
    var $MODULE_DESCRIPTION;
    var $PARTNER_NAME;
    var $PARTNER_URI;
    var $MODULE_GROUP_RIGHTS = 'N';

    function __construct()
    {
        $arModuleVersion = array();
        include(dirname(__FILE__) . '/version.php');

        $this->MODULE_VERSION = $arModuleVersion['VERSION'];
        $this->MODULE_VERSION_DATE = $arModuleVersion['VERSION_DATE'];
        $this->MODULE_NAME = Loc::getMessage('PCODE_USER_PROPS_NAME');
        $this->MODULE_DESCRIPTION = Loc::getMessage('PCODE_USER_PROPS_DESCRIPTION');

        $this->PARTNER_NAME = Loc::getMessage('PCODE_USER_PROPS_PARTNER_NAME');
        $this->PARTNER_URI = Loc::getMessage('PCODE_USER_PROPS_PARTNER_URI');
    }

    public function getPath($bNotDocumentRoot = false)
    {
        if ($bNotDocumentRoot) {
            return str_ireplace(Application::getDocumentRoot(), '', str_replace('\\', '/', dirname(__DIR__)));
        } else {
            return dirname(__DIR__);
        }
    }

    public function DoInstall()
    {
        RegisterModule($this->MODULE_ID);
        RegisterModuleDependences('main', 'OnUserTypeBuildList', $this->MODULE_ID, '\Pcode\CUserPropImage', 'GetUserTypeDescription');
        $this->InstallFiles();

        return true;
    }

    public function DoUninstall()
    {
        UnRegisterModuleDependences('main', 'OnUserTypeBuildList', $this->MODULE_ID, '\Pcode\CUserPropImage', 'GetUserTypeDescription');
        UnRegisterModule($this->MODULE_ID);
        $this->UnInstallFiles();

        return true;
    }

    public function InstallFiles()
    {
        if (\Bitrix\Main\IO\Directory::isDirectoryExists($path = $this->getPath() . '/assets')) {
            CopyDirFiles($path,
                $_SERVER["DOCUMENT_ROOT"] . '/bitrix/js/' . $this->MODULE_ID,
                true, true);
        }

        return true;
    }

    public function UnInstallFiles()
    {
        if (\Bitrix\Main\IO\Directory::isDirectoryExists($path = $this->getPath() . '/assets')) {
            DeleteDirFiles($path,
                $_SERVER["DOCUMENT_ROOT"] . '/bitrix/js/' . $this->MODULE_ID);
        }

        return true;
    }
}
