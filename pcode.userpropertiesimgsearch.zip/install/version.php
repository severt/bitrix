<?php

$arModuleVersion = array(
    "VERSION" => "1.0.0",
    "VERSION_DATE" => "2024-07-15 15:00:00",
);
