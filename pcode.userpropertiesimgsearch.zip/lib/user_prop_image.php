<?php

namespace Pcode;

use Bitrix\Main\Text\HtmlFilter;
use Bitrix\Main\Loader;
use CJSCore;
use Bitrix\Main\Localization\Loc;

Loc::loadMessages(__FILE__);

Loader::includeModule('iblock');

class CUserPropImage extends \Bitrix\Iblock\UserField\Types\ElementType
{

    public static function getModuleId()
    {
        return 'pcode.userpropertiesimgsearch';
    }

    public const USER_TYPE_ID = 'user_id_elements_search_image';

    /**
     * @return array
     */
    public static function getDescription(): array
    {
        return [
            'DESCRIPTION' => Loc::getMessage('PCODE_USER_PROPS_ADMIN_DESCRIPTION'),
            'BASE_TYPE' => \CUserTypeManager::BASE_TYPE_INT,
        ];
    }

    /**
     * @param array $userField
     * @param array|null $additionalParameters
     * @return string
     */
    public static function renderEditForm(array $userField, ?array $additionalParameters): string
    {
        $strPath = '/bitrix/js/' . self::getModuleId();
        CJSCore::RegisterExt('store_link', [
            'js' => $strPath . '/script.js',
            'css' => $strPath . '/style.css',
            'rel' => ['jquery']
        ]);

        CJSCore::Init(['jquery', 'store_link']);

        $intIBlockID = (int)$userField['SETTINGS']['IBLOCK_ID'];
        $arItems = \Bitrix\Iblock\ElementTable::getList([
            'order' => [
                'NAME' => 'ASC',
                'ID' => 'ASC',
            ],
            'select' => array('ID', 'NAME', 'DETAIL_PICTURE'),
            'filter' => array('IBLOCK_ID' => $intIBlockID),
        ])->fetchAll();

        $intSize = (int)$userField['SETTINGS']['LIST_HEIGHT'];
        if ($intSize < 5) {
            $intSize = 5;
        }

        $strNameProp = $userField['FIELD_NAME'];
        $strMultiple = '';
        $strSelectClass = '';
        if ($userField['MULTIPLE'] === 'Y') {
            $strNameProp = $userField['FIELD_NAME'] . '[]';
            $strMultiple = 'multiple';
            $strSelectClass = 'select_multiple';
        }

        $strHtml = '<div class="custom_user_field_list custom_user_field_elements_search_image ' . $strSelectClass . '">';

        $strHtml .= '<div class="inner_list">';
        foreach ($arItems as $arItem) {

            if ($userField['MULTIPLE'] === 'Y') {
                if (is_array($userField['VALUE']) && in_array($arItem['ID'], $userField['VALUE'])) {
                    $strHtml .= '<div class="inner_item"><button data-id="' . $arItem['ID'] . '" class="btn_item"></button>';
                    $strHtml .= '<span class="name_item">' . $arItem['NAME'] . '</span>';
                    $strHtml .= '</div>';
                }

            } else {
                if ($arItem['ID'] == $userField['VALUE']) {
                    $strHtml .= '<div class="inner_item"><button data-id="' . $arItem['ID'] . '" class="btn_item"></button>';
                    $strHtml .= '<span class="name_item">' . $arItem['NAME'] . '</span>';
                    $strHtml .= '</div>';
                }
            }
        }
        $strHtml .= '</div>';
        $strHtml .= '<div class="inner_search"><input type="text" placeholder="' . Loc::getMessage('PCODE_USER_PROPS_ADMIN_SEARCH') . '" class="input_search"></div>';

        $strHtml .= '<div class="inner_select">';
        $strHtml .= '<select class="' . $strSelectClass . '"
        size="' . $intSize . '" 
        name="' . HtmlFilter::encode($strNameProp) . '"
        ' . $strMultiple . '
        >';

        $strHtml .= '<option value="0" class="default">' . Loc::getMessage('PCODE_USER_PROPS_ADMIN_DEFAULT') . '</option>';

        foreach ($arItems as $arItem) {

            $strSelected = '';
            if ((is_array($userField['VALUE']) && in_array($arItem['ID'], $userField['VALUE'])) || (empty($strMultiple) && $arItem['ID'] == $userField['VALUE'])) {
                $strSelected = 'selected';
            }

            $strImage = '';
            if ((int)$arItem['DETAIL_PICTURE'] > 0) {
                $strImage = \CFile::GetPath($arItem['DETAIL_PICTURE']);
            }

            $strHtml .= '<option value="' . $arItem['ID'] . '" class="' . $strSelected . '" data-img="' . $strImage . '">' . $arItem['NAME'] . '</option>';
        }

        $strHtml .= '</select>';
        $strHtml .= '<div class="inner_image"></div>';
        $strHtml .= '</div>';
        $strHtml .= '</div>';

        return $strHtml;
    }
}
