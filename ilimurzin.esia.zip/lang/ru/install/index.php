<?php

$MESS['ILIMURZIN_ESIA_MODULE_NAME'] = 'Вход через ЕСИА';
$MESS['ILIMURZIN_ESIA_MODULE_DESCRIPTION'] = 'Добавляет «Госуслуги» в «социальные сервисы»';
$MESS['ILIMURZIN_ESIA_PARTNER_NAME'] = 'Владимир Илимурзин';
$MESS['ILIMURZIN_ESIA_PARTNER_URI'] = 'https://ilimurzin.ru';
