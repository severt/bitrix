<?php

$MESS['ILIMURZIN_ESIA_CLIENT_ID'] = 'Мнемоника информационной системы';
$MESS['ILIMURZIN_ESIA_PORTAL_URL'] = 'Ссылка на среду ЕСИА';
$MESS['ILIMURZIN_ESIA_PORTAL_URL_INSTRUCTION'] = 'В поле «URL системы» на технологическом портале ЕСИА нужно указать #URL#';
$MESS['ILIMURZIN_ESIA_SIGNER'] = 'Чем подписывать запрос';
$MESS['ILIMURZIN_ESIA_SIGNER_INSTRUCTION'] = 'Чтобы подписывать OpenSSL, он должен быть собран с поддержкой ГОСТ.<br><br>Чтобы подписывать КриптоПро, он должен быть установлен на сервере.<br><br>Консольные варианты нужны для случая, когда нет возможности установить расширения для PHP.';
$MESS['ILIMURZIN_ESIA_CERT_PATH'] = 'Путь до сертификата';
$MESS['ILIMURZIN_ESIA_PRIVATE_KEY_PATH'] = 'Путь до приватного ключа';
$MESS['ILIMURZIN_ESIA_PRIVATE_KEY_PASSWORD'] = 'Пароль приватного ключа';
$MESS['ILIMURZIN_ESIA_OPENSSL_INSTRUCTION'] = 'Выше настройки для OpenSSL. Если выбрали КриптоПро, можно не заполнять.';
$MESS['ILIMURZIN_ESIA_CRYPTCP_PATH'] = 'Путь до cryptcp';
$MESS['ILIMURZIN_ESIA_CERT_THUMBPRINT'] = 'SHA1-отпечаток сертификата';
$MESS['ILIMURZIN_ESIA_CERT_PIN'] = 'PIN-код закрытого контейнера';
$MESS['ILIMURZIN_ESIA_CP_INSTRUCTION'] = 'Выше настройки для КриптоПро. Если выбрали OpenSSL, можно не заполнять.<br><br>Путь до cryptcp обычно /opt/cprocsp/bin/amd64/cryptcp.<br>SHA1-отпечаток сертификата можно посмотреть командой certmgr -list.';
