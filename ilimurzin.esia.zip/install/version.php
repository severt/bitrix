<?php

$arModuleVersion = [
    'VERSION' => '1.0.0',
    'VERSION_DATE' => '2024-08-29 22:20:00',
];
