<?php

require $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/ilimurzin.esia/tools/callback.php';
