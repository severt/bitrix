<?php

namespace Ilimurzin\Esia\Signer\Exceptions;

class CannotReadCertificateException extends SignFailException {}
