<?php

namespace Ilimurzin\Esia\Signer\Exceptions;

class NoSuchTmpDirException extends SignFailException {}
