<?php

namespace Ilimurzin\Esia\Signer\Exceptions;

class CannotGenerateRandomIntException extends SignFailException {}
