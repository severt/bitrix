<?php

namespace Ilimurzin\Esia\Signer\Exceptions;

class NoSuchCertificateFileException extends SignFailException {}
