<?php

namespace Ilimurzin\Esia\Signer\Exceptions;

class CannotReadPrivateKeyException extends SignFailException {}
