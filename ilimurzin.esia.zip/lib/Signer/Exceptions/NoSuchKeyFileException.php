<?php

namespace Ilimurzin\Esia\Signer\Exceptions;

class NoSuchKeyFileException extends SignFailException {}
