<?php

namespace Ilimurzin\Esia\Exceptions;

class RequestFailException extends AbstractEsiaException {}
