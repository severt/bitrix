<?php

namespace Ilimurzin\Esia\Exceptions;

class InvalidConfigurationException extends AbstractEsiaException {}
