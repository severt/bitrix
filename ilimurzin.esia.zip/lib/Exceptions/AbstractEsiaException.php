<?php

namespace Ilimurzin\Esia\Exceptions;

use Exception;

abstract class AbstractEsiaException extends Exception {}
