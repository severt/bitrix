<?
$MESS["ram.highloadblock_MODULE_NAME"] = "Расширенные Highload-блоки";
$MESS["ram.highloadblock_MODULE_DESC"] = "Расширение функционала highload-блоков. Группировка, сортировка.";
$MESS["ram.highloadblock_PARTNER_NAME"] = "Мациевский Роман";
$MESS["ram.highloadblock_PARTNER_URI"] = "rommats.ru";
$MESS["RAM_HLBLOCK_UNINSTALL_TITLE"] = "Удаление модуля \"Расширенные Highload-блоки\"";
?>