<?
$MESS["RAM_HLBLOCK_WARNING"] = "Внимание!
Модуль будет удален из системы";
$MESS["RAM_HLBLOCK_SAVE"] = "Вы можете сохранить данные в таблицах базы данных";
$MESS["RAM_HLBLOCK_SAVE_TABLES"] = "Сохранить таблицы";
$MESS["RAM_HLBLOCK_DELETE_MODULE"] = "Удалить модуль";
?>