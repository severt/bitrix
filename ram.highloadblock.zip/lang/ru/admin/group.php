<?
$MESS["RAM_HLBLOCK_NAME"] = "Название";
$MESS["RAM_HLBLOCK_SORT"] = "Сортировка";
$MESS["RAM_HLBLOCK_ADD"] = "Добавить Highload-блок";
$MESS["RAM_HLBLOCK_EDIT"] = "Изменить раздел";
$MESS["RAM_HLBLOCK_COPY"] = "Копировать раздел";
$MESS["RAM_HLBLOCK_DELETE"] = "Удалить раздел";
$MESS["RAM_HLBLOCK_DELETE_CONFIRM"] = "Удалить раздел? Highload-блоки будут отвязаны от него.";
$MESS["RAM_HLBLOCK_ROWS_LIST"] = "Список записей";
$MESS["RAM_HLBLOCK_FIELDS_LIST"] = "Список полей";
$MESS["RAM_HLBLOCK_EDIT_ENTITY"] = "Изменить";
$MESS["RAM_HLBLOCK_VIEW_ENTITY"] = "Просмотр";
$MESS["RAM_HLBLOCK_DELETE_ENTITY"] = "Удалить";
$MESS["RAM_HLBLOCK_DELETE_ENTITY_CONFIRM"] = "Удалить Highload-блок и все его записи?";
$MESS["RAM_HLBLOCK_GROUP"] = "Раздел Highload-блоков";
$MESS["RAM_HLBLOCK_NAV"] = "Highload-блоки";
?>