<?
$MESS["RAM_HLBLOCK_BASE"] = "Раздел";
$MESS["RAM_HLBLOCK_BASE_HINT"] = "Раздел Highload-блоков";
$MESS["RAM_HLBLOCK_EDIT"] = "Редактирование раздела";
$MESS["RAM_HLBLOCK_CREATE"] = "Создание раздела";
$MESS["RAM_HLBLOCK_COPY"] = "Копирование раздела";
$MESS["RAM_HLBLOCK_SORT"] = "Сортировка";
$MESS["RAM_HLBLOCK_LANGS"] = "Языкозависимые названия";
$MESS["RAM_HLBLOCK_EMPTY_LANG"] = "Не указано название для языка";
?>