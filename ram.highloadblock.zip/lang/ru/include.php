<?
$MESS["RAM_HLBLOCK_MENU_FIELDS"] = "Список полей";
$MESS["RAM_HLBLOCK_MENU_EDIT"] = "Изменить";
$MESS["RAM_HLBLOCK_MENU_DELETE"] = "Удалить";
$MESS["RAM_HLBLOCK_MENU_DELETE_CONFIRM"] = "Удалить Highload-блок и все его записи?";
$MESS["RAM_HLBLOCK_TAB_GROUP"] = "Раздел";
$MESS["RAM_HLBLOCK_TAB_GROUP_TOP"] = "Верхний уровень";
$MESS["RAM_HLBLOCK_TAB_SORT"] = "Сортировка";
$MESS["RAM_HLBLOCK_TAB"] = "Дополнительно";
$MESS["RAM_HLBLOCK_TAB_TITLE"] = "Дополнительные параметры";
?>