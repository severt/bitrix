<?php
namespace Ram\Highloadblock;

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ORM\Data\DataManager;
use Bitrix\Main\ORM\Fields\IntegerField;

/**
 * Class EntityTable
 * 
 * Fields:
 * <ul>
 * <li> ID int mandatory
 * <li> ELEMENT_ID int mandatory
 * <li> GROUP_ID int mandatory
 * <li> SORT int optional default 500
 * </ul>
 *
 * @package Ram\Highloadblock
 **/

class EntityTable extends DataManager
{
	/**
	 * Returns DB table name for entity.
	 *
	 * @return string
	 */
	public static function getTableName()
	{
		return 'ram_hlblock_entity';
	}

	/**
	 * Returns entity map definition.
	 *
	 * @return array
	 */
	public static function getMap()
	{
		return [
			new IntegerField(
				'ID',
				[
					'primary' => true,
					'autocomplete' => true,
					'title' => Loc::getMessage('ENTITY_ENTITY_ID_FIELD'),
				]
			),
			new IntegerField(
				'ELEMENT_ID',
				[
					'required' => true,
					'title' => Loc::getMessage('ENTITY_ENTITY_ELEMENT_ID_FIELD'),
				]
			),
			new IntegerField(
				'GROUP_ID',
				[
					'required' => true,
					'title' => Loc::getMessage('ENTITY_ENTITY_GROUP_ID_FIELD'),
				]
			),
			new IntegerField(
				'SORT',
				[
					'default' => 500,
					'title' => Loc::getMessage('ENTITY_ENTITY_SORT_FIELD'),
				]
			),
		];
	}
}
?>