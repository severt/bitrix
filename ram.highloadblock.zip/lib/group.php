<?php
namespace Ram\Highloadblock;

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ORM\Data\DataManager;
use Bitrix\Main\ORM\Fields\IntegerField;

/**
 * Class GroupTable
 * 
 * Fields:
 * <ul>
 * <li> ID int mandatory
 * <li> SORT int optional default 500
 * </ul>
 *
 * @package Ram\Highloadblock
 **/

class GroupTable extends DataManager
{
	/**
	 * Returns DB table name for entity.
	 *
	 * @return string
	 */
	public static function getTableName()
	{
		return 'ram_hlblock_group';
	}

	/**
	 * Returns entity map definition.
	 *
	 * @return array
	 */
	public static function getMap()
	{
		return [
			new IntegerField(
				'ID',
				[
					'primary' => true,
					'autocomplete' => true,
					'title' => Loc::getMessage('GROUP_ENTITY_ID_FIELD'),
				]
			),
			new IntegerField(
				'SORT',
				[
					'default' => 500,
					'title' => Loc::getMessage('GROUP_ENTITY_SORT_FIELD'),
				]
			),
		];
	}
}
?>