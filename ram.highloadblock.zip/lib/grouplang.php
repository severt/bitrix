<?php
namespace Ram\Highloadblock;

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ORM\Data\DataManager;
use Bitrix\Main\ORM\Fields\IntegerField;
use Bitrix\Main\ORM\Fields\StringField;
use Bitrix\Main\ORM\Fields\Validators\LengthValidator;

/**
 * Class GroupLangTable
 * 
 * Fields:
 * <ul>
 * <li> ID int mandatory
 * <li> LID string(2) mandatory
 * <li> NAME string(255) mandatory
 * </ul>
 *
 * @package Ram\Highloadblock
 **/

class GroupLangTable extends DataManager
{
	/**
	 * Returns DB table name for entity.
	 *
	 * @return string
	 */
	public static function getTableName()
	{
		return 'ram_hlblock_group_lang';
	}

	/**
	 * Returns entity map definition.
	 *
	 * @return array
	 */
	public static function getMap()
	{
		return [
			new IntegerField(
				'ID',
				[
					'primary' => true,
					'required' => true,
					'title' => Loc::getMessage('GROUP_LANG_ENTITY_ID_FIELD'),
				]
			),
			new StringField(
				'LID',
				[
					'primary' => true,
					'required' => true,
					'validation' => function()
					{
						return[
							new LengthValidator(null, 2),
						];
					},
					'title' => Loc::getMessage('GROUP_LANG_ENTITY_LID_FIELD'),
				]
			),
			new StringField(
				'NAME',
				[
					'required' => true,
					'validation' => function()
					{
						return[
							new LengthValidator(null, 255),
						];
					},
					'title' => Loc::getMessage('GROUP_LANG_ENTITY_NAME_FIELD'),
				]
			),
		];
	}
}
?>