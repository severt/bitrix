CREATE TABLE IF NOT EXISTS ram_hlblock_group
(
	`ID` int(11) NOT NULL AUTO_INCREMENT,
	`SORT` int(11) NOT NULL DEFAULT 500,
	PRIMARY KEY (`ID`)
);

CREATE TABLE IF NOT EXISTS ram_hlblock_group_lang
(
	`ID` int(11) NOT NULL,
	`LID` varchar(2) NOT NULL,
	`NAME` varchar(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS ram_hlblock_entity
(
	`ID` int(11) NOT NULL AUTO_INCREMENT,
	`ELEMENT_ID` int(11) NOT NULL,
	`GROUP_ID` int(11) NOT NULL,
	`SORT` int(11) NOT NULL DEFAULT 500,
	PRIMARY KEY (`ID`)
);