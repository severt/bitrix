DROP TABLE IF EXISTS ram_hlblock_group;
DROP TABLE IF EXISTS ram_hlblock_group_lang;
DROP TABLE IF EXISTS ram_hlblock_entity;