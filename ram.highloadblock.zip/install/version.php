<?
$arModuleVersion = [
	"VERSION" => "1.0.2",
	"VERSION_DATE" => "2024-04-02 23:24:10"
];
?>