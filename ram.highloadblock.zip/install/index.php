<?php
IncludeModuleLangFile(__FILE__);
class ram_highloadblock extends CModule
{
	const MODULE_ID = "ram.highloadblock";
	var $MODULE_ID = "ram.highloadblock";
	var $MODULE_VERSION;
	var $MODULE_VERSION_DATE;
	var $MODULE_NAME;
	var $MODULE_DESCRIPTION;
	var $MODULE_CSS;
	var $strError = "";

	function __construct()
	{
		$arModuleVersion = Array();
		include(dirname(__FILE__)."/version.php");
		$this->MODULE_VERSION = $arModuleVersion["VERSION"];
		$this->MODULE_VERSION_DATE = $arModuleVersion["VERSION_DATE"];
		$this->MODULE_NAME = GetMessage("ram.highloadblock_MODULE_NAME");
		$this->MODULE_DESCRIPTION = GetMessage("ram.highloadblock_MODULE_DESC");

		$this->PARTNER_NAME = GetMessage("ram.highloadblock_PARTNER_NAME");
		$this->PARTNER_URI = GetMessage("ram.highloadblock_PARTNER_URI");
	}

	function InstallDB($arParams = Array())
	{
		global $DB, $APPLICATION;

		$this->errors = false;
		$this->errors = $DB->RunSQLBatch($_SERVER['DOCUMENT_ROOT']."/bitrix/modules/".self::MODULE_ID."/install/db/".strtolower($DB->type)."/install.sql");

		if ($this->errors !== false)
		{
			$APPLICATION->ThrowException(implode("", $this->errors));
			return false;
		}
		else
		{			
			return true;
		}
	}

	function UnInstallDB($arParams = Array())
	{
		global $APPLICATION, $DB, $errors;

		$this->errors = false;
		
		if (!$arParams['savedata'])
		{
			$this->errors = $DB->RunSQLBatch($_SERVER['DOCUMENT_ROOT']."/bitrix/modules/".self::MODULE_ID."/install/db/".strtolower($DB->type)."/uninstall.sql");
		}

		if (!empty($this->errors))
		{
			$APPLICATION->ThrowException(implode("", $this->errors));
			return false;
		}
		else
		{
			return true;
		}
	}

	function InstallEvents()
	{
		$eventManager = \Bitrix\Main\EventManager::getInstance();
		
		$eventManager->registerEventHandlerCompatible("main", "OnBuildGlobalMenu", self::MODULE_ID, "CRamHighloadblock", "OnBuildGlobalMenu");
		$eventManager->registerEventHandlerCompatible("main", "OnAdminTabControlBegin", self::MODULE_ID, "CRamHighloadblock", "OnAdminTabControlBegin");
		$eventManager->registerEventHandlerCompatible("main", "OnProlog", self::MODULE_ID, "CRamHighloadblock", "OnProlog");
		$eventManager->registerEventHandlerCompatible("main", "OnEpilog", self::MODULE_ID, "CRamHighloadblock", "OnEpilog");
		$eventManager->registerEventHandlerCompatible("highloadblock", "\\Bitrix\\HighloadBlock\\HighloadBlock::OnAfterAdd", self::MODULE_ID, "CRamHighloadblock", "OnAfterHLBlockAdd");
		$eventManager->registerEventHandlerCompatible("highloadblock", "\\Bitrix\\HighloadBlock\\HighloadBlock::OnAfterUpdate", self::MODULE_ID, "CRamHighloadblock", "OnAfterHLBlockUpdate");
		$eventManager->registerEventHandlerCompatible("highloadblock", "\\Bitrix\\HighloadBlock\\HighloadBlock::OnAfterDelete", self::MODULE_ID, "CRamHighloadblock", "OnAfterHLBlockDelete");
		
		return true;
	}

	function UnInstallEvents()
	{
		$eventManager = \Bitrix\Main\EventManager::getInstance();
		
		$eventManager->unRegisterEventHandler("main", "OnBuildGlobalMenu", self::MODULE_ID, "CRamHighloadblock", "OnBuildGlobalMenu");
		$eventManager->unRegisterEventHandler("main", "OnAdminTabControlBegin", self::MODULE_ID, "CRamHighloadblock", "OnAdminTabControlBegin");
		$eventManager->unRegisterEventHandler("main", "OnProlog", self::MODULE_ID, "CRamHighloadblock", "OnProlog");
		$eventManager->unRegisterEventHandler("main", "OnEpilog", self::MODULE_ID, "CRamHighloadblock", "OnEpilog");
		$eventManager->unRegisterEventHandler("highloadblock", "\\Bitrix\\HighloadBlock\\HighloadBlock::OnAfterAdd", self::MODULE_ID, "CRamHighloadblock", "OnAfterHLBlockAdd");
		$eventManager->unRegisterEventHandler("highloadblock", "\\Bitrix\\HighloadBlock\\HighloadBlock::OnAfterUpdate", self::MODULE_ID, "CRamHighloadblock", "OnAfterHLBlockUpdate");
		$eventManager->unRegisterEventHandler("highloadblock", "\\Bitrix\\HighloadBlock\\HighloadBlock::OnAfterDelete", self::MODULE_ID, "CRamHighloadblock", "OnAfterHLBlockDelete");
		
		return true;
	}

	function InstallFiles($arParams = Array())
	{
		CopyDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/".self::MODULE_ID."/install/admin", $_SERVER["DOCUMENT_ROOT"]."/bitrix/admin", true, true);
		CopyDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/".self::MODULE_ID."/install/panel", $_SERVER["DOCUMENT_ROOT"]."/bitrix/panel", true, true);
		
		return true;
	}

	function UnInstallFiles()
	{
		DeleteDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/".self::MODULE_ID."/install/admin", $_SERVER["DOCUMENT_ROOT"]."/bitrix/admin");
		\Bitrix\Main\IO\Directory::deleteDirectory($_SERVER["DOCUMENT_ROOT"]."/bitrix/panel/".self::MODULE_ID);
		
		return true;
	}

	function DoInstall()
	{
		global $APPLICATION;
		$this->InstallFiles();
		$this->InstallDB();
		$this->InstallEvents();
		RegisterModule(self::MODULE_ID);
		
		Bitrix\Main\Loader::includeModule("highloadblock");
		Bitrix\Main\Loader::includeModule("ram.highloadblock");
			
		$hlBlocks = Bitrix\Highloadblock\HighloadBlockTable::getList()->fetchAll();
		
		$entities = Ram\Highloadblock\EntityTable::getList()->fetchAll();
		
		foreach ($hlBlocks as $hlBlock)
		{
			$exists = false;
			
			foreach ($entities as $entity)
			{
				if ($entity["ELEMENT_ID"] == $hlBlock["ID"])
				{
					$exists = true;
				}
			}
			
			if (!$exists)
			{
				Ram\Highloadblock\EntityTable::add(Array("ELEMENT_ID" => $hlBlock["ID"], "GROUP_ID" => 0, "SORT" => 500));
			}
		}
	}

	function DoUninstall()
	{
		global $DOCUMENT_ROOT, $APPLICATION, $step;
		$step = intval($step);
		if ($step < 2)
		{
			$APPLICATION->IncludeAdminFile(GetMessage("RAM_HLBLOCK_UNINSTALL_TITLE"), $DOCUMENT_ROOT."/bitrix/modules/".self::MODULE_ID."/install/unstep1.php");
		}
		elseif ($step == 2)
		{
			UnRegisterModule(self::MODULE_ID);
			$this->UnInstallEvents();
			$this->UnInstallDB(array("savedata" => $_REQUEST["savedata"]));
			$this->UnInstallFiles();
		}
	}
}
?>
