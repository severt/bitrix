<?
use Bitrix\Main\Localization\Loc;

require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_before.php");

$moduleId = "ram.highloadblock";

Bitrix\Main\Loader::includeModule($moduleId);
Bitrix\Main\Loader::includeModule("highloadblock");

$tableId = "tbl_ram_hl";

$oSort = new CAdminSorting($tableId, "ID", "asc");
$lAdmin = new CAdminList($tableId, $oSort);

$arFilterFields = Array();

$lAdmin->InitFilter($arFilterFields);

$lAdmin->AddHeaders(Array
(
	Array("id" => "ID", "content" => "ID", "sort" => "ID", "default" => true),
	Array("id" => "NAME", "content" => Loc::getMessage("RAM_HLBLOCK_NAME"), "sort" => "NAME", "default" => true),
	Array("id" => "SORT", "content" => Loc::getMessage("RAM_HLBLOCK_SORT"), "sort" => "SORT", "default" => true),
));

$ramHlGroup = CRamHighloadblock::GetGroup($ID);

$hlblocksLang = Bitrix\Highloadblock\HighloadBlockLangTable::getList(Array("filter" => Array("LID" => LANGUAGE_ID)))->fetchAll();

if ($by === "ID" || $by === "NAME")
{
	$sortBy = "ELEMENT_ID";
}
else
{
	$sortBy = $by;
}

$sortOrder = $order;

$entities = \Ram\Highloadblock\EntityTable::getList(Array("order" => Array($sortBy => $sortOrder), "filter" => Array("GROUP_ID" => $ID), "select" => Array("*")))->fetchAll();

$hlBlocksIds = Array();
$hlBlocksData = Array();

if ($by == "NAME")
{
	foreach ($entities as $e => $entity)
	{
		foreach ($hlblocksLang as $hlblockLang)
		{
			if ($hlblockLang["ID"] == $entity["ELEMENT_ID"])
			{
				$entities[$e]["LANG_NAME"] = $hlblockLang["NAME"];
				break;
			}
		}
	}
	
	usort($entities, function($a, $b)
	{
		global $order;
		
		if (!isset($a["LANG_NAME"]) && !isset($b["LANG_NAME"]))
		{
			return 0;
		}
		
		if ($a["LANG_NAME"] === $b["LANG_NAME"])
		{
			return 0;
		}
		return ($a["LANG_NAME"] < $b["LANG_NAME"] ? -1 : 1) * ($order === "asc" ? 1 : -1);
	});
}

foreach ($entities as $entity)
{
	$hlBlocksIds[] = $entity["ELEMENT_ID"];
	$hlBlocksData[$entity["ELEMENT_ID"]] = Array("SORT" => $entity["SORT"]);
}

if (!empty($hlBlocksIds))
{
	$hlBlocks = Bitrix\Highloadblock\HighloadBlockTable::getList(Array
	(
		"filter" => Array("ID" => $hlBlocksIds),
		"select" => Array("ID", "NAME", "SORT"),
		"runtime" => Array
		(
			new Bitrix\Main\Entity\ExpressionField("SORT", "FIELD(%s, ".implode(", ", $hlBlocksIds).")", "ID"),
		),
		"order" => Array("SORT" => "ASC")
	));
}
else
{
	$hlBlocks = Bitrix\Highloadblock\HighloadBlockTable::getList(Array
	(
		"filter" => Array("ID" => 0),
		"select" => Array("ID", "NAME"),
	));
}

$result = new CAdminResult($hlBlocks, $tableId);
$result->NavStart();

$lAdmin->NavText($result->GetNavPrint(Loc::getMessage("RAM_HLBLOCK_NAV")));

$aMenu = Array
(
	Array
	(
		"TEXT"	=> Loc::getMessage("RAM_HLBLOCK_ADD"),
		"LINK"	=> "highloadblock_entity_edit.php?lang=".LANGUAGE_ID."&RAM_HIGHLOADBLOCK[GROUP]=".$ID,
		"ICON"	=> "btn_new",
	),
	Array
	(
		"TEXT"	=> Loc::getMessage("RAM_HLBLOCK_EDIT"),
		"LINK"	=> "ram.highloadblock_group_edit.php?ID=".$ID."&lang=".LANGUAGE_ID,
	),
	Array
	(
		"TEXT"	=> Loc::getMessage("RAM_HLBLOCK_COPY"),
		"LINK"	=> "ram.highloadblock_group_edit.php?ID=".$ID."&action=copy&lang=".LANGUAGE_ID,
		"ICON"	=> "btn_copy",
	),
	Array
	(
		"TEXT"	=> Loc::getMessage("RAM_HLBLOCK_DELETE"),
		"ONCLICK" => "if(confirm('".Loc::getMessage("RAM_HLBLOCK_DELETE_CONFIRM")."')) ".$lAdmin->ActionRedirect("ram.highloadblock_group_edit.php?ID=".$ID."&lang=".LANGUAGE_ID."&action=delete"),
		"ICON"	=> "btn_delete",
	),
);

while ($arRes = $result->NavNext(true, "f_"))
{
	$arRes["SORT"] = $hlBlocksData[$arRes["ID"]]["SORT"];
	$arRes["GROUP"] = $hlBlocksData[$arRes["ID"]]["GROUP"];
	
	foreach ($hlblocksLang as $hlblockLang)
	{
		if ($hlblockLang["ID"] == $arRes["ID"])
		{
			$arRes["NAME"] = $hlblockLang["NAME"];
			
			break;
		}
	}
	
	$row = $lAdmin->AddRow($f_ID, $arRes);

	$can_edit = true;

	$arActions = Array();

	$arActions[] = Array
	(
		"ICON" => "btn_fileman_view",
		"TEXT" => Loc::getMessage("RAM_HLBLOCK_ROWS_LIST"),
		"ACTION" => $lAdmin->ActionRedirect("highloadblock_rows_list.php?ENTITY_ID=".$f_ID),
		"DEFAULT" => true
	);

	$arActions[] = Array
	(
		"ICON" => "btn_fileman_prop",
		"TEXT" => Loc::getMessage("RAM_HLBLOCK_FIELDS_LIST"),
		"ACTION" => $lAdmin->ActionRedirect("userfield_admin.php?lang=".LANGUAGE_ID."&set_filter=Y&find=HLBLOCK_".intval($f_ID)."&find_type=ENTITY_ID&back_url=".urlencode($APPLICATION->GetCurPageParam()))
	);

	$arActions[] = Array
	(
		"ICON" => "edit",
		"TEXT" => $can_edit ? Loc::getMessage("RAM_HLBLOCK_EDIT_ENTITY") : Loc::getMessage("RAM_HLBLOCK_VIEW_ENTITY"),
		"ACTION"=>$lAdmin->ActionRedirect("highloadblock_entity_edit.php?ID=".$f_ID)
	);

	$arActions[] = Array
	(
		"ICON" => "delete",
		"TEXT" => Loc::getMessage("RAM_HLBLOCK_DELETE_ENTITY"),
		"ACTION" => "if(confirm('".Loc::getMessage("RAM_HLBLOCK_DELETE_ENTITY_CONFIRM")."')) ".$lAdmin->ActionRedirect("highloadblock_entity_edit.php?action=delete&ID=".$f_ID."&".bitrix_sessid_get())
	);

	$row->AddActions($arActions);
}

$context = new CAdminContextMenu($aMenu);

if ($_REQUEST["mode"] == "list")
{
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_js.php");
}
else
{
	require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php");

	$context->Show();
}

$lAdmin->CheckListMode();

$APPLICATION->SetTitle(Loc::getMessage("RAM_HLBLOCK_GROUP")." \"".$ramHlGroup["NAME"]."\"");

$lAdmin->DisplayList();

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php");
?>