<?
use Bitrix\Main\Localization\Loc;

require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_before.php");

$moduleId = "ram.highloadblock";

$MODULE_RIGHT = $APPLICATION->GetGroupRight("highloadblock");

if ($MODULE_RIGHT === 'D')
{
	$APPLICATION->AuthForm(GetMessage("ACCESS_DENIED"));
}

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php");

\Bitrix\Main\Loader::includeModule($moduleId);

IncludeModuleLangFile(__FILE__);

$langs = Bitrix\Main\Localization\LanguageTable::getList(Array("order" => Array("SORT" => "ASC", "LID" => "ASC")))->fetchAll();

$context = Bitrix\Main\Application::getInstance()->getContext();
$request = $context->getRequest();

$ID = intval($ID);
$SAVE = $request["save"] ? true : false;
$APPLY = $request["apply"] ? true : false;
$COPY = $request["action"] === "copy" ? true : false;
$DELETE = $request["action"] === "delete" ? true : false;

if ($request->isPost() && $MODULE_RIGHT === "W")
{
	$group = $_POST;
	
	$errors = Array();
	
	foreach ($group["LANGS"] as $lid => $groupLang)
	{
		if (!strlen($groupLang))
		{
			foreach ($langs as $lang)
			{
				if ($lid === $lang["LID"])
				{
					$errors[] = Loc::getMessage("RAM_HLBLOCK_EMPTY_LANG")." \"".$lang["NAME"]."\"";
				}
			}
		}
	}
	
	if (!empty($errors))
	{
		CAdminMessage::ShowMessage(implode("\n", $errors));
		
		if ($ID && $COPY)
		{
			if ($group["LANGS"][LANGUAGE_ID])
			{
				$APPLICATION->SetTitle(Loc::getMessage("RAM_HLBLOCK_COPY")." \"".$group["LANGS"][LANGUAGE_ID]."\"");
			}
			else
			{
				$APPLICATION->SetTitle(Loc::getMessage("RAM_HLBLOCK_COPY")." #".$ID);
			}
		}
		else if ($ID)
		{
			if ($group["LANGS"][LANGUAGE_ID])
			{
				$APPLICATION->SetTitle(Loc::getMessage("RAM_HLBLOCK_EDIT")." \"".$group["LANGS"][LANGUAGE_ID]."\"");
			}
			else
			{
				$APPLICATION->SetTitle(Loc::getMessage("RAM_HLBLOCK_EDIT")." #".$ID);
			}
		}
		else
		{
			$APPLICATION->SetTitle(Loc::getMessage("RAM_HLBLOCK_CREATE"));
		}
	}
	else
	{
		if ($ID && !$COPY)
		{
			// edit post
			
			Ram\Highloadblock\GroupTable::update($ID, Array("SORT" => $group["SORT"]));
			
			foreach ($langs as $lang)
			{
				Ram\Highloadblock\GroupLangTable::delete(Array("ID" => $ID, "LID" => $lang["LID"]));
			}
			
			foreach ($group["LANGS"] as $lid => $lang)
			{
				Ram\Highloadblock\GroupLangTable::add(Array("ID" => $ID, "LID" => $lid, "NAME" => $lang));
			}
			
			if ($SAVE) LocalRedirect("ram.highloadblock_group.php?ID=".$ID."&lang=".LANGUAGE_ID);
			else LocalRedirect("ram.highloadblock_group_edit.php?ID=".$ID."&lang=".LANGUAGE_ID);
		}
		else if (($ID && $COPY) || !$ID)
		{
			// copy post
			
			$res = Ram\Highloadblock\GroupTable::add(Array("SORT" => $group["SORT"]));
			
			$ID = $res->getId();
			
			foreach ($langs as $lang)
			{
				Ram\Highloadblock\GroupLangTable::delete(Array("ID" => $ID, "LID" => $lang["LID"]));
			}
			
			foreach ($group["LANGS"] as $lid => $lang)
			{
				Ram\Highloadblock\GroupLangTable::add(Array("ID" => $ID, "LID" => $lid, "NAME" => $lang));
			}
			
			if ($SAVE) LocalRedirect("ram.highloadblock_group.php?ID=".$ID."&lang=".LANGUAGE_ID);
			else LocalRedirect("ram.highloadblock_group_edit.php?ID=".$ID."&lang=".LANGUAGE_ID);
		}
	}
}
else
{
	if ($ID && $DELETE && $MODULE_RIGHT === "W")
	{
		// delete get
		
		Ram\Highloadblock\GroupTable::delete($ID);
		
		foreach ($langs as $lang)
		{
			Ram\Highloadblock\GroupLangTable::delete(Array("ID" => $ID, "LID" => $lang["LID"]));
		}
		
		$entities = Ram\Highloadblock\EntityTable::getList(Array("filter" => Array("GROUP_ID" => $ID)))->fetchAll();
		
		foreach ($entities as $entity)
		{
			Ram\Highloadblock\EntityTable::update($entity["ID"], Array("GROUP_ID" => 0));
		}
		
		LocalRedirect("highloadblock_index.php?lang=".LANGUAGE_ID);
	}
	else if ($ID && $COPY && $MODULE_RIGHT === "W")
	{
		// copy get
		$group = Ram\Highloadblock\GroupTable::getList(Array("filter" => Array("ID" => $ID)))->fetch();
		$group_langs = Ram\Highloadblock\GroupLangTable::getList(Array("filter" => Array("ID" => $ID)))->fetchAll();
		
		foreach ($group_langs as $lang)
		{
			$group["LANGS"][$lang["LID"]] = $lang["NAME"];
		}
		
		$APPLICATION->SetTitle(Loc::getMessage("RAM_HLBLOCK_COPY")." \"".$group["LANGS"][LANGUAGE_ID]."\"");
	}
	else if ($ID)
	{
		// edit get
		
		$group = Ram\Highloadblock\GroupTable::getList(Array("filter" => Array("ID" => $ID)))->fetch();
		$group_langs = Ram\Highloadblock\GroupLangTable::getList(Array("filter" => Array("ID" => $ID)))->fetchAll();
		
		foreach ($group_langs as $lang)
		{
			$group["LANGS"][$lang["LID"]] = $lang["NAME"];
		}
		
		$APPLICATION->SetTitle(Loc::getMessage("RAM_HLBLOCK_EDIT")." \"".$group["LANGS"][LANGUAGE_ID]."\"");
	}
	else
	{
		//create
		
		$APPLICATION->SetTitle(Loc::getMessage("RAM_HLBLOCK_CREATE"));
	}
}

$arTabs = Array(
	Array("DIV" => "base", "TAB" => Loc::getMessage("RAM_HLBLOCK_BASE"), "TITLE" => Loc::getMessage("RAM_HLBLOCK_BASE_HINT")),
);

$tabControl = new \CAdminTabControl("RamCalcTabControl", $arTabs);

?><form method="POST" action="<?=$APPLICATION->GetCurPageParam()?>" class="ram-calc" enctype="multipart/form-data"><?=bitrix_sessid_post()?><?

$tabControl->Begin();

$tabControl->BeginNextTab();

if ($ID && !$COPY)
{
	?>
	<tr>
		<td width="40%" class="adm-detail-content-cell-l">ID</td>
		<td class="adm-detail-content-cell-r"><?=$ID?></td>
	</tr>
	<?
}
?>
<tr>
	<td width="40%" class="adm-detail-content-cell-l"><?=Loc::getMessage("RAM_HLBLOCK_SORT")?></td>
	<td class="adm-detail-content-cell-r"><input name='SORT' type='text' value='<?=(isset($group["SORT"])?$group["SORT"]:"500")?>'/></td>
</tr>
<tr class="heading">
	<td colspan="2"><?=Loc::getMessage("RAM_HLBLOCK_LANGS")?>:</td>
</tr>
<?
foreach ($langs as $lang)
{
	?>
	<tr>
		<td class="adm-detail-content-cell-l"><b><?=$lang["NAME"]?></b></td>
		<td class="adm-detail-content-cell-r"><input type="text" name="LANGS[<?=$lang["LID"]?>]" value="<?=(isset($group["LANGS"][$lang["LID"]])?$group["LANGS"][$lang["LID"]]:"")?>"></td>
	</tr>
	<?
}
?>

<?

if ($MODULE_RIGHT === "W")
{
	$tabControl->Buttons(Array("back_url" => $_SERVER["HTTP_REFERER"]));
}
else
{
	$tabControl->Buttons(Array("btnSave" => false, "btnApply" => false, "back_url" => $_SERVER["HTTP_REFERER"]));
}

$tabControl->End();

?></form><?

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php");
?>