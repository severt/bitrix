<?
use Bitrix\Main\Localization\Loc;

require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_before.php");

$moduleId = "ram.highloadblock";

Bitrix\Main\Loader::includeModule($moduleId);
Bitrix\Main\Loader::includeModule("highloadblock");

$tableId = "tbl_ram_hl";

$oSort = new CAdminSorting($tableId, "ID", "asc");
$lAdmin = new CAdminList($tableId, $oSort);

$arFilterFields = Array();

$lAdmin->InitFilter($arFilterFields);

$lAdmin->AddHeaders(Array
(
	Array("id" => "ID", "content" => "ID", "sort" => "ID", "default" => true),
	Array("id" => "NAME", "content" => Loc::getMessage("RAM_HLBLOCK_NAME"), "sort" => "NAME", "default" => true),
	Array("id" => "SORT", "content" => Loc::getMessage("RAM_HLBLOCK_SORT"), "sort" => "SORT", "default" => true),
));

$connection = Bitrix\Main\Application::getConnection();

$result = new CAdminResult($connection->Query("SELECT _group.ID as ID, _group.SORT as SORT, _group_lang.NAME as NAME, 'G' as TYPE FROM ram_hlblock_group as _group, ram_hlblock_group_lang as _group_lang WHERE _group_lang.ID = _group.ID AND _group_lang.LID = '".LANGUAGE_ID."' UNION SELECT _b_entity.ID as ID, _entity.SORT as SORT, IFNULL(_b_entity_lang.NAME, _b_entity.NAME) as NAME, 'E' as TYPE FROM ram_hlblock_entity as _entity, b_hlblock_entity as _b_entity LEFT JOIN b_hlblock_entity_lang as _b_entity_lang ON _b_entity_lang.ID = _b_entity.ID AND _b_entity_lang.LID = '".LANGUAGE_ID."' WHERE _entity.GROUP_ID = 0 AND _b_entity.ID = _entity.ELEMENT_ID ORDER BY TYPE DESC, ".$by." ".$order.";"), $tableId);

$result->NavStart();
$lAdmin->NavText($result->GetNavPrint(Loc::getMessage("RAM_HLBLOCK_NAV")));

$aMenu = Array
(
	Array
	(
		"TEXT"	=> Loc::getMessage("RAM_HLBLOCK_ADD"),
		"LINK"	=> "highloadblock_entity_edit.php?lang=".LANGUAGE_ID,
		"ICON"	=> "btn_new",
	),
	Array
	(
		"TEXT"	=> Loc::getMessage("RAM_HLBLOCK_GROUP_ADD"),
		"LINK"	=> "ram.highloadblock_group_edit.php?lang=".LANGUAGE_ID,
		"ICON"	=> "btn_new",
	),
);

while ($arRes = $result->NavNext(true, "f_"))
{
	$arActions = Array();
	
	$row = $lAdmin->AddRow($f_ID, $arRes);
	
	$can_edit = true;
	
	if ($arRes["TYPE"] === "G")
	{
		$row->AddViewField("NAME", '<a href="/bitrix/admin/ram.highloadblock_group.php?ID='.$f_ID.'&lang='.LANGUAGE_ID.'" class="adm-list-table-icon-link"><span class="adm-submenu-item-link-icon adm-list-table-icon iblock-section-icon"></span><span class="adm-list-table-link">'.htmlspecialcharsbx($arRes['NAME']).'</span></a>');
		
		$arActions[] = Array
		(
			"ICON" => "edit",
			"TEXT" => $can_edit ? Loc::getMessage("RAM_HLBLOCK_EDIT_GROUP") : Loc::getMessage("RAM_HLBLOCK_VIEW_GROUP"),
			"ACTION" => $lAdmin->ActionRedirect("ram.highloadblock_group_edit.php?ID=".$f_ID),
			"DEFAULT" => true
		);

		$arActions[] = Array
		(
			"ICON" => "delete",
			"TEXT" => Loc::getMessage("RAM_HLBLOCK_DELETE_GROUP"),
			"ACTION" => "if(confirm('".Loc::getMessage("RAM_HLBLOCK_DELETE_GROUP_CONFIRM")."')) ".$lAdmin->ActionRedirect("ram.highloadblock_group_edit.php?action=delete&ID=".$f_ID."&".bitrix_sessid_get())
		);
	
		$arActions[] = Array
		(
			// "ICON" => "delete",
			"TEXT" => Loc::getMessage("RAM_HLBLOCK_ADD"),
			"ACTION" => $lAdmin->ActionRedirect("highloadblock_entity_edit.php?lang=".LANGUAGE_ID."&RAM_HIGHLOADBLOCK[GROUP]=".$f_ID),
		);
	}
	else
	{
		$arActions[] = Array
		(
			"ICON" => "btn_fileman_view",
			"TEXT" => Loc::getMessage("RAM_HLBLOCK_ROWS_LIST"),
			"ACTION" => $lAdmin->ActionRedirect("highloadblock_rows_list.php?ENTITY_ID=".$f_ID),
			"DEFAULT" => true
		);

		$arActions[] = Array
		(
			"ICON" => "btn_fileman_prop",
			"TEXT" => Loc::getMessage("RAM_HLBLOCK_FIELDS_LIST"),
			"ACTION" => $lAdmin->ActionRedirect("userfield_admin.php?lang=".LANGUAGE_ID."&set_filter=Y&find=HLBLOCK_".intval($f_ID)."&find_type=ENTITY_ID&back_url=".urlencode($APPLICATION->GetCurPageParam()))
		);

		$arActions[] = Array
		(
			"ICON" => "edit",
			"TEXT" => $can_edit ? Loc::getMessage("RAM_HLBLOCK_EDIT_ENTITY") : Loc::getMessage("RAM_HLBLOCK_VIEW_ENTITY"),
			"ACTION"=>$lAdmin->ActionRedirect("highloadblock_entity_edit.php?ID=".$f_ID)
		);

		$arActions[] = Array
		(
			"ICON" => "delete",
			"TEXT" => Loc::getMessage("RAM_HLBLOCK_DELETE_ENTITY"),
			"ACTION" => "if(confirm('".Loc::getMessage("RAM_HLBLOCK_DELETE_ENTITY_CONFIRM")."')) ".$lAdmin->ActionRedirect("highloadblock_entity_edit.php?action=delete&ID=".$f_ID."&".bitrix_sessid_get())
		);
	}
	
	$row->AddActions($arActions);
}

$context = new CAdminContextMenu($aMenu);

if ($_REQUEST["mode"] == "list")
{
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_js.php");
}
else
{
	require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php");

	$context->Show();
}

$lAdmin->CheckListMode();

$APPLICATION->SetTitle(Loc::getMessage("RAM_HLBLOCK"));

$lAdmin->DisplayList();

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php");
?>