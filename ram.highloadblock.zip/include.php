<?
use Bitrix\Main\Localization\Loc;

class CRamHighloadblock
{
	public static $cache = Array();
	
	public static function GetGroup($id, $lid = "")
	{
		if (!strlen($lid))
		{
			$lid = LANGUAGE_ID;
		}
		
		$group = Ram\Highloadblock\GroupTable::getList(Array("filter" => Array("ID" => intval($id))))->fetch();
		
		if (!empty($group))
		{
			$groupLang = Ram\Highloadblock\GroupLangTable::getList(Array("filter" => Array("LID" => $lid, "ID" => intval($id))))->fetch();
			
			if (!empty($groupLang))
			{
				$group["NAME"] = $groupLang["NAME"];
			}
		}
		
		return $group;
	}
	
	public static function GetHLBlock($id, $lid = "")
	{
		if (!strlen($lid))
		{
			$lid = LANGUAGE_ID;
		}
		
		$hlBlock = Bitrix\Highloadblock\HighloadBlockTable::getList(Array("filter" => Array("ID" => intval($id))))->fetch();
		
		if (!empty($hlBlock))
		{
			$hlBlockLang = Bitrix\Highloadblock\HighloadBlockLangTable::getList(Array("filter" => Array("LID" => $lid, "ID" => intval($id))))->fetch();
			
			if (!empty($hlBlockLang))
			{
				$hlBlock["LANG_NAME"] = $hlBlockLang["NAME"];
			}
			else
			{
				$hlBlock["LANG_NAME"] = $hlBlock["NAME"];
			}
		}
		
		return $hlBlock;
	}
	
	public static function OnBuildGlobalMenu(&$aGlobalMenu, &$aModuleMenu)
	{
		global $APPLICATION;
		
		foreach ($aModuleMenu as $m => $menuItem)
		{
			if ($menuItem["section"] === "highloadblock")
			{
				$newMenu = Array();
				
				$groups = Ram\Highloadblock\GroupTable::getList(Array("order" => Array("SORT" => "ASC")))->fetchAll();
				
				$entities = Ram\Highloadblock\EntityTable::getList(Array("filter" => Array("!GROUP_ID" => 0), "order" => Array("SORT" => "ASC")))->fetchAll();
				
				$ingroupEntities = Array();
				
				foreach ($groups as $group)
				{
					$group = CRamHighloadblock::GetGroup($group["ID"]);
					
					$childs = Array();
					
					foreach ($entities as $e => $entity)
					{
						if ($entity["GROUP_ID"] == $group["ID"])
						{
							$hlBlock = CRamHighloadblock::GetHLBlock($entity["ELEMENT_ID"]);
							
							if ($hlBlock)
							{
								$hlblockFields = Array();
								$userFields = Bitrix\Main\UserFieldTable::getList(Array("filter" => Array("ENTITY_ID" => "HLBLOCK_".$entity["ELEMENT_ID"])))->fetchAll();
								
								foreach ($userFields as $userField)
								{
									$hlblockFields[] = "userfield_edit.php?ID=".$userField["ID"]."&lang=".LANGUAGE_ID;
								}
								
								$hlblockFields[] = "userfield_edit.php?lang=".LANGUAGE_ID."&ENTITY_ID=HLBLOCK_".$entity["ELEMENT_ID"];
								
								$childs[] = Array
								(
									"text" => $hlBlock["LANG_NAME"],
									"url" => "highloadblock_rows_list.php?ENTITY_ID=".$entity["ELEMENT_ID"]."&lang=".LANGUAGE_ID,
									"icon" => "ram-highloadblock-entity-icon",
									"module_id" => "highloadblock",
									"more_url" => Array
									(
										"highloadblock_row_edit.php?ENTITY_ID=".$entity["ELEMENT_ID"]."&lang=".LANGUAGE_ID,
										"highloadblock_entity_edit.php?ID=".$entity["ELEMENT_ID"]."&lang=".LANGUAGE_ID,
									),
									"items_id" => "ram.highloadblock_".$entity["ELEMENT_ID"],
									"items" => Array
									(
										Array
										(
											"text" => Loc::getMessage("RAM_HLBLOCK_MENU_FIELDS"),
											"url" => "userfield_admin.php?lang=".LANGUAGE_ID."&set_filter=Y&find=HLBLOCK_".$entity["ELEMENT_ID"]."&find_type=ENTITY_ID",
											"icon" => "ram-highloadblock-fields-icon",
											"more_url" => $hlblockFields,
										),
										Array
										(
											"text" => Loc::getMessage("RAM_HLBLOCK_MENU_EDIT"),
											"url" => "highloadblock_entity_edit.php?ID=".$entity["ELEMENT_ID"]."&lang=".LANGUAGE_ID,
											"icon" => "ram-highloadblock-edit-icon",
										),
										Array
										(
											"text" => Loc::getMessage("RAM_HLBLOCK_MENU_DELETE"),
											"icon" => "ram-highloadblock-delete-icon",
											"url" => "javascript:if(confirm('".Loc::getMessage("RAM_HLBLOCK_MENU_DELETE_CONFIRM")."')) document.location=\"highloadblock_entity_edit.php?action=delete&ID=".$entity["ELEMENT_ID"]."&".bitrix_sessid_get()."\";",
										),
									),
								);
								
								$ingroupEntities[] = $entity["ELEMENT_ID"];
							}
						}
					}
					
					if (!strlen($group["NAME"]))
					{
						$group["NAME"] = "[".$group["ID"]."]";
					}
					
					$newMenu[] = Array
					(
						"text" => $group["NAME"],
						"url" => "ram.highloadblock_group.php?ID=".$group["ID"]."&lang=".LANGUAGE_ID,
						"module_id" => "ram.highloadblock",
						"items" => $childs,
						"icon" => "ram-highloadblock-group-icon",
						"items_id" => "ram.highloadblock_group_".$group["ID"],
						"more_url" => Array
						(
							"ram.highloadblock_group_edit.php?ID=".$group["ID"]."&lang=".LANGUAGE_ID,
						)
					);
				}
				
				$hlBlocks = Bitrix\Highloadblock\HighloadBlockTable::getList()->fetchAll();
				
				$entities = Ram\Highloadblock\EntityTable::getList(Array("filter" => Array("!ELEMENT_ID" => $ingroupEntities), "order" => Array("SORT" => "ASC")))->fetchAll();
				
				foreach ($entities as $e => $entity)
				{
					foreach ($hlBlocks as $h => $hlBlock)
					{
						if ($entity["ELEMENT_ID"] == $hlBlock["ID"])
						{
							$hlBlockData = CRamHighloadblock::GetHLBlock($hlBlock["ID"]);
							
							$hlblockFields = Array();
							$userFields = Bitrix\Main\UserFieldTable::getList(Array("filter" => Array("ENTITY_ID" => "HLBLOCK_".$hlBlock["ID"])))->fetchAll();
							
							foreach ($userFields as $userField)
							{
								$hlblockFields[] = "userfield_edit.php?ID=".$userField["ID"]."&lang=".LANGUAGE_ID;
							}
							
							$hlblockFields[] = "userfield_edit.php?lang=".LANGUAGE_ID."&ENTITY_ID=HLBLOCK_".$hlBlock["ID"];
							
							$newMenu[] = Array
							(
								"text" => $hlBlockData["LANG_NAME"],
								"url" => "highloadblock_rows_list.php?ENTITY_ID=".$hlBlock["ID"]."&lang=".LANGUAGE_ID,
								"icon" => "ram-highloadblock-entity-icon",
								"module_id" => "highloadblock",
								"more_url" => Array
								(
									"highloadblock_row_edit.php?ENTITY_ID=".$hlBlock["ID"]."&lang=".LANGUAGE_ID,
									"highloadblock_entity_edit.php?ID=".$hlBlock["ID"]."&lang=".LANGUAGE_ID,
								),
								"items_id" => "ram.highloadblock_".$hlBlock["ID"],
								"items" => Array
								(
									Array
									(
										"text" => Loc::getMessage("RAM_HLBLOCK_MENU_FIELDS"),
										"url" => "userfield_admin.php?lang=".LANGUAGE_ID."&set_filter=Y&find=HLBLOCK_".$hlBlock["ID"]."&find_type=ENTITY_ID",
										"icon" => "ram-highloadblock-fields-icon",
										"more_url" => $hlblockFields,
									),
									Array
									(
										"text" => Loc::getMessage("RAM_HLBLOCK_MENU_EDIT"),
										"url" => "highloadblock_entity_edit.php?ID=".$hlBlock["ID"]."&lang=".LANGUAGE_ID,
										"icon" => "ram-highloadblock-edit-icon",
									),
									Array
									(
										"text" => Loc::getMessage("RAM_HLBLOCK_MENU_DELETE"),
										"icon" => "ram-highloadblock-delete-icon",
										"url" => "javascript:if(confirm('".Loc::getMessage("RAM_HLBLOCK_MENU_DELETE_CONFIRM")."')) document.location=\"highloadblock_entity_edit.php?action=delete&ID=".$hlBlock["ID"]."&".bitrix_sessid_get()."\";",
									),
								),
							);
							
							break;
						}
					}
				}
				
				foreach ($aModuleMenu[$m]["items"] as $k => $item)
				{
					if ($item["items_id"] !== "highloadblock_tools")
					{
						// 
					}
					else
					{
						$newMenu[] = $item;
					}
				}
				
				$aModuleMenu[$m]["items"] = $newMenu;
				
				$aModuleMenu[$m]["url"] = "ram.highloadblock_index.php";
				
				$aModuleMenu[$m]["more_url"][] = "ram.highloadblock_group_edit.php";
				
				break;
			}
		}
		
		$APPLICATION->SetAdditionalCSS("/bitrix/panel/ram.highloadblock/menu.css");
	}
	
	public static function OnAdminTabControlBegin(&$form)
	{
		if (Bitrix\Main\Application::getInstance()->getContext()->getRequest()->getRequestedPage() === "/bitrix/admin/highloadblock_entity_edit.php")
		{
			$ID = intval($_REQUEST["ID"]);
			
			$groupsList = Ram\Highloadblock\GroupTable::getList(Array("order" => Array("SORT" => "ASC")))->fetchAll();
			
			$entity = Ram\Highloadblock\EntityTable::getList(Array("filter" => Array("ELEMENT_ID" => $ID)))->fetch();
			
			if (empty($entity))
			{
				$entity = Array
				(
					"GROUP_ID" => isset($_REQUEST["RAM_HIGHLOADBLOCK"]["GROUP"]) ? $_REQUEST["RAM_HIGHLOADBLOCK"]["GROUP"] : 0,
					"SORT" => isset($_REQUEST["RAM_HIGHLOADBLOCK"]["SORT"]) ? $_REQUEST["RAM_HIGHLOADBLOCK"]["SORT"] : 500
				);
			}
			
			$tabContent = "<tr><td width='40%' class='adm-detail-content-cell-l'>".Loc::getMessage("RAM_HLBLOCK_TAB_GROUP")."</td><td class='adm-detail-content-cell-r'><select name='RAM_HIGHLOADBLOCK[GROUP]'><option value='0'>".Loc::getMessage("RAM_HLBLOCK_TAB_GROUP_TOP")."</option>";
			
			foreach ($groupsList as $groupItem)
			{
				$group = CRamHighloadblock::GetGroup($groupItem["ID"]);
				
				$selected = $group["ID"] == $entity["GROUP_ID"] ? "selected" : "";
				
				$tabContent .= "<option ".$selected." value='".$group["ID"]."'>[".$group["ID"]."] ".$group["NAME"]."</option>";
			}
			
			$tabContent .= "</select></td></tr><tr><td width='40%' class='adm-detail-content-cell-l'>".Loc::getMessage("RAM_HLBLOCK_TAB_SORT")."</td><td class='adm-detail-content-cell-r'><input type='text' name='RAM_HIGHLOADBLOCK[SORT]' value='".$entity['SORT']."' size='7' maxlength='10'/></td></tr>";
			
			$form->tabs[] = Array
			(
				"DIV" => "ram_highloadblock",
				"TAB" => Loc::getMessage("RAM_HLBLOCK_TAB"),
				"TITLE" => Loc::getMessage("RAM_HLBLOCK_TAB_TITLE"),
				"CONTENT"=> $tabContent
			);
		}
	}
	
	public static function OnProlog()
	{
		if (Bitrix\Main\Application::getInstance()->getContext()->getRequest()->getRequestedPage() === "/bitrix/admin/highloadblock_entity_edit.php")
		{
			if (isset($_REQUEST["ID"]) && (isset($_REQUEST["save"]) || isset($_REQUEST["apply"])))
			{
				CRamHighloadblock::DeleteHLBlockLangs(intval($_REQUEST["ID"]));
			}
			else if (isset($_REQUEST["ID"]) && isset($_REQUEST["action"]) && $_REQUEST["action"] === "delete")
			{
				CRamHighloadblock::DeleteHLBlockLangs(intval($_REQUEST["ID"]));
			}
		}
	}
	
	public static function OnEpilog()
	{
		if (Bitrix\Main\Application::getInstance()->getContext()->getRequest()->getRequestedPage() === "/bitrix/admin/highloadblock_index.php")
		{
			if (substr_count($_SERVER["HTTP_REFERER"], "highloadblock_entity_edit.php"))
			{
				$url = parse_url($_SERVER["HTTP_REFERER"]);
				
				parse_str($url["query"], $query);
				
				if (isset($query["RAM_HIGHLOADBLOCK"]) && isset($query["RAM_HIGHLOADBLOCK"]["GROUP"]))
				{
					\LocalRedirect("ram.highloadblock_group.php?ID=".$query["RAM_HIGHLOADBLOCK"]["GROUP"]."&lang=".LANGUAGE_ID);
				}
				else if (isset($query["ID"]) && !isset($query["action"]))
				{
					\LocalRedirect("highloadblock_rows_list.php?ENTITY_ID=".$query["ID"]."&lang=".LANGUAGE_ID);
				}
				else
				{
					\LocalRedirect("ram.highloadblock_index.php?lang=".LANGUAGE_ID);
				}
			}
			else
			{
				\LocalRedirect("ram.highloadblock_index.php?lang=".LANGUAGE_ID);
			}
		}
		else if (Bitrix\Main\Application::getInstance()->getContext()->getRequest()->getRequestedPage() === "/bitrix/admin/userfield_admin.php")
		{
			if (substr_count($_SERVER["HTTP_REFERER"], "userfield_edit.php") && !isset($_REQUEST["find"]))
			{
				$url = parse_url($_SERVER["HTTP_REFERER"]);
				
				parse_str($url["query"], $query);
				
				if (isset($query["ID"]))
				{
					$userField = Bitrix\Main\UserFieldTable::getList(Array("filter" => Array("ID" => $query["ID"])))->fetch();
					
					if (substr_count($userField["ENTITY_ID"], "HLBLOCK_"))
					{
						$hlblock = str_replace("HLBLOCK_", "", $userField["ENTITY_ID"]);
						
						\LocalRedirect("userfield_admin.php?lang=".LANGUAGE_ID."&set_filter=Y&find=HLBLOCK_".$hlblock."&find_type=ENTITY_ID");
					}
				}
			}
		}
		else if (Bitrix\Main\Application::getInstance()->getContext()->getRequest()->getRequestedPage() === "/bitrix/admin/highloadblock_entity_edit.php" && isset($_REQUEST["ID"]) && (isset($_REQUEST["save"]) || isset($_REQUEST["apply"]) || isset($_REQUEST["action"])))
		{
			CRamHighloadblock::RestoreHLBlockLangs(intval($_REQUEST["ID"]));
		}
	}
	
	public static function OnAfterHLBlockAdd($ID)
	{
		try
		{
			CRamHighloadblock::UpdateEntity($ID, $_REQUEST["RAM_HIGHLOADBLOCK"]);
		}
		catch (Bitrix\Main\SystemException $e)
		{
			//
		}
	}
	
	public static function OnAfterHLBlockUpdate($arFields)
	{
		try
		{
			CRamHighloadblock::UpdateEntity($arFields["ID"], $_REQUEST["RAM_HIGHLOADBLOCK"]);
		}
		catch (Bitrix\Main\SystemException $e)
		{
			//
		}
	}
	
	public static function OnAfterHLBlockDelete($arFields)
	{
		try
		{
			CRamHighloadblock::DeleteEntity($arFields["ID"]);
		}
		catch (Bitrix\Main\SystemException $e)
		{
			//
		}
	}
	
	public static function RestoreHLBlockLangs($ID)
	{
		\Bitrix\Main\Loader::includeModule("highloadblock");
		
		foreach (CRamHighloadblock::$cache["LANGS"] as $lang)
		{
			Bitrix\Highloadblock\HighloadBlockLangTable::add(Array("ID" => $ID, "LID" => $lang["LID"], "NAME" => $lang["NAME"]));
		}
	}
	
	public static function DeleteHLBlockLangs($ID)
	{
		\Bitrix\Main\Loader::includeModule("highloadblock");
		
		$langs = Bitrix\Highloadblock\HighloadBlockLangTable::getList(Array("filter" => Array("ID" => $ID)))->fetchAll();
		
		CRamHighloadblock::$cache["LANGS"] = $langs;
		
		foreach ($langs as $lang)
		{
			Bitrix\Highloadblock\HighloadBlockLangTable::delete(Array("ID" => $lang["ID"], "LID" => $lang["LID"]));
		}
	}
	
	public static function DeleteEntity($ID)
	{
		$entity = Ram\Highloadblock\EntityTable::getList(Array("filter" => Array("ELEMENT_ID" => $ID)))->fetch();
		
		if ($entity)
		{
			Ram\Highloadblock\EntityTable::delete($entity["ID"]);
		}
	}
	
	public static function UpdateEntity($ID, $DATA)
	{
		$entity = Ram\Highloadblock\EntityTable::getList(Array("filter" => Array("ELEMENT_ID" => $ID)))->fetch();
		$groupId = isset($DATA["GROUP"]) ? intval($DATA["GROUP"]) : 0;
		$sort = isset($DATA["SORT"]) ? intval($DATA["SORT"]) : 500;
		
		if ($entity)
		{
			$result = Ram\Highloadblock\EntityTable::update
			(
				$entity["ID"],
				Array
				(
					"GROUP_ID" => $groupId,
					"SORT" => $sort
				)
			);
		}
		else
		{
			$result = Ram\Highloadblock\EntityTable::add
			(
				Array
				(
					"ELEMENT_ID" => $ID,
					"GROUP_ID" => $groupId,
					"SORT" => $sort
				)
			);
		}
	}
}
?>
