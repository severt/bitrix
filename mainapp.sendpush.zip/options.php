<?php
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;

$module_id = 'mainapp.sendpush';
Loc::loadMessages(__FILE__);
global $APPLICATION;
if ($APPLICATION->GetGroupRight($module_id) < 'S') {
    $APPLICATION->AuthForm(Loc::getMessage("ACCESS_DENIED"));
}

require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/' . $module_id . '/include.php');

Loader::includeModule('iblock');
Loader::includeModule('sale');

if (!empty(COption::GetOptionString($module_id, "TARIF_LOGIN")) && !empty(COption::GetOptionString($module_id, "TARIF_TOKEN"))) {
    $login = COption::GetOptionString($module_id, "TARIF_LOGIN");
    $token = COption::GetOptionString($module_id, "TARIF_TOKEN");

    $tarif_info = MainappBilling::GetTarifData($login, $token);
    #$statistics_info = MainappBilling::GetStatistics($login, $token);
}

// ��������� ������ ���������� ��� ���������� �������
$iblocks = GetOptions::getIblockListNewOptions();

if (CModule::IncludeModule("sale")) {
// ��������� �������� �������
    $statusList = [];
    $statusResult = \Bitrix\Sale\Internals\StatusLangTable::getList(array(
        'order' => array('STATUS.SORT' => 'ASC'),
        'filter' => array('STATUS.TYPE' => 'O', 'LID' => LANGUAGE_ID),
        'select' => array('STATUS_ID', 'NAME', 'DESCRIPTION'),
    ));
    while ($arStatus = $statusResult->fetch()) {
        $statusList[$arStatus['STATUS_ID']] = $arStatus['NAME'] . " (" . $arStatus['STATUS_ID'] . ")";
    }
}

// ����� ��� �������
$aTabs = [
    [
        'DIV' => 'general_settings',
        'TAB' => Loc::getMessage('GENERAL_SETTINGS'),
        'TITLE' => Loc::getMessage('GENERAL_SETTINGS_TITLE'),
        'OPTIONS' => [
            ['PUSH_IBLOCK_ID', Loc::getMessage('PUSH_IBLOCK_ID'), '', ['selectbox', $iblocks]],
            ['PUSH_HISTORY_IBLOCK_ID', Loc::getMessage('PUSH_HISTORY_IBLOCK_ID'), '', ['selectbox', $iblocks]],
            ['FB_CONFIG_JSON_apiKey', 'apiKey', '', ['text', 35]],
            ['FB_CONFIG_JSON_authDomain', 'authDomain', '', ['text', 35]],
            ['FB_CONFIG_JSON_databaseURL', 'databaseURL', '', ['text', 35]],
            ['FB_CONFIG_JSON_projectId', 'projectId', '', ['text', 35]],
            ['FB_CONFIG_JSON_storageBucket', 'storageBucket', '', ['text', 35]],
            ['FB_CONFIG_JSON_messagingSenderId', 'messagingSenderId', '', ['text', 35]],
            ['FB_CONFIG_JSON_appId', 'appId', '', ['text', 35]],
            ['FB_CONFIG_JSON_measurementId', 'measurementId', '', ['text', 35]],
            ['FB_CONFIG_JSON_vapidKey', 'vapidKey', '', ['text', 35]],
            ['TARIF_LOGIN', Loc::getMessage('TARIF_LOGIN'), '', ['text', 35]],
            ['TARIF_TOKEN', Loc::getMessage('TARIF_TOKEN'), '', ['text', 35]],
            ['CREATE_JS_FILES', Loc::getMessage('CREATE_JS_FILES'), 'N', ['checkbox']],
            ['USE_NEW_API_V1', Loc::getMessage('USE_NEW_API_V1'), 'N', ['checkbox']],
            ['CIRILLIC_ENCODE', Loc::getMessage('CIRILLIC_ENCODE'), 'N', ['checkbox']]
        ]
    ],
    [
        'DIV' => 'forgotten_baskets',
        'TAB' => Loc::getMessage('FORGOTTEN_BASKETS'),
        'TITLE' => Loc::getMessage('FORGOTTEN_BASKETS_TITLE'),
        'OPTIONS' => [
            ['F_BASKET_ENABLE', Loc::getMessage('F_BASKET_ENABLE'), 'N', ['checkbox']],
            ['F_BASKET_IBLOCK_ID', Loc::getMessage('F_BASKET_IBLOCK_ID'), '', ['selectbox', $iblocks]],
            ['F_BASKET_INTERVAL_FROM', Loc::getMessage('F_BASKET_INTERVAL_FROM'), '1', ['text', 10]],
            ['F_BASKET_INTERVAL_TO', Loc::getMessage('F_BASKET_INTERVAL_TO'), '2', ['text', 10]],
            ['F_BASKET_PUSH_TITLE', Loc::getMessage('F_BASKET_PUSH_TITLE'), Loc::getMessage('F_BASKET_PUSH_TITLE_DEFAULT'), ['textarea', 6, 50]],
            ['F_BASKET_PUSH_BODY', Loc::getMessage('F_BASKET_PUSH_BODY'), Loc::getMessage('F_BASKET_PUSH_BODY_DEFAULT'), ['textarea', 6, 50]],
            ['F_BASKET_PUSH_LINK', Loc::getMessage('F_BASKET_PUSH_LINK'), 'https://'.$_SERVER['HTTP_HOST'].'/basket/?ya-metrica=f_basket', ['text', 50]],
            ['F_BASKET_USE_HISTORY', Loc::getMessage('F_BASKET_USE_HISTORY'), 'N', ['checkbox']],
        ]
    ],
    [
        'DIV' => 'orders',
        'TAB' => Loc::getMessage('ORDERS'),
        'TITLE' => Loc::getMessage('ORDERS_TITLE'),
        'OPTIONS' => [
            ['ORDER_STATUS_PUSH_ENABLE', Loc::getMessage('ORDER_STATUS_PUSH_ENABLE'), 'N', ['checkbox']],
            ['ORDER_STATUS_PUSH_TITLE', Loc::getMessage('ORDER_STATUS_PUSH_TITLE'), Loc::getMessage('ORDER_STATUS_PUSH_TITLE_DEFAULT'), ['textarea', 6, 50]],
            ['ORDER_STATUS_PUSH_BODY', Loc::getMessage('ORDER_STATUS_PUSH_BODY'), Loc::getMessage('ORDER_STATUS_PUSH_BODY_DEFAULT'), ['textarea', 6, 50]],
            ['ORDER_STATUS_PUSH_LINK', Loc::getMessage('ORDER_STATUS_PUSH_LINK'), 'https://'.$_SERVER['HTTP_HOST'].'/personal/order/#ORDER_ID#/?ya-metrica=order_status', ['text', 50]],
            ['ORDER_STATUS_PUSH_USE_HISTORY', Loc::getMessage('ORDER_STATUS_PUSH_USE_HISTORY'), 'N', ['checkbox']],
        ]
    ],
    [
        'DIV' => 'other',
        'TAB' => Loc::getMessage('OTHER_EVENTS'),
        'TITLE' => Loc::getMessage('OTHER_EVENTS'),
        'OPTIONS' => [
            ['PRODUCT_SUBSCRIBE_NOTIFY_PUSH_ENABLE', Loc::getMessage('PRODUCT_SUBSCRIBE_NOTIFY_PUSH_ENABLE'), 'N', ['checkbox']],
        ]
    ],
    [
        'DIV' => 'access_rights',
        'TAB' => Loc::getMessage('ACCESS_RIGHTS'),
        'TITLE' => Loc::getMessage('ACCESS_RIGHTS_TITLE'),
        'OPTIONS' => []
    ]
];
// ����������� �����
$tabControl = new CAdminTabControl('tabControl', $aTabs);
// ��������� ����������
if ($_SERVER['REQUEST_METHOD'] === 'POST' && strlen($_REQUEST['save']) > 0 && check_bitrix_sessid()) {
    #echo "<pre>" . print_r($_POST, true) . "</pre>";
    foreach ($aTabs as $aTab) {
        foreach ($aTab['OPTIONS'] as $arOption) {
            __AdmSettingsSaveOption($module_id, $arOption);
        }
    }
    // ���������� ���� �������
    if (isset($_POST['RIGHTS']) && is_array($_POST['RIGHTS'])) {
        foreach ($_POST['RIGHTS'] as $groupKey => $permission) {
            CGroup::SetModulePermission($_POST['GROUPS'][$groupKey], $module_id, $permission);
        }
    }
    // ���������� ��������� �������� �������
    if (isset($_POST['selected_order_statuses']) && is_array($_POST['selected_order_statuses'])) {
        COption::SetOptionString($module_id, 'selected_order_statuses', serialize($_POST['selected_order_statuses']));
    } else {
        COption::SetOptionString($module_id, 'selected_order_statuses', serialize([])); // ��������� ������ ������, ���� ������ �� �������
    }
}



?>
<style>
    .tarif {
        margin: 0 auto;
        width: 100%;
        text-align: center;
        margin-bottom: 20px;
    }
    #bx-admin-prefix .adm-detail-content-item-block table {
        width: auto;
    }
</style>
<form method="post" action="<?php echo $APPLICATION->GetCurPage()?>?mid=<?=$module_id?>&amp;lang=<?=LANGUAGE_ID?>">
<?php
$tabControl->Begin();
#echo "<pre>" . print_r($aTabs, true) . "</pre>";
foreach ($aTabs as $aTab) {
    $tabControl->BeginNextTab();
    if ($aTab['DIV'] == 'general_settings') {
        ?>
        <div class="tarif">
            <h2><?=Loc::getMessage('TARIF_INFO');?></h2>
            <?= $tarif_info;?>
        </div>
        <?php
    }
    elseif ($aTab['DIV'] == 'access_rights') {
        require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/admin/group_rights.php");
    }
    __AdmSettingsDrawList($module_id, $aTab['OPTIONS']);
    if ($aTab['DIV'] == 'orders') {
        if (CModule::IncludeModule("sale")) {
            echo '<br><tr><td colspan="2"><label><h3>' . Loc::getMessage('ORDER_STATUS_LIST') . '</h3></label></td></tr>';
            //COption::GetOptionString("mainapp.sendpush", "selected_order_statuses")
            if (!empty(COption::GetOptionString($module_id, 'selected_order_statuses', ''))) {
                $selectedStatuses = unserialize(COption::GetOptionString($module_id, 'selected_order_statuses', ''));
            }
            foreach ($statusList as $statusId => $statusName) {
                if (!empty($selectedStatuses)) {
                    $isChecked = in_array($statusId, $selectedStatuses) ? ' checked="checked"' : '';
                }
                echo '<tr><td><label><input type="checkbox" name="selected_order_statuses[]" value="' . htmlspecialchars($statusId) . '"' . $isChecked . '> ' . htmlspecialchars($statusName) . '</label></td></tr>';
            }
        }
    }
    if ($aTab['DIV'] == 'forgotten_baskets') {
        // ��������� ��������� ������
        if (CModule::IncludeModule("sale")) {
            $agentStatus = GetOptions::checkAgentStatus();

            switch ($agentStatus['status']) {
                case 'not_created':
                    echo '<p style="text-align: center"><button id="create-agent">' . Loc::getMessage('MN_CREATE_AGENT') . '</button></p>';
                    break;

                case 'inactive':
                    echo '<p style="text-align: center"><button id="activate-agent" data-agent-id="' . $agentStatus['agent_id'] . '">' . Loc::getMessage('MN_AGENT_ACTIVE') . '</button></p>';
                    break;

                case 'active':
                    echo '<p style="text-align: center"><span style="color:green">' . Loc::getMessage('MN_AGENT_ALIVE') . '</span></p>';
                    break;
            }
        }
    }
}

$tabControl->Buttons();
?>
    <input type="submit" name="save" value="<?= Loc::getMessage('SAVE') ?>" class="adm-btn-save" />
    <input type="reset" name="reset" value="<?= Loc::getMessage('RESET') ?>" />
    <?= bitrix_sessid_post(); ?>
    <?php
    $tabControl->End();
    ?>
</form>

<?php
###���������� Js �����
if (COption::GetOptionString($module_id, "CREATE_JS_FILES") == "Y") {
    include $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/mainapp.sendpush/tools/firebase_subscribe-creator.php';
    include $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/mainapp.sendpush/tools/firebase-messaging-sw-creator.php';
}
/*
###���������� ��������
include $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/mainapp.sendpush/tools/iblock_updater.php';
*/
?>
<script>
    document.getElementById('create-agent')?.addEventListener('click', function() {
        // AJAX ������ ��� �������� ������
        BX.ajax({
            url: '/bitrix/tools/mainapp.sendpush/ajax_agent_handler.php',
            method: 'POST',
            data: {
                action: 'create_agent'
            },
            success: function(response) {
                alert('����� ������ �������.');
                location.reload();
            },
            error: function() {
                alert('������ ��� �������� ������.');
            }
        });
    });

    document.getElementById('activate-agent')?.addEventListener('click', function() {
        const agentId = this.getAttribute('data-agent-id');
        // AJAX ������ ��� ��������� ������
        BX.ajax({
            url: '/bitrix/tools/mainapp.sendpush/ajax_agent_handler.php',
            method: 'POST',
            data: {
                action: 'activate_agent',
                agent_id: agentId
            },
            success: function(response) {
                alert('����� ����������� �������.');
                location.reload();
            },
            error: function() {
                alert('������ ��� ��������� ������.');
            }
        });
    });
</script>
