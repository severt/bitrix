<?
$MESS['FB_COMPONENT_DESCRIPTION'] = 'Подключает скрипты Firebase.';
$MESS['FB_COMPONENT_NAME'] = 'Мои компоненты';
