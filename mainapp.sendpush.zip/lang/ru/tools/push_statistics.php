<?
$MESS['MN_PUSH_STATISTICS'] = 'Статистика отправки PUSH уведомлений';
$MESS['MN_CURRENT_PERIOD'] = '<span style="color: green;">Текущий период</span>';
$MESS['MN_PERIOD'] = 'Период';
$MESS['MN_MANUALLY_SENT'] = 'Отправлено в ручную';
$MESS['MN_FORGOTTEN_CARTS'] = 'Забытые корзины';
$MESS['MN_ORDER_STATUSES'] = 'Статусы заказов';
$MESS['MN_SUMMARY'] = 'Итого';
$MESS['MN_TARIF'] = 'Тариф';
$MESS['MN_STATISTICS_COMING_SOON'] = 'Статистика появится после первого отправленного уведомления';
$MESS['MN_THIS_PERIOD'] = 'Текущий период';
$MESS['MN_DATE'] = 'Дата';
$MESS['MN_FILTER_DATE'] = 'Дата';
$MESS['MN_NO_DATA'] = 'Не найдено данных за выбранный период';
$MESS['MN_PERIOD_SENT_SUM'] = 'Всего за выбранный период отправлено';
