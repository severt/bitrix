<?php
$MESS["SETTINGS"] = "Настройки";
$MESS["MAIN_SETTINGS"] = 'Настройки отправки PUSH уведомлений';
$MESS["PUSH_KEY_TITLE"] = "Токен для отправки PUSH-сообщений";
$MESS['PUSH_IBLOCK_ID_TITLE'] = 'Инфоблок для хранения PUSH ключей';
$MESS['PUSH_HISTORY_IBLOCK_ID_TITLE'] = 'Инфоблок для хранения истории PUSH сообщений';
$MESS['TABLE_CONTENT_GROUP'] = 'Список настроек';
$MESS['TABLE_CONTENT_MENU_8'] = 'Отправить PUSH сообщение';
$MESS['TARIF_SETTINGS_GROUP'] = 'Ваш тариф';
$MESS['TARIF_LOGIN_TITLE'] = 'Ваш логин в сервисе';
$MESS['TARIF_TOKEN_TITLE'] = 'Ваш токен в сервисе';
$MESS['TARIF_INFO_TITLE'] = 'Ваш тариф:';
$MESS['CREATE_JS_FILES_TITLE'] = 'Создать файлы для web push в корне сайта?';
$MESS['CREATE_JS_FILES_NOTES'] = 'Внимание! В корне сайта будут созданы файлы firebase-messaging-sw.js и firebase_subscribe.js,<br>необходимые для подключения сервиса Web Push. Если у вас эти файлы уже существуют - они будут перезаписаны.';
$MESS['FB_SENDER_ID_TITLE'] = 'ID отправителя';
$MESS['FB_SENDER_ID_NOTES'] = 'Этот ID Вы можете получить у наших менеджеров<br>Для тестового режима используйте ID: 378874854881';
$MESS['CIRILLIC_ENCODE_TITLE'] = 'Сайт в кириллической кодировке?';
$MESS['CIRILLIC_ENCODE_NOTES'] = 'Внимание! Уставите этот чекбокс только в случает, если сайт работает на кириллице.';
$MESS['MN_FORGOTTEN_BASKET'] = 'Забытые корзины';
$MESS['F_BASKET_IBLOCK_ID_TITLE'] = 'Инфоблок забытых корзин';
$MESS['F_BASKET_INTERVAL_FROM_TITLE'] = 'Возраст корзины в днях: от';
$MESS['F_BASKET_INTERVAL_FROM_NOTES'] = 'Началом отсчета возраста явзяется последнее добавление товара в корзину';
$MESS['F_BASKET_INTERVAL_TO_TITLE'] = 'Возраст корзины в днях: до';
$MESS['F_BASKET_INTERVAL_TO_NOTES'] = 'Началом отсчета возраста явзяется последнее добавление товара в корзину';
$MESS['F_BASKET_PUSH_TITLE_TITLE'] = 'Заголовок сообщения о забытой корзине';
$MESS['F_BASKET_PUSH_TITLE_DEFAULT'] = 'Ваши товары отложены и ждут вас';
$MESS['F_BASKET_PUSH_TITLE_NOTES'] = 'Старайтесь не использовать длинные заголовки (20-30 символов будет достаточно)';
$MESS['F_BASKET_PUSH_BODY_TITLE'] = 'Тело сообщения о забытой корзине';
$MESS['F_BASKET_PUSH_BODY_DEFAULT'] = 'Вы положили несколько товаров в корзину, но так и не оформили заказ.
На всякий случай мы отложили выбранные товары, чтобы, когда вы решите завершить покупку, вам не пришлось ждать.';
$MESS['F_BASKET_PUSH_BODY_NOTES'] = 'Старайтесь не использовать длинные сообщения (100-150 символов будет достаточно)';
$MESS['F_BASKET_PUSH_LINK_TITLE'] = 'Ссылка на корзину на сайте';
$MESS['F_BASKET_ENABLE_TITLE'] = 'Отправлять уведомления о забытых корзинах';
$MESS['MN_ORDER_STATUS_TAB'] = 'Заказы';
$MESS['MN_ORDER_STATUS_TITLE'] = 'Уведомления о смене статуса заказа';
$MESS['ORDER_STATUS_PUSH_ENABLE_TITLE'] = 'Отправлять уведомления о смене статуса заказа';
$MESS['ORDER_STATUS_PUSH_TITLE_TITLE'] = 'Заголовок сообщения о смене статуса заказа';
$MESS['ORDER_STATUS_PUSH_TITLE_DEFAULT'] = 'Статус заказа №#ORDER_ID# изменен';
$MESS['ORDER_STATUS_PUSH_BODY_BODY'] = 'Тело сообщения о смене статуса заказа';
$MESS['ORDER_STATUS_PUSH_BODY_DEFAULT'] = 'Новый статус: #ORDER_STATUS#. #ORDER_STATUS_DESCRIPTION#';
$MESS['ORDER_STATUS_PUSH_LINK_TITLE'] = 'Ссылка на детальную страницу заказа на сайте';
$MESS['ORDER_STATUS_PUSH_LINK_NOTES'] = 'В ссылке вместо id заказа подставьте #ORDER_ID#';
$MESS['ORDER_STATUS_PUSH_BODY_NOTES'] = '#ORDER_STATUS# - название статуса<br>#ORDER_STATUS_DESCRIPTION# - описание статуса';
$MESS['USE_NEW_API_V1_TITLE'] = 'Использовать новый API';
$MESS['GENERAL_SETTINGS'] = 'Общие настройки';
$MESS['GENERAL_SETTINGS_TITLE'] = 'Настройки общего характера';
$MESS['PUSH_IBLOCK_ID'] = 'Инфоблок для хранения PUSH ключей';
$MESS['PUSH_HISTORY_IBLOCK_ID'] = 'Инфоблок для хранения истории PUSH сообщений';
$MESS['CREATE_JS_FILES'] = 'Включить возможность отправлять push в браузер?';
$MESS['FB_SENDER_ID'] = 'ID отправителя';
$MESS['FB_CONFIG_JSON'] = 'json конфига firebase для web push';
$MESS['USE_NEW_API_V1'] = 'Использовать новый API';
$MESS['TARIF_LOGIN'] = 'Ваш логин в сервисе';
$MESS['TARIF_TOKEN'] = 'Ваш токен в сервисе';
$MESS['CIRILLIC_ENCODE'] = 'Сайт в кириллической кодировке?';
$MESS['TARIF_INFO'] = 'Ваш тариф';

$MESS['FORGOTTEN_BASKETS'] = 'Забытые корзины';
$MESS['FORGOTTEN_BASKETS_TITLE'] = 'Настройки уведомлений о забытых корзинах';
$MESS['F_BASKET_ENABLE'] = 'Отправлять уведомления о забытых корзинах';
$MESS['F_BASKET_IBLOCK_ID'] = 'Инфоблок забытых корзин';
$MESS['F_BASKET_INTERVAL_FROM'] = 'Возраст корзины в днях: от';
$MESS['F_BASKET_INTERVAL_TO'] = 'Возраст корзины в днях: до';
$MESS['F_BASKET_PUSH_TITLE'] = 'Заголовок сообщения о забытой корзине';
$MESS['F_BASKET_PUSH_BODY'] = 'Тело сообщения о забытой корзине';
$MESS['F_BASKET_PUSH_LINK'] = 'Ссылка на корзину на сайте
<br>Можно в конце ссылки указать якорь для Яндекс метрики
<br>Пример: ?ya-metrika=f_basket';

$MESS['ORDERS'] = 'Заказы';
$MESS['ORDERS_TITLE'] = 'Настройки уведомлений о заказах';
$MESS['ORDER_STATUS_PUSH_ENABLE'] = 'Отправлять уведомления о смене статуса заказа';
$MESS['ORDER_STATUS_PUSH_TITLE'] = 'Заголовок сообщения о смене статуса заказа';
$MESS['ORDER_STATUS_PUSH_BODY'] = 'Тело сообщения о смене статуса заказа';
$MESS['ORDER_STATUS_PUSH_LINK'] = 'Ссылка на детальную страницу заказа на сайте
<br>Можно в конце ссылки указать якорь для Яндекс метрики
<br>Пример: ?ya-metrika=order_status';

$MESS['ACCESS_RIGHTS'] = 'Права доступа';
$MESS['ACCESS_RIGHTS_TITLE'] = 'Настройки прав доступа';

$MESS['SAVE'] = 'Сохранить';
$MESS['RESET'] = 'Сбросить';
$MESS['ORDER_STATUS_LIST'] = 'Для каких статусов отправлять уведомление?';
$MESS['F_BASKET_USE_HISTORY'] = 'Использовать историю отправленных сообщений';
$MESS['ORDER_STATUS_PUSH_USE_HISTORY'] = 'Использовать историю отправленных сообщений';
$MESS['MN_AGENT_ALIVE'] = 'Агент активен.';
$MESS['MN_CREATE_AGENT'] = 'Создать агента';
$MESS['MN_AGENT_ACTIVE'] = 'Активировать агента';
$MESS['OTHER_EVENTS'] = 'Дополнительные уведомления';
$MESS['PRODUCT_SUBSCRIBE_NOTIFY_PUSH_ENABLE'] = 'Включить уведомление о поступлении товара';
$MESS['ORDER_STATUS_PUSH_TITLE_DEFAULT'] = 'Статус заказа №#ORDER_ID# изменен';
$MESS['ORDER_STATUS_PUSH_BODY_DEFAULT'] = 'Новый статус: #ORDER_STATUS#. #ORDER_STATUS_DESCRIPTION#';
$MESS['F_BASKET_PUSH_TITLE_DEFAULT'] = 'Ваши товары ждут вас!';
$MESS['F_BASKET_PUSH_BODY_DEFAULT'] = 'Вы положили несколько товаров в корзину, но так и не оформили заказ.
На всякий случай мы отложили выбранные товары, чтобы, когда вы решите завершить покупку, вам не пришлось ждать.';
?>