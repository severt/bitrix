<?
$MESS['TARIF_NAME'] = 'Тариф: ';
$MESS['TARIF_EXPIRE'] = 'Истекает: ';
$MESS['TARIF_MESS_COUNT'] = 'Использовано сообщений: ';
