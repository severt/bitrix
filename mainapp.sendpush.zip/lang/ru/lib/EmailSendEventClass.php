<?
$MESS['PUSH_TITLE'] = 'Товар появился в продаже';
$MESS['PUSH_BODY_1'] = 'Товар ';
$MESS['PUSH_BODY_2'] = ' снова доступен к покупке!';
