<?
$MESS["API_MAINAPP_PRAVA_DOSTUPA"] = "Права доступа";
$MESS["API_MAINAPP_NASTROYKA_PRAV_DOSTU"] = "Настройка прав доступа";
$MESS["API_MAINAPP_VYBOR_CVETA"] = "Выбор цвета";
$MESS["API_MAINAPP_SOHRANITQ"] = "Сохранить\" />
					<input type=\"reset\" name=\"reset\" value=\"Отменить\" />
					";
$MESS["MAINAPP_API_SOHRANITQ"] = "Сохранить\" />
                    <input type=\"reset\" name=\"reset\" value=\"Отменить\" />
                    ";
?>