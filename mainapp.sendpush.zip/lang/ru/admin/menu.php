<?php
$MESS["MAINAPP_SENDPUSH_MENU_TEXT"] = "Модуль расширенной отправки push уведомлений";
$MESS["MAINAPP_SENDPUSH_MENU_TITLE"] = "Модуль расширенной отправки push уведомлений";
$MESS["MAINAPP_SENDPUSH_MENU_ITEM_TEXT"] = "Отправка PUSH сообщений";
$MESS["MAINAPP_SENDPUSH_MENU_ITEM_TITLE"] = "PUSH сообщения";
$MESS['MAINAPP_SENDPUSH_MENU_SETTINGS_ITEM_TITLE'] = 'Настройки модуля';
$MESS['MAINAPP_SENDPUSH_MENU_STATISTICS_TEXT'] = 'Статистика';