<?php
const MODULE_ID = 'mainapp.sendpush';

class SendTokensFilter
{
    public function __construct($filterData)
    {
        $this->checkFilterData($filterData);
    }

    public function checkFilterData($filterData) {
        $site = array();
        $os = array();
        $gender = array();
        $user_group = array();
        $currentUser = "";
        $orderFilter = array();
        $profileFilter = array();
        $siteFilter = array();
        $orders_count = "";

        #echo "<pre>" . print_r($filterData, true) . "</pre>";

        if (!empty($filterData['filter']['site'])) {
            $site = $filterData['filter']['site'];
        }
        if (!empty($filterData['filter']['profile']['os'])) {
            $os = $filterData['filter']['profile']['os'];
        }
        if (!empty($filterData['filter']['profile']['gender'])) {
            $gender = $filterData['filter']['profile']['gender'];
        }
        if (!empty($filterData['filter']['profile']['user-group'])) {
            $user_group = $filterData['filter']['profile']['user-group'];
        }
        if (!empty($filterData['filter']['profile']['search-user'])) {
            $currentUser = $filterData['filter']['profile']['search-user'];
        }

        if (!empty($filterData['filter']['order']['orders_count'])) {
            $orders_count = $filterData['filter']['order']['orders_count'];
        }
        if (!empty($filterData['filter']['order']['order_sum'])) {
            $orders_sum_min = $filterData['filter']['order']['order_sum']['orders_sum_min'];
        }
        if (!empty($filterData['filter']['order']['order_sum'])) {
            $orders_sum_max = $filterData['filter']['order']['order_sum']['orders_sum_max'];
        }
        if (!empty($filterData['filter']['order']['orders_time_interval'])) {
            $orders_time_interval = $filterData['filter']['order']['orders_time_interval'];
        }
        if (!empty($filterData['filter']['order']['orders_product'])) {
            $orders_product = $filterData['filter']['order']['orders_product'];
            $orders_product_id = $this->getProductId($orders_product);
        }
        $userIds = $this->selectUserIdsByFilter($orders_count, $orders_sum_min, $orders_sum_max, $orders_time_interval, $orders_product_id);
        #echo "<pre>" . print_r($userIds, true) . "</pre>";

        $arTokens = $this->getUserTokensByArray($userIds, $site, $os, $gender, $user_group, $currentUser);

        return $arTokens;

    }

    public function selectUserIdsByFilter($orders_count, $orders_sum_min, $orders_sum_max, $orders_time_interval, $orders_product_id) {
        $orders_time_interval_arr = explode(" - ", $orders_time_interval);
        $orders_time_interval_min = $orders_time_interval_arr[0];
        $orders_time_interval_max = $orders_time_interval_arr[1];
        if (empty($orders_time_interval_max)) {
            $orders_time_interval_max = new \Bitrix\Main\Type\Date($orders_time_interval_min);
            $orders_time_interval_max->add('1D');
        }
        if (!empty($orders_time_interval_min) && !empty($orders_time_interval_max)) {
            $parameters['filter'] = array(
                ">=DATE_INSERT" => $orders_time_interval_min,
                "<=DATE_INSERT" => $orders_time_interval_max
            );
        }
        $parameters['order'] = array("DATE_INSERT" => "ASC");

        if (CModule::IncludeModule("sale")) {
            $arOrders = array();
            $dbRes = \Bitrix\Sale\Order::getList($parameters);
            while ($order = $dbRes->fetch()) {
                if (!empty($orders_product_id)) {
                    $res = CSaleBasket::GetList(array(), array("ORDER_ID" => $order["ID"]));
                    while ($arItem = $res->Fetch()) {
                        if ($arItem['PRODUCT_ID'] == $orders_product_id) {
                            $arOrders[$order["ID"]] = array(
                                "ID" => $order["ID"],
                                "USER_ID" => $order["USER_ID"],
                                "PRICE" => $order["PRICE"]
                            );
                        }
                    }
                } else {
                    $arOrders[$order["USER_ID"]][$order["ID"]] = $order["PRICE"];
                }
            }
        }
        $userIds = array();
        foreach ($arOrders as $userId => $arOrder) {
            $count = count($arOrder);
            $sum = array_sum($arOrder);
            if ($orders_count == $count) {
                $userIds[$userId] = $userId;
            }
            else {
                continue;
            }
            if ($orders_sum_min <= $sum && $sum <= $orders_sum_max) {
                $userIds[$userId] = $userId;
            }

        }

        #echo "<pre>" . print_r($arOrders, true) . "</pre>";
        #echo "<pre>" . print_r($arUsers, true) . "</pre>";

        return $userIds;
    }

    public function getUserTokensByArray($userIds, $site, $os, $gender, $user_group, $currentUser){
        $arSelect = array("ID", "IBLOCK_ID", "NAME", "PROPERTY_MN_TOKEN", "PROPERTY_MN_OS", "PROPERTY_MN_USER");
        $arFilter = array(
            "IBLOCK_ID" => COption::GetOptionString(MODULE_ID, "PUSH_IBLOCK_ID"),
            "PROPERTY_MN_OS" => $os,
            "PROPERTY_MN_SITE_ID" => $site
        );

        if (!empty($currentUser)) {
            $pushUserId = substr($currentUser, strpos($currentUser, 'ID: '));
            $pushUserId = str_replace("ID", "", $pushUserId);
            $pushUserId = str_replace(")", "", $pushUserId);
            $pushUserId = str_replace(" ", "", $pushUserId);
            $pushUserId = str_replace(":", "", $pushUserId);
            $arFilter["PROPERTY_MN_USER"] = $pushUserId;
        }
        $to = array();
        $res = CIBlockElement::GetList(array(), $arFilter, false, array(), $arSelect);
        while ($ob = $res->GetNextElement()) {
            $arFields = $ob->GetFields();
            #echo "<pre>" . print_r($arFields, true) . "</pre>";
            $resUG = CUser::GetUserGroupList($arFields["PROPERTY_MN_USER_VALUE"]);
            while ($arGroup = $resUG->Fetch()) {
                if (!empty($currentUser)) {
                    $to[] = $arFields["PROPERTY_MN_TOKEN_VALUE"];
                    break;
                }
                if (is_array($userIds) && in_array($arFields["PROPERTY_MN_USER_VALUE"], $userIds)) {
                    if (empty($user_group)) {
                        $to[] = $arFields["PROPERTY_MN_TOKEN_VALUE"];
                        break;
                    }
                }
                if (is_array($user_group) && in_array($arGroup["GROUP_ID"], $user_group)) {
                    $to[] = $arFields["PROPERTY_MN_TOKEN_VALUE"];
                    break;
                }
                if (empty($currentUser) && empty($userIds) && empty($user_group)) {
                    $to[] = $arFields["PROPERTY_MN_TOKEN_VALUE"];
                }

            }
        }

        return $to;
    }

    public function getProductId($orders_product) {
        $orders_product_id = substr($orders_product, strpos($orders_product, 'ID: '));
        $orders_product_id = str_replace("ID", "", $orders_product_id);
        $orders_product_id = str_replace(")", "", $orders_product_id);
        $orders_product_id = str_replace(" ", "", $orders_product_id);
        $orders_product_id = str_replace(":", "", $orders_product_id);

        return $orders_product_id;
    }
}