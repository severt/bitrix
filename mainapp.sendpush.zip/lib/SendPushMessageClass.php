<?php

const MODULE_ID = "mainapp.sendpush";

class MainappSendPushMessage
{
    public static function getPushKey() {
        $login = COption::GetOptionString(MODULE_ID, "TARIF_LOGIN");
        $token = COption::GetOptionString(MODULE_ID, "TARIF_TOKEN");
        $push_data = MainappBilling::GetTarifActuality($login, $token);
        if (!empty($push_data)) {
            return $push_data;
        }
        else {
            return false;
        }
    }

    public function buildAndSendPushDataFields($title, $body, $clickAction, $to) {
        $icon = COption::GetOptionString(MODULE_ID, "APP_ICON_1024");
        if (!empty($icon)) {
            $icon = MainappSendPushMessage::getDomainFromServer() . $icon;
        }
        $arr_file = Array(
            "name" => $_FILES['image']['name'],
            "size" => $_FILES['image']['size'],
            "tmp_name" => $_FILES['image']['tmp_name'],
            "type" => $_FILES['image']['type'],
            "old_file" => "",
            "del" => "Y",
            "MODULE_ID" => MODULE_ID
        );
        $fid = CFile::SaveFile($arr_file, "/".MODULE_ID."/", false, false, "native_push");
        $image = CFile::GetPath($fid);
        if (!empty($image)) {
            $image = MainappSendPushMessage::getDomainFromServer() . $image;
        }
        if (COption::GetOptionString(MODULE_ID, "USE_NEW_API_V1") == "Y") {
            $pushDataFields = MainappSendPushMessage::createPushDataFieldsV1($title, $body, $icon, $image, $clickAction, $to);
        }
        else {
            $pushDataFields = MainappSendPushMessage::createPushDataFieldsLegacy($title, $body, $icon, $image, $clickAction, $to);
        }


        if (COption::GetOptionString(MODULE_ID, "CIRILLIC_ENCODE") == "Y") {
            $pushDataFields = mb_convert_encoding($pushDataFields, 'utf-8', 'windows-1251');
        }

        if (!empty($pushDataFields)) {
            #echo "<pre>" . print_r(json_encode($pushDataFields, JSON_PRETTY_PRINT + JSON_UNESCAPED_UNICODE + JSON_UNESCAPED_SLASHES), true) . "</pre>";
            if (COption::GetOptionString(MODULE_ID, "USE_NEW_API_V1") == "Y") {
                #$result = MainappSendPushMessage::subscribeToTopic($pushDataFields);
                #echo "<pre>" . print_r($result, true) . "</pre>";
                $push_data = MainappSendPushMessage::getPushKey();
                $access_token = $push_data['ACCESS_TOKEN'];
                $url = $push_data['PUSH_SEND_URL'];

                $headers = [
                    'Authorization: Bearer ' . $access_token,
                    'Content-Type: application/json'
                ];
                if (is_array($pushDataFields["message"]["tokens"])) {
                    $arTokens = $pushDataFields["message"]["tokens"];
                    $currentTokenIndex = 0;
                    unset($pushDataFields["message"]["tokens"]);
                    foreach ($arTokens as $token) {
                        $currentTokenIndex++;
                        $result = MainappSendPushMessage::sendCurlV1ToToken($token, $url, $headers, $pushDataFields);
                    }

                }
                else {
                    $result = MainappSendPushMessage::sendCurlV1ToToken($pushDataFields["message"]["tokens"], $url, $headers, $pushDataFields);
                }

            }
            else {
                $result = MainappSendPushMessage::sendCurl($pushDataFields);
            }

            #echo "<pre>" . print_r($result, true) . "</pre>";
            return $result;
        }
    }

    private static function createPushDataFieldsLegacy ($title, $body, $icon, $image, $clickAction, $to) {
        $pushDataFields = array(
            "notification" => array(
                "title" => $title,
                "body" => $body,
                "icon" => $icon,
                'image' => $image
            ),
            "android" => array(
                "direct_boot_ok" => true,
            ),
            "apns" => array(
                "payload" => array(
                    "aps" => array(
                        "mutable-content" => 1
                    )
                ),
                "fcm_options" => array(
                    'image' => $image
                )
            ),
            "data" => array(
                "redirectUrl" => $clickAction,
                "url" => $clickAction
            ),
            "webpush" => array(
                "headers" => array(
                    'image' => $image
                )
            )
        );
        if ($to == '/topics/allDevices') {
            $pushDataFields["to"] = $to;
        }
        else {
            $pushDataFields["registration_ids"] = $to;
        }

        return $pushDataFields;
    }

    private static function createPushDataFieldsV1 ($title, $body, $icon, $image, $clickAction, $to) {
        $pushDataFields = [
            "message" => [
                "notification" => [
                    "title" => $title,
                    "body" => $body
                ],
                "android" => [
                    "notification" => [
                        "icon" => "icon_resource_name",
                    ]
                ],
                "apns" => [
                    "payload" => [
                        "aps" => [
                            "alert" => [
                                "title" => $title,
                                "body" => $body
                            ],
                            "badge" => 1
                        ]
                    ],
                    "fcm_options" => [
                        "image" => $image
                    ]
                ],
                "webpush" => [
                    "headers" => [
                        "TTL" => "4500"
                    ],
                    "notification" => [
                        "icon" => $icon,
                        "badge" => "badge_url",
                        "image" => $image
                    ]
                ],
                "fcm_options" => [
                    "analytics_label" => "campaign_name"
                ],
                "data" => [
                    "redirectUrl" => $clickAction
                ]
            ]
        ];
        if ($to == '/topics/allDevices') {
            $pushDataFields["message"]["topic"] = "allDevices";
        }
        else {
            $pushDataFields["message"]["tokens"] = $to;
        }

        return $pushDataFields;
    }

    private static function sendCurl($pushDataFields) {
        $headers = array();
        $headers[] = 'Content-Type: application/json';
        $headers[] = 'Authorization: key=' . MainappSendPushMessage::getPushKey();

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($pushDataFields));
        $result = curl_exec($ch);
        curl_close($ch);

        return $result;
    }

    private static function sendCurlV1ToToken($token, $url, $headers, $body) {

        $body["message"]["token"] = $token;

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));

        $result = curl_exec($ch);

        curl_close($ch);

        return $result;
    }

    public static function getDomainFromServer() {
        $url = ((!empty($_SERVER['HTTPS'])) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];

        return $url;
    }
}