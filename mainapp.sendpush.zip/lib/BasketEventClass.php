<?php
use Bitrix\Main\EventManager;
use Bitrix\Main\Localization\Loc;
use Bitrix\Sale\Delivery\Services\Manager;
use Bitrix\Sale;

class MainappBasketEvent
{
    public static function MainappOnBasketAddHandler($ID, $arFields) {
        if (COption::GetOptionString("mainapp.sendpush", "F_BASKET_ENABLE") !="Y") {
            return false;
        }
        if (empty($_COOKIE['MN_ANDROID_PUSH_TOKEN']) && empty($_COOKIE['MN_IOS_PUSH_TOKEN'])) {
            return false;
        }
        CModule::IncludeModule('iblock');

        // ���������, ���������� �� cookie 'MN_ANDROID_PUSH_TOKEN' � �� ������ �� ��
        if (isset($_COOKIE['MN_ANDROID_PUSH_TOKEN']) && !empty($_COOKIE['MN_ANDROID_PUSH_TOKEN']) && $_COOKIE['MN_ANDROID_PUSH_TOKEN'] != "browser") {
            $token = $_COOKIE['MN_ANDROID_PUSH_TOKEN'];
        }
        // ���������, ���������� �� cookie 'MN_IOS_PUSH_TOKEN' � �� ������ �� ��
        elseif (isset($_COOKIE['MN_IOS_PUSH_TOKEN']) && !empty($_COOKIE['MN_IOS_PUSH_TOKEN']) && $_COOKIE['MN_IOS_PUSH_TOKEN'] != "browser") {
            $token = $_COOKIE['MN_IOS_PUSH_TOKEN'];
        }
        elseif (isset($_COOKIE['MN_WEB_PUSH_TOKEN']) && !empty($_COOKIE['MN_WEB_PUSH_TOKEN'] && $_COOKIE['MN_WEB_PUSH_TOKEN'] != "browser") ) {
            $token = $_COOKIE['MN_WEB_PUSH_TOKEN'];
        }
        else {
            return false;
        }

        $basketUserID = \Bitrix\Sale\Fuser::getId();
        $elementID = MainappBasketEvent::findBasketElement($token);

        $el = new CIBlockElement;
        global $USER;
        $arLoadProductArray = array(
            'MODIFIED_BY'       => $USER->GetID(),
            'IBLOCK_SECTION_ID' => false,
            'IBLOCK_ID'         => COption::GetOptionString("mainapp.sendpush", "F_BASKET_IBLOCK_ID"), // �������� ������� ������
            'PROPERTY_VALUES'   => array(
                'MN_BASKET_USER_ID' => $basketUserID,
                'MN_BASKET_ID' => $ID,
                'MN_TOKEN' => $token,
                'MN_SITE_ID' => SITE_ID
            ),
            'NAME'              => $token,
            'ACTIVE'            => 'Y',
        );

        if ($elementID) {
            $res = $el->Update($elementID, $arLoadProductArray);
        } else {
            $el->Add($arLoadProductArray);
        }

        return true;
    }

    public static function MainappOnBasketDeleteHandler($token) {
        CModule::IncludeModule('iblock');
        //$basketUserID = CSaleBasket::GetBasketUserID(true);
        $elementID = MainappBasketEvent::findBasketElement($token);

        if ($elementID) {
            CIBlockElement::Delete($elementID);
        }
    }

    public static function findBasketElement($token) {
        $arSelect = Array('ID');
        $arFilter = Array('IBLOCK_ID' => COption::GetOptionString("mainapp.sendpush", "F_BASKET_IBLOCK_ID"), '=NAME' => $token);
        $res = CIBlockElement::GetList(Array(), $arFilter, false, Array('nPageSize' => 1), $arSelect);
        if ($ob = $res->GetNextElement()) {
            $arFields = $ob->GetFields();
            return $arFields['ID'];
        }
        return false;
    }

}