<?php
use Bitrix\Main\EventManager;
use Bitrix\Sale;

class MainappOrderEvent
{
    public static function MainappOnSaleStatusOrderHandler($id,$val) {
        if (COption::GetOptionString("mainapp.sendpush", "ORDER_STATUS_PUSH_ENABLE") !="Y") {
            return false;
        }
        if (CModule::IncludeModule("sale")) {
            $order = Sale\Order::load($id);
            $userId = $order->getUserId();
            $rsUser = CUser::GetByID($userId);
            $arUserInfo = $rsUser->Fetch();
            $sendTo = $arUserInfo["UF_PUSH_TOKEN"];
            if (empty($sendTo)) {
                return false;
            }
            $orderStatusId = $order->getField('STATUS_ID'); //ID ������� ������
            $selectedStatuses = unserialize(COption::GetOptionString("mainapp.sendpush", 'selected_order_statuses', ''));
            if (is_array($selectedStatuses) && !in_array($orderStatusId, $selectedStatuses)) {
                return false;
            }
            if ($arStatus = CSaleStatus::GetByID($orderStatusId)) {
                $orderStatus = $arStatus["NAME"];
                $orderStatusDescription = $arStatus["DESCRIPTION"];
            }

            if (CModule::IncludeModule("mainapp.sendpush")) {
                $push_title = str_replace("#ORDER_ID#", $id, COption::GetOptionString("mainapp.sendpush", "ORDER_STATUS_PUSH_TITLE"));
                $push_description = str_replace("#ORDER_STATUS#", $orderStatus, COption::GetOptionString("mainapp.sendpush", "ORDER_STATUS_PUSH_BODY"));
                $push_description = str_replace("#ORDER_STATUS_DESCRIPTION#", $orderStatusDescription, $push_description);
                $orderUrl = str_replace("#ORDER_ID#", $id, COption::GetOptionString("mainapp.sendpush", "ORDER_STATUS_PUSH_LINK"));
                $SendPushMessage = new MainappSendPushMessage();
                $result = $SendPushMessage->buildAndSendPushDataFields(
                    $push_title,
                    $push_description,
                    $orderUrl,
                    $sendTo
                );
                $message = json_decode($result, true);
                if (!empty($message['name'])) {
                    $os = $message['name'];
                }
                else {
                    return false;
                }
                #########################################
                #$file_content = $result;
                #$file = $_SERVER["DOCUMENT_ROOT"] . "/bitrix/catalog_export/log_mainapp_push_handler.txt";
                #file_put_contents($file, $file_content);
                #########################################
                $login = COption::GetOptionString("mainapp.sendpush", "TARIF_LOGIN");
                $token = COption::GetOptionString("mainapp.sendpush", "TARIF_TOKEN");
                $GetAndSavePushToken = new GetAndSavePushToken();
                $MainappBilling = new MainappBilling();
                #���������� ������������� ���� � ������� �� ���������, �.�. ������ ������ ������� ���������
                if (COption::GetOptionString("mainapp.sendpush", "ORDER_STATUS_PUSH_USE_HISTORY") =="Y") {
                    $GetAndSavePushToken->addPushMessageHistory($push_title, $push_description, $orderUrl, $os, $user_group = "", $orderUrl, $site_id = "");
                }
                $MainappBilling->setPlusPushCount($login, $token, 'order_status_push');
            }
        }

        return true;
    }
}