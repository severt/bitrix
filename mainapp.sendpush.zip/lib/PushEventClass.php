<?php
use Bitrix\Main\EventManager;
use Bitrix\Main\Localization\Loc;
use Bitrix\Sale\Delivery\Services\Manager;
use Bitrix\Sale;

class MainappSendPushEvent
{
    public static function MainappSendPushEventHandler($arUser): bool
    {
        global $USER;

        $userId = $USER->GetID();
        $pushToken = "";
        if (!empty($_COOKIE["MN_ANDROID_PUSH_TOKEN"]) || !empty($_COOKIE["MN_IOS_PUSH_TOKEN"]) || !empty($_COOKIE["MN_WEB_PUSH_TOKEN"])) {
            if (!empty($_COOKIE["MN_ANDROID_PUSH_TOKEN"])) {
                $pushToken = $_COOKIE["MN_ANDROID_PUSH_TOKEN"];
                $pushTokenToIblock = $_COOKIE["MN_ANDROID_PUSH_TOKEN"];
            }
            if (!empty($_COOKIE["MN_IOS_PUSH_TOKEN"])) {
                $pushToken = $_COOKIE["MN_IOS_PUSH_TOKEN"];
                $pushTokenToIblock = $_COOKIE["MN_IOS_PUSH_TOKEN"];
            }
            if (!empty($_COOKIE["MN_WEB_PUSH_TOKEN"])) {
                $pushToken = $_COOKIE["MN_WEB_PUSH_TOKEN"];
                $pushTokenToIblock = $_COOKIE["MN_WEB_PUSH_TOKEN"];
            }

            $rsUser = CUser::GetByID($userId);
            $arUserInfo = $rsUser->Fetch();
            $oldPushToken = $arUserInfo["UF_PUSH_TOKEN"];


            if (!empty($oldPushToken)) {
                if (!in_array($pushToken, $oldPushToken)) {
                    $oldPushToken[] = $pushToken;
                    $pushToken = $oldPushToken;
                }
                else {
                    unset($pushToken);
                }
            }
            else {
                $pushToken = array($pushToken);
            }

            $fields = array(
                "UF_PUSH_TOKEN" => $pushToken
            );
            global $USER;
            $r = $USER->Update($userId, $fields);
            if (CModule::IncludeModule("mainapp.sendpush")) {
                GetAndSavePushToken::addToken($pushTokenToIblock, $userId);
            }
        }

        #########################################
        #$file_content = json_encode($arUser);
        #$file = $_SERVER["DOCUMENT_ROOT"] . "/bitrix/catalog_export/log_mainapp_push_handler.txt";
        #file_put_contents($file, $file_content);
        #########################################

        return true;
    }
}