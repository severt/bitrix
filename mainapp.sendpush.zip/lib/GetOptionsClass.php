<?php
use Bitrix\Main\Localization\Loc;
use Bitrix\Iblock;

CModule::IncludeModule('iblock');

class GetOptions
{

    static function getDomainFromServer() {
        $url = ((!empty($_SERVER['HTTPS'])) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];

        return $url;
    }

    static function appsBottomMenuUrlTypes()
    {
        $fieldsArray = array(
            array(
                'ID' => 'link',
                'NAME' => Loc::getMessage("link"),
            ),
            array(
                'ID' => 'phone',
                'NAME' => Loc::getMessage("phone")
            ),
            array(
                'ID' => 'email',
                'NAME' => "E-mail"
            )
        );
        foreach ($fieldsArray as $fields) {
            $fieldsCode[] = $fields["ID"];
            $fieldsName[] = $fields["NAME"];
        }

        $select = array('REFERENCE_ID' => $fieldsCode, 'REFERENCE' => $fieldsName);

        return $select;
    }

    static function headerMenuTextFrom() {
        $fieldsArray = array(
            array(
                'ID' => 'H1',
                'NAME' => Loc::getMessage("h1"),
            ),
            array(
                'ID' => 'title',
                'NAME' => Loc::getMessage("title")
            )
        );
        foreach ($fieldsArray as $fields) {
            $fieldsCode[] = $fields["ID"];
            $fieldsName[] = $fields["NAME"];
        }

        $select = array('REFERENCE_ID' => $fieldsCode, 'REFERENCE' => $fieldsName);

        return $select;
    }

    static function getSecretKey() {
        $arr = array (
            'a', 'b', 'c', 'd', 'e', 'f',
            'g', 'h', 'i', 'j', 'k', 'l',
            'm', 'n', 'o', 'p', 'r', 's',
            't', 'u', 'v', 'x', 'y', 'z',
            'A', 'B', 'C', 'D', 'E', 'F',
            'G', 'H', 'I', 'J', 'K', 'L',
            'M', 'N', 'O', 'P', 'R', 'S',
            'T', 'U', 'V', 'X', 'Y', 'Z',
            '1', '2', '3', '4', '5', '6',
            '7', '8', '9', '0'
        );
        $number = 10;
        $pass = "";
        for ($i = 0; $i < $number; $i++) {
            $index = rand(0, count($arr) - 1);
            $pass .= $arr[$index];
        }
        return $pass;
    }

    static function getIblockList() {
        $iblock_id = array();
        $iblock_name = array();
        $res = CIBlock::GetList(
            Array (),
            Array ()
        );
        while ($ar_res = $res->Fetch()) {
            $iblock_id[] = $ar_res['ID'];
            $iblock_name[] = $ar_res['NAME'] . " (".$ar_res['ID'].")";
        }
        $select = array ('REFERENCE_ID' => $iblock_id, 'REFERENCE' => $iblock_name);
        array_unshift($select['REFERENCE_ID'], '');
        array_unshift($select['REFERENCE'], Loc::getMessage('SELECT'));

        return $select;
    }

    static function getIblockListNewOptions() {
        // ��������� ������ ���������� ��� ���������� �������
        $iblocks = [];
        $res = Iblock\IblockTable::getList([
            'select' => ['ID', 'NAME'],
            'order' => ['NAME' => 'ASC']
        ]);
        while ($iblock = $res->fetch()) {
            $iblocks[$iblock['ID']] = '['.$iblock['ID'].'] ' . $iblock['NAME'];
        }


        return $iblocks;
    }

    public static function getSitesList() {
        $rsSites = CSite::GetList($by="def", $order="desc", Array());
        $sites = array();
        while ($arSite = $rsSites->Fetch())
        {
            #echo "<pre>"; print_r($arSite); echo "</pre>";
            $sites[] = $arSite;
        }

        return $sites;
    }

    public static function getSiteById($siteId) {
        $rsSites = CSite::GetList($by="def", $order="desc", Array("ID" => $siteId));
        $site = array();
        while ($arSite = $rsSites->Fetch())
        {
            #echo "<pre>"; print_r($arSite); echo "</pre>";
            $site = $arSite;
            break;
        }

        return $site;
    }

    // ������� ��� �������� ��������� ������
    public static function checkAgentStatus() {
        $agentName = "MainappSendPushForgottenBasketAutoAgentFunction();";
        $agent = CAgent::GetList(array(), array("NAME" => $agentName))->Fetch();

        if (!$agent) {
            // ����� �� ������
            return ['status' => 'not_created'];
        } elseif ($agent['ACTIVE'] == 'N') {
            // ����� ������, �� ���������
            return ['status' => 'inactive', 'agent_id' => $agent['ID']];
        }

        // ����� �������
        return ['status' => 'active'];
    }
}
