<?php

use Bitrix\Main\Loader;
use Bitrix\Main\UserTable;

class MainappEmailSendEvent {

    public static function onBeforeSendSubscribeNotify(&$event, &$lid, &$arFields, &$message_id) {
        $module_id = "mainapp.sendpush";
        if ($event == 'CATALOG_PRODUCT_SUBSCRIBE_NOTIFY' && COption::GetOptionString($module_id, "PRODUCT_SUBSCRIBE_NOTIFY_PUSH_ENABLE") == "Y") {
            // ���������� ������ ������������
            if (CModule::IncludeModule("main") && CModule::IncludeModule($module_id)) {
                // ����� ������������ �� email
                $emailTo = $arFields["EMAIL_TO"];
                $user = CUser::GetList(
                    ($by = "id"),
                    ($order = "asc"),
                    ["EMAIL" => $emailTo, "ACTIVE" => "Y"],
                    ["SELECT" => ["ID", "EMAIL", "UF_PUSH_TOKEN"]]
                );

                if ($arUser = $user->Fetch()) {
                    // ������� ���������������� ���� UF_PUSH_TOKEN
                    $pushToken = $arUser["UF_PUSH_TOKEN"];
                    if (!empty($pushToken)) {
                        $SendPushMessage = new MainappSendPushMessage();
                        $title = GetMessage("PUSH_TITLE");
                        $body = GetMessage("PUSH_BODY_1") . $arFields['NAME'] . GetMessage("PUSH_BODY_2");
                        $clickAction = $arFields["PAGE_URL"];
                        $push_success = "N";
                        if (is_array($pushToken) && count($pushToken) > 1) {
                            foreach ($pushToken as $pToken) {
                                $result = $SendPushMessage->buildAndSendPushDataFields($title, $body, $clickAction, array($pToken));
                                $message = json_decode($result, true);
                                if (!empty($message['name'])) {
                                    $push_success = "Y";
                                }
                            }
                        }
                        else {
                            $result = $SendPushMessage->buildAndSendPushDataFields($title, $body, $clickAction, $pushToken);
                            $message = json_decode($result, true);
                            if (!empty($message['name'])) {
                                $push_success = "Y";
                            }
                        }
                    }
                    if ($push_success == "Y") {
                        $login = COption::GetOptionString($module_id, "TARIF_LOGIN");
                        $token = COption::GetOptionString($module_id, "TARIF_TOKEN");
                        $MainappBilling = new MainappBilling();
                        $MainappBilling->setPlusPushCount($login, $token, "subscribe_notify_push");
                    }
                }
            }
        }

        #########################################
        #$file_content = '<pre>' . print_r($arFields, true) . '</pre>';
        #$file = $_SERVER["DOCUMENT_ROOT"] . "/bitrix/catalog_export/log_mainapp_push_product_notify.txt";
        #file_put_contents($file, $file_content);
        #########################################

        return $arFields;
    }

}