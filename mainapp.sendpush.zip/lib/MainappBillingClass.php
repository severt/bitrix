<?php

const MODULE_ID = "mainapp.sendpush";

class MainappBilling
{
    public static function GetTarifData($login, $token) {
        $pushDataFields = array(
            'login' => $login,
            'token' => $token,
            'host' => $_SERVER["HTTP_HOST"],
            'type' => 'get_counterparty_info'
        );

        $resultArray = json_decode(MainappBilling::sendCurl($pushDataFields), true);

        if ($resultArray["SUCCESS"] == "Y") {
            $result = '<div>' . GetMessage('TARIF_NAME').$resultArray["TARIF_NAME"]. '<br>' . GetMessage('TARIF_EXPIRE').$resultArray["TARIF_EXPIRE"]. '<br>' . GetMessage('TARIF_MESS_COUNT').$resultArray["TARIF_MESS_COUNT"].'</div>';
        }
        else {
            $result = '<div>' .$resultArray["MESSAGE"]. '</div>';
        }

        return $result;
    }

    public static function GetStatistics($login, $token) {
        $pushDataFields = array(
            'login' => $login,
            'token' => $token,
            'host' => $_SERVER["HTTP_HOST"],
            'type' => 'get_statistics_info'
        );

        $resultArray = json_decode(MainappBilling::sendCurl($pushDataFields), true);

        if ($resultArray["SUCCESS"] == "Y") {
            #$result = '<pre>'.print_r($resultArray["STATISTICS"], true).'</pre>';
            if (!empty($resultArray["STATISTICS"]) && is_array($resultArray["STATISTICS"])) {
                foreach ($resultArray["STATISTICS"] as $statistic) {
                    $result .=
                        "<p>" .
                        "������: " . $statistic['period_start'] . "/" . $statistic['period_end']."<br>".
                        "���������� � ������: " . $statistic['manual_push']."<br>".
                        "������� �������: " .$statistic['forgotten_basket_push']."<br>".
                        "������� �������: " .$statistic['order_status_push']."<br>".
                        "</p>";
                }
            }
        }
        else {
            $result = '<div>' .$resultArray["MESSAGE"]. '</div>';
        }

        return $result;
    }

    public static function GetStatisticsArray($login, $token) {
        $pushDataFields = array(
            'login' => $login,
            'token' => $token,
            'host' => $_SERVER["HTTP_HOST"],
            'type' => 'get_statistics_info'
        );

        $resultArray = json_decode(MainappBilling::sendCurl($pushDataFields), true);



        if ($resultArray["SUCCESS"] == "Y") {
            return $resultArray;
        }
        else {
            return $resultArray;
        }
    }

    public static function GetTarifActuality($login, $token) {
        $pushDataFields = array(
            'login' => $login,
            'token' => $token,
            'host' => $_SERVER["HTTP_HOST"],
            'type' => 'get_counterparty_info'
        );

        $resultArray = json_decode(MainappBilling::sendCurl($pushDataFields), true);

        if ($resultArray["SUCCESS"] == "Y") {
            if (COption::GetOptionString(MODULE_ID, "USE_NEW_API_V1") == "Y") {
                return array('ACCESS_TOKEN' => $resultArray['ACCESS_TOKEN'], 'PUSH_SEND_URL' => $resultArray['PUSH_SEND_URL']);
            }
            else {
                return $resultArray["TARIF_TOKEN"];
            }
        }

        return false;
    }

    public static function setPlusPushCount($login, $token, $push_type){
        $dataFields = array(
            'login' => $login,
            'token' => $token,
            'push_type' => $push_type,
            'host' => $_SERVER["HTTP_HOST"],
            'type' => 'set_push_count'
        );
        MainappBilling::sendCurl($dataFields);

        return false;
    }

    private static function sendCurl($pushDataFields) {
        $needed_extensions = array('curl');
        $missing_extensions = array();
        foreach ($needed_extensions as $needed_extension) {
            if (!extension_loaded($needed_extension)) {
                $missing_extensions[] = $needed_extension;
            }
        }
        if (count($missing_extensions) > 0) {
            echo '<p>This software needs the following extensions, please install/enable them: ' . implode(', ', $missing_extensions) . '</p>' . PHP_EOL;
            return false;
        }
        else {
            $ch = curl_init('https://sendpush.mainapp.ru/api-v-1/' . $pushDataFields["type"] . '.php?' . http_build_query($pushDataFields));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HEADER, false);
            $result = curl_exec($ch);
            curl_close($ch);

            return $result;
        }
    }
}