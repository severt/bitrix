<?php
use Bitrix\Main\Loader;
use Bitrix\Sale;

const MODULE_ID = "mainapp.sendpush";

Loader::IncludeModule('iblock');
Loader::IncludeModule('Sale');

class GetAndSavePushToken
{
    public static function platformDetect(){
        $obj = new BrowserDetection();
        $objAr = $obj->detect()->getInfo();

        return $objAr;
    }

    public static function addToken($token, $userId) {

        $el = new CIBlockElement;
        $objAr = GetAndSavePushToken::platformDetect();
        $browser = $objAr["browser"];
        $platform = $objAr["platform"];

        $PROP = array();

        $fuser = "";
        if (CModule::IncludeModule("sale")) {
            $fuser = \Bitrix\Sale\Fuser::getId();
        }

        $PROP["MN_TOKEN"] = $token;
        $PROP["MN_BROWSER"] = $browser;
        $PROP["MN_OS"] = $platform;
        $PROP["MN_USER"] = $userId;
        $PROP["MN_SITE_ID"] = SITE_ID;
        $PROP["MN_FUSER_ID"] = $fuser;

        $arLoadProductArray = Array(
            "IBLOCK_SECTION_ID" => false,
            "IBLOCK_ID"      => COption::GetOptionString(MODULE_ID, "PUSH_IBLOCK_ID"), //id ���������� ��������� � ��������
            "PROPERTY_VALUES"=> $PROP,
            "NAME"           => $userId . " " . $platform,
            "ACTIVE"         => "Y",
            "XML_ID"         => $userId
        );

        $arSelect = Array("ID", "IBLOCK_ID", "NAME", "DATE_ACTIVE_FROM","PROPERTY_*");
        $arFilter = Array("IBLOCK_ID"=> COption::GetOptionString(MODULE_ID, "PUSH_IBLOCK_ID"), "PROPERTY_MN_TOKEN" => $token, "PROPERTY_MN_USER" => $userId);
        $res = CIBlockElement::GetList(Array(), $arFilter, false, Array(), $arSelect);
        if($ob = $res->GetNextElement()) {
            $arFields = $ob->GetFields();
            $elId = $arFields["ID"];
            $el->Update($elId, $arLoadProductArray);
        }
        else {
            $el->Add($arLoadProductArray);
        }
    }

    public static function addTokenForUnknownUser ($token, $fuserId) {
        $el = new CIBlockElement;
        $objAr = GetAndSavePushToken::platformDetect();
        $browser = $objAr["browser"];
        $platform = $objAr["platform"];

        $PROP = array();

        $PROP["MN_TOKEN"] = $token;
        $PROP["MN_BROWSER"] = $browser;
        $PROP["MN_OS"] = $platform;
        $PROP["MN_FUSER_ID"] = $fuserId;
        $PROP["MN_SITE_ID"] = SITE_ID;

        $arLoadProductArray = Array(
            "IBLOCK_SECTION_ID" => false,
            "IBLOCK_ID"      => COption::GetOptionString(MODULE_ID, "PUSH_IBLOCK_ID"), //id ���������� ��������� � ��������
            "PROPERTY_VALUES"=> $PROP,
            "NAME"           => $fuserId . " " . $platform,
            "ACTIVE"         => "Y",
            "XML_ID"         => $fuserId
        );

        $arSelect = Array("ID", "IBLOCK_ID", "NAME", "DATE_ACTIVE_FROM","PROPERTY_*");
        $arFilter = Array("IBLOCK_ID"=> COption::GetOptionString(MODULE_ID, "PUSH_IBLOCK_ID"), "PROPERTY_MN_TOKEN" => $token, "NAMA" => $fuserId . " " . $platform);
        $res = CIBlockElement::GetList(Array(), $arFilter, false, Array(), $arSelect);
        if($ob = $res->GetNextElement()) {
            $arFields = $ob->GetFields();
            $elId = $arFields["ID"];
            $el->Update($elId, $arLoadProductArray);
        }
        else {
            $el->Add($arLoadProductArray);
        }
    }

    public static function addPushMessageHistory ($title, $body, $click_action, $os, $user_group, $pushLinkValue, $site_id) {
        global $USER;

        $el = new CIBlockElement;
        $PROP = array();
        $PROP["MN_OS"] = $os;
        $PROP["MN_USERS_GROUP"] = $user_group;
        $PROP["MN_PUSH_LINK_VALUE"] = $pushLinkValue;
        $PROP["MN_SITE_ID"] = $site_id;

        $arLoadProductArray = Array(
            "IBLOCK_SECTION_ID" => false,
            "IBLOCK_ID"         => COption::GetOptionString(MODULE_ID, "PUSH_HISTORY_IBLOCK_ID"),
            "PROPERTY_VALUES"   => $PROP,
            "NAME"              => $title,
            "PREVIEW_TEXT"      => $body,
            "ACTIVE"            => "Y",
            "MODIFIED_BY"       => $USER->GetID(),
        );

        $el->Add($arLoadProductArray);
    }
}