<?php

use Bitrix\Main\IO\File;
use \Bitrix\Main\Localization\Loc;
use \Bitrix\Main\Application;

IncludeModuleLangFile(__FILE__);
Class mainapp_sendpush extends CModule
{
    const MODULE_ID = 'mainapp.sendpush';
    var $MODULE_ID = 'mainapp.sendpush';
    var $MODULE_VERSION;
    var $MODULE_VERSION_DATE;
    var $MODULE_NAME;
    var $MODULE_DESCRIPTION;
    var $strError = '';

    function __construct()
    {
        $arModuleVersion = array();
        include(dirname(__FILE__)."/version.php");
        $this->MODULE_VERSION = $arModuleVersion["VERSION"];
        $this->MODULE_VERSION_DATE = $arModuleVersion["VERSION_DATE"];
        $this->MODULE_NAME = Loc::getMessage("MAINAPP_SENDPUSH_MODULE_NAME");
        $this->MODULE_DESCRIPTION = Loc::getMessage("MAINAPP_SENDPUSH_MODULE_DESCRIPTION");

        $this->PARTNER_NAME = "MainApp";
        $this->PARTNER_URI = "https://mainapp.pro";
    }

    function InstallDB($arParams = array())
    {
        RegisterModuleDependences('main', 'OnBuildGlobalMenu', self::MODULE_ID);

        return true;
    }

    function UnInstallDB($arParams = array())
    {
        UnRegisterModuleDependences('main', 'OnBuildGlobalMenu', self::MODULE_ID);

        return true;
    }

    function InstallEvents()
    {
        RegisterModuleDependences("main", "OnAfterUserAuthorize", $this->MODULE_ID, "MainappSendPushEvent", "MainappSendPushEventHandler");
        RegisterModuleDependences('main', 'OnBeforeEventAdd', $this->MODULE_ID, 'MainappEmailSendEvent', 'onBeforeSendSubscribeNotify');
        if (CModule::IncludeModule("sale")) {
            RegisterModuleDependences("sale", "OnBasketAdd", $this->MODULE_ID, "MainappBasketEvent", "MainappOnBasketAddHandler");
            RegisterModuleDependences("sale", "OnSaleStatusOrder", $this->MODULE_ID, "MainappOrderEvent", "MainappOnSaleStatusOrderHandler");
        }

        return true;
    }

    function UnInstallEvents()
    {
        UnRegisterModuleDependences("main", "OnAfterUserAuthorize", $this->MODULE_ID, "MainappSendPushEvent", "MainappSendPushEventHandler");
        UnRegisterModuleDependences('main', 'OnBeforeEventAdd', $this->MODULE_ID, 'MainappEmailSendEvent', 'onBeforeSendSubscribeNotify');
        if (CModule::IncludeModule("sale")) {
            UnRegisterModuleDependences("sale", "OnBasketAdd", $this->MODULE_ID, "MainappBasketEvent", "MainappOnBasketAddHandler");
            UnRegisterModuleDependences("sale", "OnSaleStatusOrder", $this->MODULE_ID, "MainappOrderEvent", "MainappOnSaleStatusOrderHandler");
        }

        return true;
    }

    function InstallAgent ()
    {
        // ����������� ������ � �������
        CAgent::AddAgent(
            "MainappSendPushAutoSendPushAgentFunction();",
            "mainapp.sendpush",
            "N",
            60,
            date("d.m.Y H:i:s"),
            "Y",
            date("d.m.Y H:i:s")
        );
        if (CModule::IncludeModule("sale")) {
            // ����������� ������ � �������
            CAgent::AddAgent(
                "MainappSendPushForgottenBasketAutoAgentFunction();",
                "mainapp.sendpush",
                "N",
                600,
                date("d.m.Y H:i:s"),
                "Y",
                date("d.m.Y H:i:s")
            );
        }


        return true;
    }

    function UnInstallAgent ()
    {
        CAgent::RemoveModuleAgents("mainapp.sendpush");
    }

    function InstallFiles($arParams = array()){
        $path = $this->GetPath()."/install/components";

        if (\Bitrix\Main\IO\Directory::isDirectoryExists($path)){
            CopyDirFiles($path, $_SERVER["DOCUMENT_ROOT"]."/bitrix/components", true, true);
        }

        if (\Bitrix\Main\IO\Directory::isDirectoryExists($path = $this->GetPath().'/install/files')){
            $this->copyArbitraryFiles();
        }

        return true;
    }

    function UnInstallFiles()
    {
        if (is_dir($p = $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/'.self::MODULE_ID.'/admin'))
        {
            if ($dir = opendir($p))
            {
                while (false !== $item = readdir($dir))
                {
                    if ($item == '..' || $item == '.')
                        continue;
                    unlink($_SERVER['DOCUMENT_ROOT'].'/bitrix/admin/'.self::MODULE_ID.'_'.$item);
                }
                closedir($dir);
            }
        }
        return true;
    }

    function copyArbitraryFiles(){
        $rootPath = $_SERVER["DOCUMENT_ROOT"];
        $localPath = $this->GetPath().'/install/files';

        $dirIterator = new RecursiveDirectoryIterator($localPath, RecursiveDirectoryIterator::SKIP_DOTS);
        $iterator = new RecursiveIteratorIterator($dirIterator, RecursiveIteratorIterator::SELF_FIRST);

        foreach ($iterator as $object){
            $destPath = $rootPath.DIRECTORY_SEPARATOR.$iterator->getSubPathName();
            ($object->isDir()) ? mkdir($destPath) : copy($object, $destPath);
        }
    }

    function generateDestPathName($length = 6){
        $chars = 'abdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $numChars = strlen($chars);
        $string = '';
        for ($i = 0; $i < $length; $i++) {
            $string .= substr($chars, rand(1, $numChars) - 1, 1);
        }
        return $string;
    }

    function deleteArbitraryFiles(){

    }

    function createServicesIblocks(){
        if (CModule::IncludeModule('iblock')) {
            ###������� ����� ��� ����������
            $iblockType = "mainapp_services";

            $obIBlockType = new CIBlockType;
            $arFields = Array(
                "ID" => $iblockType,
                "SECTIONS" => "N",
                "LANG" => Array(
                    "ru" => Array(
                        "NAME" => GetMessage('MAINAPP_SERVICES_IBLOCK_NAME'),
                    )
                )
            );
            $res = $obIBlockType->Add($arFields);
            if(!$res){
                $error = $obIBlockType->LAST_ERROR;
            }
            else {
                $this->createPushTokensIblock();
                $this->createPushHistoryIblock();
            }
            $this->createMainappBasketIblock();
        }
    }

    function createPushTokensIblock() {
        if (CModule::IncludeModule('iblock')) {
            ###������� �������� ��� �������� PUSH �������
            $siteId = "s1";
            $rsSites = CSite::GetList($by="sort", $order="desc", Array());
            while ($arSite = $rsSites->Fetch()) {
                if ($arSite["DEF"] == "Y") {
                    $siteId = $arSite["LID"];
                }
            }
            $obIblock = new CIBlock;
            $arFields = array(
                "NAME" => GetMessage('TOKENS_FOR_PUSH'),
                "ACTIVE" => "Y",
                "CODE" => "mainapp_push",
                "IBLOCK_TYPE_ID" => "mainapp_services",
                "SITE_ID" => $siteId
            );
            $newIblockID = $obIblock->Add($arFields);

            // ����������, ���� �� � ��������� ��������
            $dbProperties = CIBlockProperty::GetList(array(), array("IBLOCK_ID" => $newIblockID));
            // �������� ������ ���� ������� ���������

            if ($dbProperties->SelectedRowsCount() <= 0) {
                $ibp = new CIBlockProperty;

                $arFields = array(
                    "NAME" => GetMessage('MN_NOTIFICATION_SENT'),
                    "ACTIVE" => "Y",
                    "SORT" => 5,
                    "CODE" => "MN_NOTIFICATION_SENT",
                    "PROPERTY_TYPE" => "L",
                    "LIST_TYPE" => "C",
                    "VALUES" => array(
                        array(
                            "VALUE" => GetMessage('MN_YES'),
                            "DEF" => "N", // �� ������������� �� ���������
                            "SORT" => "100"
                        )
                    ),
                    "IBLOCK_ID" => $newIblockID
                );
                $propId = $ibp->Add($arFields);
                if ($propId > 0) {
                    echo "&mdash; " . GetMessage("DOBAVLENO_SVOYSTVO") . $arFields["NAME"] . "<br />";
                } else {
                    echo "&mdash; " . GetMessage("OSIBKA_DOBAVLENIA_SVOISTVA") . $arFields["NAME"] . "<br />";
                }

                $arFields = array(
                    "NAME" => GetMessage('MN_USER_NAME'),
                    "ACTIVE" => "Y",
                    "SORT" => 10,
                    "CODE" => "MN_USER",
                    "PROPERTY_TYPE" => "S",
                    "USER_TYPE" => 'UserID',
                    "IBLOCK_ID" => $newIblockID
                );
                $propId = $ibp->Add($arFields);
                if ($propId > 0) {
                    echo "&mdash; " . GetMessage("DOBAVLENO_SVOYSTVO") . $arFields["NAME"] . "<br />";
                } else {
                    echo "&mdash; " . GetMessage("OSIBKA_DOBAVLENIA_SVOISTVA") . $arFields["NAME"] . "<br />";
                }

                $arFields = array(
                    "NAME" => GetMessage('MN_TOKEN_NAME'),
                    "ACTIVE" => "Y",
                    "SORT" => 20,
                    "CODE" => "MN_TOKEN",
                    "PROPERTY_TYPE" => "S",
                    "IBLOCK_ID" => $newIblockID
                );
                $propId = $ibp->Add($arFields);
                if ($propId > 0) {
                    echo "&mdash; " . GetMessage("DOBAVLENO_SVOYSTVO") . $arFields["NAME"] . "<br />";
                } else {
                    echo "&mdash; " . GetMessage("OSIBKA_DOBAVLENIA_SVOISTVA") . $arFields["NAME"] . "<br />";
                }

                $arFields = array(
                    "NAME" => GetMessage('MN_BROWSER_NAME'),
                    "ACTIVE" => "Y",
                    "SORT" => 30,
                    "CODE" => "MN_BROWSER",
                    "PROPERTY_TYPE" => "S",
                    "IBLOCK_ID" => $newIblockID
                );
                $propId = $ibp->Add($arFields);
                if ($propId > 0) {
                    echo "&mdash; " . GetMessage("DOBAVLENO_SVOYSTVO") . $arFields["NAME"] . "<br />";
                } else {
                    echo "&mdash; " . GetMessage("OSIBKA_DOBAVLENIA_SVOISTVA") . $arFields["NAME"] . "<br />";
                }

                $arFields = array(
                    "NAME" => GetMessage('MN_OS_NAME'),
                    "ACTIVE" => "Y",
                    "SORT" => 40,
                    "CODE" => "MN_OS",
                    "PROPERTY_TYPE" => "S",
                    "IBLOCK_ID" => $newIblockID
                );
                $propId = $ibp->Add($arFields);
                if ($propId > 0) {
                    echo "&mdash; " . GetMessage("DOBAVLENO_SVOYSTVO") . $arFields["NAME"] . "<br />";
                } else {
                    echo "&mdash; " . GetMessage("OSIBKA_DOBAVLENIA_SVOISTVA") . $arFields["NAME"] . "<br />";
                }

                $arFields = array(
                    "NAME" => GetMessage('MN_FUSER_ID_NAME'),
                    "ACTIVE" => "Y",
                    "SORT" => 50,
                    "CODE" => "MN_FUSER_ID",
                    "PROPERTY_TYPE" => "S",
                    "IBLOCK_ID" => $newIblockID
                );
                $propId = $ibp->Add($arFields);
                if ($propId > 0) {
                    echo "&mdash; " . GetMessage("DOBAVLENO_SVOYSTVO") . $arFields["NAME"] . "<br />";
                } else {
                    echo "&mdash; " . GetMessage("OSIBKA_DOBAVLENIA_SVOISTVA") . $arFields["NAME"] . "<br />";
                }
            } else {
                echo "&mdash; " . GetMessage('SVOISTVA_SUSHESTVUYUT') . "<br />";
            }
        }
    }

    function createPushHistoryIblock() {
        if (CModule::IncludeModule('iblock')) {
            ###������� �������� ��� �������� ������� PUSH ���������
            $siteId = "s1";
            $rsSites = CSite::GetList($by="sort", $order="desc", Array());
            while ($arSite = $rsSites->Fetch()) {
                if ($arSite["DEF"] == "Y") {
                    $siteId = $arSite["LID"];
                }
            }
            $obIblock = new CIBlock;
            $arFields = array(
                "NAME" => GetMessage('PUSH_HISTORY'),
                "ACTIVE" => "Y",
                "CODE" => "push_messages",
                "IBLOCK_TYPE_ID" => "mainapp_services",
                "SITE_ID" => $siteId
            );
            $newIblockID = $obIblock->Add($arFields);

            // ����������, ���� �� � ��������� ��������
            $dbProperties = CIBlockProperty::GetList(array(), array("IBLOCK_ID" => $newIblockID));
            if ($dbProperties->SelectedRowsCount() <= 0) {
                $ibp = new CIBlockProperty;

                $arFields = array(
                    "NAME" => GetMessage('OS'),
                    "ACTIVE" => "Y",
                    "SORT" => 10,
                    "CODE" => "MN_OS",
                    "PROPERTY_TYPE" => "S",
                    "MULTIPLE" => "Y",
                    "IBLOCK_ID" => $newIblockID
                );
                $propId = $ibp->Add($arFields);
                if ($propId > 0) {
                    echo "&mdash; " . GetMessage("DOBAVLENO_SVOYSTVO") . $arFields["NAME"] . "<br />";
                } else {
                    echo "&mdash; " . GetMessage("OSIBKA_DOBAVLENIA_SVOISTVA") . $arFields["NAME"] . "<br />";
                }

                $arFields = array(
                    "NAME" => GetMessage('USERS_GROUP'),
                    "ACTIVE" => "Y",
                    "SORT" => 20,
                    "CODE" => "MN_USERS_GROUP",
                    "PROPERTY_TYPE" => "S",
                    "MULTIPLE" => "Y",
                    "IBLOCK_ID" => $newIblockID
                );
                $propId = $ibp->Add($arFields);
                if ($propId > 0) {
                    echo "&mdash; " . GetMessage("DOBAVLENO_SVOYSTVO") . $arFields["NAME"] . "<br />";
                } else {
                    echo "&mdash; " . GetMessage("OSIBKA_DOBAVLENIA_SVOISTVA") . $arFields["NAME"] . "<br />";
                }

                $arFields = array(
                    "NAME" => GetMessage('MESSAGE_LINK'),
                    "ACTIVE" => "Y",
                    "SORT" => 30,
                    "CODE" => "MN_PUSH_LINK_VALUE",
                    "PROPERTY_TYPE" => "S",
                    "IBLOCK_ID" => $newIblockID
                );
                $propId = $ibp->Add($arFields);
                if ($propId > 0) {
                    echo "&mdash; " . GetMessage("DOBAVLENO_SVOYSTVO") . $arFields["NAME"] . "<br />";
                } else {
                    echo "&mdash; " . GetMessage("OSIBKA_DOBAVLENIA_SVOISTVA") . $arFields["NAME"] . "<br />";
                }
            } else {
                echo "&mdash; " . GetMessage('SVOISTVA_SUSHESTVUYUT') . "<br />";
            }
        }
    }

    function createMainappBasketIblock() {
        if (CModule::IncludeModule('iblock') && CModule::IncludeModule("sale")) {
            ###������� �������� ��� �������� ������� ������
            $siteId = "s1";
            $rsSites = CSite::GetList($by="sort", $order="desc", Array());
            while ($arSite = $rsSites->Fetch()) {
                if ($arSite["DEF"] == "Y") {
                    $siteId = $arSite["LID"];
                }
            }
            $obIblock = new CIBlock;
            $arFields = array(
                "NAME" => GetMessage('IB_MAINAPP_BASKET'),
                "ACTIVE" => "Y",
                "CODE" => "mainapp_basket",
                "IBLOCK_TYPE_ID" => "mainapp_services",
                "SITE_ID" => $siteId
            );
            $newIblockID = $obIblock->Add($arFields);

            // ����������, ���� �� � ��������� ��������
            $dbProperties = CIBlockProperty::GetList(array(), array("IBLOCK_ID" => $newIblockID));
            if ($dbProperties->SelectedRowsCount() <= 0) {
                $ibp = new CIBlockProperty;

                $arFields = array(
                    "NAME" => GetMessage('MN_BASKET_USER_ID'),
                    "ACTIVE" => "Y",
                    "SORT" => 10,
                    "CODE" => "MN_BASKET_USER_ID",
                    "PROPERTY_TYPE" => "S",
                    "MULTIPLE" => "Y",
                    "IBLOCK_ID" => $newIblockID
                );
                $propId = $ibp->Add($arFields);
                if ($propId > 0) {
                    echo "&mdash; " . GetMessage("DOBAVLENO_SVOYSTVO") . $arFields["NAME"] . "<br />";
                } else {
                    echo "&mdash; " . GetMessage("OSIBKA_DOBAVLENIA_SVOISTVA") . $arFields["NAME"] . "<br />";
                }

                $arFields = array(
                    "NAME" => GetMessage('MN_TOKEN'),
                    "ACTIVE" => "Y",
                    "SORT" => 20,
                    "CODE" => "MN_TOKEN",
                    "PROPERTY_TYPE" => "S",
                    "MULTIPLE" => "Y",
                    "IBLOCK_ID" => $newIblockID
                );
                $propId = $ibp->Add($arFields);
                if ($propId > 0) {
                    echo "&mdash; " . GetMessage("DOBAVLENO_SVOYSTVO") . $arFields["NAME"] . "<br />";
                } else {
                    echo "&mdash; " . GetMessage("OSIBKA_DOBAVLENIA_SVOISTVA") . $arFields["NAME"] . "<br />";
                }

                $arFields = array(
                    "NAME" => GetMessage('MN_SITE_ID'),
                    "ACTIVE" => "Y",
                    "SORT" => 30,
                    "CODE" => "MN_SITE_ID",
                    "PROPERTY_TYPE" => "S",
                    "MULTIPLE" => "Y",
                    "IBLOCK_ID" => $newIblockID
                );
                $propId = $ibp->Add($arFields);
                if ($propId > 0) {
                    echo "&mdash; " . GetMessage("DOBAVLENO_SVOYSTVO") . $arFields["NAME"] . "<br />";
                } else {
                    echo "&mdash; " . GetMessage("OSIBKA_DOBAVLENIA_SVOISTVA") . $arFields["NAME"] . "<br />";
                }

                $arFields = array(
                    "NAME" => GetMessage('MN_BASKET_ID'),
                    "ACTIVE" => "Y",
                    "SORT" => 40,
                    "CODE" => "MN_BASKET_ID",
                    "PROPERTY_TYPE" => "S",
                    "IBLOCK_ID" => $newIblockID
                );
                $propId = $ibp->Add($arFields);
                if ($propId > 0) {
                    echo "&mdash; " . GetMessage("DOBAVLENO_SVOYSTVO") . $arFields["NAME"] . "<br />";
                } else {
                    echo "&mdash; " . GetMessage("OSIBKA_DOBAVLENIA_SVOISTVA") . $arFields["NAME"] . "<br />";
                }
            } else {
                echo "&mdash; " . GetMessage('SVOISTVA_SUSHESTVUYUT') . "<br />";
            }
        }
    }

    function createPushTokenUserField() {
        $oEntity = new \CUserTypeEntity();

        if ($oEntity->GetList(array(), array(
            'ENTITY_ID'  => "USER",
            'FIELD_NAME' => 'UF_PUSH_TOKEN'
        ))->fetch()) {
            //��� ����������
        } else {
            $arTypeEntityAdd = array();
            $arTypeEntityAdd['ENTITY_ID'] = 'USER';
            $arTypeEntityAdd['FIELD_NAME'] = 'UF_PUSH_TOKEN';
            $arTypeEntityAdd['USER_TYPE_ID'] = 'string';
            $arTypeEntityAdd['XML_ID'] = 'PUSH_TOKEN';
            $arTypeEntityAdd['SORT'] = '1';
            $arTypeEntityAdd['MULTIPLE'] = 'Y';
            $arTypeEntityAdd['MANDATORY'] = 'N';
            $arTypeEntityAdd['SHOW_FILTER'] = 'I';
            $arTypeEntityAdd['SHOW_IN_LIST'] = 'Y';
            $arTypeEntityAdd['EDIT_IN_LIST'] = 'N';
            $arTypeEntityAdd['IS_SEARCHABLE'] = 'N';
            $arTypeEntityAdd['SETTINGS'] = array();

            // ����� � ������� -------
            $dbrLang = \CLang::GetList($by, $order);
            while ($arLang = $dbrLang->fetch()) {
                $arTypeEntityAdd['EDIT_FORM_LABEL'][ $arLang['LANGUAGE_ID'] ] = GetMessage('APPS_TOKENS');
                $arTypeEntityAdd['LIST_COLUMN_LABEL'][ $arLang['LANGUAGE_ID'] ] = GetMessage('APPS_TOKENS');
                $arTypeEntityAdd['LIST_FILTER_LABEL'][ $arLang['LANGUAGE_ID'] ] = GetMessage('APPS_TOKENS');
                $arTypeEntityAdd['ERROR_MESSAGE'][ $arLang['LANGUAGE_ID'] ] = GetMessage('APPS_TOKENS');
                $arTypeEntityAdd['HELP_MESSAGE'][ $arLang['LANGUAGE_ID'] ] = GetMessage('APPS_TOKENS');
            }

            $oEntity->Add($arTypeEntityAdd);
        }
    }

    function GetPath($notDocumentRoot = false){
        if ($notDocumentRoot){
            return str_ireplace(Application::getDocumentRoot(), '', dirname(__DIR__));
        }else{
            return dirname(__DIR__);
        }
    }

    function DoInstall()
    {
        global $APPLICATION;
        $this->InstallFiles();
        $this->createServicesIblocks();
        $this->createPushTokenUserField();
        $this->InstallDB();
        $this->InstallEvents();
        RegisterModule(self::MODULE_ID);
    }

    function DoUninstall()
    {
        global $APPLICATION;
        UnRegisterModule(self::MODULE_ID);
        $this->UnInstallDB();
        $this->UnInstallFiles();
        $this->UnInstallEvents();
    }

}