<?
$arModuleVersion = [
	"VERSION" => "0.1.22",
	"VERSION_DATE" => "2024-08-01 12:12:59"
];
?>