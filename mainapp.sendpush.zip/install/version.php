<?
$arModuleVersion = [
	"VERSION" => "0.1.31",
	"VERSION_DATE" => "2024-10-22 14:32:36"
];
?>