<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

$arComponentDescription = array(
    "NAME" => "Firebase Scripts",
    "DESCRIPTION" => GetMessage('FB_COMPONENT_DESCRIPTION'),
    "PATH" => array(
        "ID" => "mainapp.sendpush",
        "NAME" => GetMessage('FB_COMPONENT_NAME'),
    ),
);
?>