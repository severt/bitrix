<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}
?>
<?php
if (COption::GetOptionString("mainapp.sendpush", "CREATE_JS_FILES") =="Y") {
    $APPLICATION->AddHeadScript("/firebase_subscribe.js");
    $APPLICATION->AddHeadScript("https://www.gstatic.com/firebasejs/7.14.5/firebase-app.js");
    $APPLICATION->AddHeadScript("https://www.gstatic.com/firebasejs/7.14.5/firebase-messaging.js");
?>
    <script>
        window.onload = initializeApp();
    </script>
<?php
}
?>