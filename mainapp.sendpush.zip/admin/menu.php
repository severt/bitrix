<?php
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_admin_before.php");

global $APPLICATION;
if ($APPLICATION->GetGroupRight("form") > "D") {

    $MODULE_ID = basename(dirname(__FILE__));
    $aMenu = array(
        "parent_menu" => "global_menu_services",
        "sort" => 100,
        "text" => GetMessage("MAINAPP_SENDPUSH_MENU_TEXT"),
        "title" => GetMessage("MAINAPP_SENDPUSH_MENU_TITLE"),
        "icon" => "form_menu_icon",
        "page_icon" => "form_page_icon",
        "items_id" => $MODULE_ID . "_items",
        "items" => array(),
    );

    $aMenu["items"][] = array(
        "text" => GetMessage("MAINAPP_SENDPUSH_MENU_ITEM_TEXT"),
        'url' => "/bitrix/admin/mainapp_send_push.php",
        "icon" => "forum_menu_icon",
        "page_icon" => "form_page_icon",
        "title" => GetMessage("MAINAPP_SENDPUSH_MENU_ITEM_TITLE")
    );
    $aMenu["items"][] = array(
        "text" => GetMessage('MAINAPP_SENDPUSH_MENU_SETTINGS_ITEM_TITLE'),
        'url' => "/bitrix/admin/settings.php?mid=mainapp.sendpush",
        "icon" => "sys_menu_icon",
        "page_icon" => "form_page_icon",
        "title" => GetMessage("MAINAPP_SENDPUSH_MENU_SETTINGS_ITEM_TITLE")
    );
    $aMenu["items"][] = array(
        "text" => GetMessage('MAINAPP_SENDPUSH_MENU_STATISTICS_TEXT'),
        'url' => "/bitrix/admin/mainapp_push_statistics.php",
        "icon" => "vote_menu_icon",
        "page_icon" => "form_page_icon",
        "title" => GetMessage('MAINAPP_SENDPUSH_MENU_STATISTICS_TEXT')
    );

    return $aMenu;
}

return false;
?>