<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/mainapp.sendpush/tools/push_statistics.php';
