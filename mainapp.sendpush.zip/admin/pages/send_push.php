<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/mainapp.sendpush/tools/send_push.php';
