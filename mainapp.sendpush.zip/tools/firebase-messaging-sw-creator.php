<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_before.php';

use Bitrix\Main\Loader;

$module_id = 'mainapp.sendpush';
Loader::IncludeModule($module_id);

$messagingSenderId = COption::GetOptionString($module_id, "FB_CONFIG_JSON_messagingSenderId");

ob_start();?>
importScripts('https://www.gstatic.com/firebasejs/3.6.8/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/3.6.8/firebase-messaging.js');

firebase.initializeApp({
messagingSenderId: '<?=$messagingSenderId;?>' 
});

const messaging = firebase.messaging();
<?php
$js = ob_get_clean() . PHP_EOL;
file_put_contents($_SERVER['DOCUMENT_ROOT'] . '/firebase-messaging-sw.js', $js);
?>
