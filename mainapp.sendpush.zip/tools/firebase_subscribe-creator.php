<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_before.php';

use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;

$module_id = 'mainapp.sendpush';
Loader::IncludeModule($module_id);
$apiKey = COption::GetOptionString($module_id, "FB_CONFIG_JSON_apiKey");
$authDomain = COption::GetOptionString($module_id, "FB_CONFIG_JSON_authDomain");
$databaseURL = COption::GetOptionString($module_id, "FB_CONFIG_JSON_databaseURL");
$projectId = COption::GetOptionString($module_id, "FB_CONFIG_JSON_projectId");
$storageBucket = COption::GetOptionString($module_id, "FB_CONFIG_JSON_storageBucket");
$messagingSenderId = COption::GetOptionString($module_id, "FB_CONFIG_JSON_messagingSenderId");
$appId = COption::GetOptionString($module_id, "FB_CONFIG_JSON_appId");
$measurementId = COption::GetOptionString($module_id, "FB_CONFIG_JSON_measurementId");
$vapidKey = COption::GetOptionString($module_id, "FB_CONFIG_JSON_vapidKey");

$firebaseConfig = json_encode(
    array(
        "apiKey" => $apiKey,
        "authDomain" => $authDomain,
        "databaseURL" => $databaseURL,
        "projectId" => $projectId,
        "storageBucket" => $storageBucket,
        "messagingSenderId" => $messagingSenderId,
        "appId" => $appId,
        "measurementId" => $measurementId
    )
);

ob_start();?>
function initializeApp() {

var firebaseConfig = <?=$firebaseConfig; ?>;
// Initialize Firebase

const app = firebase.initializeApp(firebaseConfig);
const messaging = firebase.messaging(app);

// Request permission to send notifications
Notification.requestPermission().then((permission) => {
if (permission === 'granted') {
console.log('Permission granted for notifications');

// Getting a token
messaging.getToken({ vapidKey: '<?=$vapidKey;?>' }).then((currentToken) => {
if (currentToken) {
console.log('Token received: ', currentToken);
// Saving the token on server
sendTokenToServer(currentToken);
} else {
console.log('No registration token available. Request permission to generate one.');
console.warn('Error get token');
setTokenSentToServer(false);
}
}).catch((err) => {
console.log('An error occurred while retrieving token: ', err);
});
} else {
console.log('Unable to get permission to notify.');
}
});

function sendTokenToServer(currentToken) {
if (!isTokenSentToServer(currentToken)) {
console.log('Send token to server...');
document.cookie = "MN_WEB_PUSH_TOKEN="+currentToken+";max-age=31556926";
var url = '/bitrix/tools/mainapp.sendpush/get_token_from_web.php';
$.post(url, {
token: currentToken
});

setTokenSentToServer(currentToken);
} else {
console.log('Token already sent');
}
}

function isTokenSentToServer(currentToken) {
return window.localStorage.getItem('sentFirebaseMessagingToken') == currentToken;
}

function setTokenSentToServer(currentToken) {
window.localStorage.setItem(
'sentFirebaseMessagingToken',
currentToken ? currentToken : ''
);
}
}
<?php
$js = ob_get_clean() . PHP_EOL;
file_put_contents($_SERVER['DOCUMENT_ROOT'] . '/firebase_subscribe.js', $js);
?>
