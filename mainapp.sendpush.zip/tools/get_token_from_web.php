<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_before.php';

use \Bitrix\Sale;
if (!empty($_COOKIE["MN_WEB_PUSH_TOKEN"])) {
    $pushToken = $_COOKIE["MN_WEB_PUSH_TOKEN"];
    if (CModule::IncludeModule("sale")) {
        $current_fuser = \Bitrix\Sale\Fuser::getId();

    }
    else {
        $current_fuser = $pushToken;
    }
    if (CModule::IncludeModule("mainapp.sendpush")) {
        GetAndSavePushToken::addTokenForUnknownUser($pushToken, $current_fuser);
    }
}