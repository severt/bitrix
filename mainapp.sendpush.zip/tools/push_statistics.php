<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_before.php';
use Bitrix\Main\UI\Extension;
use Bitrix\Main\Grid\Options;
use Bitrix\Main\UI\Filter;
use Bitrix\Main\Loader;
use Bitrix\Main\UI\PageNavigation;
$module_id = 'mainapp.sendpush';
Loader::includeModule('main');
Loader::includeModule($module_id);
global $APPLICATION;
$APPLICATION->SetTitle(GetMessage('MN_PUSH_STATISTICS'));

require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_after.php';

$gridId = 'mainapp_statistics_grid';

$gridOptions = new Options($gridId);
$filter = [];
$filterOption = new Bitrix\Main\UI\Filter\Options('mainapp_statistics_filter');
$filterData = $filterOption->getFilter([]);
foreach ($filterData as $k => $v) {
    $filter[$k] = $v;
}

// ������ ��������� ������ � ��������
$data = getData($filterData);

$sort = $gridOptions->GetSorting(['sort' => ['ID' => 'DESC'], 'vars' => ['by' => 'by', 'order' => 'order']]);
$nav = new PageNavigation($gridId);
$nav->allowAllRecords(true)
    ->setPageSize(10)
    ->initFromUri();

$gridData = [];
foreach ($data as $row) {
    $gridData[] = [
        'data' => $row,
        'actions' => [],
    ];
}
$arResult['GRID_ID'] = $gridId;
$arResult['HEADERS'] = [
    ['id' => 'DATE', 'name' => GetMessage('MN_DATE'), 'default' => true],
    ['id' => 'MANUALLY_SENT', 'name' => GetMessage('MN_MANUALLY_SENT'), 'default' => true],
    ['id' => 'FORGOTTEN_CARTS', 'name' => GetMessage('MN_FORGOTTEN_CARTS'), 'default' => true],
    ['id' => 'ORDER_STATUSES', 'name' => GetMessage('MN_ORDER_STATUSES'), 'default' => true],
    ['id' => 'SUMMARY', 'name' => GetMessage('MN_SUMMARY'), 'default' => true],
    ['id' => 'TARIF', 'name' => GetMessage('MN_TARIF'), 'default' => true],
    //['id' => 'CURRENT_PERIOD', 'name' => '', 'default' => true],
];

if (!empty($data)) {
    $totalCount = count($data);

    $arResult['ROWS'] = array_map(function ($item) {
        return ['data' => $item];
    }, $data);

    $arResult['NAV_OBJECT'] = $nav;
    $arResult['TOTAL_ROWS_COUNT'] = $totalCount;

    #echo "<pre>" . print_r($arResult, true) . "</pre>";
    // ���������� ������ ����������
    Extension::load("ui.buttons");
    Extension::load("ui.buttons.icons");
    Extension::load("ui.icons");
    Extension::load("ui.common");
    Extension::load("ui.alerts");
    Extension::load("ui.hint");
    Extension::load("ui.notification");
}

$APPLICATION->IncludeComponent('bitrix:main.ui.filter', '', [
    'FILTER_ID' => 'mainapp_statistics_filter',
    'GRID_ID' => 'mainapp_statistics_grid',
    'FILTER' => [
        [
            'id' => 'DATE',
            'name' => GetMessage('MN_FILTER_DATE'),
            'type' => 'date',
            'default' => true,
            "exclude" => [
                \Bitrix\Main\UI\Filter\DateType::TOMORROW,
                \Bitrix\Main\UI\Filter\DateType::NEXT_DAYS,
                \Bitrix\Main\UI\Filter\DateType::QUARTER,
                \Bitrix\Main\UI\Filter\DateType::LAST_60_DAYS,
                \Bitrix\Main\UI\Filter\DateType::LAST_90_DAYS,
                \Bitrix\Main\UI\Filter\DateType::NEXT_WEEK,
                \Bitrix\Main\UI\Filter\DateType::NEXT_MONTH,
                \Bitrix\Main\UI\Filter\DateType::MONTH,
                \Bitrix\Main\UI\Filter\DateType::YEAR,
            ]
        ]
    ],
    'ENABLE_LIVE_SEARCH' => false,
    'ENABLE_LABEL' => false
]);

$APPLICATION->IncludeComponent(
    'bitrix:main.ui.grid',
    '',
    [
        'GRID_ID' => $arResult['GRID_ID'],
        'COLUMNS' => $arResult['HEADERS'],
        'ROWS' => $arResult['ROWS'],
        'NAV_OBJECT' => $arResult['NAV_OBJECT'],
        'TOTAL_ROWS_COUNT' => $arResult['TOTAL_ROWS_COUNT'],
        'SORT' => $sort['sort'],
        'SORT_VARS' => $sort['vars'],
        'PAGE_SIZES' => [
            ['NAME' => '5', 'VALUE' => '5'],
            ['NAME' => '10', 'VALUE' => '10'],
            ['NAME' => '20', 'VALUE' => '20'],
            ['NAME' => '50', 'VALUE' => '50'],
            ['NAME' => '100', 'VALUE' => '100']
        ],
        'SHOW_PAGINATION' => true,
        'SHOW_SELECTED_COUNTER' => false,
        'SHOW_NAVIGATION_PANEL' => true,
        'SHOW_PAGESIZE' => true,
        'SHOW_ACTION_PANEL' => true,
        'ENABLE_COLLAPSIBLE_ROWS' => true,
        'ALLOW_COLUMNS_SORT' => true,
        'ALLOW_COLUMNS_RESIZE' => true,
        'ALLOW_HORIZONTAL_SCROLL' => true,
        'ALLOW_SORT' => true,
        'ALLOW_PIN_HEADER' => true,
        'AJAX_OPTION_HISTORY' => 'N',
        'ENABLE_ROW_COUNT' => true,
        'SHOW_ROW_COUNT' => true,
        'SHOW_ROW_CHECKBOXES' => false,
        'SHOW_ROW_ACTIONS_MENU' => false,
        'AJAX_MODE' => 'Y',
    ]
);

function getData($dateFilter) {
    #print_r($_REQUEST);
    #echo "<pre>" . print_r($dateFilter, true) . "</pre>";
    $module_id = 'mainapp.sendpush';
    // ����� �������� ���� ������ ��� ��������� ������ �� ����
    if (!empty(COption::GetOptionString($module_id, "TARIF_LOGIN")) && !empty(COption::GetOptionString($module_id, "TARIF_TOKEN"))) {
        $login = COption::GetOptionString($module_id, "TARIF_LOGIN");
        $token = COption::GetOptionString($module_id, "TARIF_TOKEN");

        $statistics_info = MainappBilling::GetStatisticsArray($login, $token);
        if (!empty($dateFilter)) {
            $dateFrom = new DateTime($dateFilter['DATE_from']);
            $dateTo = new DateTime($dateFilter['DATE_to']);
        }

        if ($statistics_info['STATISTICS'] && is_array($statistics_info['STATISTICS'])) {
            $i = 1;
            foreach ($statistics_info['STATISTICS'] as $statistic) {
                #echo $statistic['period_start'];
                // ������ ������
                $statisticsDate = new DateTime($statistic['date']);
                if (!empty($dateFrom) || !empty($dateTo)) {
                    if ($statisticsDate < $dateFrom || $statisticsDate > $dateTo) {
                        continue;
                    }
                }
                if (!empty($statistic['date'])) {
                    $data[] = array(
                        'ID' => $i,
                        'DATE' => $statistic['date'],
                        'MANUALLY_SENT' => $statistic['manual_push'],
                        'FORGOTTEN_CARTS' => $statistic['forgotten_basket_push'],
                        'ORDER_STATUSES' => $statistic['order_status_push'],
                        'SUMMARY' => $statistic['manual_push'] + $statistic['forgotten_basket_push'] + $statistic['order_status_push'],
                        'TARIF' => $statistic['tarif'],
                    );
                    $MANUALLY_SENT_SUM[] = $statistic['manual_push'];
                    $FORGOTTEN_CARTS_SUM[] = $statistic['forgotten_basket_push'];
                    $ORDER_STATUSES_SUM[] = $statistic['order_status_push'];
                }
                $i++;
            }
            if (is_array($data)) {
                $data[$i+1] = array(
                    'ID' => $i+1,
                    'DATE' => "<b>" . GetMessage('MN_PERIOD_SENT_SUM') . "</b>",
                    'MANUALLY_SENT' => array_sum($MANUALLY_SENT_SUM),
                    'FORGOTTEN_CARTS' => array_sum($FORGOTTEN_CARTS_SUM),
                    'ORDER_STATUSES' => array_sum($ORDER_STATUSES_SUM),
                    'SUMMARY' => array_sum($MANUALLY_SENT_SUM) + array_sum($FORGOTTEN_CARTS_SUM) + array_sum($ORDER_STATUSES_SUM),
                    'TARIF' => '',
                );
            }
        }
    }

    if (is_array($data)) {
        usort($data, function ($a, $b) {
            $dateA = DateTime::createFromFormat('d-m-Y', $a['DATE']);
            $dateB = DateTime::createFromFormat('d-m-Y', $b['DATE']);
            return $dateB <=> $dateA; // ���������� �� ��������
        });
    }
    return $data;
}
?>


