<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_before.php';

use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;

$module_id = 'mainapp.sendpush';
Loader::IncludeModule($module_id);
global $APPLICATION;
$APPLICATION->SetTitle(Loc::getMessage("MAINAPP_PAGE_TITLE"));
$sites = GetOptions::getSitesList();
$j= 1;
foreach ($sites as $key => $site) {
    $optionPrefix = "_" . $site["LID"];
    $login = COption::GetOptionString($module_id, "TARIF_LOGIN");
    $token = COption::GetOptionString($module_id, "TARIF_TOKEN");
    if (!empty($login && !empty($token))) {
        break;
    }
}
if (!MainappBilling::GetTarifActuality($login, $token)) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_after.php';
    echo GetMessage('TARIF_NOT_ACTIVE');
    exit();
}

###�������� ������ ����� ��� ��������
$filter = Array();
$rsGroups = CGroup::GetList(($by="c_sort"), ($order="asc"), $filter); // �������� ������
while($arGroup = $rsGroups->Fetch()) {
    $arGroups[] = array(
        "ID" => $arGroup["ID"],
        "NAME" => $arGroup["NAME"]
    );

}

$sites = GetOptions::getSitesList();

require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_after.php';
$action = $_GET["action"];

if ($action == "send") {
    #echo "<pre>" . print_r($_POST, true) . "</pre>";
    if ($_POST["use-filter"] == "filter") {
        $SendTokensFilter = new SendTokensFilter($_POST);
        $to = $SendTokensFilter->checkFilterData($_POST);
        if (empty($to)) {
            if (empty($_POST['filter']['profile']["user-group"])) {
                ?>
                <p><?= Loc::getMessage("NO_USER_GROUP_CHECKED") ?></p>
                <?php
            }
            ?>
            <p><?= Loc::getMessage("NO_USERS_FOUND") ?></p>
            <?php
        }
    }
    else {
        $to = '/topics/allDevices';
    }
    $pushLinkType = $_POST["offer-link-type"];
    $pushLinkValue = $_POST["search-" . $_POST["offer-link-type"]];
    if (!empty($pushLinkType && !empty($pushLinkValue))) {
        $clickAction = $pushLinkValue;
    }

    if (!empty($_POST['send-date-time'])) {
        GetAndSavePushToken::addPushMessageHistory($_POST["title"], $_POST["body"], $clickAction, $_POST["os"], $_POST["user-group"], $pushLinkValue, $_POST["site"], $_POST['send-date-time']);
        ?>
        <p><?= GetMessage('MN_SEND_PLANNED') . $_POST['send-date-time'] ?>.</p>
        <?php
    } else {
        $SendPushMessage = new MainappSendPushMessage();
        if (COption::GetOptionString(MODULE_ID, "USE_NEW_API_V1") != "Y" || $to == '/topics/allDevices') {
            $result = $SendPushMessage->buildAndSendPushDataFields($_POST["title"], $_POST["body"], $clickAction, $to);
        }
        else {
        #############################
        $tokens = array();
        foreach ($to as $token) {
            if (!empty($token)) {
                $tokens[] = $token;
            }
        }
        $uniqueTokens = array_unique($tokens);
        $arr_file = Array(
            "name" => $_FILES['image']['name'],
            "size" => $_FILES['image']['size'],
            "tmp_name" => $_FILES['image']['tmp_name'],
            "type" => $_FILES['image']['type'],
            "old_file" => "",
            "del" => "Y",
            "MODULE_ID" => $module_id
        );
        $fid = CFile::SaveFile($arr_file, "/".$module_id."/", false, false, "native_push");
        $image = CFile::GetPath($fid);
        if (!empty($image)) {
            $image = MainappSendPushMessage::getDomainFromServer() . $image;
        }
        ?>
        <style>
            #progressContainer {
                width: 100%;
                background-color: #ddd;
            }
            #progressBar {
                width: 0%;
                height: 30px;
                background-color: #4CAF50;
                text-align: center;
                line-height: 30px;
                color: white;
            }
        </style>
        <div id="progressContainer">
            <div id="progressBar">0%</div>
        </div>

        <script>
            const tokens = <?php echo json_encode(array_values($uniqueTokens)); ?>;
            const title = '<?=$_POST["title"];?>';
            const body = '<?=$_POST["body"];?>';
            const clickAction = '<?=$clickAction;?>';
            const image = '<?=$image;?>'
            let currentIndex = 0;

            function updateProgressBar(percentage) {
                const roundedPercentage = Math.round(percentage);
                const progressBar = document.getElementById('progressBar');
                progressBar.style.width = roundedPercentage + '%';
                if (roundedPercentage >= 100) {
                    progressBar.textContent = "<?= GetMessage('MN_ALL_MESSAGES_SENT');?>";
                } else {
                    progressBar.textContent = roundedPercentage + '%';
                }
            }

            function sendNotification(token) {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', '/bitrix/tools/mainapp.sendpush/send_notification.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onreadystatechange = function () {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        const response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            currentIndex++;
                            const percentage = (currentIndex / tokens.length) * 100;
                            updateProgressBar(percentage);
                            if (currentIndex % 30 === 0 && currentIndex < tokens.length) { //������ 30 ��������� ������ �����
                                setTimeout(function() {
                                    sendNotification(tokens[currentIndex]);
                                }, 5000); // ����� � 5 ������
                            } else if (currentIndex < tokens.length) {
                                sendNotification(tokens[currentIndex]);
                            }
                        } else {
                            alert('send error: ' + (response.message || 'error'));
                        }
                    }
                };
                xhr.send('token=' + encodeURIComponent(token) + '&title=' + encodeURIComponent(title) + '&body=' + encodeURIComponent(body) + '&clickAction=' + encodeURIComponent(clickAction) + '&image=' + encodeURIComponent(image));
            }

            sendNotification(tokens[currentIndex]);
        </script>

        <?php
        }
        #############################
        $message_success = "Y";
        $message = json_decode($result, true);

        if (COption::GetOptionString(MODULE_ID, "USE_NEW_API_V1") != "Y") {
            $message_success = "N";
            if ($message["message_id"] > 0 || $message["success"] > 0) {
                $message_success = "Y";
            }
        }
        if ($message_success == "Y") {
            GetAndSavePushToken::addPushMessageHistory($_POST["title"], $_POST["body"], $clickAction, $_POST["os"], $_POST["user-group"], $pushLinkValue, $_POST["site"]);
            MainappBilling::setPlusPushCount($login, $token, 'manual_push');
            if (COption::GetOptionString(MODULE_ID, "USE_NEW_API_V1") != "Y" || $to == '/topics/allDevices') {
            ?>
                <p><?= GetMessage("PUSH_SUCCESS") ?>.</p>
            <?
            }
        }
        else {
            if (COption::GetOptionString(MODULE_ID, "USE_NEW_API_V1") != "Y" || $to == '/topics/allDevices') {
            ?>
            <p><?= GetMessage("PUSH_FAIL") ?></p>
            <?
            #echo "<pre>" . print_r($message, true) . "</pre>"; //��������� �� ������
            }
        }
    }
    ?>
    <p><a href="mainapp_send_push.php"><?=GetMessage("PUSH_BACK")?></a></p>
    <?php
}
else {
    ?>
    <style>
        .search_box {
            position: relative;
        }
        .search_box input[type="text"] {
            display: block;
            width: 100%;
            height: 35px;
            line-height: 35px;
            padding: 0;
            margin: 0;
            border: 1px solid #fd4836;
            outline: none;
            overflow: hidden;
            border-radius: 4px;
            background-color: rgb(255, 255, 255);
            text-indent: 15px;
            font-size: 14px;
            color: #222;
        }
        .search_box input[type="submit"] {
            display: inline-block;
            width: 17px;
            height: 17px;
            padding: 0;
            margin: 0;
            border: 0;
            outline: 0;
            overflow: hidden;
            text-indent: -999px;
            background: url(/bitrix/modules/mainapp.sendpush/img/icons/search.png) 0 0 no-repeat;
            position: absolute;
            top: 9px;
            right: 16px;
        }

        /* ����� ��� ������ � ������������ */
        .search_result {
            position: absolute;
            top: 100%;
            left: 0;
            border: 1px solid #ddd;
            background: #fff;
            padding: 10px;
            z-index: 9999;
            box-shadow: 0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22);
        }
        .hide{
            display:none!important;
        }
        .hide.show{
            display: block!important;
        }
        h2, h3, h4 {
            color: #86ad00;
        }
        hr {
            border-top: 1px solid #86ad50;
        }
        input,
        input[type="radio"] + label,
        input[type="checkbox"] + label:before,
        select option,
        select {
            width: 90%;
            padding: 1em;
            line-height: 1.4;
            background-color: #f9f9f9;
            border: 1px solid #e5e5e5;
            border-radius: 3px;
            -webkit-transition: 0.35s ease-in-out;
            -moz-transition: 0.35s ease-in-out;
            -o-transition: 0.35s ease-in-out;
            transition: 0.35s ease-in-out;
            transition: all 0.35s ease-in-out;
        }
        input:focus {
            outline: 0;
            border-color: #bd8200;
        }
        input:focus + .input-icon i {
            color: #f0a500;
        }
        input:focus + .input-icon:after {
            border-right-color: #f0a500;
        }
        input[type="radio"] {
            display: none;
        }
        input[type="radio"] + label,
        select {
            display: inline-block;
            width: 43%;
            text-align: center;
            float: left;
            border-radius: 0;
        }
        input[type="radio"] + label:first-of-type {
            border-top-left-radius: 3px;
            border-bottom-left-radius: 3px;
        }
        input[type="radio"] + label:last-of-type {
            border-top-right-radius: 3px;
            border-bottom-right-radius: 3px;
        }
        input[type="radio"] + label i {
            padding-right: 0.4em;
        }
        input[type="radio"]:checked + label,
        input:checked + label:before,
        select:focus,
        select:active {
            background-color: #f0a500;
            color: #212121;
            border-color: #bd8200;
        }
        input[type="checkbox"] {
            display: none;
        }
        input[type="checkbox"] + label {
            position: relative;
            display: block;
            padding-left: 1.6em;
            padding-bottom: 1em;
            padding-top: 0.2em;
        }
        input[type="checkbox"] + label:before {
            position: absolute;
            top: 0.2em;
            left: 0;
            display: block;
            width: 1em;
            height: 1em;
            padding: 0;
            content: "";
        }
        input[type="checkbox"] + label:after {
            position: absolute;
            top: 0.45em;
            left: 0.2em;
            font-size: 0.8em;
            color: #fff;
            opacity: 0;
            font-family: FontAwesome;
            content: "\f00c";
        }
        input:checked + label:after {
            opacity: 1;
        }
        select {
            height: 3.4em;
            line-height: 2;
        }
        select:first-of-type {
            border-top-left-radius: 3px;
            border-bottom-left-radius: 3px;
        }
        select:last-of-type {
            border-top-right-radius: 3px;
            border-bottom-right-radius: 3px;
        }
        select:focus,
        select:active {
            outline: 0;
        }
        select option {
            background-color: #f0a500;
            color: #212121;
        }
        .input-group {
            margin-bottom: 1em;
            zoom: 1;
        }
        .input-group:before,
        .input-group:after {
            content: "";
            display: table;
        }
        .input-group:after {
            clear: both;
        }
        .input-group-icon {
            position: relative;
            display: flex;
        }
        .input-group-icon input {
            padding-left: 4.4em;
        }
        .input-group-icon .input-icon {
            position: absolute;
            top: 0;
            left: 0;
            width: 3.4em;
            height: 3.4em;
            line-height: 3.4em;
            text-align: center;
            pointer-events: none;
        }
        .input-group-icon .input-icon:after {
            position: absolute;
            top: 0.6em;
            bottom: 0.6em;
            left: 3.4em;
            display: block;
            border-right: 1px solid #e5e5e5;
            content: "";
            -webkit-transition: 0.35s ease-in-out;
            -moz-transition: 0.35s ease-in-out;
            -o-transition: 0.35s ease-in-out;
            transition: 0.35s ease-in-out;
            transition: all 0.35s ease-in-out;
        }
        .input-group-icon .input-icon i {
            -webkit-transition: 0.35s ease-in-out;
            -moz-transition: 0.35s ease-in-out;
            -o-transition: 0.35s ease-in-out;
            transition: 0.35s ease-in-out;
            transition: all 0.35s ease-in-out;
        }
        .container {
            padding: 1em 3em 2em 3em;
            background-color: #f8f8f9;
            border-radius: 4.2px;
            box-shadow: 0px 3px 10px -2px rgba(0, 0, 0, 0.2);
        }
        .row {
            zoom: 1;
        }
        .row:before,
        .row:after {
            content: "";
            display: table;
        }
        .row:after {
            clear: both;
        }
        .col-half {
            padding-right: 0px;
            float: left;
            width: 50%;
        }
        .col-half:last-of-type {
            padding-right: 0;
        }
        .col-third {
            padding-right: 10px;
            float: left;
            width: 33.33333333%;
        }
        .col-third:last-of-type {
            padding-right: 0;
        }
        @media only screen and (max-width: 540px) {
            .col-half {
                width: 100%;
                padding-right: 0;
            }
        }
    </style>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
    <!--<link rel="stylesheet" href="/bitrix/modules/mainapp.sendpush/css/style.css">-->
    <script src="https://cdn.jsdelivr.net/npm/air-datepicker@3.3.5/air-datepicker.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/air-datepicker@3.3.5/air-datepicker.min.css">

    <div class="container">
        <form enctype="multipart/form-data" method="post" action="mainapp_send_push.php?action=send">
            <div class="row">
                <h3><?= Loc::getMessage("PUSH_SEND_H4") ?></h3>
                <div class="input-group input-group-icon">
                    <input required type="textarea" name="title" placeholder="<?= Loc::getMessage("PUSH_TITLE") ?>"/>
                    <div class="input-icon"><i class="fa fa-font" aria-hidden="true"></i></div>
                </div>
                <div class="input-group input-group-icon">
                    <input required name="body" type="textarea" placeholder="<?= Loc::getMessage("PUSH_TEXT") ?>"/>
                    <div class="input-icon"><i class="fa fa-comment-o" aria-hidden="true"></i></div>
                </div>
            </div>
            <hr>
            <div class="row">
                <h3><?= Loc::getMessage("PUSH_SEND_TO_FILTER") ?></h3>
                <div class="input-group" id="send-to">
                    <input id="all" type="radio" name="use-filter" class="use-filter" value="all" checked="true"/>
                    <label for="all"><span><i class="fa fa-users" aria-hidden="true"></i><?= Loc::getMessage("MN_PWA_SEND_TO_ALL") ?></span></label>
                    <input id="filter-on" type="radio" name="use-filter" class="use-filter" value="filter"/>
                    <label for="filter-on"> <span><i class="fa fa-filter" aria-hidden="true"></i><?= Loc::getMessage("MN_PWA_SEND_BY_FILTER") ?></span></label>
                </div>
            </div>
            <div class="row" id="filter" style="display:none;">
                <div class="col-half">
                    <h4><?= Loc::getMessage('PUSH_SEND_TO_SITE') ?></h4>
                    <div class="input-group">
                        <?php foreach ($sites as $site) {?>
                            <input id="<?=$site["LID"];?>" type="checkbox" name="filter[site][]" value="<?=$site["LID"];?>"/>
                            <label for="<?=$site["LID"];?>"><?=$site["NAME"];?></label>
                        <?php }?>
                    </div>
                </div>
                <div class="col-half">
                    <h4><?= Loc::getMessage("PUSH_SEND_TO_OS") ?></h4>
                    <div class="input-group">
                        <input id="ios" type="checkbox" name="filter[profile][os][]" value="ios"/>
                        <label for="ios">IOS</label>
                        <input id="android" type="checkbox" name="filter[profile][os][]" value="android"/>
                        <label for="android">Android</label>
                        <input id="windows" type="checkbox" name="filter[profile][os][]" value="windows"/>
                        <label for="windows">Windows</label>
                        <input id="apple" type="checkbox" name="filter[profile][os][]" value="apple"/>
                        <label for="apple">Apple</label>
                    </div>
                </div>
                <div class="col-half">
                    <h4><?= Loc::getMessage("PUSH_SEND_TO_USER_GROUP") ?></h4>
                    <div class="input-group">
                        <?php foreach ($arGroups as $arGroup) {?>
                            <input id="<?=$arGroup["ID"]?>" type="checkbox" name="filter[profile][user-group][]" value="<?=$arGroup["ID"]?>"/>
                            <label for="<?=$arGroup["ID"]?>"><?=$arGroup["NAME"]?></label>
                        <?php }?>
                    </div>
                </div>
                <div class="col-half">
                    <h4><?= Loc::getMessage('PUSH_SEND_TO_USER_PROPS') ?></h4>
                    <h5><?= Loc::getMessage('PUSH_SEND_TO_USER_GENDER') ?></h5>
                    <div class="input-group">
                        <input id="male" type="checkbox" name="filter[profile][gender][]" value="male"/>
                        <label for="male"><?= Loc::getMessage('PUSH_SEND_TO_USER_GENDER_MALE') ?></label>
                        <input id="female" type="checkbox" name="filter[profile][gender][]" value="female"/>
                        <label for="female"><?= Loc::getMessage('PUSH_SEND_TO_USER_GENDER_FEMALE') ?></label>
                    </div>
                </div>
                <div class="col-half">
                    <h4><?= Loc::getMessage('PUSH_SEND_TO_USER_ORDERS') ?></h4>
                    <div class="input-group">
                        <h5><?= Loc::getMessage('PUSH_SEND_TO_USER_ORDERS_COUNT') ?></h5>
                        <div class="search_box input-group input-group-icon count">
                            <input style="width: 200px" id="orders_count" type="number" name="filter[order][orders_count]" placeholder="<?= Loc::getMessage('PUSH_SEND_TO_USER_ORDERS_COUNT')?>" value=""/>
                            <div class="input-icon"><i class="fa fa-list-ol" aria-hidden="true"></i></div>
                        </div>
                    </div>
                    <div class="input-group">
                        <h5><?= Loc::getMessage('PUSH_SEND_TO_USER_ORDERS_SUM') ?></h5>
                        <input placeholder="<?= Loc::getMessage('PUSH_SEND_TO_USER_ORDERS_SUM_MIN') ?>" class="col-half" style="width: 42%" id="orders_sum_min" type="textarea" name="filter[order][order_sum][orders_sum_min]" value=""/>
                        <input placeholder="<?= Loc::getMessage('PUSH_SEND_TO_USER_ORDERS_SUM_MAX') ?>" class="col-half" style="width: 42%; margin-left: 6%" id="orders_sum_max" type="textarea" name="filter[order][order_sum][orders_sum_max]" value=""/>
                    </div>
                    <div class="input-group">
                        <h5><?= Loc::getMessage('PUSH_SEND_TO_USER_ORDERS_TIME') ?></h5>
                        <div class="search_box input-group input-group-icon interval">
                            <input placeholder="<?= Loc::getMessage('PUSH_SEND_TO_USER_ORDERS_DATE_INTERVAL') ?>" class="col-half" style="width: 42%" id="orders_time_interval" type="textarea" name="filter[order][orders_time_interval]" value=""/>
                            <div class="input-icon"><i class="fa fa-calendar" aria-hidden="true"></i></div>
                        </div>
                    </div>
                    <div class="input-group">
                        <h5><?= Loc::getMessage('PUSH_SEND_TO_USER_ORDERS_PRODUCT') ?></h5>
                        <div class="search_box input-group input-group-icon product">
                            <input id="orders_product" type="textarea" name="filter[order][orders_product]" placeholder="<?= Loc::getMessage("PUSH_MESSAGE_OFFER_PLACEHOLDER") ?>" value=""/>
                            <div class="input-icon"><i class="fa fa-shopping-cart" aria-hidden="true"></i></div>
                        </div>
                        <div class="row">
                            <div id="search_box-result-orders-offer"></div>
                        </div>
                    </div>
                </div>
                <div style="clear: both"></div>
                <div class="col">
                    <h4><?= Loc::getMessage('PUSH_SEND_TO_USER') ?></h4>
                    <div class="search_box input-group input-group-icon user">
                        <input type="textarea" name="filter[profile][search-user]" id="search-user" placeholder="<?=Loc::getMessage('ENTER_LOGIN_OR_EMAIL');?>">
                        <div class="input-icon"><i class="fa fa-link" aria-hidden="true"></i></div>

                    </div>
                    <div class="row">
                        <div id="search_box-result-user"></div>
                    </div>
                </div>
            </div>
            <hr>

            <div class="row">
                <h3><?= Loc::getMessage("PUSH_IMAGE") ?></h3>
                <div class="input-group input-group-icon">
                    <input type="file" name="image" data-buttonText="�������" placeholder=""/>
                    <div class="input-icon"><i class="fa fa-picture-o" aria-hidden="true"></i></div>
                </div>
            </div>

            <div class="row" style="display: none">
                <h3><?= Loc::getMessage("PUSH_MESSAGE_LINK_TYPE") ?></h3>
                <div class="input-group">
                    <select id="offer-link" name="offer-link-type">
                        <!--<option value="offer" selected="selected"><?= Loc::getMessage("PUSH_MESSAGE_LINK_OFFER") ?></option>
                        <option value="category"><?= Loc::getMessage("PUSH_MESSAGE_LINK_CATEGORY") ?></option>
                        <option value="news"><?= Loc::getMessage("PUSH_MESSAGE_LINK_NEWS") ?></option>
                        <option value="article"><?= Loc::getMessage("PUSH_MESSAGE_LINK_ARTICLE") ?></option>-->
                        <option value="link"><?= Loc::getMessage("PUSH_MESSAGE_LINK_URL") ?></option>
                    </select>
                </div>
            </div>
            <div class="row">
                <h3><?= Loc::getMessage("PUSH_LINK") ?></h3>
                <!--
                <div class="search_box input-group input-group-icon hide offer" id="search_box_offer">
                    <input type="textarea" name="search-offer" id="search-offer" placeholder="<?= Loc::getMessage("PUSH_MESSAGE_OFFER_PLACEHOLDER") ?>">
                    <div class="input-icon"><i class="fa fa-link" aria-hidden="true"></i></div>
                    <div id="search_box-result-offer"></div>
                </div>
                <div class="search_box input-group input-group-icon hide category">
                    <input type="textarea" name="search-category" id="search-category" placeholder="<?= Loc::getMessage("PUSH_MESSAGE_CATEGORY_PLACEHOLDER") ?>">
                    <div class="input-icon"><i class="fa fa-link" aria-hidden="true"></i></div>
                    <div id="search_box-result-category"></div>
                </div>
                <div class="search_box input-group input-group-icon hide news">
                    <input type="textarea" name="search-news" id="search-news" placeholder="<?= Loc::getMessage("PUSH_MESSAGE_NEWS_PLACEHOLDER") ?>">
                    <div class="input-icon"><i class="fa fa-link" aria-hidden="true"></i></div>
                    <div id="search_box-result-news"></div>
                </div>
                <div class="search_box input-group input-group-icon hide article">
                    <input type="textarea" name="search-article" id="search-article" placeholder="<?= Loc::getMessage("PUSH_MESSAGE_ARTICLE_PLACEHOLDER") ?>">
                    <div class="input-icon"><i class="fa fa-link" aria-hidden="true"></i></div>
                    <div id="search_box-result-article"></div>
                </div>
                -->
                <div class="search_box input-group input-group-icon hide link">
                    <input type="textarea" name="search-link" id="search-link" placeholder="<?= Loc::getMessage("PUSH_MESSAGE_LINK_PLACEHOLDER") ?>">
                    <div class="input-icon"><i class="fa fa-link" aria-hidden="true"></i></div>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <h4><?=GetMessage('MN_SEND_CALENDAR')?></h4>
                    <div class="input-group">
                        <input id="send-now" type="radio" name="send-date" value="send-now" class="send-date" checked="true">
                        <label for="send-now"><?= GetMessage('MN_SEND_NOW') ?></label>
                        <!--<input id="send-after" type="radio" name="send-date" value="send-after" class="send-date">
                        <label for="send-after"><?= GetMessage('MN_SEND_AFTER') ?></label>-->
                    </div>
                    <div id="calendar" class="search_box input-group input-group-icon interval" style="display:none;">
                        <input placeholder="<?= GetMessage('MN_SEND_CHOOSE_DATE')?>" class="col" id="send-calendar" type="textarea" name="send-date-time" value="" autocomplete="off">
                        <div class="input-icon"><i class="fa fa-calendar" aria-hidden="true"></i></div>
                    </div>
                </div>
            </div>

            <input class="adm-btn adm-btn-save" style="width: auto" type="submit" name="update" value="<?= Loc::getMessage("PUSH_SEND") ?>">
        </form>
    </div>
<?php }?>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="/bitrix/modules/mainapp.sendpush/js/script.js"></script>
<script>
    new AirDatepicker('#orders_time_interval', {
        range: true,
        multipleDatesSeparator: ' - '
    })
</script>
<script>
    new AirDatepicker('#send-calendar', {
        position: 'top left',
        range: false,
        timepicker: true,
        dateTimeSeparator: " ",
        timeFormat: 'HH:mm:00',
        multipleDatesSeparator: ' - '
    })
</script>
<script>
    $(document).ready(function() {
        $(".use-filter").change(function() {

            if ($('#filter-on').prop("checked")) {
                $('#filter').fadeIn(300);
            } else {
                $('#filter').fadeOut(300);
            }

        });
        $(".send-date").change(function() {

            if ($('#send-after').prop("checked")) {
                $('#calendar').fadeIn(300);
            } else {
                $('#calendar').fadeOut(300);
            }

        });
    });
</script>
<script>
    window.addEventListener('DOMContentLoaded', function() {
        var select = document.querySelector('#offer-link'),
            hide = document.querySelectorAll('.hide');
        function change()
        {
            [].forEach.call(hide, function(el) {
                var add = el.classList.contains(select.value) ? "add" : "remove"
                el.classList[add]('show');
                //document.getElementById('search-offer').value = '';
                //document.getElementById('search-category').value = '';
                //document.getElementById('search-news').value = '';
                //ocument.getElementById('search-article').value = '';
                document.getElementById('orders-product').value = '';
                document.getElementById('search-link').value = '';
            });
        }
        select.addEventListener('change', change);
        change()
    });
</script>
<script>
    $(document).ready(function() {
        //var $result_offer = $('#search_box-result-offer');
        //var $result_category = $('#search_box-result-category');
        //var $result_news = $('#search_box-result-news');
        //var $result_article = $('#search_box-result-article');
        var $result_offer = $('#search_box-result-orders-offer');
        var $result_user = $('#search_box-result-user');
        $('#orders_product').on('keyup', function(){
            var search = $(this).val();
            if ((search != '') && (search.length > 1)){
                $.ajax({
                    type: "POST",
                    url: "/bitrix/tools/mainapp.sendpush/ajax_link.php",
                    data: {'search_offer': search},
                    success: function(msg){
                        $result_offer.html(msg);
                        if(msg != ''){
                            $result_offer.fadeIn();
                        } else {
                            $result_offer.fadeOut(100);
                        }
                    }
                });
            } else {
                $result_offer.html('');
                $result_offer.fadeOut(100);
            }
        });
        /*
        $('#search-offer').on('keyup', function(){
            var search = $(this).val();
            if ((search != '') && (search.length > 1)){
                $.ajax({
                    type: "POST",
                    url: "/bitrix/tools/mainapp.sendpush/ajax_link.php",
                    data: {'search_offer': search},
                    success: function(msg){
                        $result_offer.html(msg);
                        if(msg != ''){
                            $result_offer.fadeIn();
                        } else {
                            $result_offer.fadeOut(100);
                        }
                    }
                });
            } else {
                $result_offer.html('');
                $result_offer.fadeOut(100);
            }
        });

        $('#search-category').on('keyup', function(){
            var search = $(this).val();
            if ((search != '') && (search.length > 1)){
                $.ajax({
                    type: "POST",
                    url: "/bitrix/tools/mainapp.sendpush/ajax_link.php",
                    data: {'search_category': search},
                    success: function(msg){
                        $result_category.html(msg);
                        if(msg != ''){
                            $result_category.fadeIn();
                        } else {
                            $result_category.fadeOut(100);
                        }
                    }
                });
            } else {
                $result_category.html('');
                $result_category.fadeOut(100);
            }
        });

        $('#search-news').on('keyup', function(){
            var search = $(this).val();
            if ((search != '') && (search.length > 1)){
                $.ajax({
                    type: "POST",
                    url: "/bitrix/tools/mainapp.sendpush/ajax_link.php",
                    data: {'search_news': search},
                    success: function(msg){
                        $result_news.html(msg);
                        if(msg != ''){
                            $result_news.fadeIn();
                        } else {
                            $result_news.fadeOut(100);
                        }
                    }
                });
            } else {
                $result_news.html('');
                $result_news.fadeOut(100);
            }
        });

        $('#search-article').on('keyup', function(){
            var search = $(this).val();
            if ((search != '') && (search.length > 1)){
                $.ajax({
                    type: "POST",
                    url: "/bitrix/tools/mainapp.sendpush/ajax_link.php",
                    data: {'search_article': search},
                    success: function(msg){
                        $result_article.html(msg);
                        if(msg != ''){
                            $result_article.fadeIn();
                        } else {
                            $result_article.fadeOut(100);
                        }
                    }
                });
            } else {
                $result_article.html('');
                $result_article.fadeOut(100);
            }
        });
        */

        $('#search-user').on('keyup', function(){
            var search = $(this).val();
            if ((search != '') && (search.length > 1)){
                $.ajax({
                    type: "POST",
                    url: "/bitrix/tools/mainapp.sendpush/ajax_link.php",
                    data: {'search_user': search},
                    success: function(msg){
                        $result_user.html(msg);
                        if(msg != ''){
                            $result_user.fadeIn();
                        } else {
                            $result_user.fadeOut(100);
                        }
                    }
                });
            } else {
                $result_user.html('');
                $result_user.fadeOut(100);
            }
        });
        /*
        $(document).on('click', '.search_result-name a', function(){
            $('#search-offer').val($(this).text());
            $result_offer.fadeOut(100);
            return false;
        });

        $(document).on('click', '.search_result-name a', function(){
            $('#search-category').val($(this).text());
            $result_category.fadeOut(100);
            return false;
        });

        $(document).on('click', '.search_result-name a', function(){
            $('#search-news').val($(this).text());
            $result_news.fadeOut(100);
            return false;
        });

        $(document).on('click', '.search_result-name a', function(){
            $('#search-article').val($(this).text());
            $result_article.fadeOut(100);
            return false;
        });
         */



        $(document).on('click', '.search_result-name-user a', function(){
            $('#search-user').val($(this).text());
            $result_user.fadeOut(100);
            return false;
        });

        $(document).on('click', '.search_result-name-offer a', function(){
            $('#orders_product').val($(this).text());
            $result_offer.fadeOut(100);
            return false;
        });
    });
</script>