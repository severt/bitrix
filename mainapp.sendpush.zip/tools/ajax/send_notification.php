<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_before.php';
use Bitrix\Main\Loader;
$module_id = 'mainapp.sendpush';
Loader::IncludeModule($module_id);

// �������� �������� �����������
function sendPushNotification($token, $apiKey, $url, $title, $body, $clickAction, $image) {
    // ����� ������ ���� �������� ����� API
    $headers = [
        'Authorization: Bearer ' . $apiKey,
        'Content-Type: application/json'
    ];

    $notification = [
        "message" => [
            'token' => $token,
            "notification" => [
                "title" => $title,
                "body" => $body
            ],
            "android" => [
                "notification" => [
                    "icon" => "icon_resource_name",
                    "color" => "#rrggbb",
                    "image" => $image
                ]
            ],
            "apns" => [
                "payload" => [
                    "aps" => [
                        "alert" => [
                            "title" => $title,
                            "body" => $body
                        ],
                        "badge" => 1
                    ]
                ],
                "fcm_options" => [
                    "image" => $image
                ]
            ],
            "webpush" => [
                "headers" => [
                    "TTL" => "4500"
                ],
                "notification" => [
                    "badge" => "badge_url",
                    "image" => $image
                ]
            ],
            "fcm_options" => [
                "analytics_label" => "campaign_name"
            ],
            "data" => [
                "redirectUrl" => $clickAction
            ]
        ]
    ];

    #########################################
    #$file = $_SERVER["DOCUMENT_ROOT"] . "/bitrix/catalog_export/log_mainapp_push.txt";
    #file_put_contents($file, json_encode($notification));
    #########################################

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($notification));
    $result = curl_exec($ch);
    curl_close($ch);
    usleep(50000); // �������� ��� �������� ������� ��������

    return true;
}

// ��������� ������ �� �������
$token = isset($_POST['token']) ? $_POST['token'] : null;

$access_token = "";
$MainappSendPushMessage = new MainappSendPushMessage();
$push_data = $MainappSendPushMessage->getPushKey();
$apiKey = $push_data['ACCESS_TOKEN'];
$url = $push_data['PUSH_SEND_URL'];
$title = $_POST['title'];
$body = $_POST['body'];
$clickAction = $_POST['clickAction'];
$image = $_POST['image'];

if ($token) {
    $result = sendPushNotification($token, $apiKey, $url, $title, $body, $clickAction, $image);
    echo json_encode(['success' => $result]);
} else {
    echo json_encode(['success' => false, 'message' => 'No token provided']);
}
?>