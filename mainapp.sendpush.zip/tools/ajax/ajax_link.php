<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_before.php';

use Bitrix\Main\Localization\Loc;

CModule::IncludeModule('iblock');
$arSelect = Array("ID", "NAME");
if (!empty($_POST["search_offer"])) {
    $searchIn = "offer";
}
if (!empty($_POST["search_category"])) {
    $searchIn = "category";
}
if (!empty($_POST["search_news"])) {
    $searchIn = "news";
}
if (!empty($_POST["search_article"])) {
    $searchIn = "article";
}
if (!empty($_POST["search_user"])) {
    $searchIn = "user";
}
switch ($searchIn) {
    case "offer":
        $iblockId = 2;
        $arFilter = Array(
            "IBLOCK_ID"=> $iblockId,
            "ACTIVE" => "Y",
            array(
                "LOGIC" => "OR",
                array("NAME" => '%' . $_POST["search_" . $searchIn] . '%'),
                array("ID" => $_POST["search_" . $searchIn])
            )
        );
        $res = CIBlockElement::GetList(Array(), $arFilter, false, Array(), $arSelect);
        break;
    case "category":
        $iblockId = 2;
        $arSelect = array("ID", "NAME");
        $arFilter = array(
            'IBLOCK_ID' => $iblockId,
            'ACTIVE'=> 'Y'
        );

        $arFilter["NAME"] = '%' . $_POST["search_" . $searchIn] . '%';

        $res = CIBlockSection::GetList(Array("SORT" => "ASC"), $arFilter, true);
        break;
    case "news":
        $iblockId = 1;
        $arFilter = Array(
            "IBLOCK_ID"=> $iblockId,
            "ACTIVE" => "Y",
            array(
                "LOGIC" => "OR",
                array("NAME" => '%' . $_POST["search_" . $searchIn] . '%'),
                array("ID" => $_POST["search_" . $searchIn])
            )
        );
        $res = CIBlockElement::GetList(Array(), $arFilter, false, Array(), $arSelect);
        break;

    case "article":
        $iblockId = 1;
        $arFilter = Array(
            "IBLOCK_ID"=> $iblockId,
            "ACTIVE" => "Y",
            array(
                "LOGIC" => "OR",
                array("NAME" => '%' . $_POST["search_" . $searchIn] . '%'),
                array("ID" => $_POST["search_" . $searchIn])
            )
        );
        $res = CIBlockElement::GetList(Array(), $arFilter, false, Array(), $arSelect);
        break;

    case "user":
        $filter = Array (
            "LOGIN" => '%' . $_POST["search_" . $searchIn] . '%'
        );
        $res = CUser::GetList( $by,$sort, $filter);
        break;
}

if ($searchIn == "user") {
    while($arUser = $res->Fetch()){
        $result[] = $arUser["LOGIN"] . " (ID: " . $arUser["ID"] . ")";
    }
    if ($result) {
        $i = 0;
        ?>
        <div class="search_result_<?=$searchIn;?>">
            <table>
                <? foreach ($result as $item) {?>
                    <tr>
                        <td class="search_result-name-<?=$searchIn;?>">
                            <a href="#"><?php echo $item; ?></a>
                        </td>
                    </tr>
                    <?
                    $i++;
                    if ($i > 10) {
                        break;
                    }
                }?>
            </table>
        </div>
        <?
    }
}
else {
    while($ob = $res->GetNextElement())
    {
        $arFields = $ob->GetFields();
        $result[] = $arFields["NAME"] . " (ID: " . $arFields["ID"] . ")";
    }
    if ($result) {
        $i = 0;
        ?>
        <div class="search_result_<?=$searchIn;?>">
            <table>
                <? foreach ($result as $item) {?>
                    <tr>
                        <td class="search_result-name-<?=$searchIn;?>">
                            <a href="#"><?php echo $item; ?></a>
                        </td>
                    </tr>
                    <?
                    $i++;
                    if ($i > 10) {
                        break;
                    }
                }?>
            </table>
        </div>
        <?
    }
    else {
        ?>
        <div class="search_result_<?=$searchIn;?>">
            <table>
                <tr>
                    <td class="search_result-name-<?=$searchIn;?>">
                        <span><?= Loc::getMessage("NO_RESULT") ?></span>
                    </td>
                </tr>
            </table>
        </div>
        <?
    }
}
?>