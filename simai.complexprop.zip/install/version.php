<?php
$arModuleVersion = array(
    "VERSION" => "1.5.0",
    "VERSION_DATE" => "2024-05-19 00:00:00"
);
?>