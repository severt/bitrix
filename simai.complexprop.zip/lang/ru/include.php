<?php
global $MESS;

$MESS['SMCP_COMPLEX_PROP'] = 'Составное свойство';
$MESS['SMCP_COMPLEX_PROP_LIST'] = 'составное свойство';
$MESS['SMCP_SELECT_SUBPROPS'] = 'Выбор обычных свойств для составного свойства';
$MESS['SMCP_PROP_NUM'] = 'Свойство №';
$MESS['SMCP_PROP_REQ'] = 'обязательное';
$MESS['SMCP_DEL_CVAL'] = 'Удалить это составное значение';
$MESS['SMCP_ADD_CVAL'] = 'Добавить составное значение';
$MESS['SMCP_REQ_EMPTY'] = 'Для составного значения не задано необходимое свойство ';
?>