<?php

global $MESS;

$MESS['SMCP_MODULE_NAME'] = 'SIMAI: Составное свойство';
$MESS['SMCP_MODULE_DESCRIPTION'] = 'Возможность использовать составное свойство для инфоблока';
?>