<?php
$arModuleVersion = array(
	"VERSION" => "1.0.0",
	"VERSION_DATE" => "2023-09-30 14:00:00"
);