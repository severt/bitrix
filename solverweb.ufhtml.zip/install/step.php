<?php
/** @global CMain $APPLICATION */
use Bitrix\Main\Localization\Loc;

if (!check_bitrix_sessid())
    return;

if ($errorException = $APPLICATION->getException()) {
    CAdminMessage::showMessage(
        Loc::getMessage('SOLVERWEB_UFHTML_INSTALL_ERROR') . ': ' . $errorException->GetString()
    );
} else {
    CAdminMessage::showNote(
        Loc::getMessage('SOLVERWEB_UFHTML_INSTALL_OK')
    );
}

?>
<form action="<?php echo $APPLICATION->GetCurPage(); ?>">
    <input type="hidden" name="lang" value="<?php echo LANG ?>">
    <input type="submit" name="" value="<?php echo Loc::getMessage('SOLVERWEB_UFHTML_INSTALL_BACK') ?>">
<form>