<?php
use Bitrix\Main\EventManager;
use Bitrix\Main\ModuleManager;
use Bitrix\Main\Localization\Loc;
Loc::loadMessages(__FILE__);

if(class_exists("solverweb_ufhtml")) return;

class solverweb_ufhtml extends CModule
{
	public $MODULE_ID = "solverweb.ufhtml";
    public $MODULE_VERSION;
    public $MODULE_VERSION_DATE;
    public $MODULE_NAME;
    public $MODULE_DESCRIPTION;
    public $eventManager;

    public $errors;

	function __construct()
	{
        $this->eventManager = EventManager::getInstance();

		$arModuleVersion = array();

		$path = str_replace("\\", "/", __FILE__);
		$path = substr($path, 0, strlen($path) - strlen("/index.php"));
		include($path."/version.php");

		if (is_array($arModuleVersion) && array_key_exists("VERSION", $arModuleVersion))
		{
			$this->MODULE_VERSION = $arModuleVersion["VERSION"];
			$this->MODULE_VERSION_DATE = $arModuleVersion["VERSION_DATE"];
		}

		$this->MODULE_NAME = Loc::getMessage('SOLVERWEB_UFHTML_MODULE_NAME');
		$this->MODULE_DESCRIPTION = Loc::getMessage('SOLVERWEB_UFHTML_MODULE_DESCRIPTION');
		$this->PARTNER_NAME = Loc::getMessage('SOLVERWEB_UFHTML_MODULE_PARTNER');
		$this->PARTNER_URI = "https://solverweb.ru";
	}


	function InstallDB()
	{
        ModuleManager::RegisterModule("solverweb.ufhtml");

		$this->eventManager->registerEventHandler(
            "main",
            "OnUserTypeBuildList",
            $this->MODULE_ID,
            "SolverWeb\Ufhtml\CCustomTypeHtml",
            "GetUserTypeDescription"
        );

        return true;
	}

	function UnInstallDB()
	{
        $this->eventManager->unRegisterEventHandler(
            "main",
            "OnUserTypeBuildList",
            $this->MODULE_ID,
            "SolverWeb\Ufhtml\CCustomTypeHtml",
            "GetUserTypeDescription"
        );
        ModuleManager::UnRegisterModule("solverweb.ufhtml");

		return true;
	}

	function DoInstall()
	{
		global $DOCUMENT_ROOT, $APPLICATION;
		$this->InstallDB();
		$APPLICATION->IncludeAdminFile(Loc::getMessage('SOLVERWEB_UFHTML_MODULE_INSTALL'), $DOCUMENT_ROOT."/bitrix/modules/solverweb.ufhtml/install/step.php");
	}

	function DoUninstall()
	{
		global $DOCUMENT_ROOT, $APPLICATION;
		$this->UnInstallDB();
		$APPLICATION->IncludeAdminFile(Loc::getMessage('SOLVERWEB_UFHTML_MODULE_UNINSTALL'), $DOCUMENT_ROOT."/bitrix/modules/solverweb.ufhtml/install/unstep.php");
	}
}