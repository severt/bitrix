<?php
CModule::AddAutoloadClasses(
	"solverweb.ufhtml",
	array(
		"SolverWeb\Ufhtml\CCustomTypeHtml" => "lib/customtypehtml.php",
	)
);