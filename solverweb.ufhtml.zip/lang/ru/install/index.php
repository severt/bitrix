<?php
$MESS ['SOLVERWEB_UFHTML_MODULE_PARTNER'] = "SolverWeb";
$MESS ['SOLVERWEB_UFHTML_MODULE_NAME'] = "Пользовательское свойство тип HTML/Визуальный редактор";
$MESS ['SOLVERWEB_UFHTML_MODULE_DESCRIPTION'] = "Добавляет новое свойство в список доступных свойcтв";
$MESS ['SOLVERWEB_UFHTML_MODULE_INSTALL'] = "Установка модуля solverweb.ufhtml";
$MESS ['SOLVERWEB_UFHTML_MODULE_UNINSTALL'] = "Удаление модуля solverweb.ufhtml";