<?php
$MESS ['SOLVERWEB_UFHTML_INSTALL_OK'] = "Модуль успешно установлен";
$MESS ['SOLVERWEB_UFHTML_INSTALL_ERROR'] = "При установке модуля произошла ошибка";
$MESS ['SOLVERWEB_UFHTML_INSTALL_BACK'] = "Вернуться к списку модулей";