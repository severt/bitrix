<?php
$MESS ['SOLVERWEB_UFHTML_UNINSTALL_OK'] = "Модуль успешно удален";
$MESS ['SOLVERWEB_UFHTML_UNINSTALL_ERROR'] = "При удалении модуля произошла ошибка";
$MESS ['SOLVERWEB_UFHTML_UNINSTALL_BACK'] = "Вернуться к списку модулей";