<?php
$MESS ['SW_PROP_NAME'] = "HTML/Визуальный редактор";